#!/usr/bin/env python3
"""Restore the newest backup and prove it actually works.

A backup nobody has restored is a hope, not a backup. This takes the newest
snapshot backup.py wrote, restores it to a scratch directory, and asks the
questions that matter on the day it is needed for real:

  - is the file a sound SQLite database, not a truncated copy?
  - does the CRM BOOT against it — migrations and all?
  - is the data actually there: clients, visits, invoices, scans?
  - is it FRESH: written recently, and holding roughly what the live database
    holds right now (a backup of an empty file is a perfect backup of nothing)?
  - does the uploads archive open, and does it carry the files the restored
    database references?

Usage:
    python3 restore_drill.py                 # newest backup in data/backups
    python3 restore_drill.py --file X.db     # a specific one
    python3 restore_drill.py --max-age 48    # allow a 48h-old backup

Exits non-zero if any of that fails, so a systemd timer turns a silent rot into
a failed unit you can see in `systemctl --failed`.
"""
import glob
import os
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import urllib.request

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backup import read_manifest, generations
from restore import restore_uploads

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("PESTCRM_DATA_DIR", os.path.join(BASE_DIR, "data"))
BACKUP_DIR = os.path.join(DATA_DIR, "backups")
LIVE_DB = os.path.join(DATA_DIR, "crm.db")
PORT = 8768                       # clear of the server (8000) and both suites
DEFAULT_MAX_AGE_H = 36            # nightly + a margin for a late run

# Tables whose emptiness would mean the snapshot is not of a working system.
MUST_HAVE_ROWS = ("users", "clients", "visits")
# Tables worth comparing against live, with how far behind the backup may sit.
COMPARED = ("users", "clients", "visits", "invoices", "device_inspections",
            "petty_cash", "chemical_usage", "reports")

passed = failed = 0


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name}" + (f" — {detail}" if detail else ""))


def counts(path):
    cx = sqlite3.connect(f"file:{path}?mode=ro", uri=True)
    try:
        names = {r[0] for r in cx.execute(
            "SELECT name FROM sqlite_master WHERE type='table'")}
        out = {}
        for t in COMPARED:
            out[t] = cx.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] if t in names else None
        return out, names
    finally:
        cx.close()


def main(argv):
    global failed
    chosen, max_age = None, DEFAULT_MAX_AGE_H
    i = 0
    while i < len(argv):
        if argv[i] == "--file" and i + 1 < len(argv):
            chosen = argv[i + 1]; i += 2
        elif argv[i] == "--max-age" and i + 1 < len(argv):
            max_age = float(argv[i + 1]); i += 2
        else:
            print(__doc__); return 2

    print("RESTORE DRILL")
    # The dated series only. "crm-*.db" also matches hand-kept milestones like
    # crm-PRE-ROLE-SPLIT-20260818.db, which sort AFTER every date and were being
    # drilled as though they were last night's backup.
    backups = sorted(glob.glob(os.path.join(BACKUP_DIR, "crm-2*.db")))
    check("there is a backup to restore", bool(backups) or bool(chosen),
          f"nothing in {BACKUP_DIR}")
    if not backups and not chosen:
        return 1
    newest = chosen or backups[-1]
    age_h = (time.time() - os.path.getmtime(newest)) / 3600.0
    print(f"  using {os.path.basename(newest)} ({os.path.getsize(newest) / 1024:.0f} KB, "
          f"{age_h:.1f}h old)")
    check(f"the newest backup is under {max_age:g}h old", age_h <= max_age,
          f"{age_h:.1f}h — has the nightly timer stopped?")

    scratch = tempfile.mkdtemp(prefix="pestcrm-restore-")
    restored = os.path.join(scratch, "crm.db")
    try:
        shutil.copy2(newest, restored)          # a restore is a copy back into place
        cx = sqlite3.connect(restored)
        try:
            integrity = cx.execute("PRAGMA integrity_check").fetchone()[0]
        finally:
            cx.close()
        check("the restored file is a sound database", integrity == "ok", integrity)

        got, names = counts(restored)
        for t in MUST_HAVE_ROWS:
            check(f"the restore carries {t}", bool(got.get(t)), f"{got.get(t)} rows")

        # A night's growth is not drift — a busy day legitimately doubles a
        # table. What would be wrong is a backup holding MORE than live, which
        # means the live database was rebuilt or emptied under it.
        if os.path.exists(LIVE_DB):
            live, _ = counts(LIVE_DB)
            ahead = [f"{t}: backup {got[t]} vs live {live[t]}"
                     for t in COMPARED
                     if got.get(t) is not None and live.get(t) is not None
                     and got[t] > live[t]]
            check("the live database has not shrunk beneath its backup", not ahead,
                  "; ".join(ahead[:3]))
            grew = {t: (live[t] - got[t]) for t in COMPARED
                    if got.get(t) is not None and live.get(t) is not None and live[t] > got[t]}
            if grew:
                print("  (added since the snapshot: "
                      + ", ".join(f"{t} +{n}" for t, n in sorted(grew.items())) + ")")

        # The real question: does the application come up on it?
        env = dict(os.environ, PESTCRM_DATA_DIR=scratch)
        proc = subprocess.Popen([sys.executable, "server.py", str(PORT)], cwd=BASE_DIR,
                                env=env, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE)
        booted = False
        try:
            for _ in range(60):
                if proc.poll() is not None:
                    break
                try:
                    with urllib.request.urlopen(f"http://127.0.0.1:{PORT}/", timeout=1) as r:
                        booted = r.status == 200
                    break
                except Exception:
                    time.sleep(0.25)
            check("the CRM boots on the restored database", booted,
                  (proc.stderr.read().decode()[-200:] if proc.poll() is not None else "no response"))
            if booted:
                # A login page is not proof of data; ask the API for something.
                try:
                    req = urllib.request.Request(
                        f"http://127.0.0.1:{PORT}/api/auth/login", method="POST",
                        data=b'{"email":"x@x","password":"x"}',
                        headers={"Content-Type": "application/json"})
                    urllib.request.urlopen(req, timeout=3)
                    reachable = True
                except Exception as e:
                    reachable = getattr(e, "code", None) in (400, 401, 403)
                check("its API answers on the restored data", reachable)
        finally:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()

        # Photos, signatures and site maps live outside the database, and are
        # now kept as a base plus increments — so the only honest drill is to
        # replay the whole chain the way a real restore would.
        if generations(BACKUP_DIR):
            man = restore_uploads(BACKUP_DIR, scratch)
            check("the uploads chain replays into a complete tree", man is not None,
                  "base + increments did not reconstruct the manifest")
            if man:
                wanted_files = read_manifest(man)
                root = os.path.join(scratch, "uploads")
                # Every signature the restored reports point at should be there.
                cx = sqlite3.connect(f"file:{restored}?mode=ro", uri=True)
                try:
                    wanted = [r[0] for r in cx.execute(
                        "SELECT filename FROM photos ORDER BY id DESC LIMIT 25")]
                finally:
                    cx.close()
                have = {os.path.basename(r) for r in wanted_files}
                missing = [w for w in wanted if w and w not in have]
                check("the files the restore references are in the chain", not missing,
                      f"{len(missing)} missing, e.g. {missing[:2]}")
                # A manifest that agrees with nothing on disk is not a restore.
                on_disk = sum(len(f) for _d, _s, f in os.walk(root))
                check("the replayed tree matches its manifest",
                      on_disk == len(wanted_files),
                      f"{on_disk} files on disk vs {len(wanted_files)} in the manifest")
        else:
            print("  (no uploads generation found — run backup.py --uploads)")
    finally:
        shutil.rmtree(scratch, ignore_errors=True)

    print("=" * 40)
    if failed:
        print(f"\033[31mFAIL\033[0m — {failed} problem(s), {passed} checks passed")
        return 1
    print(f"\033[32mPASS\033[0m — the newest backup restores and runs ({passed} checks)")
    return 0


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
