#!/usr/bin/env python3
"""Rebuild a CRM data set from the backups — database and uploads together.

Incremental backups are only worth having if getting back is still one command.
This is that command. It picks the database snapshot and the uploads chain for a
moment in time, replays base + increments in order, then removes anything the
manifest for that moment says was not there — so what lands is the tree as it
stood, not the tree plus everything ever deleted from it.

Usage:
    python3 restore.py --into /tmp/restored              # newest backup
    python3 restore.py --into /tmp/restored --at 20260901   # as of that day
    python3 restore.py --list                            # what can be restored
    python3 restore.py --into /tmp/restored --verify     # re-hash every file

It never touches the live data directory: --into must be an empty or new path.
To go live, stop the service, move the restored crm.db and uploads/ into place,
and start it again.
"""
import os
import sys
import glob
import shutil
import hashlib
import sqlite3
import tarfile

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from backup import (BASE_DIR, DEFAULT_DEST, GEN_RE,          # noqa: E402
                    read_manifest, generations, manifests)


def _stamp_of(path, prefix, suffix):
    b = os.path.basename(path)
    return b[len(prefix):len(b) - len(suffix)]


def _db_snapshots(dest):
    """The dated nightly series, oldest first.

    Deliberately not "crm-*.db": a hand-kept snapshot such as
    crm-PRE-ROLE-SPLIT-20260818.db sorts after every date (an uppercase letter
    outranks a digit) and would be picked as the "newest" backup — restoring the
    system to a milestone from months ago while reporting success.
    """
    return sorted(glob.glob(os.path.join(dest, "crm-2*.db")))


def _pick(paths, at, extract):
    """Newest path whose stamp is <= at (or the newest, when at is None)."""
    if not paths:
        return None
    if not at:
        return paths[-1]
    ok = [p for p in paths if extract(p) <= at + "~"]   # '~' > any digit/dash
    return ok[-1] if ok else None


def do_list(dest):
    print(f"Backups in {dest}\n")
    dbs = _db_snapshots(dest)
    print(f"  database snapshots ({len(dbs)}):")
    for p in dbs:
        print(f"    {os.path.basename(p):44}{os.path.getsize(p) / 1024:8.0f} KB")
    others = sorted(set(glob.glob(os.path.join(dest, "crm-*.db"))) - set(dbs))
    if others:
        print("\n  kept by hand (never auto-selected — name them with --at or copy):")
        for p in others:
            print(f"    {os.path.basename(p):44}{os.path.getsize(p) / 1024:8.0f} KB")
    gens = generations(dest)
    print(f"\n  uploads generations ({len(gens)}):")
    for g in gens:
        base = os.path.join(dest, f"uploads-g{g}-base.tar.gz")
        incs = sorted(glob.glob(os.path.join(dest, f"uploads-g{g}-inc-*.tar.gz")))
        mans = manifests(dest, g)
        size = sum(os.path.getsize(f) for f in
                   glob.glob(os.path.join(dest, f"uploads-g{g}-*")))
        print(f"    g{g}: base {os.path.getsize(base) / 1048576:.1f} MB"
              if os.path.exists(base) else f"    g{g}: BASE MISSING",
              end="")
        print(f" + {len(incs)} increment(s), {len(mans)} manifest(s)"
              f" — {size / 1048576:.1f} MB total")
        if mans:
            print(f"        restorable to: {_stamp_of(mans[0], f'uploads-g{g}-manifest-', '.tsv.gz')}"
                  f" .. {_stamp_of(mans[-1], f'uploads-g{g}-manifest-', '.tsv.gz')}")
    return 0


def restore_uploads(dest, into, at=None, verify=False):
    """Replay a generation into `into`, and return the manifest it restored to."""
    gens = generations(dest)
    if not gens:
        print("  no uploads generations found — nothing to restore")
        return None
    # The generation that can actually reach `at`: the newest whose first
    # manifest is not after it.
    gen = None
    for g in gens:
        first = manifests(dest, g)
        if first and (not at or _stamp_of(first[0], f"uploads-g{g}-manifest-",
                                          ".tsv.gz") <= at + "~"):
            gen = g
    if gen is None:
        # Asked for a moment older than anything still kept. Say so loudly: an
        # uploads tree newer than the database beside it is a quiet wrong answer.
        gen = gens[0]
        print(f"  WARNING: no uploads generation reaches back to {at}; using the "
              f"oldest kept (g{gen}), which is NEWER than the database restored.")
    base = os.path.join(dest, f"uploads-g{gen}-base.tar.gz")
    if not os.path.exists(base):
        print(f"  FAIL: generation g{gen} has no base archive", file=sys.stderr)
        return None

    incs = sorted(glob.glob(os.path.join(dest, f"uploads-g{gen}-inc-*.tar.gz")))
    if at:
        incs = [p for p in incs
                if _stamp_of(p, f"uploads-g{gen}-inc-", ".tar.gz") <= at + "~"]
    man = _pick(manifests(dest, gen), at,
                lambda p: _stamp_of(p, f"uploads-g{gen}-manifest-", ".tsv.gz"))

    os.makedirs(into, exist_ok=True)
    for archive in [base] + incs:                    # base first, then in order
        with tarfile.open(archive) as tf:
            tf.extractall(into)                      # later archives win
        print(f"  applied {os.path.basename(archive)}")

    root = os.path.join(into, "uploads")
    os.makedirs(root, exist_ok=True)
    wanted = read_manifest(man) if man else {}
    if wanted:
        # A restore is the tree as it WAS: drop what had been deleted by then.
        removed = 0
        for dirpath, _dirs, names in os.walk(root):
            for n in names:
                rel = os.path.relpath(os.path.join(dirpath, n), root)
                if rel not in wanted:
                    os.remove(os.path.join(dirpath, n))
                    removed += 1
        missing = [r for r in wanted if not os.path.exists(os.path.join(root, r))]
        print(f"  manifest {os.path.basename(man)}: {len(wanted)} files expected, "
              f"{removed} removed as deleted-by-then, {len(missing)} missing")
        if missing:
            print(f"  FAIL: {len(missing)} file(s) not in the chain, "
                  f"e.g. {missing[:3]}", file=sys.stderr)
            return None
        if verify:
            bad = []
            for rel, (size, sha) in wanted.items():
                p = os.path.join(root, rel)
                h = hashlib.sha256()
                with open(p, "rb") as fh:
                    for chunk in iter(lambda: fh.read(1 << 20), b""):
                        h.update(chunk)
                if h.hexdigest() != sha or os.path.getsize(p) != size:
                    bad.append(rel)
            print(f"  verified {len(wanted)} files by SHA-256: "
                  + (f"{len(bad)} CORRUPT, e.g. {bad[:3]}" if bad else "all match"))
            if bad:
                return None
    return man


def main(argv):
    dest, into, at, verify, listing = DEFAULT_DEST, None, None, False, False
    i = 0
    while i < len(argv):
        if argv[i] == "--into" and i + 1 < len(argv):
            into = argv[i + 1]; i += 2
        elif argv[i] == "--at" and i + 1 < len(argv):
            at = argv[i + 1]; i += 2
        elif argv[i] == "--dest" and i + 1 < len(argv):
            dest = argv[i + 1]; i += 2
        elif argv[i] == "--verify":
            verify = True; i += 1
        elif argv[i] == "--list":
            listing = True; i += 1
        else:
            print(__doc__); return 2

    if listing:
        return do_list(dest)
    if not into:
        print(__doc__); return 2
    if os.path.abspath(into) == os.path.abspath(
            os.environ.get("PESTCRM_DATA_DIR", os.path.join(BASE_DIR, "data"))):
        print("Refusing to restore over the live data directory.", file=sys.stderr)
        return 2

    print(f"RESTORE from {dest} into {into}" + (f" as of {at}" if at else " (newest)"))
    db = _pick(_db_snapshots(dest), at, lambda p: os.path.basename(p)[4:])
    if not db:
        print("  no database snapshot to restore", file=sys.stderr)
        return 1
    os.makedirs(into, exist_ok=True)
    shutil.copy2(db, os.path.join(into, "crm.db"))
    cx = sqlite3.connect(os.path.join(into, "crm.db"))
    try:
        integrity = cx.execute("PRAGMA integrity_check").fetchone()[0]
    finally:
        cx.close()
    print(f"  database {os.path.basename(db)} -> crm.db (integrity: {integrity})")
    if integrity != "ok":
        return 1

    man = restore_uploads(dest, into, at=at, verify=verify)
    print("\nRestored. To go live:")
    print(f"  systemctl stop pestcrm && cp {into}/crm.db <data>/crm.db && "
          f"rsync -a --delete {into}/uploads/ {BASE_DIR}/uploads/ && systemctl start pestcrm")
    return 0 if man is not None else 1


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
