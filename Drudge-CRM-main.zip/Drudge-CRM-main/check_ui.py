#!/usr/bin/env python3
"""Browser smoke test for the CRM's screens.

test_api.py proves the API is right; check_frontend.py proves the bundles agree
with each other. Neither can see a page that renders and yet does not WORK — a
Save button that raises no submit event, a table whose last column runs off the
end of its header, an untranslated key shown to a user. Those are the three
faults this catches, on every screen, for the office and for an engineer.

Run:  python3 check_ui.py            (add --headed to watch it)

Needs Playwright + Chromium:
    pip install playwright && python3 -m playwright install --with-deps chromium
Without them it prints SKIP and exits 0, so it never blocks a machine that
cannot run a browser.
"""
import datetime
import json
import os
import re
import subprocess
import sys
import tempfile
import time
import urllib.request

PORT = 8766                     # one above test_api.py, so both can run at once
HERE = os.path.dirname(os.path.abspath(__file__))
BASE = f"http://127.0.0.1:{PORT}"

passed = failed = 0
problems = []


def check(name, cond, detail=""):
    global passed, failed
    if cond:
        passed += 1
        print(f"  \033[32mPASS\033[0m {name}")
    else:
        failed += 1
        print(f"  \033[31mFAIL\033[0m {name}" + (f" — {detail}" if detail else ""))
        problems.append(name)


# An untranslated key reaches the page as bare snake_case. Real content can look
# like that too — a filename, an email, an id — so those shapes are excused.
KEY_RE = re.compile(r"\b[a-z][a-z0-9]*(?:_[a-z0-9]+)+\b")
NOT_A_KEY = re.compile(r"\.(png|jpe?g|pdf|csv|xlsx?|zip|webp)$|@|^https?_|^[0-9_]+$")


def raw_keys(text):
    return sorted({w for w in KEY_RE.findall(text or "") if not NOT_A_KEY.search(w)})


def main():
    argv = sys.argv[1:]
    headed = "--headed" in argv
    try:
        from playwright.sync_api import sync_playwright
    except ImportError:
        print("SKIP — playwright is not installed (pip install playwright)")
        return 0

    tmp = tempfile.mkdtemp(prefix="pestcrm-ui-")
    # Keep the suite's photos out of the real uploads folder too — the data
    # dir is a scratch one, and the files that go with it should be as well.
    env = dict(os.environ, PESTCRM_DATA_DIR=tmp,
               PESTCRM_UPLOAD_DIR=os.path.join(tmp, "uploads"))
    proc = subprocess.Popen([sys.executable, "server.py", str(PORT)], cwd=HERE, env=env,
                            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    try:
        for _ in range(60):
            try:
                urllib.request.urlopen(BASE + "/", timeout=1)
                break
            except Exception:
                time.sleep(0.25)
        else:
            print("the server did not come up")
            return 1
        _seed()
        with sync_playwright() as p:
            browser = p.chromium.launch(headless=not headed)
            try:
                sweep(browser, "admin@pestcrm.com", "admin123", "office",
                      {"width": 1440, "height": 1000}, False)
                sweep(browser, "agent1@pestcrm.com", "agent123", "engineer",
                      {"width": 390, "height": 844}, True)
                # A supervisor works from a phone like an engineer but carries
                # the oversight screens, so they are swept at phone size too.
                sweep(browser, "leader@pestcrm.com", "leader123", "leader",
                      {"width": 390, "height": 844}, True)
                leader_checks(browser)
                team_leader_checks(browser)
                roster_checks(browser)
                auto_roster_checks(browser)
                branch_days_checks(browser)
                switch_off_checks(browser)
                branch_board_checks(browser)
                workflow_checks(browser)
                stay_in_place_checks(browser)
                permission_change_checks(browser)
                scan_back_checks(browser)
                fast_save_checks(browser)
                calendar_filter_checks(browser)
                offline_sweep(browser)
            finally:
                browser.close()
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()

    print("\n" + "=" * 40)
    if failed:
        print(f"\033[31mFAIL\033[0m — {failed} problem(s), {passed} checks passed")
        for p_ in problems:
            print("  - " + p_)
        return 1
    print(f"\033[32mPASS\033[0m — {passed} checks across every screen")
    return 0


def _api(method, path, token=None, body=None):
    req = urllib.request.Request(BASE + "/api" + path, method=method,
                                 data=json.dumps(body).encode() if body else None)
    req.add_header("Content-Type", "application/json")
    if token:
        req.add_header("Authorization", "Bearer " + token)
    with urllib.request.urlopen(req) as r:
        return json.loads(r.read() or b"{}")


def _today_str():
    return datetime.date.today().isoformat()


def _seed():
    """Enough data that the pages under test are not all empty states — an
    empty table hides exactly the faults this looks for."""
    adm = _api("POST", "/auth/login", body={"email": "admin@pestcrm.com",
                                            "password": "admin123"})["token"]
    eng = _api("POST", "/auth/login", body={"email": "agent1@pestcrm.com",
                                            "password": "agent123"})["token"]
    who = next(u for u in _api("GET", "/users", adm) if u["email"] == "agent1@pestcrm.com")
    visit = next(v for v in _api("GET", "/visits", adm) if v.get("client_id") == 1)
    _api("PUT", f"/visits/{visit['id']}", adm, {"status": "in_progress"})
    for ty in ("light_trap", "glue_station", "bait_station", "fly_trap"):
        _api("POST", "/devices/generate", adm, {"type": ty, "count": 1})
    devices = _api("GET", "/devices", adm)
    _api("POST", "/devices/assign", adm, {"ids": [d["id"] for d in devices], "client_id": 1})
    for d in devices:
        _api("POST", "/scan/" + d["code"], adm, {"status": "activity", "details": {
            "trap_condition": "damaged", "trap_action": "next_visit_replaced",
            "station_condition": "damaged", "station_action": "replaced",
            "pests_found": "house_flies,moths", "fly_count": 12, "insect_count": 4}})
    _api("POST", f"/visits/{visit['id']}/usage", adm,
         {"chemical_id": 1, "quantity": 2, "method": "spraying", "equipment": "sprayer"})
    _api("POST", f"/visits/{visit['id']}/transport", adm, {"vehicle": "van", "cost": 50})
    _api("POST", "/cash", adm, {"kind": "advance", "amount": 500, "agent_id": who["id"]})
    claim = _api("POST", "/cash", eng, {"kind": "expense", "amount": 60,
                                        "category": "repair", "note": "seal"})
    _api("POST", f"/cash/{claim['id']}/approve", adm)
    _api("POST", "/issues", adm, {"agent_id": who["id"],
                                  "items": [{"chemical_id": 1, "quantity": 10}]})


# Every screen the sidebar offers, by the view name navigate() takes.
OFFICE_VIEWS = ["backup", "dashboard", "clients", "leads", "visits", "dispatch", "requests", "branchsched",
                "pipeline",
                "calendar", "shifts", "contracts", "chemicals", "issues", "cash",
                "devices", "ipm", "invoices", "finance", "transport", "reports",
                "analytics", "marketing", "agents", "availability", "fixedposts", "areas", "settings"]
AGENT_VIEWS = ["dashboard", "visits", "calendar", "shifts", "issues", "cash",
               "certificates", "ipm", "transport", "marketing"]
# A supervisor gets the engineer's screens PLUS the oversight ones. myteam and
# myday are theirs alone, so they are swept here and nowhere else.
LEADER_VIEWS = ["dashboard", "myday", "myteam", "clients", "locations", "schedule",
                "dispatch", "reports", "calendar", "shifts", "issues", "cash",
                "devices", "certificates", "ipm", "transport", "analytics"]


def sweep(browser, email, password, who, viewport, mobile):
    print(f"\n{who.upper()} — {viewport['width']}x{viewport['height']}")
    page = browser.new_page(viewport=viewport, is_mobile=mobile, has_touch=mobile)
    errors, dialogs, requests, navigations = [], [], [], []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
    page.on("request", lambda r: requests.append(r.method + " " + r.url)
            if r.method in ("POST", "PUT", "DELETE") else None)
    # A form with no handler at all still "does something" — the browser
    # submits it and reloads the app. That is the bug, not the fix, so a
    # navigation is watched for and counted against the button.
    page.on("framenavigated", lambda f: navigations.append(f.url)
            if f == page.main_frame else None)

    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", email)
    page.fill("#login-password", password)
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")
    # Whatever language the account prefers, the checks below are language-blind.
    check(f"{who}: signs in", page.evaluate("() => !!document.getElementById('view')"))

    views = {"office": OFFICE_VIEWS, "leader": LEADER_VIEWS}.get(who, AGENT_VIEWS)
    for view in views:
        errors.clear()
        page.evaluate("v => navigate(v)", view)
        page.wait_for_timeout(1400)
        body = page.evaluate("() => document.getElementById('view').innerText")
        check(f"{who}/{view}: renders without a script error", not errors,
              "; ".join(errors[:2]))
        leaks = raw_keys(body)
        check(f"{who}/{view}: every label is translated", not leaks, ", ".join(leaks[:5]))
        # A spanned cell is as wide as it says it is — on both sides, or a
        # perfectly good "Next movements" header spanning three columns reads
        # as a fault.
        bad = page.evaluate("""() => {
          const width = (row) => [...row.children].reduce((n, c) => n + (c.colSpan || 1), 0);
          const out = [];
          document.querySelectorAll('#view table').forEach((t, i) => {
            const headRow = t.querySelector('thead tr:last-child');
            if (!headRow || !headRow.children.length) return;
            const head = width(headRow);
            t.querySelectorAll('tbody tr').forEach(r => {
              const cells = width(r);
              if (cells !== head && !r.querySelector('.empty')) out.push(i + ':' + head + 'vs' + cells);
            });
          });
          return [...new Set(out)];
        }""")
        check(f"{who}/{view}: every table's rows fit its header", not bad, ", ".join(bad[:4]))

    # THE FAULT AN API TEST CANNOT SEE: a picker that renders perfectly and is
    # EMPTY. Fixed Assignments listed its branches from the customer list,
    # which does not carry them, so the only choice the office was ever offered
    # was "none" (2026-08-27, his report: "why i cant choose the branch").
    if who == "office":
        page.evaluate("() => navigate('fixedposts')")
        page.wait_for_timeout(1400)
        if page.query_selector("#fp-new"):
            page.click("#fp-new")
            page.wait_for_timeout(900)
            counts = page.evaluate("""() => {
                const g = (n) => { const s = document.querySelector(`#modal-body select[name="${n}"]`);
                  return s ? s.options.length : -1; };
                return { site: g('site_id'), primary: g('primary_agent_id') }; }""")
            check("office/fixedposts: the branch picker offers real branches",
                  counts["site"] > 1, f"options={counts['site']}")
            check("office/fixedposts: and the engineer picker offers engineers",
                  counts["primary"] > 1, f"options={counts['primary']}")
            page.evaluate("closeModal && closeModal()")
            page.wait_for_timeout(300)

    # HIS MENU, CUT DOWN TO WHAT HE USES — and nothing lost by it. The whole
    # value of doing this as a PREFERENCE rather than a permission is that a
    # hidden section is still one click away and still his to open.
    if who == "office":
        page.evaluate("() => navigate('dashboard')")
        page.wait_for_timeout(900)
        before = page.evaluate("() => document.querySelectorAll('#nav .nav-item[data-view]').length")
        check("office/menu: the sidebar has sections to thin out", before > 10)
        check("office/menu: and offers to customise itself",
              bool(page.query_selector("#nav-customise")))
        ok = page.evaluate("""async () => {
            await API.put('/me/prefs', { nav_hidden: ['areas', 'ipm', 'backup'] });
            await loadNavPrefs(); renderNav(); return NAV_HIDDEN.length; }""")
        page.wait_for_timeout(500)
        check("office/menu: three sections move out of the way", ok == 3)
        front = page.evaluate("""() => [...document.querySelectorAll(
            '#nav > .nav-item[data-view]')].map(a => a.dataset.view)""")
        tucked = page.evaluate("""() => [...document.querySelectorAll(
            '#nav .nav-more .nav-item[data-view]')].map(a => a.dataset.view)""")
        check("office/menu: they leave the front of the menu",
              not any(k in front for k in ("areas", "ipm", "backup")), ",".join(front[:6]))
        check("office/menu: and are all still there under More",
              all(k in tucked for k in ("areas", "ipm", "backup")), ",".join(tucked))
        # THE POINT: hidden is not revoked.
        still = page.evaluate("""async () => {
            try { await API.get('/areas'); return 'reachable'; }
            catch (e) { return 'BLOCKED: ' + (e.message || ''); } }""")
        check("office/menu: a hidden section still answers", still == "reachable", still)
        page.evaluate("""async () => { await API.put('/me/prefs', { nav_hidden: [] });
            await loadNavPrefs(); renderNav(); }""")
        page.wait_for_timeout(400)
        after = page.evaluate("() => document.querySelectorAll('#nav .nav-item[data-view]').length")
        check("office/menu: and putting them back restores the menu", after == before)

    # THE MONTH ON THE DISPATCH BOARD — the complaint that started this work
    # was that it was too small to read. So the checks are about SIZE and
    # SCROLL: the hours must be on screen, the matrix must own its scrolling
    # (a second scroll box inside it left the month unable to move sideways),
    # and both layouts must draw.
    if who == "office":
        page.evaluate("() => navigate('dispatch', { date: '2026-08-15', scope: 'month' })")
        page.wait_for_timeout(1800)
        if page.query_selector("td.dg-cell"):
            check("office/dispatch: the month draws as a matrix",
                  page.evaluate("() => document.querySelectorAll('td.dg-cell').length") > 20)
            check("office/dispatch: it offers both layouts",
                  page.evaluate("""() => document.querySelectorAll('[data-dglay]').length""") == 2)
            box = page.evaluate("""() => { const w = document.querySelector('.dg-wrap');
                const inner = w.querySelector('.table-scroll');
                return { wrap: w.scrollWidth >= w.clientWidth,
                         scrolls: w.scrollWidth > w.clientWidth,
                         inner: inner ? getComputedStyle(inner).overflowX : 'none',
                         tall: w.clientHeight > 0 && w.scrollHeight >= w.clientHeight }; }""")
            check("office/dispatch: the matrix, not a box inside it, does the scrolling",
                  box["inner"] in ("visible", "none"), str(box))
            hours = page.evaluate("""() => { const t = document.querySelector('td.dg-cell .dg-t');
                if (!t) return 'no cell with hours';
                const cs = getComputedStyle(t);
                return (cs.display !== 'none' && parseFloat(cs.fontSize) >= 9.5)
                  ? 'ok' : cs.display + '/' + cs.fontSize; }""")
            check("office/dispatch: and the hours are printed big enough to read",
                  hours == "ok", hours)
            page.evaluate("""() => document.querySelector('[data-dglay=\"day\"]').click()""")
            page.wait_for_timeout(1500)
            check("office/dispatch: days-down puts the names above",
                  bool(page.query_selector("table.dg-by-day thead th.dg-eng-h")))
            page.evaluate("""() => document.querySelector('[data-dglay=\"eng\"]').click()""")
            page.wait_for_timeout(1200)
        # WHERE, NOT JUST HOW MANY. The board's own Print/PDF must also offer
        # the sheet that names the branch of every call — his second ask:
        # "in live i can stop on it but in pdf i have to see the locations too".
        check("office/dispatch: the board offers a sheet to print",
              bool(page.query_selector("#dp-print")))
        if page.query_selector("#dp-print"):
            page.click("#dp-print")
            page.wait_for_timeout(700)
            opts = page.evaluate("""() => document.querySelector('#dp-pf')
                ? [...document.querySelectorAll('#dp-pf select[name=what] option')].map(o => o.value)
                : []""")
            check("office/dispatch: and asks which — the visits, or the month's counts",
                  opts == ["list", "grid"], ",".join(opts))
            page.evaluate("closeModal && closeModal()")
            page.wait_for_timeout(300)
        # The visits sheet itself: a pure function, so what it prints is read
        # here. The BRANCH is the column he asked for.
        vdoc = page.evaluate("""() => scheduleDocHtml({
            from: '2026-09-01', to: '2026-09-02',
            agents: [{ id: 1, full_name: 'Test Engineer' }],
            visits: [{ agent_id: 1, scheduled_start: '2026-09-02T09:00:00',
                       scheduled_end: '2026-09-02T10:00:00', site_name: 'Branch One',
                       client_en: 'Customer One', area_en: 'Patch A' }],
            posts: [], compact: true, heading: 'Dispatch schedule', note: 'Maadi' })""")
        check("office/dispatch: the visits sheet names the branch of every call",
              bool(vdoc) and "Branch One" in vdoc and "Customer One" in vdoc)
        check("office/dispatch: it says which board it came from, and what was filtered",
              bool(vdoc) and "Dispatch schedule" in vdoc and "Maadi" in vdoc)
        check("office/dispatch: and one day's crew runs on rather than a page each",
              bool(vdoc) and "break-before: page" not in vdoc)
        check("office/dispatch: while a page each is still what the Calendar prints",
              "break-before: page" in page.evaluate("""() => scheduleDocHtml({
                  from: '2026-09-01', to: '2026-09-02', agents: [], visits: [], posts: [] })"""))

        # AND THE SAME SHEET AS A FILE. Print is not the only way out of the
        # board: the dialog also hands over a workbook or a CSV.
        acts = page.evaluate("""() => [...document.querySelectorAll('#dp-pf [data-act]')]
            .map(b => b.dataset.act)""") if page.query_selector("#dp-pf") else []
        if not acts:
            page.click("#dp-print")
            page.wait_for_timeout(600)
            acts = page.evaluate("""() => [...document.querySelectorAll('#dp-pf [data-act]')]
                .map(b => b.dataset.act)""")
        check("office/dispatch: print, Excel and CSV are all offered",
              acts == ["print", "xlsx", "csv"], ",".join(acts))
        page.evaluate("closeModal && closeModal()")
        page.wait_for_timeout(300)
        table = page.evaluate("""() => dpVisitRows({
            agents: [{ id: 1, full_name: 'Test Engineer' }],
            visits: [{ agent_id: 1, scheduled_start: '2026-09-02T09:00:00',
                       scheduled_end: '2026-09-02T10:00:00', site_name: 'Branch One',
                       client_en: 'Customer One', area_en: 'Patch A', status: 'scheduled' }],
            posts: [] }, '2026-09-01', '2026-09-03')""")
        check("office/dispatch: the download carries one row per call, branch included",
              len(table["rows"]) == 1 and "Branch One" in table["rows"][0]
              and "Customer One" in table["rows"][0], str(table)[:160])
        # THE ORDERING TRAP: day columns named "1".."31" are numeric keys, and an
        # object would have sorted them in front of the engineer's name.
        grid = page.evaluate("""() => dpGridRows({
            days: ['2026-09-01', '2026-09-02'],
            engineers: [{ id: 1, full_name: 'Test Engineer' }],
            cells: [{ agent_id: 1, date: '2026-09-02', count: 4, first: '08:00', last: '16:00' }] })""")
        check("office/dispatch: and the counts sheet starts with the engineer, not day 1",
              grid["heads"][0] != "1" and grid["heads"][1] == "1"
              and grid["rows"][0][0] == "Test Engineer" and grid["rows"][0][2] == 4,
              str(grid)[:160])

        # THE WHOLE MONTH ON ONE SHEET — a pure function again, so the paper
        # layout is read here rather than guessed at.
        doc = page.evaluate("""() => {
            if (typeof monthDocHtml !== 'function') return null;
            return monthDocHtml({ from: '2026-09-01', to: '2026-09-30',
              days: Array.from({ length: 30 }, (_, i) =>
                '2026-09-' + String(i + 1).padStart(2, '0')),
              engineers: [{ id: 1, full_name: 'Test Engineer' },
                          { id: 2, full_name: 'Second Engineer' }],
              cells: [{ agent_id: 1, date: '2026-09-02', count: 4,
                        first: '08:00', last: '16:00' }] }); }""")
        check("office/dispatch: the month sheet is a whole document",
              bool(doc) and doc.lstrip().lower().startswith("<!doctype html"))
        check("office/dispatch: laid out sideways on paper, so a month fits across",
              bool(doc) and "A4 landscape" in doc)
        for want in ("Test Engineer", "Second Engineer", "08–16", "&gt;30&lt;" if False else ">30<"):
            check(f"office/dispatch: the sheet carries {want}", bool(doc) and want in doc)
        check("office/dispatch: and totals what each man and each day is carrying",
              bool(doc) and doc.count("<tfoot>") == 1)

    # TYPE 1, GET 01:00 — IN EVERY ROW. The hour boxes tidy what is typed;
    # a stretch added with "+ add another time" used to miss out on that, so
    # the office had to type "01:00" in full on the second window of a day.
    if who == "office":
        page.evaluate("() => navigate('availability')")
        page.wait_for_timeout(1800)
        if page.query_selector(".av-wd"):
            page.evaluate("""() => { const cb = document.querySelector('.av-wd');
                if (!cb.checked) { cb.checked = true;
                  cb.dispatchEvent(new Event('change', { bubbles: true })); } }""")
            page.wait_for_timeout(400)
            typed = page.evaluate("""async () => {
                const cell = document.querySelector('.av-day.av-on') || document.querySelector('.av-day');
                const type = (input, text) => { input.value = text;
                    input.dispatchEvent(new Event('change', { bubbles: true })); return input.value; };
                const first = type(cell.querySelector('.av-win .av-from'), '1');
                cell.querySelector('.av-add').click();
                await new Promise(r => setTimeout(r, 200));
                const rows = cell.querySelectorAll('.av-win');
                const added = rows.length > 1
                    ? type(rows[rows.length - 1].querySelector('.av-from'), '1') : 'no row added';
                return { first, added }; }""")
            check("office/availability: the first hour box turns 1 into 01:00",
                  typed["first"] == "01:00", str(typed))
            check("office/availability: and so does one added afterwards",
                  typed["added"] == "01:00", str(typed))

    # THE SCHEDULE SHEET THE OFFICE PRINTS. Built as a pure function, so it can
    # be asked for a document and read, without a printer anywhere near it.
    if who == "office":
        page.evaluate("() => navigate('calendar')")
        page.wait_for_timeout(1500)
        check("office/calendar: offers a printable schedule",
              bool(page.query_selector("#cal-print")))
        doc = page.evaluate("""() => {
            if (typeof scheduleDocHtml !== 'function') return null;
            return scheduleDocHtml({
              from: '2026-09-01', to: '2026-09-07',
              agents: [{ id: 1, full_name: 'Test Engineer' }],
              visits: [{ agent_id: 1, scheduled_start: '2026-09-02T09:00:00',
                         scheduled_end: '2026-09-02T10:00:00', site_name: 'Branch One',
                         client_en: 'Customer One', area_en: 'Patch A' }],
              posts: [{ active: 1, primary_agent_id: 1, primary_weekdays: [2],
                        relief_weekdays: [], from_time: '08:00', to_time: '16:00',
                        site_name: 'The Factory', client_en: 'Factory Co' }],
            }); }""")
        check("office/calendar: the schedule sheet is a whole document",
              bool(doc) and doc.lstrip().lower().startswith("<!doctype html"))
        for want in ("Test Engineer", "Branch One", "Customer One", "09:00", "The Factory"):
            check(f"office/calendar: the sheet shows {want}", bool(doc) and want in doc)
        check("office/calendar: it prints itself when opened",
              bool(doc) and "window.print()" in doc)
        check("office/calendar: and is laid out for paper",
              bool(doc) and "@page" in doc and "A4" in doc)

    # The fault no static check can see: a button that looks like a save and
    # does nothing at all — no request, no complaint, no closed modal.
    for view, opener in (("clients", "#add-client"), ("chemicals", "#add-chem"),
                         ("issues", "#add-issue"), ("cash", "#cash-spend"),
                         ("leads", "#add-lead"), ("visits", "#add-visit")):
        if who != "office" and view in ("clients", "chemicals", "leads"):
            continue
        page.evaluate("v => navigate(v)", view)
        page.wait_for_timeout(1200)
        if not page.query_selector(opener):
            continue
        page.click(opener)
        page.wait_for_timeout(900)
        form = page.query_selector("#modal-body form")
        if not form:
            page.evaluate("closeModal && closeModal()")
            continue
        save = page.query_selector("#modal-body button[type=submit]")
        check(f"{who}/{view}: the modal offers a save", bool(save))
        if not save:
            continue
        dialogs.clear()
        requests.clear()
        navigations.clear()
        before = page.evaluate("() => !!document.querySelector('#modal-body form')")
        save.click()
        page.wait_for_timeout(1500)
        after = page.evaluate("() => !!document.querySelector('#modal-body form')")
        acted = bool(dialogs) or bool(requests) or (before and not after)
        check(f"{who}/{view}: pressing save actually does something",
              acted and not navigations,
              "reloaded the page" if navigations else "no request, no message, no close")
        page.evaluate("closeModal && closeModal()")
        page.wait_for_timeout(300)
    page.close()


def offline_sweep(browser):
    """The engineer in the basement.

    Half this CRM is used where there is no signal — a plant room, a warehouse
    aisle, a lift shaft on the way out. What matters is not that the app looks
    fine offline but that work TYPED offline is not lost: it must queue, say so,
    and replay when the signal comes back. Anything that silently fails here is
    a job an engineer did twice.
    """
    print("\nENGINEER — OFFLINE")
    ctx = browser.new_context(viewport={"width": 390, "height": 844},
                              is_mobile=True, has_touch=True)
    page = ctx.new_page()
    errors, dialogs = [], []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("dialog", lambda d: (dialogs.append(d.message), d.dismiss()))
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "agent1@pestcrm.com")
    page.fill("#login-password", "agent123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")
    page.evaluate("setLang && setLang('en')")
    page.wait_for_timeout(1500)
    # Warm the pages the engineer will need, then pull the plug.
    for view in ("cash", "issues", "visits"):
        page.evaluate("v => navigate(v)", view)
        page.wait_for_timeout(1200)
    before = len(_api("GET", "/cash", _token("agent1@pestcrm.com", "agent123")))
    ctx.set_offline(True)
    page.wait_for_timeout(500)

    errors.clear()
    page.evaluate("navigate('cash')")
    page.wait_for_timeout(1500)
    check("offline: the pocket-money page still opens",
          page.evaluate("() => !!document.getElementById('cash-spend')"), "; ".join(errors[:2]))
    page.click("#cash-spend")
    page.wait_for_timeout(900)
    filed = False
    if page.query_selector("#cf [name=amount]"):
        page.fill("#cf [name=amount]", "25")
        sel = page.query_selector("#cf [name=category]")
        if sel:
            page.select_option("#cf [name=category]", "transport")
        page.fill("#cf [name=note]", "typed with no signal")
        dialogs.clear()
        page.click("#cf-save")
        page.wait_for_timeout(1500)
        filed = not page.query_selector("#modal-body form")
    check("offline: a claim can still be filed", filed,
          "the form stayed open: " + "; ".join(dialogs[:1]))
    queued = page.evaluate("""async () => {
      if (!window.OfflineQueue || !OfflineQueue.count) return null;
      const n = await OfflineQueue.count();
      return typeof n === 'number' ? n : (n && n.length) || 0;
    }""")
    check("offline: the claim is held in the queue, not dropped",
          queued is None or queued > 0, f"queue reported {queued}")

    # The other flow written this week: handing material back.
    errors.clear()
    page.evaluate("navigate('issues')")
    page.wait_for_timeout(1500)
    check("offline: the materials page still opens",
          page.evaluate("() => !!document.getElementById('view').innerText"),
          "; ".join(errors[:2]))
    handed = None
    if page.query_selector("#ret-materials"):
        page.click("#ret-materials")
        page.wait_for_timeout(900)
        if page.query_selector(".ret-q"):
            page.fill(".ret-q", "1")
            dialogs.clear()
            page.click("#rtf-save")
            page.wait_for_timeout(1500)
            handed = not page.query_selector("#modal-body form")
        else:
            page.evaluate("closeModal && closeModal()")
    if handed is not None:
        check("offline: a material return can still be filed", handed,
              "the form stayed open: " + "; ".join(dialogs[:1]))

    ctx.set_offline(False)
    page.wait_for_timeout(600)
    # A reconnect replays the queue; give it a beat, then ask the server.
    page.evaluate("() => window.OfflineQueue && OfflineQueue.flush && OfflineQueue.flush()")
    page.wait_for_timeout(3000)
    after = len(_api("GET", "/cash", _token("agent1@pestcrm.com", "agent123")))
    check("offline: the work reaches the server once the signal is back",
          after > before, f"{before} claims before, {after} after")
    page.close()
    ctx.close()


def branch_days_checks(browser):
    """When a branch opens its doors — typed on the branch, read on the list.

    The office asked to know "every branch available time and which days" in
    one place, so this proves both halves: the form takes the days (with hours
    only for the day that differs), and the Locations list reads them back
    without opening a hundred forms."""
    print("\nBRANCH VISITING DAYS")
    adm = _token("admin@pestcrm.com", "admin123")
    sites = _api("GET", "/sites", adm)
    target = sites[0]
    # One branch left off a cycle, so the "no visit cycle" gap has something to
    # find — that gap is what stands between the office and the ⚡ button.
    _api("PUT", f"/sites/{sites[-1]['id']}", adm, {"visits_per_month": 0})

    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("dialog", lambda d: d.accept())
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    page.evaluate("() => navigate('locations')")
    page.wait_for_selector("#loc-body tr", timeout=8000)
    page.wait_for_timeout(600)
    check("branch days: the locations list renders", not errors, "; ".join(errors[:2]))
    # innerText is the RENDERED text and `th` is styled uppercase, so this
    # compares case-insensitively rather than against the raw label.
    check("branch days: it has a visiting-schedule column",
          page.evaluate("""() => [...document.querySelectorAll('th')]
              .some(th => th.innerText.trim().toLowerCase()
                          === t('visiting_schedule').toLowerCase())"""))
    check("branch days: a branch with no cycle is called out",
          page.evaluate("() => !!document.querySelector('[data-gapfilter=sched]')"))
    check("branch days: filtering to that gap hides the rest",
          page.evaluate("""() => {
              document.querySelector('[data-gapfilter=sched]').click();
              const rows=[...document.querySelectorAll('#loc-body tr')];
              const shown=rows.filter(r => r.style.display !== 'none');
              return shown.length > 0 && shown.every(r => r.dataset.gap === 'sched'); }"""))
    page.evaluate("() => document.querySelector('[data-gapfilter=\"\"]').click()")

    # --- type the days on the branch itself ---
    page.evaluate(f"() => document.querySelector('[data-siteedit=\"{target['id']}\"]').click()")
    page.wait_for_selector(".sd-grid", timeout=8000)
    check("branch days: the branch form asks which days it opens",
          page.evaluate("() => document.querySelectorAll('.sd-wd').length") == 7)
    check("branch days: a day's hours stay hidden until it is ticked",
          page.evaluate("""() => [...document.querySelectorAll('.sd-day:not(.sd-on) .sd-hours')]
              .every(e => e.style.display === 'none')"""))
    check("branch days: the per-day boxes offer the usual window as their default",
          page.evaluate("""() => { const f=document.querySelector('[name=service_from]');
              f.value='09:00'; f.dispatchEvent(new Event('input'));
              return document.querySelector('.sd-from').placeholder === '09:00'; }"""))
    # Monday on the usual window, Wednesday afternoons only — the exact shape
    # the office asked for.
    errors.clear()
    page.evaluate("""() => {
        const tick = (wd) => { const cb=document.querySelector(`.sd-wd[data-wd="${wd}"]`);
          cb.checked = true; cb.dispatchEvent(new Event('change')); };
        tick(0); tick(2);
        document.querySelector('[name=service_to]').value = '17:00';
        // Visits a MONTH, and only that: the office asked for the per-week
        // option to be taken off every screen.
        document.querySelector('[name=freq_n]').value = '2';
        document.querySelector('.sd-from[data-wd="2"]').value = '14:00';
        document.querySelector('.sd-to[data-wd="2"]').value = '16:00'; }""")
    page.wait_for_timeout(300)
    check("branch days: ticking a day reveals its hours",
          page.evaluate("""() => document.querySelector('.sd-day[data-wd="0"] .sd-hours')
              .style.display !== 'none'"""))
    page.evaluate("() => document.querySelector('#sf button[type=submit]').click()")
    page.wait_for_timeout(2400)
    check("branch days: saving raises nothing", not errors, "; ".join(errors[:2]))

    saved = next(s for s in _api("GET", "/sites", adm) if s["id"] == target["id"])
    got = {d["weekday"]: d for d in saved.get("service_days", [])}
    check("branch days: the server stored the days that were ticked", set(got) == {0, 2})
    check("branch days: the day left on the usual window carries no hours",
          0 in got and not got[0]["start_time"])
    check("branch days: the day that differs carries its own",
          2 in got and got[2]["start_time"] == "14:00" and got[2]["end_time"] == "16:00")

    # --- and read back, both in the list and in the form ---
    page.wait_for_selector("#loc-body tr", timeout=8000)
    page.wait_for_timeout(500)
    check("branch days: the list names the days without opening the form",
          page.evaluate(f"""() => {{ const tr=[...document.querySelectorAll('#loc-body tr')]
              .find(r => r.innerText.includes({target['name']!r}));
              return !!tr && tr.querySelectorAll('.sd-chip').length === 2; }}"""))
    check("branch days: the day with its own hours is marked apart",
          page.evaluate("() => document.querySelectorAll('.sd-chip.sd-chip-own').length") >= 1)
    page.evaluate(f"() => document.querySelector('[data-siteedit=\"{target['id']}\"]').click()")
    page.wait_for_selector(".sd-grid", timeout=8000)
    check("branch days: reopening the form shows what was saved",
          page.evaluate("""() => document.querySelectorAll('.sd-wd:checked').length === 2
              && document.querySelector('.sd-from[data-wd="2"]').value === '14:00'"""))
    page.evaluate("closeModal && closeModal()")
    page.wait_for_timeout(400)

    # A branch already in the book must be reachable from the company's own
    # folder too — that page could only ADD and DELETE one, so everything the
    # scheduler reads was unreachable on the branches the office already had.
    page.evaluate(f"() => navigate('client', {{ id: {target['client_id']} }})")
    page.wait_for_selector("#sites-body tr", timeout=8000)
    page.wait_for_timeout(600)
    check("branch days: the client folder offers an edit on each branch",
          page.evaluate("() => document.querySelectorAll('#sites-body [data-editsite]').length") >= 1)
    check("branch days: the folder shows each branch's schedule too",
          page.evaluate("() => !!document.querySelector('#sites-body .sd-chip, #sites-body .sd-chips')"))
    errors.clear()
    page.evaluate(f"() => document.querySelector('#sites-body [data-editsite=\"{target['id']}\"]').click()")
    page.wait_for_selector(".sd-grid", timeout=8000)
    check("branch days: it opens the branch with its days already filled in",
          page.evaluate("""() => document.querySelectorAll('.sd-wd:checked').length === 2"""), )
    check("branch days: opening it from the folder raises nothing", not errors,
          "; ".join(errors[:2]))
    page.evaluate("closeModal && closeModal()")
    page.evaluate("() => navigate('locations')")
    page.wait_for_selector("#loc-body tr", timeout=8000)
    page.wait_for_timeout(500)
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("branch days: every label on the page is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))
    page.close()


def switch_off_checks(browser):
    """Switching a customer or a branch off, and putting it back.

    A customer who stops and a branch that shuts must leave the roster without
    leaving the CRM. That is two screens — the customer's own folder and the
    Branches list — and one dialog, which has to say how many visits are still
    booked before anybody presses anything."""
    print("\nSWITCHED OFF (customers + branches)")
    adm = _token("admin@pestcrm.com", "admin123")
    cl = _api("POST", "/clients", adm, {"name_en": "Shut Down Cafe"})
    br = _api("POST", f"/clients/{cl['id']}/sites", adm,
              {"name": "Shut Down Branch", "visits_per_month": 4})
    tomorrow = (datetime.date.today() + datetime.timedelta(days=2)).isoformat()
    _api("POST", "/visits", adm, {"client_id": cl["id"], "site_id": br["id"],
                                  "scheduled_start": tomorrow + " 10:00",
                                  "ignore_conflict": True})

    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("dialog", lambda d: d.accept())
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    # --- the branch, from the customer's folder ---
    page.evaluate(f"() => navigate('client', {{ id: {cl['id']} }})")
    page.wait_for_selector("#sites-body tr", timeout=8000)
    page.wait_for_timeout(400)
    check("switch off: the branch row offers to switch it off",
          page.evaluate(f"""() => !!document.querySelector('[data-turn-off="{br['id']}"]')"""))
    errors.clear()
    page.evaluate(f"""() => document.querySelector('[data-turn-off="{br['id']}"]').click()""")
    page.wait_for_selector("#dof", timeout=8000)
    check("switch off: the dialog opens and raises nothing", not errors, "; ".join(errors[:2]))
    check("switch off: it says how many visits are still booked",
          page.evaluate("""() => (document.getElementById('modal-body').innerText || '')
              .includes('1')""") and page.evaluate("() => !!document.getElementById('dof-cancel')"))
    check("switch off: every word of the dialog is translated",
          not raw_keys(page.evaluate("() => document.getElementById('modal-body').innerText")),
          ", ".join(raw_keys(page.evaluate("() => document.getElementById('modal-body').innerText"))[:4]))
    page.evaluate("() => document.getElementById('dof-cancel').click()")
    page.evaluate("() => document.querySelector('#dof button[type=submit]').click()")
    page.wait_for_timeout(1800)
    check("switch off: the branch comes back marked off", not errors and page.evaluate(
        f"""() => !!document.querySelector('#sites-body [data-turn-on="{br['id']}"]')"""),
        "; ".join(errors[:2]))
    booked = _api("GET", f"/visits?client={cl['id']}", adm)
    booked = booked["items"] if isinstance(booked, dict) else booked
    check("switch off: and the visit it had booked was called off",
          bool(booked) and booked[0]["status"] == "cancelled")

    # --- and back on again ---
    errors.clear()
    page.evaluate(f"""() => document.querySelector('#sites-body [data-turn-on="{br['id']}"]').click()""")
    page.wait_for_timeout(1800)
    check("switch off: one press puts the branch back", not errors and page.evaluate(
        f"""() => !!document.querySelector('#sites-body [data-turn-off="{br['id']}"]')"""),
        "; ".join(errors[:2]))

    # --- the customer itself ---
    errors.clear()
    page.evaluate("() => document.getElementById('client-status-btn').click()")
    page.wait_for_selector("#dof", timeout=8000)
    page.evaluate("() => document.querySelector('#dof button[type=submit]').click()")
    page.wait_for_timeout(1800)
    check("switch off: a customer can be switched off from their folder",
          not errors and page.evaluate("""() => document.getElementById('view').innerText
              .toLowerCase().includes('reactivate')"""), "; ".join(errors[:2]))
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("switch off: the folder still reads in whole words", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))

    # --- the Branches list: a column, and a way to hide them ---
    errors.clear()
    page.evaluate("() => navigate('locations')")
    page.wait_for_selector("#loc-body tr", timeout=8000)
    page.wait_for_timeout(600)
    check("switch off: the branches list has a status column", not errors and page.evaluate(
        """() => [...document.querySelectorAll('th')]
            .some(th => th.innerText.trim().toLowerCase() === 'status')"""),
        "; ".join(errors[:2]))
    check("switch off: it offers to hide the ones switched off",
          page.evaluate("() => !!document.getElementById('loc-hide-off')"))
    shown = page.evaluate("""() => [...document.querySelectorAll('#loc-body tr')]
        .filter(tr => tr.offsetParent !== null).length""")
    page.evaluate("() => document.getElementById('loc-hide-off').click()")
    page.wait_for_timeout(400)
    hidden = page.evaluate("""() => [...document.querySelectorAll('#loc-body tr')]
        .filter(tr => tr.offsetParent !== null).length""")
    check("switch off: ticking it takes them off the list", hidden < shown,
          f"{shown} rows shown, {hidden} after hiding")
    page.close()
    _api("DELETE", f"/clients/{cl['id']}", adm)


def branch_board_checks(browser):
    """The branch schedule board and the way back from an applied plan.

    Both exist for the same reason: the office is about to type the visiting
    schedule for ~150 branches, and then press a button that books hundreds of
    real customer visits. One screen to type it on, and one button to take it
    back."""
    print("\nBRANCH SCHEDULE BOARD + UNDO")
    adm = _token("admin@pestcrm.com", "admin123")
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    # "Failed to load resource" on the console does not say WHICH resource, and
    # a nameless 404 is a bug report nobody can act on. Name it.
    page.on("response", lambda r: errors.append(f"HTTP {r.status} {r.url}")
            if r.status >= 400 else None)
    page.on("console", lambda m: errors.append(m.text)
            if m.type == "error" and "Failed to load resource" not in m.text else None)
    page.on("dialog", lambda d: d.accept())
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    page.evaluate("() => navigate('branchsched')")
    page.wait_for_selector("#bs-body tr[data-b]", timeout=8000)
    page.wait_for_timeout(500)
    check("board: it renders", not errors, "; ".join(errors[:2]))
    total = page.evaluate("() => document.querySelectorAll('#bs-body tr[data-b]').length")
    check("board: every branch is on the one screen, not one per dialog", total >= 2)
    # The board is wider than any screen, so it scrolls in its own box with a
    # rail above it and the branch name frozen — the office should never have
    # to go to the bottom of two hundred rows to reach Thursday.
    check("board: the page itself does not scroll sideways",
          not page.evaluate("() => document.documentElement.scrollWidth > document.documentElement.clientWidth"))
    check("board: there is a scrollbar above the table as well",
          page.evaluate("""() => { const r=document.getElementById('bs-rail'),
              b=document.querySelector('.bs-table').closest('.table-scroll');
            return !!r && r.style.display !== 'none'
              && Math.abs(document.getElementById('bs-rail-in').offsetWidth - b.scrollWidth) < 4; }"""))
    check("board: dragging it moves the table with it",
          page.evaluate("""() => { const r=document.getElementById('bs-rail'),
              b=document.querySelector('.bs-table').closest('.table-scroll');
            r.scrollLeft = 300; return new Promise(res => setTimeout(
              () => res(Math.abs(b.scrollLeft - 300) < 4), 250)); }"""))
    check("board: and the branch name stays put while it moves",
          page.evaluate("""() => { const c=document.querySelector('#bs-body tr[data-b] td:first-child');
            const r=c.getBoundingClientRect(); const box=c.closest('.table-scroll').getBoundingClientRect();
            return r.left >= box.left - 2 && r.left < box.left + 20; }"""))
    page.evaluate("() => { const b=document.querySelector('.bs-table').closest('.table-scroll'); b.scrollLeft = 0; }")
    page.wait_for_timeout(250)
    check("board: seven day columns per branch",
          page.evaluate("""() => { const r=document.querySelector('#bs-body tr[data-b]');
              return r ? r.querySelectorAll('.bs-day').length : 0; }""") == 7)
    check("board: hours are not even built until a day is ticked",
          page.evaluate("""() => [...document.querySelectorAll('.bs-day:not(.bs-on) .bs-hours')]
              .every(e => e.children.length === 0)"""))
    # Filter to ONE area, then fill only what is shown — the rest of the book
    # must be untouched. This is the assertion that matters for a bulk tool.
    area_id = page.evaluate("""() => { const r=[...document.querySelectorAll('#bs-body tr[data-b]')]
        .find(x => x.dataset.area); return r ? r.dataset.area : ''; }""")
    check("board: at least one branch carries an area to filter by", bool(area_id))
    outside = page.evaluate(f"""() => {{ const r=[...document.querySelectorAll('#bs-body tr[data-b]')]
        .find(x => x.dataset.area !== '{area_id}');
        return r ? {{ id: r.dataset.b, vpm: r.querySelector('.bs-vpm').value }} : null; }}""")
    page.evaluate(f"""() => {{ const s=document.getElementById('bs-filter');
        s.value='{area_id}'; s.dispatchEvent(new Event('change')); }}""")
    page.wait_for_timeout(300)
    # Assert what is LEFT, not how many went: if the fixture happens to put
    # every branch in one area, filtering correctly hides nothing at all.
    check("board: filtering to an area leaves only that area's branches",
          page.evaluate(f"""() => [...document.querySelectorAll('#bs-body tr[data-b]')]
              .filter(r => r.style.display !== 'none')
              .every(r => r.dataset.area === '{area_id}')"""))
    if outside:
        check("board: a branch from another area is hidden by the filter",
              page.evaluate(f"""() => document.querySelector('#bs-body tr[data-b="{outside['id']}"]')
                  .style.display === 'none'"""))
    # Filtering by CLIENT: an office works through one company's branches as
    # often as one area's. It must also COMPOSE with the area filter rather
    # than replace it — that is where a filter bug would hide.
    check("board: it offers a client filter too",
          page.evaluate("() => document.querySelectorAll('#bs-client option').length") >= 2)
    page.evaluate("""() => { const s=document.getElementById('bs-filter');
        s.value=''; s.dispatchEvent(new Event('change')); }""")
    cid = page.evaluate("""() => { const r=document.querySelector('#bs-body tr[data-b]');
        return r ? r.dataset.client : ''; }""")
    page.evaluate(f"""() => {{ const s=document.getElementById('bs-client');
        s.value='{cid}'; s.dispatchEvent(new Event('change')); }}""")
    page.wait_for_timeout(300)
    check("board: filtering by client leaves only that company's branches",
          page.evaluate(f"""() => {{ const vis=[...document.querySelectorAll('#bs-body tr[data-b]')]
              .filter(r => r.style.display !== 'none');
              return vis.length > 0 && vis.every(r => r.dataset.client === '{cid}'); }}"""))
    page.evaluate(f"""() => {{ const s=document.getElementById('bs-filter');
        s.value='{area_id}'; s.dispatchEvent(new Event('change')); }}""")
    page.wait_for_timeout(300)
    check("board: client and area filters narrow together, not one instead of the other",
          page.evaluate(f"""() => [...document.querySelectorAll('#bs-body tr[data-b]')]
              .filter(r => r.style.display !== 'none')
              .every(r => r.dataset.client === '{cid}' && r.dataset.area === '{area_id}')"""))
    page.evaluate("""() => { const c=document.getElementById('bs-client');
        c.value=''; c.dispatchEvent(new Event('change')); }""")
    page.wait_for_timeout(300)
    errors.clear()
    page.evaluate("() => document.getElementById('bs-fill').click()")
    page.wait_for_selector("#bf", timeout=8000)
    page.evaluate("""() => {
        document.querySelector('#bf [name=from]').value = '08:30';
        document.querySelector('#bf [name=to]').value = '15:30';
        document.querySelector('#bf [name=vpm]').value = '12';
        document.querySelectorAll('.bf-wd').forEach(cb => {
          if (cb.value === '5' || cb.value === '0') { cb.checked = true; cb.dispatchEvent(new Event('change')); } });
        document.querySelector('#bf button[type=submit]').click(); }""")
    page.wait_for_timeout(700)
    check("board: filling all shown raises nothing", not errors, "; ".join(errors[:2]))
    check("board: it filled the rows on screen",
          page.evaluate("""() => [...document.querySelectorAll('#bs-body tr[data-b]')]
              .filter(r => r.style.display !== 'none')
              .every(r => r.querySelector('.bs-sfrom').value === '08:30'
                       && r.querySelector('.bs-vpm').value === '12')"""))
    if outside:
        check("board: and left the branches it was not showing alone",
              page.evaluate(f"""() => document.querySelector('#bs-body tr[data-b="{outside['id']}"]')
                  .querySelector('.bs-vpm').value === '{outside['vpm']}'"""))
    # How long the visit takes lives on the branch too — a hotel and a corner
    # shop are not the same job, and the planner now books what it is told.
    check("board: it asks how long a visit takes",
          page.evaluate("() => document.querySelectorAll('#bs-body .bs-mins').length")
          == page.evaluate("() => document.querySelectorAll('#bs-body tr[data-b]').length"))
    check("board: the length box shows the company default until told otherwise",
          page.evaluate("""() => { const el=document.querySelector('#bs-body .bs-mins');
              return !!el && !!el.placeholder && el.placeholder !== 'undefined'; }"""))
    page.evaluate("""() => { const el=[...document.querySelectorAll('#bs-body tr[data-b]')]
        .find(r => r.style.display !== 'none').querySelector('.bs-mins');
        el.value = '90'; el.dispatchEvent(new Event('input', { bubbles: true })); }""")
    page.evaluate("() => document.getElementById('bs-save').click()")
    page.wait_for_timeout(2200)
    check("board: saving raises nothing", not errors, "; ".join(errors[:2]))
    check("board: the visit length reached the server",
          any(b.get("visit_minutes") == 90
              for b in _api("GET", "/branch-schedule", adm)["branches"]))
    # The board speaks in visits a MONTH — the office had the week option taken
    # off every screen — so twelve in the box is twelve a month on the server.
    saved = [b for b in _api("GET", "/branch-schedule", adm)["branches"]
             if b["service_from"] == "08:30" and (b["visits_per_month"] or 0) == 12
             and b["freq_unit"] == "month"]
    check("board: the server has what the screen showed", len(saved) >= 1)
    check("board: with the days that were ticked",
          saved and sorted(d["weekday"] for d in saved[0]["service_days"]) == [0, 5])
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("board: every label on it is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))

    # --- can the book be serviced, and can it be imported ---
    check("capacity: the board asks whether the book can be serviced",
          page.evaluate("() => !!document.querySelector('.cap-panel')"))
    check("capacity: it states what it assumed about time",
          page.evaluate("""() => (document.querySelector('.cap-panel') || {}).innerText
              ?.match(/\\d+/) !== null"""))
    check("capacity: every word of it is translated",
          not raw_keys(page.evaluate(
              "() => (document.querySelector('.cap-panel') || {}).innerText || ''")))
    errors.clear()
    page.evaluate("() => document.getElementById('bs-import').click()")
    page.wait_for_selector("#imp", timeout=8000)
    check("import: the dialog opens", not errors, "; ".join(errors[:2]))
    cname = _api("GET", "/clients", adm)
    cname = (cname if isinstance(cname, list) else cname["items"])[0]["name_en"]
    page.evaluate(f"""() => {{ document.getElementById('imp-text').value =
        'client,branch,area,from,to,days,visits_per_month,visit_minutes,lat,lng\\n'
        + {cname!r} + ',UI Imported Branch,,09:00,15:00,"Sat,Wed",2,45,,';
        document.getElementById('imp-check').click(); }}""")
    page.wait_for_timeout(1800)
    check("import: checking the file writes nothing and reports",
          page.evaluate("() => !!document.querySelector('#imp-out .sc-chip')")
          and not any(s["name"] == "UI Imported Branch" for s in _api("GET", "/sites", adm)))
    check("import: a clean file offers to go ahead",
          page.evaluate("() => document.getElementById('imp-go').style.display !== 'none'"))
    page.evaluate("() => document.getElementById('imp-go').click()")
    page.wait_for_timeout(2500)
    imported = [s for s in _api("GET", "/sites", adm) if s["name"] == "UI Imported Branch"]
    check("import: the branch arrives with what the sheet said",
          imported and imported[0]["visits_per_month"] == 2
          and imported[0]["visit_minutes"] == 45
          and sorted(d["weekday"] for d in imported[0]["service_days"]) == [2, 5])
    check("import: importing raises nothing", not errors, "; ".join(errors[:2]))
    if imported:
        _api("DELETE", f"/sites/{imported[0]['id']}", adm)

    # --- backup: the CRM offered in parts, not just all-or-nothing ---
    page.evaluate("() => navigate('backup')")
    page.wait_for_selector("#bk-go", timeout=8000)
    page.wait_for_timeout(600)
    check("backup: the parts list is out of the way until it is wanted",
          page.evaluate("() => document.getElementById('bk-parts').style.display === 'none'"))
    page.evaluate("""() => { const c=document.getElementById('bk-parts-on');
        c.checked = true; c.dispatchEvent(new Event('change', {bubbles:true})); }""")
    page.wait_for_timeout(300)
    check("backup: every part of the CRM can be picked on its own",
          page.evaluate("() => document.querySelectorAll('.bk-part').length") >= 10)
    check("backup: and each one is named in words, not table names",
          not raw_keys(page.evaluate(
              """() => [...document.querySelectorAll('.bk-parts .chk-item')].map(x=>x.innerText).join(' ')""")))
    check("backup: nothing chosen means nothing to download",
          page.evaluate("""() => { for (const id of ['bk-db','bk-files']) {
              const c=document.getElementById(id); c.checked=false;
              c.dispatchEvent(new Event('change', {bubbles:true})); }
            return document.getElementById('bk-go').disabled; }"""))
    check("backup: ticking one part is enough to take one",
          page.evaluate("""() => { const c=document.querySelector('.bk-part');
              c.checked = true; c.dispatchEvent(new Event('change', {bubbles:true}));
            return !document.getElementById('bk-go').disabled; }"""))

    # --- an uploaded document is never translated ---
    # Chrome and the phone's WebView translate any text they can reach. A visit
    # report is meant to be translated for the customer; an IPM manual is the
    # document itself and must read as it was written.
    page.evaluate("() => navigate('ipm')")
    page.wait_for_timeout(1500)
    check("ipm: the document's own title and description are marked never-translate",
          page.evaluate("""() => { const c=[...document.querySelectorAll('#view td')];
            const doc=c.find(x => x.querySelector('strong'));
            return !doc || (doc.getAttribute('translate') === 'no'
              && doc.classList.contains('notranslate')); }"""))
    check("ipm: but the column headings around them still translate",
          page.evaluate("""() => { const th=document.querySelector('#view th');
            return !th || !th.hasAttribute('translate'); }"""))

    # --- work that could not be booked, and why ---
    # A branch in an area nobody is allowed to work can never be served, so the
    # plan must say so by name rather than adding 1 to a counter.
    area = _api("POST", "/areas", adm, {"name_en": "Unreachable Patch"})
    orphan = _api("POST", "/clients/1/sites", adm, {
        "name": "Unreachable Branch", "area_id": area["id"], "service_from": "09:00",
        "service_to": "17:00", "visits_per_month": 28})
    errors.clear()
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(1600)
    page.evaluate("() => document.getElementById('sh-auto').click()")
    page.wait_for_selector("#arf", timeout=8000)
    page.evaluate("() => document.querySelector('#arf button[type=submit]').click()")
    page.wait_for_timeout(3000)
    check("unplaced: the plan shows what it could not book", not errors
          and page.evaluate("() => !!document.querySelector('.auto-unplaced')"),
          "; ".join(errors[:2]))
    check("unplaced: it groups them by what to do about it",
          page.evaluate("() => document.querySelectorAll('.auto-unplaced .un-group').length") >= 1)
    check("unplaced: it names the branch nobody can reach",
          page.evaluate("""() => (document.querySelector('.auto-unplaced') || {}).innerText
              ?.includes('Unreachable Branch') || false"""))
    check("unplaced: every reason it prints is translated",
          not raw_keys(page.evaluate(
              "() => (document.querySelector('.auto-unplaced') || {}).innerText || ''")))
    # HIS REQUEST: the branch it could not book is a BUTTON, and pressing it
    # says who could take it and what is in the way.
    check("who-can-take: the branch it could not book can be clicked",
          page.evaluate("() => !!document.querySelector('.auto-unplaced [data-wct]')"))
    errors.clear()
    page.evaluate("() => document.querySelector('.auto-unplaced [data-wct]').click()")
    page.wait_for_timeout(2500)
    check("who-can-take: it opens without a script error", not errors, "; ".join(errors[:2]))
    check("who-can-take: it answers with men or with why nobody can",
          page.evaluate("""() => { const b = document.querySelector('.auto-unplaced .up-who');
              return !!b && (!!b.querySelector('.wct-man') || !!b.querySelector('.wct-note')); }"""))
    check("who-can-take: every word of the answer is translated",
          not raw_keys(page.evaluate(
              "() => (document.querySelector('.auto-unplaced .up-who') || {}).innerText || ''")))
    # IT MUST NOT TAKE THE PLAN AWAY. The branch chip lives inside the plan's
    # own form, and a button with no type re-submits that form: one press used
    # to re-run the whole plan and wipe the answer off the screen.
    check("who-can-take: the plan it was opened from is still there",
          page.evaluate("() => !!document.querySelector('.auto-unplaced [data-wct]')"))
    page.evaluate("closeModal && closeModal()")
    _api("DELETE", f"/sites/{orphan['id']}", adm)

    # --- and the way back from a plan ---
    # A branch nobody is allowed to work, so the run about to be applied is
    # GUARANTEED to leave work behind — which is what the worklist below reads.
    left_area = _api("POST", "/areas", adm, {"name_en": "Left Behind Patch"})
    left_site = _api("POST", "/clients/1/sites", adm, {
        "name": "Left Out Branch", "area_id": left_area["id"], "service_from": "09:00",
        "service_to": "17:00", "visits_per_month": 28})
    errors.clear()
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(1800)
    runs_before = len(_api("GET", "/shifts/auto/runs", adm))
    page.evaluate("() => document.getElementById('sh-auto').click()")
    page.wait_for_selector("#arf", timeout=8000)
    # THE PRESS HAS TO HAVE WORK TO DO, or "take it back" takes back nothing.
    # An earlier block in this file already applied a plan for the very same
    # week, so this second press booked 0 visits and 0 shifts, the undo below
    # removed nothing, and the count could never drop — the check failed on
    # every run for months for that reason alone (found 2026-08-31). So the
    # week the form is offering is cleared first, through the same guarded
    # endpoint the office uses: preview, then apply with the counts echoed back.
    _rng = page.evaluate("""() => ({from: document.querySelector('#arf [name=from]').value,
                                    to: document.querySelector('#arf [name=to]').value})""")
    _pre = _api("POST", "/schedule/clear", adm, dict(_rng))
    _api("POST", "/schedule/clear", adm, dict(_rng, apply=True,
                                              expect_visits=_pre["visits"],
                                              expect_shifts=_pre["shifts"]))
    page.evaluate("() => document.querySelector('#arf button[type=submit]').click()")
    page.wait_for_timeout(2500)
    page.evaluate("() => document.getElementById('arf-apply').click()")
    page.wait_for_timeout(3000)
    check("undo: applying a plan raises nothing", not errors, "; ".join(errors[:2]))
    runs = _api("GET", "/shifts/auto/runs", adm)
    check("undo: the press was recorded so it can be taken back", len(runs) > runs_before)
    page.wait_for_timeout(1200)
    check("undo: the Shifts page offers the way back",
          page.evaluate("() => !!document.querySelector('[data-undorun]')"))

    # --- what it could NOT book, kept where the office can work through it ---
    # Applying is allowed to leave work behind; that work vanishing is not.
    check("worklist: the run says how much still needs a place by hand",
          page.evaluate("() => !!document.querySelector('[data-unplaced]')"))
    errors.clear()
    page.evaluate("() => document.querySelector('[data-unplaced]').click()")
    page.wait_for_selector(".up-row", timeout=8000)
    check("worklist: it opens without a script error", not errors, "; ".join(errors[:2]))
    check("worklist: the branch that was left out is named",
          page.evaluate("""() => [...document.querySelectorAll('.up-row')]
              .some(r => r.innerText.includes('Left Out Branch'))"""))
    check("worklist: every reason it gives is translated",
          not raw_keys(page.evaluate(
              """() => [...document.querySelectorAll('.up-why')].map(x => x.innerText).join(' ')""")))
    check("worklist: a line can be booked or dismissed from here",
          page.evaluate("""() => !!document.querySelector('[data-book]')
              && !!document.querySelector('[data-dismiss]')"""))
    check("worklist: each waiting line can ask who could take it",
          page.evaluate("() => !!document.querySelector('[data-who]')"))
    errors.clear()
    page.evaluate("() => document.querySelector('[data-who]').click()")
    page.wait_for_timeout(2500)
    check("worklist: the answer opens under the line, with no script error",
          not errors and page.evaluate(
              """() => { const b = document.querySelector('.up-who:not(.hidden)');
                  return !!b && b.innerText.trim().length > 0; }"""),
          "; ".join(errors[:2]))
    check("worklist: and every word of it is translated",
          not raw_keys(page.evaluate(
              """() => (document.querySelector('.up-who:not(.hidden)') || {}).innerText || ''""")))
    # HIS REQUEST: "let me accept or change the engineer you recomend". Both are
    # offered on any man the answer puts forward; when nobody can go there is
    # nothing to accept, and the panel says why instead — so this only asserts
    # the pair appears together.
    check("worklist: a recommended engineer can be accepted or changed",
          page.evaluate("""() => { const b = document.querySelector('.up-who:not(.hidden)');
              if (!b || !b.querySelector('.wct-man')) return true;   // nobody to offer
              return !!b.querySelector('[data-wctaccept]') && !!b.querySelector('[data-wctbook]'); }"""))
    page.evaluate("() => document.querySelector('[data-dismiss]').click()")
    page.wait_for_timeout(1800)
    check("worklist: a dismissed line is marked, not spirited away",
          page.evaluate("() => !!document.querySelector('.up-done')"))
    page.evaluate("closeModal && closeModal()")
    page.wait_for_timeout(500)
    _api("DELETE", f"/sites/{left_site['id']}", adm)

    # --- the branches the book asks too much of -------------------------------
    # A branch open for one hour whose visit takes ninety minutes can never be
    # booked, whoever is free. The office fixes that in the branch, so the list
    # exists to be READ and then opened.
    oa_area = _api("POST", "/areas", adm, {"name_en": "Asks Too Much Patch"})
    oa_site = _api("POST", "/clients/1/sites", adm, {
        "name": "Impossible Branch", "area_id": oa_area["id"], "service_from": "09:00",
        "service_to": "10:00", "visits_per_month": 4, "visit_minutes": 90})
    errors.clear()
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(2600)
    check("asks-too-much: the Shifts page says how many branches cannot fit",
          page.evaluate("""() => { const b = document.getElementById('sh-overasked');
              return !!b && !b.classList.contains('hidden') && b.innerText.trim().length > 0; }"""))
    page.evaluate("() => document.getElementById('sh-overasked').click()")
    page.wait_for_selector(".oa-row", timeout=8000)
    check("asks-too-much: it opens without a script error", not errors, "; ".join(errors[:2]))
    check("asks-too-much: the branch that cannot fit is named",
          page.evaluate("""() => [...document.querySelectorAll('.oa-row')]
              .some(r => r.innerText.includes('Impossible Branch'))"""))
    check("asks-too-much: it says what the numbers are, not just that it failed",
          page.evaluate("""() => [...document.querySelectorAll('.oa-row')]
              .some(r => /90/.test(r.innerText) && /60/.test(r.innerText))"""))
    check("asks-too-much: every word of it is translated",
          not raw_keys(page.evaluate(
              """() => [...document.querySelectorAll('.oa-row')].map(x => x.innerText).join(' ')""")))
    check("asks-too-much: the branch can be opened to fix it by hand",
          page.evaluate("() => !!document.querySelector('[data-oaopen]')"))
    page.evaluate("closeModal && closeModal()")
    page.wait_for_timeout(400)
    _api("DELETE", f"/sites/{oa_site['id']}", adm)
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(2600)

    booked = [v for v in _api("GET", "/visits", adm)]
    errors.clear()
    page.evaluate("() => document.querySelector('[data-undorun]').click()")
    page.wait_for_timeout(3000)
    check("undo: taking it back raises nothing", not errors, "; ".join(errors[:2]))
    after = [v for v in _api("GET", "/visits", adm)]
    # EXACTLY what that press booked, no more and no less. A bare "fewer than
    # before" passes just as well when the run booked nothing at all.
    check("undo: the press booked something there is a way back from",
          runs[0]["visits"] > 0)
    check("undo: the visits it booked are gone again",
          len(after) == len(booked) - runs[0]["visits"])
    check("undo: and the run no longer offers to be undone twice",
          all(r["undone_at"] for r in _api("GET", "/shifts/auto/runs", adm)
              if r["id"] == runs[0]["id"]))
    page.close()


def workflow_checks(browser):
    """The joins between modules: the board that shows where work stopped, and
    the two steps that carry a won deal through to a schedule."""
    print("\nWORKFLOW — THE JOINS BETWEEN MODULES")
    adm = _token("admin@pestcrm.com", "admin123")
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("response", lambda r: errors.append(f"HTTP {r.status} {r.url}")
            if r.status >= 400 else None)
    page.on("console", lambda m: errors.append(m.text)
            if m.type == "error" and "Failed to load resource" not in m.text else None)
    page.on("dialog", lambda d: d.accept())
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    page.evaluate("() => navigate('pipeline')")
    page.wait_for_selector(".pipe-card", timeout=8000)
    check("workflow: the board renders", not errors, "; ".join(errors[:2]))
    check("workflow: it covers the whole chain, not one module",
          page.evaluate("() => document.querySelectorAll('.pipe-group').length") >= 4)
    check("workflow: every stall is a number you can open",
          page.evaluate("() => [...document.querySelectorAll('.pipe-card')].every(c => c.dataset.go)"))
    check("workflow: every label on it is translated",
          not raw_keys(page.evaluate("() => document.getElementById('view').innerText")))
    errors.clear()
    page.evaluate("() => document.querySelector('.pipe-card').click()")
    page.wait_for_timeout(1800)
    check("workflow: opening a stall goes somewhere real", not errors, "; ".join(errors[:2]))

    # A won quote -> contract -> the branches that must deliver it.
    site = _api("POST", "/clients/1/sites", adm, {"name": "Workflow Branch"})
    quote = _api("POST", "/invoices", adm, {
        "client_id": 1, "doc_type": "quote", "issue_date": _today_str(),
        "amount": 600, "status": "sent"})
    errors.clear()
    page.evaluate(f"() => navigate('invoice', {{ id: {quote['id']} }})")
    page.wait_for_timeout(1800)
    check("workflow: a sent quote offers to become a contract",
          page.evaluate("() => !!document.getElementById('quote-contract')"))
    page.evaluate("() => document.getElementById('quote-contract').click()")
    page.wait_for_selector("#q2c", timeout=8000)
    page.evaluate(f"""() => {{
        document.querySelector('#q2c [name=frequency]').value = 'weekly';
        [...document.querySelectorAll('.q2c-site')].forEach(c => {{
          if (c.value === '{site['id']}') c.checked = true; }});
        document.querySelector('#q2c button[type=submit]').click(); }}""")
    page.wait_for_timeout(2500)
    check("workflow: making the contract raises nothing", not errors, "; ".join(errors[:2]))
    made = [c for c in _api("GET", "/contracts", adm) if c.get("quote_id") == quote["id"]]
    check("workflow: the contract exists and remembers the quote", bool(made))
    if made:
        errors.clear()
        page.evaluate("() => navigate('contracts')")
        page.wait_for_timeout(1800)
        check("workflow: a contract offers to push its terms to its branches",
              page.evaluate(f"() => !!document.querySelector('[data-tobranch=\"{made[0]['id']}\"]')"))
        page.evaluate(f"() => document.querySelector('[data-tobranch=\"{made[0]['id']}\"]').click()")
        page.wait_for_selector("#c2b", timeout=8000)
        check("workflow: it shows what would change before changing it",
              page.evaluate("() => document.querySelectorAll('#c2b tbody tr').length") >= 1)
        page.evaluate("() => document.querySelector('#c2b button[type=submit]').click()")
        page.wait_for_timeout(2200)
        check("workflow: applying it raises nothing", not errors, "; ".join(errors[:2]))
        after = next((s for s in _api("GET", "/sites", adm) if s["id"] == site["id"]), None)
        check("workflow: the branch now carries the contract's frequency",
              after and after["visits_per_month"] == 4)
        _api("DELETE", f"/contracts/{made[0]['id']}", adm)
    _api("DELETE", f"/sites/{site['id']}", adm)
    page.close()


def leader_checks(browser):
    """The area manager's own screens, driven rather than reasoned about.

    The point of the role is that the crew is READ FROM THE ROSTER, so the test
    rosters one engineer into the manager's area and another outside it, and
    asserts the page tells them apart."""
    print("\nAREA MANAGER")
    adm = _token("admin@pestcrm.com", "admin123")
    areas = {a["name_en"]: a["id"] for a in _api("GET", "/areas", adm)}
    users = _api("GET", "/users", adm)
    yousef = next(u for u in users if u["email"] == "agent1@pestcrm.com")
    omar = next(u for u in users if u["email"] == "agent2@pestcrm.com")
    types = _api("GET", "/shift-types", adm)
    day = datetime.date.today().isoformat()
    # Yousef works the leader's patch today; Omar works someone else's.
    _api("POST", "/shifts/day", adm, {"agent_id": yousef["id"], "date": day,
                                      "shifts": [{"shift_type_id": types[0]["id"],
                                                  "area_id": areas["6th of October"]}]})
    _api("POST", "/shifts/day", adm, {"agent_id": omar["id"], "date": day,
                                      "shifts": [{"shift_type_id": types[0]["id"],
                                                  "area_id": areas["Maadi"]}]})

    page = browser.new_page(viewport={"width": 390, "height": 844},
                            is_mobile=True, has_touch=True)
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "leader@pestcrm.com")
    page.fill("#login-password", "leader123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    nav = page.evaluate("() => [...document.querySelectorAll('.nav-item')].map(a => a.dataset.view)")
    check("leader: the sidebar carries My Team and My Day", "myteam" in nav and "myday" in nav)
    check("leader: the office screens are not offered",
          not {"finance", "invoices", "chemicals", "agents", "permissions"} & set(nav),
          ", ".join(sorted({"finance", "invoices", "chemicals", "agents", "permissions"} & set(nav))))

    page.evaluate("() => navigate('myteam')")
    page.wait_for_timeout(1600)
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("leader: My Team lists the engineer rostered onto their area",
          "Yousef" in body, body[:150])
    check("leader: and not the one working another area", "Omar" not in body, body[:150])
    check("leader: it names the areas being led", "6th of October" in body, body[:120])
    check("leader: every label on it is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))
    check("leader: My Team renders without a script error", not errors, "; ".join(errors[:2]))

    # Rotation is the whole idea: move Omar onto the patch and he joins the team.
    _api("POST", "/shifts/day", adm, {"agent_id": omar["id"], "date": day,
                                      "shifts": [{"shift_type_id": types[0]["id"],
                                                  "area_id": areas["6th of October"]}]})
    page.evaluate("() => navigate('dashboard')")
    page.wait_for_timeout(800)
    page.evaluate("() => navigate('myteam')")
    page.wait_for_timeout(1600)
    body2 = page.evaluate("() => document.getElementById('view').innerText")
    check("leader: re-rostering moves an engineer onto the team that same day",
          "Omar" in body2, body2[:150])

    page.evaluate("() => navigate('dashboard')")
    page.wait_for_timeout(1400)
    dash = page.evaluate("() => document.getElementById('view').innerText")
    check("leader: the dashboard names their patch", "6th of October" in dash, dash[:150])
    check("leader: no money reaches the dashboard",
          "Outstanding" not in dash and "Revenue" not in dash, dash[:150])
    check("leader: the phone layout does not scroll sideways",
          page.evaluate("() => document.documentElement.scrollWidth <= window.innerWidth"))

    # The area picker is the office's control, and belongs to area managers only.
    page.close()
    office = browser.new_page(viewport={"width": 1440, "height": 1000})
    office.goto(BASE + "/", wait_until="networkidle")
    office.fill("#login-email", "admin@pestcrm.com")
    office.fill("#login-password", "admin123")
    office.click("#login-form button[type=submit]")
    office.wait_for_timeout(2500)
    office.evaluate("closeModal && closeModal()")
    office.evaluate("() => navigate('agents')")
    office.wait_for_timeout(1400)
    office.evaluate("""() => {
      const row = [...document.querySelectorAll('#view tbody tr')]
        .find(r => r.innerText.includes('Tarek'));
      row.querySelector('[data-edit]').click();
    }""")
    office.wait_for_timeout(1200)
    check("office: the area picker is shown for an area manager",
          office.evaluate("() => { const b = document.querySelector('.uf-areas');"
                          " return !!b && b.style.display !== 'none'; }"))
    check("office: their current areas are ticked",
          office.evaluate("() => [...document.querySelectorAll('.uf-area:checked')].length") >= 1)
    office.evaluate("""() => {
      const sel = document.querySelector('[name=role]');
      sel.value = 'agent'; sel.dispatchEvent(new Event('change'));
    }""")
    office.wait_for_timeout(400)
    check("office: it disappears for any other role",
          office.evaluate("() => document.querySelector('.uf-areas').style.display === 'none'"))
    office.close()


def team_leader_checks(browser):
    """The other supervising role: a crew instead of a patch.

    A team leader's team is STANDING — it is the engineers who report to them,
    not whoever the roster happened to send into an area — so this drives the
    office screen that builds the team, then reads the team leader's own pages
    back and asserts they follow the people."""
    print("\nTEAM LEADER")
    adm = _token("admin@pestcrm.com", "admin123")
    users = _api("GET", "/users", adm)
    yousef = next(u for u in users if u["email"] == "agent1@pestcrm.com")
    gone = next((u for u in users if u["email"] == "crewlead@pestcrm.com"), None)
    if gone:
        _api("DELETE", f"/users/{gone['id']}/permanent", adm)

    # Built through the office UI, because the team picker is the new control.
    office = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    office.on("pageerror", lambda e: errors.append(str(e)))
    office.goto(BASE + "/", wait_until="networkidle")
    office.fill("#login-email", "admin@pestcrm.com")
    office.fill("#login-password", "admin123")
    office.click("#login-form button[type=submit]")
    office.wait_for_timeout(2500)
    office.evaluate("closeModal && closeModal()")
    office.evaluate("() => navigate('agents')")
    office.wait_for_timeout(1400)
    office.evaluate("() => document.getElementById('add-user').click()")
    office.wait_for_timeout(900)
    office.evaluate("""() => {
      const sel = document.querySelector('[name=role]');
      sel.value = 'team_leader'; sel.dispatchEvent(new Event('change'));
    }""")
    office.wait_for_timeout(400)
    check("office: the team picker is shown for a team leader",
          office.evaluate("() => { const b = document.querySelector('.uf-team');"
                          " return !!b && b.style.display !== 'none'; }"))
    check("office: the area picker is NOT",
          office.evaluate("() => document.querySelector('.uf-areas').style.display === 'none'"))
    office.evaluate("""(yid) => {
      document.querySelector('[name=full_name]').value = 'Crew Leader';
      document.querySelector('[name=email]').value = 'crewlead@pestcrm.com';
      document.querySelector('[name=password]').value = 'crew123';
      const box = document.querySelector('.uf-member[value="' + yid + '"]');
      box.checked = true;
      document.querySelector('#uf').dispatchEvent(new Event('submit', {cancelable: true}));
    }""", yousef["id"])
    office.wait_for_timeout(2000)
    listing = office.evaluate("() => document.getElementById('view').innerText")
    check("office: the new team leader is listed with their engineer",
          "Crew Leader" in listing and "Yousef" in listing.split("Crew Leader")[-1][:120],
          listing[:160])
    check("office: building the team raised no script error", not errors, "; ".join(errors[:2]))
    office.close()

    # Now read it back as the team leader, on a phone.
    page = browser.new_page(viewport={"width": 390, "height": 844},
                            is_mobile=True, has_touch=True)
    perrors = []
    page.on("pageerror", lambda e: perrors.append(str(e)))
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "crewlead@pestcrm.com")
    page.fill("#login-password", "crew123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")
    nav = page.evaluate("() => [...document.querySelectorAll('.nav-item')].map(a => a.dataset.view)")
    check("team leader: the sidebar carries My Team and My Day",
          "myteam" in nav and "myday" in nav, ", ".join(nav))
    check("team leader: the office screens are not offered",
          not {"finance", "invoices", "chemicals", "agents", "devices"} & set(nav),
          ", ".join(sorted({"finance", "invoices", "chemicals", "agents", "devices"} & set(nav))))
    page.evaluate("() => navigate('myteam')")
    page.wait_for_timeout(1600)
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("team leader: My Team lists the engineer who reports to them",
          "Yousef" in body, body[:150])
    # The table's area column still names where the engineer is working — what
    # must not appear is the "my areas" strip, which belongs to the other role.
    check("team leader: it does not claim to hold any areas",
          "My areas" not in body and "مناطقي" not in body, body[:150])
    check("team leader: every label on it is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))
    page.evaluate("() => navigate('dashboard')")
    page.wait_for_timeout(1600)
    dash = page.evaluate("() => document.getElementById('view').innerText")
    check("team leader: the dashboard counts their team, not an area",
          "Engineers on my team" in dash or "مهندسو فريقي" in dash, dash[:200])
    check("team leader: no money reaches the dashboard",
          "Outstanding" not in dash and "Revenue" not in dash, dash[:150])
    check("team leader: every label on the dashboard is translated", not raw_keys(dash),
          ", ".join(raw_keys(dash)[:4]))
    check("team leader: the phone layout does not scroll sideways",
          page.evaluate("() => document.documentElement.scrollWidth <= window.innerWidth"))
    check("team leader: their screens raise no script error", not perrors, "; ".join(perrors[:2]))
    page.close()


def roster_checks(browser):
    """Rostering by AREA, with no clock involved.

    The office this is for does not run 08:00–16:00 blocks: the day is defined
    by WHERE someone works. So the test drives the simple path — pick an area,
    pick everyone, save — and asserts the hours never appear, that a second
    area can join the same day, and that the by-area grid answers "who covers
    Maadi on Tuesday" without reading down every engineer's row."""
    print("\nROSTER BY AREA")
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(1600)

    page.evaluate("() => document.getElementById('sh-area').click()")
    page.wait_for_timeout(1200)
    check("roster: the area dialog opens",
          page.evaluate("() => !!document.getElementById('saf')"))
    check("roster: the hours-free shift is the default",
          "cover" in page.evaluate("""() => { const s=document.querySelector('[name=shift_type_id]');
              return s.options[s.selectedIndex].text.toLowerCase(); }"""))
    check("roster: no clock is shown for it",
          page.evaluate("""() => [...document.querySelectorAll('.saf-hours')]
              .every(e => e.style.display === 'none')"""))
    # Any shift that is not the hours-free one. The labels carry no times, so
    # they cannot be matched on a digit — pick by what it is NOT.
    page.evaluate("""() => { const s=document.querySelector('[name=shift_type_id]');
        const hourly=[...s.options].find(o => !o.text.toLowerCase().includes('cover'));
        s.value = hourly.value;
        s.dispatchEvent(new Event('change')); }""")
    page.wait_for_timeout(400)
    check("roster: choosing a shift WITH hours brings the clock back",
          page.evaluate("""() => [...document.querySelectorAll('.saf-hours')]
              .every(e => e.style.display !== 'none')"""))
    # Back to area cover, everyone, save.
    page.evaluate("""() => { const s=document.querySelector('[name=shift_type_id]');
        for (const o of s.options) if (o.text.toLowerCase().includes('cover')) s.value = o.value;
        s.dispatchEvent(new Event('change'));
        document.getElementById('saf-all').click(); }""")
    page.wait_for_timeout(300)
    errors.clear()
    page.evaluate("() => document.getElementById('saf-save').click()")
    page.wait_for_timeout(2400)
    check("roster: saving an area roster raises nothing", not errors, "; ".join(errors[:2]))

    page.evaluate("""() => { const m=document.getElementById('sh-mode');
        m.value='area'; m.dispatchEvent(new Event('change')); }""")
    page.wait_for_timeout(1800)
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("roster: the by-area grid renders", not errors, "; ".join(errors[:2]))
    check("roster: it has a row per area and a cell per day",
          page.evaluate("() => document.querySelectorAll('[data-arearow]').length") >= 7)
    check("roster: the engineers just rostered are named in it",
          page.evaluate("() => document.querySelectorAll('.ar-who').length") > 0)
    check("roster: every label on it is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))
    # Clicking a day of an area opens the dialog already pointed at it.
    page.evaluate("() => document.querySelector('[data-arearow]').click()")
    page.wait_for_timeout(1200)
    check("roster: clicking an area's day opens the dialog on that area",
          page.evaluate("""() => { const f=document.getElementById('saf'); if (!f) return false;
              const a=document.querySelector('[name=area_id]');
              const ticked=[...document.querySelectorAll('.sh-day:checked')];
              return !!a.value && ticked.length === 1; }"""))
    page.close()


def auto_roster_checks(browser):
    """The one button, end to end, through the screens that feed it.

    The office's whole complaint was doing this by hand, one engineer at a
    time. So the test proves the two halves of the escape: that the whole team
    is set up on ONE screen and comes back saved, and that the button then
    proposes a week — visibly, before anything is written — and writes exactly
    what it showed."""
    print("\nAUTO-ROSTER")
    adm = _token("admin@pestcrm.com", "admin123")
    # A branch only enters the plan if it says how often it needs a visit and
    # when it will take one. That is the office's data, so it goes in as the
    # office would put it in.
    for site in _api("GET", "/sites", adm):
        _api("PUT", f"/sites/{site['id']}", adm,
             {"visits_per_month": 8, "service_from": "09:00", "service_to": "16:00"})
    before = {v["id"] for v in _api("GET", "/visits", adm)}

    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("console", lambda m: errors.append(m.text) if m.type == "error" else None)
    page.on("dialog", lambda d: d.accept())
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    # --- the whole team on one screen ---
    page.evaluate("() => navigate('availability')")
    page.wait_for_timeout(1600)
    check("availability: the board renders", not errors, "; ".join(errors[:2]))
    check("availability: it shows every engineer at once, not one at a time",
          page.evaluate("() => document.querySelectorAll('[data-row]').length") >= 2)
    check("availability: seven days per engineer",
          page.evaluate("""() => { const r=document.querySelector('[data-row]');
              return r ? r.querySelectorAll('.av-day').length : 0; }""") == 7)
    check("availability: hours stay hidden until a day is worked",
          page.evaluate("""() => [...document.querySelectorAll('.av-day:not(.av-on) .av-hours')]
              .every(e => e.style.display === 'none')"""))
    # Tick every day and every area for everybody — the bulk gesture the screen
    # exists for — and check the hours appear on the days now worked.
    page.evaluate("""() => {
        document.querySelectorAll('.av-wd').forEach(cb => {
          if (!cb.checked) { cb.checked = true; cb.dispatchEvent(new Event('change')); } });
        document.querySelectorAll('.av-area').forEach(cb => { cb.checked = true; }); }""")
    page.wait_for_timeout(400)
    check("availability: ticking a day reveals its hours",
          page.evaluate("""() => [...document.querySelectorAll('.av-hours')]
              .every(e => e.style.display !== 'none')"""))
    errors.clear()
    page.evaluate("() => document.getElementById('av-save').click()")
    page.wait_for_timeout(2200)
    check("availability: one save for the whole board raises nothing", not errors,
          "; ".join(errors[:2]))
    # Come back to it: what was saved is what is shown.
    page.evaluate("() => navigate('dashboard')")
    page.wait_for_timeout(900)
    page.evaluate("() => navigate('availability')")
    page.wait_for_timeout(1600)
    check("availability: the days saved come back ticked",
          page.evaluate("() => document.querySelectorAll('.av-wd:checked').length") >= 7)
    check("availability: the areas saved come back ticked",
          page.evaluate("() => document.querySelectorAll('.av-area:checked').length") >= 1)
    body = page.evaluate("() => document.getElementById('view').innerText")
    check("availability: every label on it is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))

    # --- filling an area from its own row, instead of branch by branch ---
    page.evaluate("() => navigate('areas')")
    page.wait_for_timeout(1500)
    check("area branches: every area row offers the picker",
          page.evaluate("() => document.querySelectorAll('[data-branches]').length") >= 2)
    page.evaluate("""() => document.querySelector('#ar-list [data-branches]').click()""")
    page.wait_for_timeout(1200)
    check("area branches: the dialog lists the branches to tick",
          page.evaluate("() => document.querySelectorAll('.ab-site').length") >= 2)
    check("area branches: it says how many are ticked",
          page.evaluate("""() => (document.getElementById('ab-sum')||{}).innerText || ''""")
          .strip() != "")
    body = page.evaluate("() => document.getElementById('modal-body').innerText")
    check("area branches: every label on it is translated", not raw_keys(body),
          ", ".join(raw_keys(body)[:4]))
    # Ticking a branch that is somewhere else shows the move BEFORE it is saved.
    moved = page.evaluate("""() => {
        const row = [...document.querySelectorAll('.ab-row')]
          .find(r => r.dataset.in === '0');
        if (!row) return false;
        const cb = row.querySelector('.ab-site');
        cb.checked = true; cb.dispatchEvent(new Event('change', {bubbles: true}));
        return (document.getElementById('ab-sum').innerText || '').includes('1'); }""")
    check("area branches: ticking one shows what is about to move", moved)
    errors.clear()
    page.evaluate("() => document.getElementById('ab-save').click()")
    page.wait_for_timeout(2000)
    check("area branches: saving the move raises nothing", not errors, "; ".join(errors[:2]))
    check("area branches: the dialog closes on save",
          page.evaluate("() => document.getElementById('modal-overlay').classList.contains('hidden')"))

    # --- zones: the grouping that lets one round hold two nearby areas ---
    page.evaluate("() => navigate('areas')")
    page.wait_for_timeout(1500)
    check("zones: the areas page offers zones too",
          page.evaluate("() => !!document.getElementById('zn-add')"))
    page.evaluate("() => document.getElementById('zn-add').click()")
    page.wait_for_timeout(900)
    check("zones: the dialog lists the areas to group",
          page.evaluate("() => document.querySelectorAll('.zn-area').length") >= 2)
    errors.clear()
    page.evaluate("""() => {
        document.querySelector('#zn-form [name=name_en]').value = 'West';
        document.querySelectorAll('.zn-area').forEach(cb => { cb.checked = true; });
        document.querySelector('#zn-form button[type=submit]').click(); }""")
    page.wait_for_timeout(2200)
    check("zones: saving a zone raises nothing", not errors, "; ".join(errors[:2]))
    check("zones: the new zone is listed with its areas",
          page.evaluate("""() => { const b=document.getElementById('zn-list');
              return !!b && b.innerText.includes('West')
                  && b.querySelectorAll('.dp-area').length >= 2; }"""))

    # --- one button: propose, then agree ---
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(1600)
    check("auto: the Shifts page carries the button",
          page.evaluate("() => !!document.getElementById('sh-auto')"))
    page.evaluate("() => document.getElementById('sh-auto').click()")
    page.wait_for_timeout(1000)
    check("auto: the dialog opens on the week being viewed",
          page.evaluate("""() => { const f=document.getElementById('arf');
              return !!f && !!f.querySelector('[name=from]').value
                  && !!f.querySelector('[name=to]').value; }"""))
    errors.clear()
    page.evaluate("() => document.getElementById('arf-go').click()")
    page.wait_for_timeout(3000)
    check("auto: previewing raises nothing", not errors, "; ".join(errors[:2]))
    check("auto: the plan is shown before anything is written",
          page.evaluate("() => document.querySelectorAll('.auto-summary .sc-chip').length") >= 3)
    check("auto: it says who goes where",
          page.evaluate("() => document.querySelectorAll('.ar-line .ar-who').length") > 0
          and page.evaluate("() => document.querySelectorAll('.ar-line .dp-area').length") > 0)
    check("auto: a preview writes nothing",
          {v["id"] for v in _api("GET", "/visits", adm)} == before)
    out = page.evaluate("() => document.getElementById('ar-out').innerText")
    check("auto: every label in the plan is translated", not raw_keys(out),
          ", ".join(raw_keys(out)[:4]))

    errors.clear()
    page.evaluate("() => document.getElementById('arf-apply').click()")
    page.wait_for_timeout(4000)
    check("auto: applying raises nothing", not errors, "; ".join(errors[:2]))
    check("auto: the dialog closes once the plan is agreed",
          not page.evaluate("() => !!document.getElementById('arf')"))
    fresh = [v for v in _api("GET", "/visits", adm) if v["id"] not in before]
    check("auto: the plan it showed is the work it booked", len(fresh) > 0)
    check("auto: every visit it booked has an engineer on it",
          bool(fresh) and all(v.get("agent_id") for v in fresh))
    check("auto: the engineers are rostered onto the areas it sent them to",
          any(s.get("area_id") for s in _api("GET", "/shifts", adm)))

    # --- and the way back out: clear a slice of the board and start again ---
    # Deliberately pinned to ONE far-off date this block owns, so wiping it
    # cannot pull the rug from under anything else in the suite.
    far = (datetime.date.today() + datetime.timedelta(days=400)).isoformat()
    any_site = _api("GET", "/sites", adm)[0]
    _api("POST", "/visits", adm, {"client_id": any_site["client_id"],
                                  "site_id": any_site["id"],
                                  "scheduled_start": far + "T09:00",
                                  "ignore_conflict": True})
    page.evaluate("() => navigate('shifts')")
    page.wait_for_timeout(1600)
    check("clear: the Shifts page carries the clear button",
          page.evaluate("() => !!document.getElementById('sh-clear')"))
    page.evaluate("() => document.getElementById('sh-clear').click()")
    page.wait_for_timeout(900)
    check("clear: the dialog offers every filter the office asked for",
          page.evaluate("""() => { const f=document.getElementById('clf');
              return !!f && ['from','to','agent_id','area_id','client_id','site_id','what']
                  .every(n => !!f.querySelector('[name='+n+']')); }"""))
    errors.clear()
    page.evaluate(f"""() => {{ const f=document.getElementById('clf');
        f.querySelector('[name=from]').value = '{far}';
        f.querySelector('[name=to]').value = '{far}';
        document.getElementById('clf-go').click(); }}""")
    page.wait_for_timeout(2500)
    check("clear: previewing raises nothing", not errors, "; ".join(errors[:2]))
    out = page.evaluate("() => document.getElementById('cl-out').innerText")
    check("clear: it says what it would delete, before deleting it", "1" in out)
    check("clear: every word of it is translated", not raw_keys(out),
          ", ".join(raw_keys(out)[:4]))
    check("clear: previewing deletes nothing",
          any(v["scheduled_start"][:10] == far for v in _api("GET", "/visits", adm)))
    errors.clear()
    page.evaluate("() => { window.confirm = () => true; "
                  "document.getElementById('clf-do').click(); }")
    page.wait_for_timeout(2500)
    check("clear: agreeing raises nothing", not errors, "; ".join(errors[:2]))
    check("clear: the dialog closes once it is done",
          not page.evaluate("() => !!document.getElementById('clf')"))
    check("clear: and that day is off the book",
          not any(v["scheduled_start"][:10] == far for v in _api("GET", "/visits", adm)))
    page.close()


def calendar_filter_checks(browser):
    """FILTERING THE MONTH BY ENGINEER MUST SHOW THE DAYS HE WORKS.

    His words: "when i choose engineer in filter i dosnt get me all days he
    works, in some is blank — i have to choose day to see it, but i want to see
    it from outside in month too".

    The month cell only ever DREW the first four visits of a day and hid the
    rest behind "+N"; the engineer filter then hid what was drawn. On a book
    where a day carries twenty-eight visits, an engineer's own job is almost
    never in that four — so his day reads as blank until the day is opened.

    The fixture is built to reproduce exactly that: one day carrying five visits
    for one engineer and a single early visit for another. It owns its own
    company, branch and month — a rule about what a cell shows cannot be proved
    on days another block is booking into."""
    print("\nCALENDAR FILTERED BY ENGINEER")
    adm = _token("admin@pestcrm.com", "admin123")
    users = _api("GET", "/users", adm)
    engineers = [u for u in (users if isinstance(users, list) else users["items"])
                 if u["role"] == "agent" and u["active"]]
    if len(engineers) < 2:
        check("calendar: two engineers exist to tell apart", False)
        return
    mine, other = engineers[0], engineers[1]
    co = _api("POST", "/clients", adm, {"name_en": "Calendar Co"})
    site = _api("POST", f"/clients/{co['id']}/sites", adm, {"name": "Calendar Branch"})
    DAY, QUIET = "2099-04-14", "2099-04-15"
    # Five visits for the OTHER engineer, later in the day, so they are the ones
    # a "first four" would draw...
    for hh in ("10", "12", "14", "16", "18"):
        _api("POST", "/visits", adm, {"client_id": co["id"], "site_id": site["id"],
             "agent_id": other["id"], "scheduled_start": f"{DAY} {hh}:00:00",
             "ignore_conflict": True})
    # ...and one early visit for the engineer being looked for, which the old
    # cell never put on the page at all.
    _api("POST", "/visits", adm, {"client_id": co["id"], "site_id": site["id"],
         "agent_id": mine["id"], "scheduled_start": f"{DAY} 08:00:00",
         "ignore_conflict": True})
    # A second day where only the OTHER engineer works, to prove the filter
    # still empties a day that really is empty for him.
    _api("POST", "/visits", adm, {"client_id": co["id"], "site_id": site["id"],
         "agent_id": other["id"], "scheduled_start": f"{QUIET} 09:00:00",
         "ignore_conflict": True})

    ctx = browser.new_context(viewport={"width": 1440, "height": 1000},
                              service_workers="block")   # see fast_save_checks
    page = ctx.new_page()
    errors, calls = [], []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("request", lambda r: calls.append(r.url) if "/api/" in r.url else None)
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")
    page.evaluate("() => navigate('calendar', { month: '2099-04' })")
    page.wait_for_timeout(2000)

    cell = """(d) => { const el = [...document.querySelectorAll('[data-calday]')]
        .find(x => x.dataset.calday === d);
        if (!el) return null;
        const box = el.parentElement;
        return { shown: [...box.querySelectorAll('.cal-ev')]
                   .filter(e => e.offsetParent !== null).length,
                 more: (box.innerText.match(/\+(\d+)/) || [null, null])[1],
                 first: (box.querySelector('.cal-ev') || {}).title || "" }; }"""
    check("calendar: the month opened on the fixture's month",
          page.evaluate(cell, DAY) is not None)
    before = page.evaluate(cell, DAY)
    check("calendar: an unfiltered day shows the busiest day's work",
          bool(before) and before["shown"] == 4 and before["more"] == "2",
          f"{before}")

    # THE BUG: pick the engineer whose only visit that day is the early one.
    calls.clear()
    page.evaluate("""(id) => { const s = document.getElementById('cal-agent');
        s.value = String(id); s.dispatchEvent(new Event('change', {bubbles:true})); }""",
                  mine["id"])
    page.wait_for_timeout(1200)
    after = page.evaluate(cell, DAY)
    check("calendar: filtering to an engineer shows the day he works",
          bool(after) and after["shown"] == 1, f"{after}")
    check("calendar: and does not still promise more behind a +N",
          bool(after) and not after["more"], f"{after}")
    quiet = page.evaluate(cell, QUIET)
    check("calendar: a day he does not work stays empty",
          bool(quiet) and quiet["shown"] == 0, f"{quiet}")
    check("calendar: filtering re-reads nothing — the month is already in hand",
          not [c for c in calls if "/api/visits" in c], f"{calls}")

    # A month grid reads earliest-first; the old one drew the LAST four of a day.
    page.evaluate("""() => { const s = document.getElementById('cal-agent');
        s.value = ''; s.dispatchEvent(new Event('change', {bubbles:true})); }""")
    page.wait_for_timeout(900)
    check("calendar: the day's visits read in time order",
          page.evaluate("""(d) => { const el = [...document.querySelectorAll('[data-calday]')]
              .find(x => x.dataset.calday === d);
              const evs = [...el.parentElement.querySelectorAll('.cal-ev')];
              return evs.length >= 2; }""", DAY))

    # Flipping the month must not lose who you were looking at.
    page.evaluate("""(id) => { const s = document.getElementById('cal-agent');
        s.value = String(id); s.dispatchEvent(new Event('change', {bubbles:true})); }""",
                  mine["id"])
    page.wait_for_timeout(700)
    page.evaluate("() => document.getElementById('cal-next').click()")
    page.wait_for_timeout(1800)
    check("calendar: the engineer is still chosen in the next month",
          page.evaluate("""(id) => { const s = document.getElementById('cal-agent');
              return !!s && String(s.value) === String(id); }""", mine["id"]))
    check("calendar: filtering the month raises no script error", not errors,
          "; ".join(errors[:2]))
    ctx.close()


def fast_save_checks(browser):
    """A SAVE SHOULD COST ONE ROUND TRIP, NOT A WHOLE SCREEN.

    Measured on a copy of his book (see /root/perf-audit-2026-08-25/): saving one
    branch from the Branches list cost 835 ms on a real phone link — a PUT, then
    a 241 KB re-fetch of every branch in the company, then the whole screen
    rebuilt, to change one row. This block holds the three screens the audit
    named to the rule the audit implied:

      * exactly ONE request per save — the save itself;
      * no full-list GET afterwards;
      * only the edited row is rebuilt (every other row keeps a sentinel);
      * the row shows the NEW value and no stale copy of the old one survives;
      * counters that really can change (the branch gap bar) still update;
      * a FAILED save changes nothing at all and keeps the dialog open;
      * the page does not move — the scroll behaviour shipped in c5b0d41 holds.

    It owns its fixture: a rule about what a save re-fetches cannot be proved on
    rows another block is editing."""
    print("\nA SAVE COSTS ONE ROUND TRIP")
    adm = _token("admin@pestcrm.com", "admin123")
    areas = _api("GET", "/areas", adm)
    area_id = areas[0]["id"] if areas else None
    co = _api("POST", "/clients", adm, {"name_en": "Fast Save Co", "phone": "0100"})
    sites = [_api("POST", f"/clients/{co['id']}/sites", adm,
                  {"name": f"Fast Branch {i}", "address": "old address",
                   "area_id": area_id, "visits_per_month": 2}) for i in range(4)]
    svc = _api("GET", "/service-types", adm)
    for i in range(3):
        _api("POST", "/visits", adm, {"client_id": co["id"], "site_id": sites[i]["id"],
             "scheduled_start": f"2099-03-0{i+1} 09:00:00",
             "service_type_id": (svc[0]["id"] if svc else None), "ignore_conflict": True})

    # NO SERVICE WORKER ON THIS PAGE. This block counts the requests a save
    # makes, and the app deliberately reloads itself when the worker reports new
    # code waiting — a reload landing inside the measured window counts a whole
    # app boot against one save and fails the run for no reason. The worker has
    # its own block (offline_sweep); here it is only noise.
    ctx = browser.new_context(viewport={"width": 1440, "height": 1000},
                              service_workers="block")
    page = ctx.new_page()
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.on("dialog", lambda d: d.accept())
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")
    # AND NO OFFLINE WARM-UP EITHER. warmOfflineCache() starts at login and walks
    # a long list of GETs one at a time; on a busy machine it is still running
    # when the first save is measured, and its reads are then counted against
    # that save ("PUT sites/32, GET dashboard, GET clients, GET visits…"). It is
    # not the save's traffic, so wait it out rather than race it.
    try:
        page.wait_for_function(
            "() => typeof warming === 'undefined' || warming === false", timeout=45000)
    except Exception:
        pass

    calls = []

    def watch(r):
        if "/api/" in r.url:
            calls.append(r.method + " " + r.url.split("/api/")[-1].split("?")[0])

    page.on("request", watch)

    def during(fn, ms=2600):
        calls.clear()
        fn()
        page.wait_for_timeout(ms)
        return list(calls)

    def mark_rows(sel):
        """Tag every row on screen. A row that still carries the tag afterwards
        was NOT rebuilt — which is how "only the edited row changed" is proved
        rather than assumed."""
        page.evaluate("""(s) => document.querySelectorAll(s)
            .forEach(tr => tr.setAttribute('data-sentinel', '1'))""", sel)

    def sentinels(sel):
        return page.evaluate("""(s) => [...document.querySelectorAll(s)]
            .filter(tr => tr.getAttribute('data-sentinel') === '1').length""", sel)

    # ---------- 1. the Branches list ------------------------------------
    page.evaluate("() => navigate('locations')")
    page.wait_for_timeout(2000)
    page.evaluate("""() => { const q = document.getElementById('loc-q');
        q.value = 'Fast Branch'; q.dispatchEvent(new Event('input', {bubbles:true})); }""")
    page.wait_for_timeout(400)
    rows_sel = "#loc-body tr:not(.hidden)"
    mark_rows("#loc-body tr")
    before_rows = page.evaluate("(s) => document.querySelectorAll(s).length", rows_sel)
    page.evaluate("""() => { const b = [...document.querySelectorAll('#loc-body tr:not(.hidden) [data-siteedit]')][0];
        b.scrollIntoView({block:'center'}); b.click(); }""")
    page.wait_for_timeout(900)
    scroll_before = page.evaluate("() => Math.round(window.scrollY)")
    made = during(lambda: page.evaluate("""() => {
        document.querySelector('#sf [name=address]').value = 'PATCHED ADDRESS';
        document.querySelector('#sf button[type=submit]').click(); }"""))
    check("branches: one save = one request", made == [f"PUT sites/{sites[0]['id']}"],
          f"sent {made}")
    check("branches: no full-list GET after a save",
          not any(c in ("GET sites", "GET clients") for c in made), f"sent {made}")
    body = page.evaluate("() => document.getElementById('loc-body').innerText")
    check("branches: the row shows the new value", "PATCHED ADDRESS" in body)
    check("branches: no stale copy of the old value is left",
          body.count("old address") == before_rows - 1, body[:120])
    check("branches: only the edited row was rebuilt",
          sentinels("#loc-body tr") == page.evaluate(
              "() => document.querySelectorAll('#loc-body tr').length") - 1)
    check("branches: the page did not move",
          abs(page.evaluate("() => Math.round(window.scrollY)") - scroll_before) <= 4)

    # the gap bar counts branches with no area — clearing one must move it
    gap_before = page.evaluate("""() => { const b = document.querySelector('[data-gapfilter="area"]');
        return b ? parseInt(b.innerText.replace(/[^0-9]/g, ''), 10) : 0; }""")
    page.evaluate("""() => { const b = [...document.querySelectorAll('#loc-body tr:not(.hidden) [data-siteedit]')][1];
        b.click(); }""")
    page.wait_for_timeout(900)
    made = during(lambda: page.evaluate("""() => {
        const sel = document.querySelector('#sf [name=area_id]'); sel.value = '';
        document.querySelector('#sf button[type=submit]').click(); }"""))
    gap_after = page.evaluate("""() => { const b = document.querySelector('[data-gapfilter="area"]');
        return b ? parseInt(b.innerText.replace(/[^0-9]/g, ''), 10) : 0; }""")
    check("branches: taking a branch's area away updates the gap counter",
          gap_after == gap_before + 1, f"{gap_before} -> {gap_after}")
    check("branches: and still only one request", len(made) == 1, f"sent {made}")

    # A SAVE THAT FAILS MUST CHANGE NOTHING.
    page.evaluate("""() => { const b = [...document.querySelectorAll('#loc-body tr:not(.hidden) [data-siteedit]')][2];
        b.click(); }""")
    page.wait_for_timeout(900)
    page.route("**/api/sites/*", lambda route: route.fulfill(
        status=500, content_type="application/json", body='{"error":"nope"}'))
    during(lambda: page.evaluate("""() => {
        document.querySelector('#sf [name=address]').value = 'MUST NOT APPEAR';
        document.querySelector('#sf button[type=submit]').click(); }"""), 2000)
    page.unroute("**/api/sites/*")
    body = page.evaluate("() => document.getElementById('loc-body').innerText")
    check("branches: a failed save leaves the table untouched", "MUST NOT APPEAR" not in body)
    check("branches: and leaves the dialog open to try again",
          not page.evaluate("() => document.getElementById('modal-overlay').classList.contains('hidden')"))
    page.evaluate("closeModal && closeModal()")

    # ---------- 2. the company folder -----------------------------------
    page.evaluate("id => navigate('client', {id})", str(co["id"]))
    page.wait_for_timeout(2000)
    mark_rows("#sites-body tr")
    scroll_before = page.evaluate("() => Math.round(window.scrollY)")
    page.evaluate("""() => { const b = document.querySelector('#sites-body [data-editsite]');
        b.click(); }""")
    page.wait_for_timeout(900)
    made = during(lambda: page.evaluate("""() => {
        document.querySelector('#sf [name=address]').value = 'FOLDER PATCHED';
        document.querySelector('#sf button[type=submit]').click(); }"""))
    check("folder: editing a branch = one request", len(made) == 1 and made[0].startswith("PUT sites/"),
          f"sent {made}")
    check("folder: it does not re-read the company or its maps",
          not any(c.startswith("GET clients") for c in made), f"sent {made}")
    check("folder: the branch row shows the new value",
          "FOLDER PATCHED" in page.evaluate("() => document.getElementById('sites-body').innerText"))
    check("folder: only that branch row was rebuilt",
          sentinels("#sites-body tr") == page.evaluate(
              "() => document.querySelectorAll('#sites-body tr').length") - 1)

    # the company itself
    made = during(lambda: (page.evaluate("() => document.getElementById('edit-client').click()"),
                           page.wait_for_timeout(900),
                           page.evaluate("""() => {
                               document.querySelector('#cf [name=phone]').value = '0999888777';
                               document.querySelector('#cf button[type=submit]').click(); }""")))
    check("folder: editing the company = one request",
          [c for c in made if c.startswith("PUT")] == [f"PUT clients/{co['id']}"]
          and not any(c.startswith("GET") for c in made), f"sent {made}")
    check("folder: the company panel shows the new phone",
          "0999888777" in page.evaluate("() => document.getElementById('view').innerText"))
    check("folder: the page did not move",
          abs(page.evaluate("() => Math.round(window.scrollY)") - scroll_before) <= 4)

    # ---------- 3. the Schedule screen ----------------------------------
    # OWN THE FIXTURE HERE TOO: the Schedule list holds every visit in the book,
    # and which one lands at the top depends on the sort order the page defaults
    # to (soonest first). Picking "the first edit button" therefore measured a
    # visit from the seed — one with no branch, whose save stops at "pick a
    # location" and sends nothing. Filter the screen down to this block's own
    # 2099 visits so the rule is proved on rows this block created.
    page.evaluate("() => navigate('schedule')")
    page.wait_for_timeout(2200)
    page.evaluate("""() => { const f = document.getElementById('f-from');
        f.value = '2099-01-01'; f.dispatchEvent(new Event('change')); }""")
    page.wait_for_timeout(1600)
    mark_rows("#visit-list tr[data-visit]")
    n_before = page.evaluate("() => document.querySelectorAll('#visit-list tr[data-visit]').length")
    scroll_before = page.evaluate("() => Math.round(window.scrollY)")
    evid = page.evaluate("""() => { const b = document.querySelector('#visit-list [data-editvisit]');
        return b ? b.dataset.editvisit : null; }""")
    page.evaluate("""() => document.querySelector('#visit-list [data-editvisit]').click()""")
    page.wait_for_timeout(1400)
    made = during(lambda: page.evaluate("""() => {
        const a = document.querySelector('#vf [name=agent_id]');
        if (a && a.options.length > 1) a.selectedIndex = a.options.length - 1;
        document.querySelector('#vf button[type=submit]').click(); }"""))
    check("schedule: editing a visit = one request", made == [f"PUT visits/{evid}"],
          f"sent {made}")
    check("schedule: the list of visits is NOT re-fetched",
          "GET visits" not in made, f"sent {made}")
    check("schedule: only the edited visit row was rebuilt",
          sentinels("#visit-list tr[data-visit]") == n_before - 1,
          f"{sentinels('#visit-list tr[data-visit]')} of {n_before} kept their tag")
    check("schedule: the page did not move",
          abs(page.evaluate("() => Math.round(window.scrollY)") - scroll_before) <= 4)

    vid = page.evaluate("""() => { const b = document.querySelector('#visit-list [data-delvisit]');
        return b ? b.dataset.delvisit : null; }""")
    made = during(lambda: page.evaluate("""() => document.querySelector('#visit-list [data-delvisit]').click()"""))
    check("schedule: deleting a visit = one request", made == [f"DELETE visits/{vid}"], f"sent {made}")
    check("schedule: the deleted row is gone and the others stayed",
          page.evaluate("() => document.querySelectorAll('#visit-list tr[data-visit]').length") == n_before - 1
          and not page.evaluate("(id) => !!document.querySelector(`tr[data-visit='${id}']`)", vid))
    check("schedule: no visit list re-fetch after a delete either",
          "GET visits" not in made, f"sent {made}")

    # ---------- 4. the two duplicate GETs the audit found ----------------
    page.evaluate("() => navigate('areas')")
    page.wait_for_timeout(1800)
    page.evaluate("""() => document.querySelector('#ar-list [data-branches]').click()""")
    page.wait_for_timeout(1400)
    moved = page.evaluate("""() => { const r = [...document.querySelectorAll('.ab-row')]
        .find(x => x.dataset.in === '0');
        if (!r) return false; const cb = r.querySelector('.ab-site');
        cb.checked = true; cb.dispatchEvent(new Event('change', {bubbles:true})); return true; }""")
    if moved:
        made = during(lambda: page.evaluate("() => document.getElementById('ab-save').click()"))
        check("areas: the area list is read once, not twice",
              len([c for c in made if c == "GET areas"]) == 1, f"sent {made}")
    page.evaluate("() => navigate('chemicals')")
    page.wait_for_timeout(1800)
    if page.evaluate("() => !!document.querySelector('#view [data-edit]')"):
        page.evaluate("() => document.querySelector('#view [data-edit]').click()")
        page.wait_for_timeout(900)
        made = during(lambda: page.evaluate(
            "() => document.querySelector('#modal-body form button[type=submit]').click()"))
        check("chemicals: the chemical list is read once, not twice",
              len([c for c in made if c == "GET chemicals"]) == 1, f"sent {made}")

    check("saving in place raises no script error", not errors, "; ".join(errors[:2]))
    page.remove_listener("request", watch)
    ctx.close()


def stay_in_place_checks(browser):
    """SAVING SOMETHING MUST NOT THROW YOU BACK TO THE TOP OF THE PAGE.

    He reported it on Branches and asked for it everywhere: "every change or
    edit ... dont make it relod and get to the top page just make it save and
    stay where i am". Most screens re-render themselves after a save by calling
    navigate() again; that empties the page for a moment, the browser clamps
    the scroll to 0 because there is nothing left to scroll, and the office is
    back at row 1 of 179.

    Measured the way the eye measures it: WHERE THE ROW YOU EDITED SITS IN THE
    WINDOW, before opening the dialog and after saving. The scroll number alone
    lies on a screen that loads part of itself late."""
    print("\nSAVING KEEPS YOUR PLACE")
    adm = _token("admin@pestcrm.com", "admin123")
    # A list taller than the window, or there is nothing to be thrown off.
    areas = _api("GET", "/areas", adm)
    made = _api("POST", "/clients", adm, {"name_en": "Stay Put Co"})
    for i in range(24):
        _api("POST", f"/clients/{made['id']}/sites", adm,
             {"name": f"Stay Put Branch {i:02d}", "address": "somewhere",
              "area_id": areas[0]["id"] if areas else None, "visits_per_month": 1})

    def run(page, who, view, opener, arg=None):
        if arg is None:
            page.evaluate("v => navigate(v)", view)
        else:
            page.evaluate("a => navigate(a[0], a[1])", [view, arg])
        page.wait_for_timeout(1800)
        found = page.evaluate("""(sel) => { const e=[...document.querySelectorAll(sel)];
            if (!e.length) return false;
            e[e.length-1].scrollIntoView({block: 'center'}); return true; }""", opener)
        check(f"{who}: {view} has rows to edit", found)
        if not found:
            return
        page.wait_for_timeout(400)
        row_before = page.evaluate("""(sel) => { const e=[...document.querySelectorAll(sel)];
            const r = e[e.length-1].closest('tr,li,.card,div');
            return r ? Math.round(r.getBoundingClientRect().top) : null; }""", opener)
        was = page.evaluate("() => Math.round(window.scrollY)")
        check(f"{who}: {view} is scrolled away from the top to begin with", was > 100)
        page.evaluate("""(sel) => { const e=[...document.querySelectorAll(sel)];
            e[e.length-1].click(); }""", opener)
        page.wait_for_timeout(900)
        opened = page.evaluate(
            "() => !document.getElementById('modal-overlay').classList.contains('hidden')")
        check(f"{who}: {view} opens the edit dialog", opened)
        if not opened:
            return
        page.evaluate("""() => { const b = document.querySelector('#modal-body form button[type=submit]')
            || document.querySelector('#modal-body button[type=submit]'); if (b) b.click(); }""")
        page.wait_for_timeout(2600)
        closed = page.evaluate(
            "() => document.getElementById('modal-overlay').classList.contains('hidden')")
        check(f"{who}: {view} saves and closes the dialog", closed)
        now = page.evaluate("() => Math.round(window.scrollY)")
        row_after = page.evaluate("""(sel) => { const e=[...document.querySelectorAll(sel)];
            if (!e.length) return null;
            const r = e[e.length-1].closest('tr,li,.card,div');
            return r ? Math.round(r.getBoundingClientRect().top) : null; }""", opener)
        # The row must still be where it was, and the page must not have been
        # thrown to the top. Both, because either one alone can pass by luck.
        check(f"{who}: saving on {view} leaves the page where it was",
              now > 100 and row_after is not None and abs(row_after - row_before) <= 40,
              f"scroll {was}->{now}, row {row_before}->{row_after}")

    for who, vp, mobile in (("office", {"width": 1440, "height": 1000}, False),
                            ("phone", {"width": 390, "height": 844}, True)):
        page = browser.new_page(viewport=vp, is_mobile=mobile, has_touch=mobile)
        errors = []
        page.on("pageerror", lambda e: errors.append(str(e)))
        page.on("dialog", lambda d: d.accept())
        page.goto(BASE + "/", wait_until="networkidle")
        page.fill("#login-email", "admin@pestcrm.com")
        page.fill("#login-password", "admin123")
        page.click("#login-form button[type=submit]")
        page.wait_for_timeout(2500)
        page.evaluate("closeModal && closeModal()")
        # Three screens, three different ways of re-rendering after a save:
        # the branch list (navigate by name), the company folder (navigate with
        # an argument) and Chemicals (which fetches part of itself late).
        run(page, who, "locations", "[data-siteedit]")
        run(page, who, "client", "[data-editsite]", {"id": str(made["id"])})
        run(page, who, "chemicals", "[data-edit]")
        check(f"{who}: keeping your place raises no script error", not errors,
              "; ".join(errors[:2]))
        page.close()


def permission_change_checks(browser):
    """A CHANGE OF ACCESS HAS TO REACH THE APP THAT IS ALREADY OPEN.

    He reported it plainly: "the rbac is not applying any role i choose on the
    engineer or on the general role ... it always doesnt apply when i open with
    the engineer i changed his rbac". The server was right the whole time — a
    fresh login always carried the new permissions. What was wrong is that
    NOTHING EVER ASKED IT AGAIN. can() reads the map that landed in
    localStorage at login and was refreshed once more in boot(), on a full page
    load, and a full page load is the one thing an installed app never does:
    the Android WebView restores the open page on resume, pull-to-refresh is
    off, and the CRM's own refresh button only re-fetched the current screen.
    So the office granted, the engineer opened the app, and nothing changed —
    for days.

    Measured the way it failed: the page is NEVER RELOADED here. A marker is
    set on window and must still be there afterwards, or the test would be
    proving the fix by doing the very thing the field cannot do.

    The second half is the other way a grant could go missing: the matrix drew
    a fixed four columns (view/create/edit/delete) while the catalog also
    carries approve and clear_all, so three permissions had no checkbox
    anywhere in the app and a module's master tick granted four of Issues' five.
    """
    print("\nA CHANGE OF ACCESS REACHES AN APP THAT IS ALREADY OPEN")
    adm = _token("admin@pestcrm.com", "admin123")
    eng = next(u for u in _api("GET", "/users", adm) if u["email"] == "agent1@pestcrm.com")
    cat = _api("GET", "/permissions/catalog", adm)
    every = [f"{m['module']}.{a}" for m in cat["catalog"] for a in m["actions"]]

    # ---- the matrix can express every permission the server knows ----------
    page = browser.new_page(viewport={"width": 1440, "height": 1000})
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "admin@pestcrm.com")
    page.fill("#login-password", "admin123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2000)
    page.evaluate("closeModal && closeModal()")
    page.evaluate("() => navigate('permissions')")
    page.wait_for_timeout(1500)
    boxes = page.evaluate(
        "() => [...document.querySelectorAll('#perm-matrix input[data-perm]')]"
        ".map(c => c.dataset.perm)")
    missing = [p for p in every if p not in boxes]
    check("every permission the server knows has a box in the matrix",
          not missing, "no box for: " + ", ".join(missing[:6]))
    check("the approve and clear-all permissions among them",
          all(p in boxes for p in ("issues.approve", "cash.approve", "schedule.clear_all")))
    # A MODULE TICKED WHOLE MUST MEAN WHOLE. The master box beside a module's
    # name drives every checkbox in its row; while approve had no checkbox, it
    # drove four of Issues' five and said nothing about the fifth. Asked on the
    # agent role, whose Issues row starts part-ticked (view + create, no approve,
    # no delete), so the toggle has somewhere to travel in both directions.
    page.evaluate("() => navigate('permissions', { tab: 'roles', role: 'agent' })")
    page.wait_for_timeout(1200)
    row = 'input.prow[data-mod="issues"]'
    kids = ('() => Object.fromEntries([...document.querySelectorAll('
            '\'input[data-perm^="issues."]\')].map(c => [c.dataset.perm, c.checked]))')
    before = page.evaluate(kids)
    check("the Issues row starts part-ticked, as the agent role has it",
          before.get("issues.view") is True and before.get("issues.approve") is False,
          str(before))
    page.click(row)
    page.wait_for_timeout(300)
    after_on = page.evaluate(kids)
    check("ticking the module master ticks EVERY permission in that module",
          after_on and all(after_on.values()), str(after_on))
    check("approve among them, not silently left behind",
          after_on.get("issues.approve") is True)
    page.click(row)
    page.wait_for_timeout(300)
    after_off = page.evaluate(kids)
    check("and clearing it clears every one of them too",
          after_off and not any(after_off.values()), str(after_off))
    # Nothing is saved: the matrix is left as it was found, for the checks below.
    check("the permission matrix raises no script error", not errors,
          "; ".join(errors[:2]))
    page.close()

    # ---- the engineer's open app picks the change up ----------------------
    ep = browser.new_page(viewport={"width": 390, "height": 844},
                          is_mobile=True, has_touch=True)
    eerr = []
    ep.on("pageerror", lambda e: eerr.append(str(e)))
    ep.goto(BASE + "/", wait_until="networkidle")
    ep.fill("#login-email", "agent1@pestcrm.com")
    ep.fill("#login-password", "agent123")
    ep.click("#login-form button[type=submit]")
    ep.wait_for_timeout(2500)
    ep.evaluate("closeModal && closeModal()")
    has_nav = "() => !!document.querySelector('#nav [data-view=\"chemicals\"]')"
    check("the engineer's menu has no Chemicals to begin with",
          not ep.evaluate(has_nav))
    # A marker that only survives if this page is never reloaded.
    ep.evaluate("() => { window.__samePage = true; }")

    _api("PUT", f"/permissions/users/{eng['id']}", adm,
         {"perms": {"chemicals.view": True}})
    # The phone is put down and picked up again. That is all that happens: the
    # WebView does not navigate, so this event is the whole of "opening it".
    ep.evaluate("() => document.dispatchEvent(new Event('visibilitychange'))")
    ep.wait_for_timeout(2000)
    check("picking the app back up brings the new permission with it",
          ep.evaluate(has_nav))
    check("and it did so without reloading the page",
          ep.evaluate("() => !!window.__samePage"))
    check("the screen underneath was re-drawn, not left on the old rules",
          ep.evaluate("() => !!can('chemicals.view')"))

    # ---- and taking it away lands the same way, on the refresh button ------
    _api("PUT", f"/permissions/users/{eng['id']}", adm,
         {"perms": {"chemicals.view": None}})
    ep.click("#nav-refresh")
    ep.wait_for_timeout(2500)
    check("taking a permission away reaches the open app too",
          not ep.evaluate(has_nav))
    check("still the same page, never reloaded",
          ep.evaluate("() => !!window.__samePage"))
    # ---- and the signal coming back is the third door -------------------
    # An engineer out of range while the office grants something: the change has
    # to be there when the phone finds a network again, without them doing
    # anything at all.
    has_disp = "() => !!document.querySelector('#nav [data-view=\"dispatch\"]')"
    check("the engineer's menu has no Dispatch to begin with",
          not ep.evaluate(has_disp))
    _api("PUT", f"/permissions/users/{eng['id']}", adm,
         {"perms": {"dispatch.view": True}})
    ep.evaluate("() => window.dispatchEvent(new Event('online'))")
    ep.wait_for_timeout(2000)
    check("the signal coming back brings the change with it",
          ep.evaluate(has_disp))
    check("and that page was never reloaded either",
          ep.evaluate("() => !!window.__samePage"))
    _api("PUT", f"/permissions/users/{eng['id']}", adm,
         {"perms": {"dispatch.view": None}})
    ep.evaluate("() => document.dispatchEvent(new Event('visibilitychange'))")
    ep.wait_for_timeout(2000)
    check("the engineer is left exactly as they were found",
          not ep.evaluate(has_disp) and not ep.evaluate(has_nav))
    check("living through a permission change raises no script error", not eerr,
          "; ".join(eerr[:2]))
    ep.close()


def scan_back_checks(browser):
    """THE WAY OUT OF A SCANNED CODE IS THE PAGE YOU CAME FROM.

    He asked for it in those words: "in the report of the scan qr codes in the
    bottom two option is next scan or dashboard — instead of dashboard make it
    back, when i press it i go back to the previous page". The dashboard is the
    one place an engineer standing at a trap has NOT just come from: they reach a
    device from the branch, from a visit, or from the previous trap in the run,
    and being thrown home means finding their way back in every single time.

    Both halves are checked, because the second is what a plain history.back()
    would get wrong: a code opened COLD from the camera has nothing behind it,
    and must still have a way out rather than a dead button.
    """
    print("\nTHE WAY OUT OF A SCANNED CODE")
    adm = _token("admin@pestcrm.com", "admin123")
    dev = _api("GET", "/devices", adm)[0]
    page = browser.new_page(viewport={"width": 390, "height": 844},
                            is_mobile=True, has_touch=True)
    errors = []
    page.on("pageerror", lambda e: errors.append(str(e)))
    page.goto(BASE + "/", wait_until="networkidle")
    page.fill("#login-email", "agent1@pestcrm.com")
    page.fill("#login-password", "agent123")
    page.click("#login-form button[type=submit]")
    page.wait_for_timeout(2500)
    page.evaluate("closeModal && closeModal()")

    # Walk in from a real screen, the way an engineer reaches a trap.
    page.evaluate("() => navigate('calendar')")
    page.wait_for_timeout(1200)
    page.evaluate("c => navigate('scan', { token: c })", dev["code"])
    page.wait_for_timeout(2000)
    check("the scanned device opens for the engineer",
          page.evaluate("() => currentView") == "scan")
    label = page.evaluate(
        "() => { const b = document.getElementById('sc-back'); return b ? b.textContent.trim() : null; }")
    # Asked in the language the app is actually in. A phone left in Arabic reads
    # "← رجوع", which is the right answer, not a failure — an English-word
    # assertion here only tested which language the previous check had left
    # behind in localStorage.
    word_back = page.evaluate("() => t('back')")
    word_home = page.evaluate("() => t('nav_dashboard')")
    check("its way out is labelled Back, in the language the app is in",
          bool(label) and word_back in label, f"{label!r} should contain {word_back!r}")
    check("and no longer says Dashboard",
          bool(label) and word_home not in label, f"{label!r} still names {word_home!r}")
    page.click("#sc-back")
    page.wait_for_timeout(1500)
    check("pressing it returns to the page the code was opened from",
          page.evaluate("() => currentView") == "calendar",
          page.evaluate("() => currentView"))

    # A code opened cold, straight off the camera, with nothing behind it.
    page.goto(BASE + "/scan/" + dev["code"], wait_until="networkidle")
    page.wait_for_timeout(2500)
    check("a code opened cold still lands on the device",
          page.evaluate("() => currentView") == "scan",
          page.evaluate("() => currentView"))
    page.click("#sc-back")
    page.wait_for_timeout(1500)
    check("and Back still has somewhere to go, so nobody is stranded",
          page.evaluate("() => currentView") == "dashboard",
          page.evaluate("() => currentView"))
    check("the scan screen raises no script error", not errors, "; ".join(errors[:2]))
    page.close()


def _token(email, password):
    return _api("POST", "/auth/login", body={"email": email, "password": password})["token"]


if __name__ == "__main__":
    sys.exit(main())
