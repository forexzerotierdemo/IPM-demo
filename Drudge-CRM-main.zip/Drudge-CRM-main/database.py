"""SQLite database layer for the Pest Control CRM.

Uses only the Python standard library. The schema is created on first run and
demo data is seeded by seed.py.
"""
import sqlite3
import os
import contextlib
import threading

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("PESTCRM_DATA_DIR", os.path.join(BASE_DIR, "data"))
DB_PATH = os.path.join(DATA_DIR, "crm.db")

SCHEMA = """
PRAGMA foreign_keys = ON;

-- Users: staff (admin/manager/agent) and client portal users.
CREATE TABLE IF NOT EXISTS users (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name     TEXT NOT NULL,
    email         TEXT NOT NULL UNIQUE,
    password_hash TEXT NOT NULL,
    -- Two supervising field roles sit between agent and manager:
    --   'area_manager' answers for PLACES — the parts of town listed in
    --   area_manager_areas. Every branch, visit, report and roster line in
    --   those areas is theirs.
    --   'team_leader'  answers for PEOPLE — the engineers whose
    --   team_leader_id points at them. Their team's diary and reports are
    --   theirs, wherever in town the work happens to be.
    -- Both still work visits like an agent.
    role          TEXT NOT NULL CHECK (role IN ('admin','manager','agent','area_manager','team_leader','client')),
    phone         TEXT,
    -- For role='client': which client company they belong to.
    client_id     INTEGER REFERENCES clients(id) ON DELETE SET NULL,
    -- For role='client': pin the portal login to ONE of that company's
    -- locations (a branch manager sees their branch only). NULL = the whole
    -- company, which is how every existing portal user behaves.
    site_id       INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    -- The team leader this engineer reports to (NULL = on nobody's team).
    -- One team per person: the leader's team is exactly the rows pointing here.
    team_leader_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    -- Agent profile extras (NULL for non-agents).
    specialization TEXT,
    hire_date     TEXT,
    -- Technician licensing/certification (shown on audit packs).
    license_no    TEXT,
    license_expiry TEXT,
    lang          TEXT NOT NULL DEFAULT 'en',
    active        INTEGER NOT NULL DEFAULT 1,
    -- bumped to invalidate a user's outstanding session tokens (see auth.py)
    token_version INTEGER NOT NULL DEFAULT 0,
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Client companies. Each row is the "company folder".
CREATE TABLE IF NOT EXISTS clients (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name_en        TEXT NOT NULL,
    name_ar        TEXT,
    contact_person TEXT,
    phone          TEXT,
    email          TEXT,
    address_en     TEXT,
    address_ar     TEXT,
    city           TEXT,
    -- Used when a client has no branches, so a visit still has an area.
    area_id        INTEGER REFERENCES areas(id) ON DELETE SET NULL,
    notes          TEXT,
    status         TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active','inactive')),
    -- 0 = never send this customer automatic overdue reminders.
    dunning        INTEGER NOT NULL DEFAULT 1,
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Sites/locations belonging to a client (optional, a client can have many).
CREATE TABLE IF NOT EXISTS sites (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id  INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    name       TEXT NOT NULL,
    address    TEXT,
    area       TEXT,                             -- legacy free text, kept for history
    area_id    INTEGER REFERENCES areas(id) ON DELETE SET NULL,
    map_image  TEXT,   -- uploaded floor-plan / map-design picture for this site
    lat        REAL,   -- geographic coordinates (for dispatch / route optimization)
    lng        REAL,
    -- When this place will actually accept a visit, and how often it needs one.
    -- Together with the branch's area these are the three facts the automatic
    -- scheduler needs: WHERE the work is, WHEN it can be done, HOW OFTEN.
    service_from    TEXT,                          -- 'HH:MM', NULL = any time
    service_to      TEXT,
    -- HOW OFTEN, IN VISITS A MONTH. The office thinks and sells in months
    -- ("four visits a month", "one a month"), so that is the unit it enters
    -- and the unit every screen shows. The roster still plans in Saturday-to-
    -- Friday weeks and deals the month's visits out over four of them.
    visits_per_month REAL NOT NULL DEFAULT 0,      -- 0 = not on a routine cycle
    -- Which unit that number is READ AND TYPED in on the branch screens.
    -- 'month' is what the office is moving to; 'week' is how the book was
    -- first entered and is still the natural unit for a place serviced several
    -- times a week. Only ever a lens on the SAME stored monthly figure — the
    -- roster never reads this — so switching it changes no visit.
    freq_unit       TEXT NOT NULL DEFAULT 'month'
                    CHECK (freq_unit IN ('week','month')),
    -- How long a visit here actually takes. NULL = the company default
    -- (setting auto_slot_minutes). A hotel and a corner shop are not the same
    -- job, and pretending they are is what makes a day's plan undeliverable.
    visit_minutes   INTEGER,
    -- THE ENGINEER THIS BRANCH BELONGS TO. NULL = the roster decides, which is
    -- every branch until somebody names one. A factory that is one man's
    -- standing shift is not a job to be dealt round the team, and the office
    -- knows which those are; the auto-roster offers such a branch to nobody
    -- else, and says so plainly when he cannot get to it.
    preferred_agent_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    -- IS THIS PLACE STILL BEING SERVICED. A branch that closes, or a customer
    -- that stops, must leave the roster WITHOUT leaving the CRM: its visits,
    -- reports and invoices are the company's own history and deleting it takes
    -- them with it. 'inactive' means the automatic roster never offers it, the
    -- capacity sums ignore it and it stops being nagged about; everything
    -- already recorded stays exactly where it is, and one press puts it back.
    status     TEXT NOT NULL DEFAULT 'active'
               CHECK (status IN ('active','inactive')),
    -- THE LINK THE OFFICE PASTED, kept beside the coordinates it produced.
    -- A pin is a pair of numbers nobody can check by looking at it; the link
    -- opens the place in Google Maps, which is how the office verifies it is
    -- the right door. Asked for in exactly those words: "save the URL of the
    -- map or the link I put too".
    map_url    TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- WHICH KINDS OF ALERT A PERSON WANTS. A row is an explicit choice; no row
-- means on, so nobody has to opt in to their own work. Grouped by kind rather
-- than by the ~30 individual types: an engineer wants to mute "the money", not
-- to reason about invoice_overdue versus vat_due.
CREATE TABLE IF NOT EXISTS notification_prefs (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    grp     TEXT NOT NULL,
    enabled INTEGER NOT NULL DEFAULT 1,
    UNIQUE (user_id, grp)
);

-- WHAT ONE PRESS OF THE AUTO-ROSTER BUTTON WROTE, so it can be taken back.
--
-- Applying a plan books hundreds of real customer visits in one go. Without a
-- record of which rows came from which press, undoing a run the office does not
-- like means deleting them by hand — which is enough to stop anyone daring to
-- press the button on live data at all.
--
-- Only rows the run ACTUALLY wrote are listed. The apply path skips shifts that
-- already exist and only claims visits that had nobody on them, so recording
-- the attempt rather than the write would make undoing a second press delete
-- the first press's work.
--
-- 'visit_assigned' is why this is a list and not a column on visits: that visit
-- existed before the run and must never be deleted by an undo, only handed back
-- to nobody — and only if it is still the engineer this run put on it.
CREATE TABLE IF NOT EXISTS roster_runs (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    from_date  TEXT NOT NULL,
    to_date    TEXT NOT NULL,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    visits     INTEGER NOT NULL DEFAULT 0,   -- booked outright
    assigned   INTEGER NOT NULL DEFAULT 0,   -- existing visits given an engineer
    shifts     INTEGER NOT NULL DEFAULT 0,
    undone_at  TEXT,
    undone_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    kept       INTEGER NOT NULL DEFAULT 0,   -- rows an undo refused to touch
    -- A CLEAR IS NOT AN UNDO, and the history must not pretend it was. When a
    -- clear takes work off the book these say so: if it took EVERYTHING the run
    -- wrote, undone_at is set too (the run really is taken back, and Undo must
    -- stop offering it); if it took only part, these stand alone and Undo still
    -- works on the rest. Before this, a clear left a run standing with its rows
    -- already gone and the next Undo reported "0 deleted, 848 kept".
    cleared_at     TEXT,
    cleared_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    cleared_visits INTEGER NOT NULL DEFAULT 0,
    cleared_shifts INTEGER NOT NULL DEFAULT 0
);
CREATE TABLE IF NOT EXISTS roster_run_items (
    run_id   INTEGER NOT NULL REFERENCES roster_runs(id) ON DELETE CASCADE,
    kind     TEXT NOT NULL CHECK (kind IN ('visit_created','visit_assigned','shift_created')),
    ref_id   INTEGER NOT NULL,
    agent_id INTEGER
);
CREATE INDEX IF NOT EXISTS idx_roster_run_items_run ON roster_run_items(run_id);

-- WHAT A RUN COULD NOT BOOK, kept as a worklist instead of a number on a
-- screen. The plan is drawn fresh on every press and thrown away, so before
-- this the shortfall existed only in the preview: press Apply and the 26
-- visits nobody could fit simply vanished. The office asked for the opposite —
-- book everything that fits, then hand them the leftovers to place by hand.
--
-- One row per MISSED VISIT, not per branch: a branch due twice in the week
-- that got neither is two rows, because two visits have to be found. `reason`
-- is the planner's own vocabulary (_unplaced_reason) so the advice shown never
-- has to be worked out a second time. Nothing here is derived at read time
-- except whether it has since been dealt with: a visit that now exists for
-- that branch on that date counts as solved, so booking one by hand clears it
-- without anybody having to come back and tick it off.
CREATE TABLE IF NOT EXISTS roster_run_unplaced (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    run_id     INTEGER NOT NULL REFERENCES roster_runs(id) ON DELETE CASCADE,
    visit_date TEXT NOT NULL,
    site_id    INTEGER REFERENCES sites(id) ON DELETE CASCADE,
    area_id    INTEGER REFERENCES areas(id) ON DELETE SET NULL,
    minutes    INTEGER,
    reason     TEXT NOT NULL,
    dismissed_at TEXT,                     -- "dealt with another way", by hand
    dismissed_by INTEGER REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_roster_run_unplaced_run ON roster_run_unplaced(run_id);

-- WHICH DAYS a branch will actually accept a visit, and the hours on that day
-- when they differ from the branch's usual window above.
--
-- The mirror image of agent_availability: one side says when the engineer can
-- work, this side says when the customer will open the door, and the scheduler
-- books in the overlap. A row means "this branch accepts visits this weekday";
-- NULL times mean "the usual window", so the office types hours only for the
-- odd day out (Saturday mornings only, say).
--
-- NO ROWS AT ALL means the branch has not said, and the scheduler keeps its
-- older behaviour of spreading the visits over whatever days anyone works —
-- which is what every existing branch does, so this is additive.
--
-- weekday is PYTHON's Mon=0..Sun=6, the same as agent_availability, so the two
-- are compared without converting anything. The Saturday-first week the office
-- reads is a display concern and lives in the frontend alone.
CREATE TABLE IF NOT EXISTS site_service_days (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    site_id    INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
    weekday    INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
    start_time TEXT,                              -- NULL = the branch's usual window
    end_time   TEXT,
    -- And who does it on THIS weekday. NULL = whoever the branch names, else
    -- the roster's choice. The odd day out is the whole point: a factory that
    -- is one man's shift six days a week is somebody else's on the seventh,
    -- and that is a fact about the day, not about the branch.
    agent_id   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    UNIQUE (site_id, weekday)
);
CREATE INDEX IF NOT EXISTS idx_site_service_days_site ON site_service_days(site_id);

-- Service catalog (bilingual).
CREATE TABLE IF NOT EXISTS service_types (
    id      INTEGER PRIMARY KEY AUTOINCREMENT,
    name_en TEXT NOT NULL,
    name_ar TEXT
);

-- Scheduled / completed agent visits.
CREATE TABLE IF NOT EXISTS visits (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id       INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    site_id         INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    agent_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    service_type_id INTEGER REFERENCES service_types(id) ON DELETE SET NULL,
    -- The deal this visit was worked under, when there is one. Set for visits
    -- generated from a contract; pickable on a manual one. Drives profit per
    -- contract, so an unattributed visit costs the company, not the deal.
    contract_id     INTEGER REFERENCES contracts(id) ON DELETE SET NULL,
    scheduled_start TEXT NOT NULL,
    scheduled_end   TEXT,
    status          TEXT NOT NULL DEFAULT 'scheduled'
                    CHECK (status IN ('scheduled','in_progress','completed','cancelled')),
    location        TEXT,
    notes           TEXT,
    -- LEGACY. The visit's number within its month is no longer stored: it is
    -- counted per client+location on read (VISIT_NO_SQL in server.py), so it
    -- cannot be typed, cannot drift when a visit moves, and restarts at 1 each
    -- month. Old hand-entered values are kept here but never read.
    visit_number    INTEGER,
    -- GPS proof-of-presence: the agent taps Check in / Check out on site and
    -- the app stamps time + device location (nullable — GPS can be denied or
    -- unavailable indoors; the timestamp is still recorded). Staff-only data.
    checkin_at      TEXT,
    checkin_lat     REAL,
    checkin_lng     REAL,
    checkin_acc     REAL,   -- reported GPS accuracy, metres
    checkout_at     TEXT,
    checkout_lat    REAL,
    checkout_lng    REAL,
    checkout_acc    REAL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    completed_at    TEXT
);

-- One report per visit.
CREATE TABLE IF NOT EXISTS reports (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    visit_id        INTEGER NOT NULL UNIQUE REFERENCES visits(id) ON DELETE CASCADE,
    summary         TEXT,
    pests_found     TEXT,
    findings        TEXT,
    recommendations TEXT,
    severity        TEXT DEFAULT 'low' CHECK (severity IN ('low','medium','high','critical')),
    next_visit_due  TEXT,
    customer_name        TEXT,
    customer_signature   TEXT,   -- filename of captured signature image
    technician_signature TEXT,
    -- Engineer service log (per the field visit tracker): parts & materials
    -- consumed during the visit, plus any branch issue found.
    spare_parts_changed  TEXT,
    lamps_used           REAL NOT NULL DEFAULT 0,
    cables_used          REAL NOT NULL DEFAULT 0,
    transformers_used    REAL NOT NULL DEFAULT 0,
    light_sheets_used    REAL NOT NULL DEFAULT 0,
    fipronil_ml          REAL NOT NULL DEFAULT 0,
    imidacloprid_gm      REAL NOT NULL DEFAULT 0,
    baits_count          REAL NOT NULL DEFAULT 0,
    glo_pieces           REAL NOT NULL DEFAULT 0,
    flybase_bags         REAL NOT NULL DEFAULT 0,
    branch_issue         TEXT,
    -- Site condition, chosen from the office-maintained list (report_options).
    -- Stored as the chosen wording, one per line, exactly like recommendations:
    -- a report keeps what it said even if the list is edited afterwards.
    condition            TEXT,
    -- Legacy single transportation pair — superseded by transport_entries
    -- (kept so old cached clients don't error; values are migrated + cleared).
    transport_vehicle    TEXT,
    transport_cost       REAL NOT NULL DEFAULT 0,
    -- 'draft' while the agent is still filling it in (auto-saved); 'complete'
    -- once the core fields + both signatures are captured.
    status          TEXT NOT NULL DEFAULT 'draft' CHECK (status IN ('draft','complete')),
    completed_at    TEXT,
    created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Transportation invoice (internal): the trips an agent took for a visit —
-- where it went from, where to, and what it cost; any number per visit. Never
-- shown to clients or printed. `vehicle` is the retired picker this replaced,
-- kept so historical trips still read back.
CREATE TABLE IF NOT EXISTS transport_entries (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    visit_id   INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
    vehicle    TEXT,
    from_place TEXT,
    to_place   TEXT,
    cost       REAL NOT NULL DEFAULT 0,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Chemical / product inventory.
CREATE TABLE IF NOT EXISTS chemicals (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    name_en           TEXT NOT NULL,
    name_ar           TEXT,
    active_ingredient TEXT,
    unit              TEXT NOT NULL DEFAULT 'L',
    quantity_in_stock REAL NOT NULL DEFAULT 0,
    reorder_level     REAL NOT NULL DEFAULT 0,
    hazard_class      TEXT,
    reg_no            TEXT,
    cost_per_unit     REAL NOT NULL DEFAULT 0,
    expiry_date       TEXT,   -- product expiry; dashboard warns when near/past
    created_at        TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Chemicals consumed during a specific visit.
CREATE TABLE IF NOT EXISTS chemical_usage (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    visit_id     INTEGER NOT NULL REFERENCES visits(id) ON DELETE CASCADE,
    chemical_id  INTEGER NOT NULL REFERENCES chemicals(id) ON DELETE CASCADE,
    quantity     REAL NOT NULL,
    area_treated TEXT,
    -- How it was applied (spraying, gel, fogging, ...) and with what (sprayer,
    -- duster, fogger, ...). Stored as keys so they print in whichever language
    -- the report is read in.
    method       TEXT,
    equipment    TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Stock movements (purchases / adjustments / usage log).
CREATE TABLE IF NOT EXISTS inventory_transactions (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    chemical_id INTEGER NOT NULL REFERENCES chemicals(id) ON DELETE CASCADE,
    change      REAL NOT NULL,
    reason      TEXT NOT NULL CHECK (reason IN ('purchase','usage','adjustment','issue')),
    reference   TEXT,
    note        TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Engineer materials: what an engineer takes out of inventory.
-- An engineer cannot help themselves — they RAISE A REQUEST ('requested', no
-- stock movement) which an admin/manager approves. Approval is the single moment
-- stock leaves the warehouse, so 'approved' rows are the real issues. A manager
-- issuing materials directly creates an already-approved row.
-- Legacy rows (before the approval step existed) default to 'approved' so
-- history and every balance stay exactly as they were.
CREATE TABLE IF NOT EXISTS engineer_issues (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    note        TEXT,
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    status      TEXT NOT NULL DEFAULT 'approved'
                CHECK (status IN ('requested','approved','declined')),
    handled_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    handled_at  TEXT,
    decline_reason TEXT,
    -- The other half of the handover: releasing the stock is the office saying
    -- "we gave it", and receipt_status is the engineer saying "I got it". NULL
    -- means an approved issue nobody has answered for yet.
    receipt_status TEXT,          -- NULL | 'received' | 'disputed'
    receipt_at     TEXT,
    receipt_note   TEXT
);
CREATE TABLE IF NOT EXISTS engineer_issue_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    issue_id    INTEGER NOT NULL REFERENCES engineer_issues(id) ON DELETE CASCADE,
    chemical_id INTEGER NOT NULL REFERENCES chemicals(id) ON DELETE CASCADE,
    quantity    REAL NOT NULL,
    -- What the office actually agreed to hand over, line by line: a request for
    -- five materials can come back with four approved and one cut to half.
    -- NULL approved_quantity means "as asked" and NULL line_status means
    -- approved, so every row written before per-line approval still reads
    -- exactly as it did.
    approved_quantity REAL,
    line_status TEXT CHECK (line_status IS NULL OR line_status IN ('approved','declined'))
);
CREATE INDEX IF NOT EXISTS idx_issue_items ON engineer_issue_items(issue_id);
CREATE INDEX IF NOT EXISTS idx_issues_agent ON engineer_issues(agent_id);

-- The other direction: material an engineer did not use, coming back to the
-- warehouse. Signed for twice, like an issue is — the office agrees the
-- quantities (status), and the warehouse says the goods are physically back
-- (receipt_status). NOTHING returns to stock until that second signature: an
-- engineer must not be able to top up the stock book by typing into a form.
CREATE TABLE IF NOT EXISTS material_returns (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    note        TEXT,
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    status      TEXT NOT NULL DEFAULT 'requested'
                CHECK (status IN ('requested','approved','declined')),
    handled_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    handled_at  TEXT,
    decline_reason TEXT,
    receipt_status TEXT,          -- NULL | 'received' | 'disputed'
    receipt_at     TEXT,
    receipt_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    receipt_note   TEXT
);
CREATE TABLE IF NOT EXISTS material_return_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    return_id   INTEGER NOT NULL REFERENCES material_returns(id) ON DELETE CASCADE,
    chemical_id INTEGER NOT NULL REFERENCES chemicals(id) ON DELETE CASCADE,
    quantity    REAL NOT NULL,
    -- What the office agreed to take back, line by line — same shape as an
    -- issue's approved_quantity, so a line can be cut or refused on its own.
    approved_quantity REAL,
    line_status TEXT CHECK (line_status IS NULL OR line_status IN ('approved','declined'))
);
CREATE INDEX IF NOT EXISTS idx_return_items ON material_return_items(return_id);
CREATE INDEX IF NOT EXISTS idx_returns_agent ON material_returns(agent_id);

-- Unified photo store: client folders, reports, visits, chemicals.
CREATE TABLE IF NOT EXISTS photos (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    -- 'expense' = a receipt filed against a company cost (finance-only).
    -- 'cash'    = a receipt for pocket money an engineer spent in the field.
    entity_type   TEXT NOT NULL CHECK (entity_type IN ('client','report','visit','chemical','expense','cash')),
    entity_id     INTEGER NOT NULL,
    filename      TEXT NOT NULL,
    original_name TEXT,
    caption       TEXT,
    -- When set, the attachment is a "Business plan" and is surfaced on the report.
    is_business_plan INTEGER NOT NULL DEFAULT 0,
    uploaded_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    uploaded_at   TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Invoices and quotes (client finance). doc_type distinguishes the two.
-- status is free-text (app-controlled) to allow quote states (accepted/declined).
CREATE TABLE IF NOT EXISTS invoices (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    site_id     INTEGER REFERENCES sites(id) ON DELETE SET NULL,  -- location this doc belongs to
    visit_id    INTEGER REFERENCES visits(id) ON DELETE SET NULL,
    contract_id INTEGER REFERENCES contracts(id) ON DELETE SET NULL,
    doc_type    TEXT NOT NULL DEFAULT 'invoice',   -- 'invoice' | 'quote'
    number      TEXT NOT NULL,
    issue_date  TEXT NOT NULL,
    due_date    TEXT,
    valid_until TEXT,                               -- quotes
    amount      REAL NOT NULL DEFAULT 0,
    tax         REAL NOT NULL DEFAULT 0,
    total       REAL NOT NULL DEFAULT 0,
    status      TEXT NOT NULL DEFAULT 'draft',
    notes       TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Line items for an invoice / quote.
CREATE TABLE IF NOT EXISTS invoice_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id  INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    description TEXT NOT NULL,
    quantity    REAL NOT NULL DEFAULT 1,
    unit_price  REAL NOT NULL DEFAULT 0,
    amount      REAL NOT NULL DEFAULT 0
);

-- Recurring service contracts that auto-generate visits.
CREATE TABLE IF NOT EXISTS contracts (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id       INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    site_id         INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    service_type_id INTEGER REFERENCES service_types(id) ON DELETE SET NULL,
    agent_id        INTEGER REFERENCES users(id) ON DELETE SET NULL,
    quote_id        INTEGER REFERENCES invoices(id) ON DELETE SET NULL,
    frequency       TEXT NOT NULL DEFAULT 'monthly'
                    CHECK (frequency IN ('weekly','biweekly','monthly','quarterly','semiannual','annual')),
    start_date      TEXT NOT NULL,
    end_date        TEXT,
    next_run_date   TEXT NOT NULL,
    price           REAL NOT NULL DEFAULT 0,
    status          TEXT NOT NULL DEFAULT 'active'
                    CHECK (status IN ('active','paused','ended')),
    notes           TEXT,
    -- Recurring billing: when auto_invoice=1 an invoice is generated every
    -- bill_every cadence (NULL falls back to `frequency`) on next_bill_date.
    bill_every      TEXT,
    next_bill_date  TEXT,
    auto_invoice    INTEGER NOT NULL DEFAULT 0,
    -- Who BROUGHT this contract in, which is a different person from agent_id
    -- (who services it). Their commission stands only while status='active',
    -- so ending or pausing the contract takes the uplift away by itself.
    -- commission_rate NULL = the company rate in settings.
    sold_by         INTEGER REFERENCES users(id) ON DELETE SET NULL,
    commission_rate REAL,
    created_at      TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
-- idx_contracts_sold_by is created in _migrate, not here: this script runs
-- before the ALTERs, so on an existing database the column is not there yet.

-- Per-site lines on a contract: each covered location, its Google Maps
-- location (a maps URL or "lat,lng" string) and the price for that site.
-- A contract's overall price is the sum of its site rows.
CREATE TABLE IF NOT EXISTS contract_sites (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    contract_id  INTEGER NOT NULL REFERENCES contracts(id) ON DELETE CASCADE,
    site_id      INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    map_location TEXT,
    price        REAL NOT NULL DEFAULT 0
);
CREATE INDEX IF NOT EXISTS idx_contract_sites_contract ON contract_sites(contract_id);

-- What an engineer is asked to BRING IN, month by month. One row per person
-- per month; the achievement side is never stored — it is counted live from
-- the contracts they are credited with, so a contract that ends or is paused
-- takes its commission back out of the figure the moment it does.
CREATE TABLE IF NOT EXISTS marketing_targets (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id          INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    period           TEXT NOT NULL,               -- 'YYYY-MM'
    target_amount    REAL NOT NULL DEFAULT 0,     -- contract value per month
    target_contracts INTEGER NOT NULL DEFAULT 0,  -- 0 = not counted
    note             TEXT,
    created_by       INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at       TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at       TEXT
);
CREATE UNIQUE INDEX IF NOT EXISTS idx_marketing_targets_person
    ON marketing_targets(user_id, period);

-- Self-service visit requests submitted by clients from their portal. Staff
-- approve a request (which creates a real visit) or decline it.
CREATE TABLE IF NOT EXISTS visit_requests (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id      INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    site_id        INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    preferred_date TEXT,
    note           TEXT,
    status         TEXT NOT NULL DEFAULT 'pending'
                   CHECK (status IN ('pending','approved','declined')),
    visit_id       INTEGER REFERENCES visits(id) ON DELETE SET NULL,
    created_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    handled_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    handled_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_visit_requests_client ON visit_requests(client_id);

-- Online-payment attempts. One row per "pay this invoice" click. Gateway-
-- agnostic: `provider` selects the adapter, `provider_ref` holds the gateway's
-- order/transaction id (equals `token` for the built-in manual provider), and
-- `token` is our opaque id used in checkout/return URLs. Marked 'paid' by the
-- provider's callback, which also writes the matching payments row.
CREATE TABLE IF NOT EXISTS payment_intents (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id   INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    client_id    INTEGER REFERENCES clients(id) ON DELETE SET NULL,
    provider     TEXT NOT NULL,
    provider_ref TEXT,
    token        TEXT NOT NULL UNIQUE,
    amount       REAL NOT NULL,
    currency     TEXT NOT NULL DEFAULT 'EGP',
    status       TEXT NOT NULL DEFAULT 'pending'
                 CHECK (status IN ('pending','paid','failed','cancelled')),
    payment_id   INTEGER REFERENCES payments(id) ON DELETE SET NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_payment_intents_invoice ON payment_intents(invoice_id);

-- Price book: reusable service/line-item catalog for quotes & invoices.
CREATE TABLE IF NOT EXISTS price_book (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    name_en     TEXT NOT NULL,
    name_ar     TEXT,
    description TEXT,
    unit_price  REAL NOT NULL DEFAULT 0,
    active      INTEGER NOT NULL DEFAULT 1,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- IPM file library: company PDF documents (IPM manual, policies, licences,
-- MSDS binders) published once by the office. Unlike everything else in the
-- database these belong to no single client — every client portal login reads
-- the same shelf, unless a document is flagged internal (visible_to_clients=0).
CREATE TABLE IF NOT EXISTS company_files (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    title         TEXT NOT NULL,
    description   TEXT,
    filename      TEXT NOT NULL,
    original_name TEXT,
    size_bytes    INTEGER NOT NULL DEFAULT 0,
    visible_to_clients INTEGER NOT NULL DEFAULT 1,
    uploaded_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at    TEXT
);
CREATE INDEX IF NOT EXISTS idx_company_files_filename ON company_files(filename);

-- The wording an engineer may choose from when writing a report: the site
-- conditions they can report, and the recommendations they can make. Kept by
-- the office so every report says the same thing the same way, and so a phone
-- in the field is a few taps rather than a paragraph of typing. Reports store
-- the chosen wording, not a reference, so editing this list never rewrites
-- history.
CREATE TABLE IF NOT EXISTS report_options (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    kind       TEXT NOT NULL CHECK (kind IN ('condition','recommendation')),
    name_en    TEXT NOT NULL,
    name_ar    TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_report_options_kind ON report_options(kind, sort_order);

-- Post-visit customer satisfaction (one rating per visit).
CREATE TABLE IF NOT EXISTS visit_ratings (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    visit_id    INTEGER NOT NULL UNIQUE REFERENCES visits(id) ON DELETE CASCADE,
    client_id   INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    stars       INTEGER NOT NULL CHECK (stars BETWEEN 1 AND 5),
    comment     TEXT,
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Sales leads: from the marketing website's booking form or entered manually.
CREATE TABLE IF NOT EXISTS leads (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    name           TEXT NOT NULL,
    company        TEXT,
    phone          TEXT,
    email          TEXT,
    sector         TEXT,
    message        TEXT,
    preferred_date TEXT,
    source         TEXT NOT NULL DEFAULT 'manual',
    status         TEXT NOT NULL DEFAULT 'new'
                   CHECK (status IN ('new','contacted','quoted','won','lost')),
    note           TEXT,
    client_id      INTEGER REFERENCES clients(id) ON DELETE SET NULL,
    handled_by     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at     TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at     TEXT
);
CREATE INDEX IF NOT EXISTS idx_leads_status ON leads(status);

-- Purchase orders: stock-in with supplier + cost tracking.
CREATE TABLE IF NOT EXISTS purchase_orders (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    supplier    TEXT,
    reference   TEXT,
    note        TEXT,
    total_cost  REAL NOT NULL DEFAULT 0,
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE TABLE IF NOT EXISTS purchase_order_items (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    po_id       INTEGER NOT NULL REFERENCES purchase_orders(id) ON DELETE CASCADE,
    chemical_id INTEGER NOT NULL REFERENCES chemicals(id) ON DELETE CASCADE,
    quantity    REAL NOT NULL,
    unit_cost   REAL NOT NULL DEFAULT 0
);

-- Key/value settings (company profile, tax rate, SMTP, etc.).
CREATE TABLE IF NOT EXISTS settings (
    key   TEXT PRIMARY KEY,
    value TEXT
);

-- Cache of machine translations (report text auto-translated EN<->AR for
-- display/printing). Keyed by a hash of the source text + target language.
CREATE TABLE IF NOT EXISTS translations (
    src_hash   TEXT NOT NULL,
    target     TEXT NOT NULL,
    src_lang   TEXT,
    text       TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    PRIMARY KEY (src_hash, target)
);

-- In-app notifications / reminders.
CREATE TABLE IF NOT EXISTS notifications (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id) ON DELETE CASCADE,
    type        TEXT NOT NULL,
    title       TEXT NOT NULL,
    body        TEXT,
    link_view   TEXT,
    link_id     INTEGER,
    is_read     INTEGER NOT NULL DEFAULT 0,
    dedup_key   TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS payments (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    invoice_id INTEGER NOT NULL REFERENCES invoices(id) ON DELETE CASCADE,
    amount     REAL NOT NULL,
    method     TEXT NOT NULL DEFAULT 'cash',
    paid_at    TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    note       TEXT
);

-- Site/branch floor-plan maps per client, with placeable device markers.
CREATE TABLE IF NOT EXISTS maps (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    client_id   INTEGER NOT NULL REFERENCES clients(id) ON DELETE CASCADE,
    site_id     INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    name        TEXT NOT NULL,
    filename    TEXT NOT NULL,
    uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Markers placed on a map (traps, bait stations, monitors, …). x/y are percents.
CREATE TABLE IF NOT EXISTS map_markers (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    map_id     INTEGER NOT NULL REFERENCES maps(id) ON DELETE CASCADE,
    type       TEXT NOT NULL DEFAULT 'other',
    label      TEXT,
    x          REAL NOT NULL,
    y          REAL NOT NULL,
    status     TEXT NOT NULL DEFAULT 'ok',
    notes      TEXT,
    qr_token   TEXT,                       -- unguessable id printed as a QR label
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Status history for map markers — powers pest-activity trend analytics.
-- One row per recorded inspection / status change of a device.
CREATE TABLE IF NOT EXISTS marker_events (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    marker_id   INTEGER NOT NULL REFERENCES map_markers(id) ON DELETE CASCADE,
    map_id      INTEGER NOT NULL REFERENCES maps(id) ON DELETE CASCADE,
    client_id   INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    type        TEXT,                       -- device type at time of record
    status      TEXT NOT NULL,              -- ok / needs_service / activity / missing
    note        TEXT,
    source      TEXT NOT NULL DEFAULT 'manual', -- 'scan' = recorded via QR tap-to-inspect
    lat         REAL,                       -- geo-stamp captured at scan time
    lng         REAL,
    recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    recorded_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE INDEX IF NOT EXISTS idx_maps_client ON maps(client_id);
CREATE INDEX IF NOT EXISTS idx_markers_map ON map_markers(map_id);
-- NOTE: the UNIQUE index on map_markers(qr_token) is created in _migrate(), not
-- here, so it isn't attempted against a pre-existing table before the column is
-- added by the migration.
CREATE INDEX IF NOT EXISTS idx_marker_events_client ON marker_events(client_id, recorded_at);
CREATE INDEX IF NOT EXISTS idx_marker_events_marker ON marker_events(marker_id);
CREATE INDEX IF NOT EXISTS idx_visits_agent ON visits(agent_id);
CREATE INDEX IF NOT EXISTS idx_visits_client ON visits(client_id);
CREATE INDEX IF NOT EXISTS idx_photos_entity ON photos(entity_type, entity_id);
CREATE INDEX IF NOT EXISTS idx_invoices_client ON invoices(client_id);
CREATE INDEX IF NOT EXISTS idx_items_invoice ON invoice_items(invoice_id);
CREATE INDEX IF NOT EXISTS idx_contracts_client ON contracts(client_id);
CREATE INDEX IF NOT EXISTS idx_notif_user ON notifications(user_id, is_read);
CREATE UNIQUE INDEX IF NOT EXISTS idx_notif_dedup ON notifications(dedup_key);

-- RBAC: per-role default permissions. A row overrides the code default for
-- (role, perm). Absence of a row means "use the built-in default".
CREATE TABLE IF NOT EXISTS role_permissions (
    role    TEXT NOT NULL CHECK (role IN ('admin','manager','agent','client')),
    perm    TEXT NOT NULL,
    allowed INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (role, perm)
);

-- RBAC: per-user overrides. A row overrides whatever the user's role resolves
-- to for (user_id, perm). Absence of a row means "inherit from role".
CREATE TABLE IF NOT EXISTS user_permissions (
    user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    perm    TEXT NOT NULL,
    allowed INTEGER NOT NULL DEFAULT 0,
    PRIMARY KEY (user_id, perm)
);

-- Audit trail: who did what, on which record. Append-only.
CREATE TABLE IF NOT EXISTS audit_log (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id     INTEGER REFERENCES users(id) ON DELETE SET NULL,
    user_name   TEXT,                          -- denormalized for history
    action      TEXT NOT NULL,                 -- e.g. invoice.create
    entity      TEXT,                          -- e.g. invoice
    entity_id   TEXT,
    detail      TEXT,                          -- short human-readable note
    ip          TEXT,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_audit_created ON audit_log(created_at);

-- QR-coded field devices (light traps, glue/bait stations, fly traps). Admin
-- generates a batch of sequential codes (LIT0001…), assigns them to a client,
-- and prints them. Agents scan the printed code on a visit to file its report.
CREATE TABLE IF NOT EXISTS devices (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL UNIQUE,           -- e.g. LIT0001 (printed as the QR)
    type       TEXT NOT NULL,                  -- light_trap|glue_station|bait_station|fly_trap
    client_id  INTEGER REFERENCES clients(id) ON DELETE SET NULL,
    site_id    INTEGER REFERENCES sites(id) ON DELETE SET NULL,
    label      TEXT,                           -- optional friendly location ("Kitchen")
    placement  TEXT,                           -- exactly where inside the site it sits
                                               -- ("behind the freezer, north wall")
    status     TEXT NOT NULL DEFAULT 'ok',     -- last-known: ok|activity|needs_service|missing
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_devices_client ON devices(client_id);
CREATE INDEX IF NOT EXISTS idx_devices_type ON devices(type);

-- One row per scan: a device's inspection during a visit (proof-of-presence +
-- the per-device part of the visit report). Time- and geo-stamped.
CREATE TABLE IF NOT EXISTS device_inspections (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    device_id   INTEGER NOT NULL REFERENCES devices(id) ON DELETE CASCADE,
    visit_id    INTEGER REFERENCES visits(id) ON DELETE SET NULL,
    client_id   INTEGER REFERENCES clients(id) ON DELETE CASCADE,
    status      TEXT NOT NULL,                 -- ok|activity|needs_service|missing
    findings    TEXT,                          -- what the agent recorded for this device
    note        TEXT,
    source      TEXT NOT NULL DEFAULT 'scan',
    lat         REAL,
    lng         REAL,
    recorded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    recorded_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_dinsp_device ON device_inspections(device_id);
CREATE INDEX IF NOT EXISTS idx_dinsp_visit ON device_inspections(visit_id);

-- The parts of town the company works. A branch sits in one, an engineer is
-- rostered onto one for a shift, and dispatch reads both to see whether the
-- person a job is being given to actually covers where it is. Kept as a list so
-- "Zayed" is the same area everywhere it is written.
-- Zones group the areas that sit near each other ("West" holding 6th of October,
-- Sheikh Zayed, Haram…). One engineer's day may span several areas of ONE zone,
-- which is how "Zayed is near October, give him both" is expressed without
-- anyone entering a distance for every pair of areas.
CREATE TABLE IF NOT EXISTS zones (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name_en    TEXT NOT NULL,
    name_ar    TEXT,
    sort_order INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    -- A ZONE THAT TAKES A WHOLE DAY. Alexandria is not a detour from Nasr City
    -- and the coast is not a detour from anywhere: an engineer sent there is
    -- there for the day. The planner will not put any other zone's work in a
    -- round that touches this one. Off by default, because for the districts
    -- of one city it is simply not true.
    own_day    INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

CREATE TABLE IF NOT EXISTS areas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name_en    TEXT NOT NULL,
    name_ar    TEXT,
    -- NULL = the area belongs to no zone, so it is never combined with another.
    zone_id    INTEGER REFERENCES zones(id) ON DELETE SET NULL,
    sort_order INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);

-- Which areas an engineer may be sent to at all. Empty for an engineer means no
-- restriction — a new hire is not accidentally unschedulable.
CREATE TABLE IF NOT EXISTS agent_areas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    area_id    INTEGER NOT NULL REFERENCES areas(id) ON DELETE CASCADE,
    -- WHICH DAYS HE WORKS THIS PATCH. NULL or empty = any day he is on the
    -- board, which is what a patch down the road means. Named days are for the
    -- patch that is a journey: "I assign Alexandria to two engineers; they go
    -- there just the two days I assign them, the rest of the week they come
    -- here and work the other areas I assigned them." Python weekdays, Mon=0,
    -- comma separated — the same numbering as agent_availability.
    weekdays   TEXT,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (agent_id, area_id)
);
CREATE INDEX IF NOT EXISTS idx_agent_areas_agent ON agent_areas(agent_id);

-- When an engineer can work, per weekday (0=Monday … 6=Sunday, Python's own
-- numbering so no conversion is needed at the point of comparison). A weekday
-- with NO row is a day the engineer does not work — absence is the "off"
-- switch, so clearing the roster of someone on leave is deleting rows.
CREATE TABLE IF NOT EXISTS agent_availability (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    weekday    INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
    start_time TEXT,                              -- 'HH:MM', NULL = all day
    end_time   TEXT,
    UNIQUE (agent_id, weekday)
);
CREATE INDEX IF NOT EXISTS idx_agent_avail_agent ON agent_availability(agent_id);
CREATE INDEX IF NOT EXISTS idx_areas_order ON areas(sort_order, id);

-- Which parts of town an area manager is responsible for. One manager can
-- hold several and the office changes them at any time, so this is a plain
-- list rather than a column on the user: today's set is the whole truth and
-- there is no history to keep. An area manager holds the PLACE, so whoever is
-- rostered into it that day is working under them — which is read from
-- agent_shifts.area_id, never stored on the person. (An engineer's standing
-- boss is a different question: that is users.team_leader_id.)
CREATE TABLE IF NOT EXISTS area_manager_areas (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    manager_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    area_id    INTEGER NOT NULL REFERENCES areas(id) ON DELETE CASCADE,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    UNIQUE (manager_id, area_id)
);
CREATE INDEX IF NOT EXISTS idx_am_areas_manager ON area_manager_areas(manager_id);
CREATE INDEX IF NOT EXISTS idx_am_areas_area ON area_manager_areas(area_id);

-- Shift catalog: the named shifts an agent can be rostered onto (Morning,
-- Night, Day Off …). is_off marks the non-working ones so the roster can count
-- working days without hard-coding names.
CREATE TABLE IF NOT EXISTS shift_types (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    code       TEXT NOT NULL UNIQUE,
    name_en    TEXT NOT NULL,
    name_ar    TEXT,
    start_time TEXT,                              -- 'HH:MM' (NULL for off/leave)
    end_time   TEXT,
    color      TEXT NOT NULL DEFAULT '#1f74d6',
    is_off     INTEGER NOT NULL DEFAULT 0,
    -- A worked shift with NO set hours. Some companies do not run 08:00–16:00
    -- blocks at all: the engineer is simply covering an area that day and
    -- finishes when the work is done. Such a shift never collides with another,
    -- so one engineer can cover two areas in a day.
    open_ended INTEGER NOT NULL DEFAULT 0,
    active     INTEGER NOT NULL DEFAULT 1,
    sort_order INTEGER NOT NULL DEFAULT 0
);

-- Weekly roster. An agent can hold SEVERAL shifts on one day (a short morning
-- and a short evening, say), so this is deliberately not unique per agent/day —
-- the server rejects overlapping hours instead. start/end_time are NULL unless
-- this entry overrides the shift type's standard hours, which is how a 2-hour
-- or 4-hour block gets recorded against a standard shift.
CREATE TABLE IF NOT EXISTS agent_shifts (
    id            INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id      INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    shift_date    TEXT NOT NULL,                  -- 'YYYY-MM-DD'
    shift_type_id INTEGER NOT NULL REFERENCES shift_types(id) ON DELETE CASCADE,
    -- The part of town this shift covers. NULL means the engineer is not tied
    -- to one that day, which is how a shift stays purely a block of hours.
    area_id       INTEGER REFERENCES areas(id) ON DELETE SET NULL,
    start_time    TEXT,
    end_time      TEXT,
    note          TEXT,
    assigned_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at    TEXT NOT NULL DEFAULT (datetime('now','localtime'))
);
CREATE INDEX IF NOT EXISTS idx_agent_shifts_agent_day ON agent_shifts(agent_id, shift_date);
CREATE INDEX IF NOT EXISTS idx_agent_shifts_date ON agent_shifts(shift_date);

-- The standing bills: rent, each salary, the annual licence, the tax the
-- company pays on a cycle. A row here is a STANDING ORDER, not a cost — it
-- posts an `expenses` row each time its next_due arrives, so the ledger below
-- stays the single record of what was actually spent.
CREATE TABLE IF NOT EXISTS cost_recurring (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    category   TEXT NOT NULL DEFAULT 'other',
    amount     REAL NOT NULL DEFAULT 0,
    frequency  TEXT NOT NULL DEFAULT 'monthly',
    start_date TEXT NOT NULL,
    next_due   TEXT,                        -- NULL = nothing more to post
    end_date   TEXT,
    user_id    INTEGER REFERENCES users(id) ON DELETE SET NULL,  -- whose salary
    vendor     TEXT,
    note       TEXT,
    auto_post  INTEGER NOT NULL DEFAULT 1,  -- 0 = remind me, I will post it
    active     INTEGER NOT NULL DEFAULT 1,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT
);
CREATE INDEX IF NOT EXISTS idx_cost_recurring_due ON cost_recurring(next_due);

-- The expense ledger: one row per amount of money that left the company, dated
-- by the period it belongs to. Rows posted from a standing order carry its id,
-- which is what keeps the posting idempotent (one row per cycle).
CREATE TABLE IF NOT EXISTS expenses (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    spent_on     TEXT NOT NULL,             -- 'YYYY-MM-DD'
    category     TEXT NOT NULL DEFAULT 'other',
    description  TEXT,
    amount       REAL NOT NULL DEFAULT 0,
    vendor       TEXT,
    method       TEXT,                      -- cash / bank / card …
    reference    TEXT,
    user_id      INTEGER REFERENCES users(id) ON DELETE SET NULL,
    recurring_id INTEGER REFERENCES cost_recurring(id) ON DELETE SET NULL,
    source       TEXT NOT NULL DEFAULT 'manual',   -- manual | recurring
    note         TEXT,
    created_by   INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT
);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON expenses(spent_on);
CREATE INDEX IF NOT EXISTS idx_expenses_cycle ON expenses(recurring_id, spent_on);

-- Pocket money: the cash an engineer carries for a taxi, a part, a repair.
-- One row per movement, always a positive amount; `kind` says which way it
-- goes. Balance = advances handed out − what was spent − what came back, over
-- the approved rows only, so a claim waiting on the office moves nothing.
--   advance — the office gave the engineer cash
--   expense — the engineer spent some of it
--   return  — the engineer handed cash back
CREATE TABLE IF NOT EXISTS petty_cash (
    id          INTEGER PRIMARY KEY AUTOINCREMENT,
    agent_id    INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    kind        TEXT NOT NULL CHECK (kind IN ('advance','expense','return')),
    amount      REAL NOT NULL,
    -- expenses only: transport | purchase | repair | other
    category    TEXT,
    spent_on    TEXT NOT NULL DEFAULT (date('now','localtime')),
    note        TEXT,
    visit_id    INTEGER REFERENCES visits(id) ON DELETE SET NULL,
    -- An engineer's claim starts pending; anything the office records itself is
    -- approved as it is written.
    status      TEXT NOT NULL DEFAULT 'pending'
                CHECK (status IN ('pending','approved','declined')),
    created_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at  TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    handled_by  INTEGER REFERENCES users(id) ON DELETE SET NULL,
    handled_at  TEXT,
    decline_reason TEXT
);
CREATE INDEX IF NOT EXISTS idx_cash_agent ON petty_cash(agent_id, status);

-- VAT the company has charged its customers and must hand to the authority.
-- One row per filing period, created once the period has closed. It is money
-- the company is holding, not money it earned — which is exactly why the cash
-- forecast has to see it.
CREATE TABLE IF NOT EXISTS vat_returns (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    period       TEXT NOT NULL UNIQUE,          -- '2026-06' or '2026-Q2'
    period_start TEXT NOT NULL,
    period_end   TEXT NOT NULL,
    due_date     TEXT NOT NULL,
    output_vat   REAL NOT NULL DEFAULT 0,       -- charged on invoices issued
    input_vat    REAL NOT NULL DEFAULT 0,       -- reclaimable, entered by the owner
    status       TEXT NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','paid')),
    expense_id   INTEGER REFERENCES expenses(id) ON DELETE SET NULL,
    note         TEXT,
    created_at   TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at   TEXT
);

-- What the owner INTENDED to spend, per category, for one year. `period` says
-- whether `amount` is per month or for the whole year; either way the page
-- prorates it to whatever window is on screen. One row per category per year,
-- so setting a budget twice corrects it rather than doubling it.
CREATE TABLE IF NOT EXISTS cost_budgets (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    category   TEXT NOT NULL,
    year       TEXT NOT NULL,                 -- 'YYYY'
    period     TEXT NOT NULL DEFAULT 'monthly' CHECK (period IN ('monthly','annual')),
    amount     REAL NOT NULL DEFAULT 0,
    note       TEXT,
    created_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
    created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')),
    updated_at TEXT,
    UNIQUE (category, year)
);
"""

# Additive migrations for databases created by an earlier version.
# EVERY SHAPE GOOGLE MAPS HANDS SOMEBODY WHO PRESSES SHARE.
#
# The office pins a branch on the phone, presses Share, and pastes what it
# gets. That is not one format, it is six, and the first version of this only
# understood one of them — so most pins were typed, silently discarded, and the
# planner went on believing it had no coordinates for anything.
#
#   .../@30.0444,31.2357,17z/...        the desktop URL bar
#   ...!3d30.0444!4d31.2357             inside the `data=` blob of the same URL
#   ?q=30.04,31.23  /  ?ll=  /  ?daddr= the query forms
#   /maps/place/30.0444,31.2357         a dropped pin with no name
#   30.0444, 31.2357                    what the "copy coordinates" menu gives
#   8FVW9V6X+7C                         a FULL plus code (needs no reference)
#
# The one shape that carries no coordinates at all is the short share link
# (maps.app.goo.gl / goo.gl/maps). Nothing can be parsed out of it; it has to
# be followed, which is a network call and lives in server.py.
_LATLNG_PATTERNS = (
    r"@(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)",
    r"!3d(-?\d{1,3}\.\d+)!4d(-?\d{1,3}\.\d+)",
    r"[?&](?:q|ll|daddr|saddr|center|destination)=(-?\d{1,3}\.\d+),\s*(-?\d{1,3}\.\d+)",
    r"/place/(-?\d{1,3}\.\d+),(-?\d{1,3}\.\d+)",
    r"^\s*(-?\d{1,3}\.\d+)\s*[,;\s]\s*(-?\d{1,3}\.\d+)\s*$",
)

# Open Location Code ("plus code"). Only the FULL form is decoded here: a short
# code like "X5VF+PG2" is meaningless without knowing which town it is near,
# and guessing the town is how a branch in Alexandria ends up pinned in Giza.
_PLUS_ALPHABET = "23456789CFGHJMPQRVWX"
_FULL_PLUS_RE = r"\b([23456789CFGHJMPQRVWX]{8}\+[23456789CFGHJMPQRVWX]{0,7})\b"


def _decode_plus_code(code):
    """A full plus code -> (lat, lng) at the centre of its cell."""
    code = code.upper().replace("+", "")
    if len(code) < 8:
        return None
    lat, lng, size = -90.0, -180.0, 20.0
    for i in range(0, min(len(code), 10), 2):
        try:
            lat += _PLUS_ALPHABET.index(code[i]) * size
            lng += _PLUS_ALPHABET.index(code[i + 1]) * size
        except (ValueError, IndexError):
            return None
        size /= 20.0
    lat += size * 10        # centre of the cell rather than its corner
    lng += size * 10
    if -90 <= lat <= 90 and -180 <= lng <= 180:
        return (round(lat, 6), round(lng, 6))
    return None


def _parse_latlng(text):
    """Best-effort (lat, lng) out of anything the office pastes. None when
    there is nothing plausible in it — including a short share link, which
    carries no coordinates and has to be followed instead."""
    import re
    if not text:
        return None
    text = str(text).strip()
    for pat in _LATLNG_PATTERNS:
        m = re.search(pat, text)
        if m:
            lat, lng = float(m.group(1)), float(m.group(2))
            if -90 <= lat <= 90 and -180 <= lng <= 180 and (lat or lng):
                return (lat, lng)
    m = re.search(_FULL_PLUS_RE, text.upper())
    if m:
        return _decode_plus_code(m.group(1))
    return None


def _migrate(conn):
    def cols(table):
        return {r[1] for r in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    # report signature columns
    for c, ddl in (("customer_name", "TEXT"), ("customer_signature", "TEXT"),
                   ("technician_signature", "TEXT")):
        if c not in cols("reports"):
            conn.execute(f"ALTER TABLE reports ADD COLUMN {c} {ddl}")
    # engineer service-log columns (materials & parts consumed per visit)
    for c, ddl in (("spare_parts_changed", "TEXT"),
                   ("lamps_used", "REAL NOT NULL DEFAULT 0"),
                   ("cables_used", "REAL NOT NULL DEFAULT 0"),
                   ("transformers_used", "REAL NOT NULL DEFAULT 0"),
                   ("light_sheets_used", "REAL NOT NULL DEFAULT 0"),
                   ("fipronil_ml", "REAL NOT NULL DEFAULT 0"),
                   ("imidacloprid_gm", "REAL NOT NULL DEFAULT 0"),
                   ("baits_count", "REAL NOT NULL DEFAULT 0"),
                   ("glo_pieces", "REAL NOT NULL DEFAULT 0"),
                   ("flybase_bags", "REAL NOT NULL DEFAULT 0"),
                   ("branch_issue", "TEXT"),
                   # site condition, picked from the office's list
                   ("condition", "TEXT")):
        if c not in cols("reports"):
            conn.execute(f"ALTER TABLE reports ADD COLUMN {c} {ddl}")
    # transportation invoice (internal-only travel log per visit)
    for c, ddl in (("transport_vehicle", "TEXT"),
                   ("transport_cost", "REAL NOT NULL DEFAULT 0")):
        if c not in cols("reports"):
            conn.execute(f"ALTER TABLE reports ADD COLUMN {c} {ddl}")
    # GPS check-in/out on visits (proof of presence)
    for c in ("checkin_at TEXT", "checkin_lat REAL", "checkin_lng REAL", "checkin_acc REAL",
              "checkout_at TEXT", "checkout_lat REAL", "checkout_lng REAL", "checkout_acc REAL"):
        if c.split()[0] not in cols("visits"):
            conn.execute(f"ALTER TABLE visits ADD COLUMN {c}")
    # chemical product expiry dates
    if "expiry_date" not in cols("chemicals"):
        conn.execute("ALTER TABLE chemicals ADD COLUMN expiry_date TEXT")
    # how a chemical was applied on a visit, and with what
    for c in ("method", "equipment"):
        if c not in cols("chemical_usage"):
            conn.execute(f"ALTER TABLE chemical_usage ADD COLUMN {c} TEXT")
    # multi-trip transportation: move any legacy single vehicle/cost pair off
    # the report into transport_entries, then clear it (so this copies once).
    conn.execute(
        "INSERT INTO transport_entries(visit_id, vehicle, cost, created_at) "
        "SELECT visit_id, NULLIF(transport_vehicle,''), COALESCE(transport_cost,0), created_at "
        "FROM reports WHERE COALESCE(transport_cost,0)>0 OR COALESCE(transport_vehicle,'')<>''")
    conn.execute(
        "UPDATE reports SET transport_vehicle=NULL, transport_cost=0 "
        "WHERE COALESCE(transport_cost,0)>0 OR COALESCE(transport_vehicle,'')<>''")
    # trips are logged as from -> to instead of picking a vehicle off a list
    for c in ("from_place TEXT", "to_place TEXT"):
        if c.split()[0] not in cols("transport_entries"):
            conn.execute(f"ALTER TABLE transport_entries ADD COLUMN {c}")
    # report draft/complete workflow: agents auto-save drafts; a report is only
    # "complete" once the core fields + both signatures are present.
    if "status" not in cols("reports"):
        conn.execute("ALTER TABLE reports ADD COLUMN status TEXT NOT NULL DEFAULT 'draft'")
        # Legacy rows predate the workflow — treat them as complete so we don't
        # nag agents to re-finish historical reports.
        conn.execute("UPDATE reports SET status='complete'")
    if "completed_at" not in cols("reports"):
        conn.execute("ALTER TABLE reports ADD COLUMN completed_at TEXT")
        conn.execute("UPDATE reports SET completed_at=created_at "
                     "WHERE completed_at IS NULL AND status='complete'")
    # business-plan flag on attachments (surfaced on the printed report)
    if "is_business_plan" not in cols("photos"):
        conn.execute("ALTER TABLE photos ADD COLUMN is_business_plan INTEGER NOT NULL DEFAULT 0")
    # per-site uploaded map-design picture
    if "map_image" not in cols("sites"):
        conn.execute("ALTER TABLE sites ADD COLUMN map_image TEXT")
    # visit number within the year/month — legacy, now derived on read
    if "visit_number" not in cols("visits"):
        conn.execute("ALTER TABLE visits ADD COLUMN visit_number INTEGER")
    # Engineer materials now go through a request an admin/manager approves.
    # Everything already in the table WAS issued, so it defaults to 'approved' —
    # no historical row changes meaning and no balance moves.
    if "status" not in cols("engineer_issues"):
        conn.execute("ALTER TABLE engineer_issues ADD COLUMN status TEXT NOT NULL "
                     "DEFAULT 'approved' "
                     "CHECK (status IN ('requested','approved','declined'))")
    for c, ddl in (("handled_by", "INTEGER"), ("handled_at", "TEXT"),
                   ("decline_reason", "TEXT")):
        if c not in cols("engineer_issues"):
            conn.execute(f"ALTER TABLE engineer_issues ADD COLUMN {c} {ddl}")
    # The engineer now confirms receipt as well (a handover both sides sign for).
    # Materials already handed over were never confirmed and never will be, so on
    # first add every existing approved row is marked received at the moment it
    # was approved — nobody is nagged about last month's stock.
    if "receipt_status" not in cols("engineer_issues"):
        for c, ddl in (("receipt_status", "TEXT"), ("receipt_at", "TEXT"),
                       ("receipt_note", "TEXT")):
            conn.execute(f"ALTER TABLE engineer_issues ADD COLUMN {c} {ddl}")
        conn.execute("UPDATE engineer_issues SET receipt_status='received', "
                     "receipt_at=COALESCE(handled_at, created_at) WHERE status='approved'")
    # Areas became a list rather than a box each branch typed into. On first
    # add, every distinct area already written on a branch becomes an entry and
    # the branch is pointed at it — so a company that has been typing "Zayed"
    # keeps its areas without anyone re-entering them. The old free-text column
    # stays exactly as it was.
    if "area_id" not in cols("sites"):
        conn.execute("ALTER TABLE sites ADD COLUMN area_id INTEGER")
        for (name,) in conn.execute(
                "SELECT DISTINCT TRIM(area) FROM sites "
                "WHERE area IS NOT NULL AND TRIM(area)<>''").fetchall():
            row = conn.execute("SELECT id FROM areas WHERE name_en=?", (name,)).fetchone()
            aid = row[0] if row else conn.execute(
                "INSERT INTO areas(name_en) VALUES(?)", (name,)).lastrowid
            conn.execute("UPDATE sites SET area_id=? WHERE TRIM(area)=?", (aid, name))
    if "area_id" not in cols("clients"):
        conn.execute("ALTER TABLE clients ADD COLUMN area_id INTEGER")
    if "area_id" not in cols("agent_shifts"):
        conn.execute("ALTER TABLE agent_shifts ADD COLUMN area_id INTEGER")
    # A clear that eats into an applied run now says so on the run itself, so
    # Undo and the run history keep telling the truth. NULL on every existing
    # row, which reads as "no clear has touched this run" — the only honest
    # thing to say about a run that predates the bookkeeping.
    for c, ddl in (("cleared_at", "TEXT"), ("cleared_by", "INTEGER"),
                   ("cleared_visits", "INTEGER NOT NULL DEFAULT 0"),
                   ("cleared_shifts", "INTEGER NOT NULL DEFAULT 0")):
        if c not in cols("roster_runs"):
            conn.execute(f"ALTER TABLE roster_runs ADD COLUMN {c} {ddl}")
    # Per-line approval: the office can now approve some materials and not
    # others, and cut a quantity. Left NULL on every existing row, which reads
    # as "approved, exactly as asked" — so no past issue changes meaning and no
    # engineer's balance moves.
    for c, ddl in (("approved_quantity", "REAL"), ("line_status", "TEXT")):
        if c not in cols("engineer_issue_items"):
            conn.execute(f"ALTER TABLE engineer_issue_items ADD COLUMN {c} {ddl}")
    # invoice columns
    for c, ddl in (("contract_id", "INTEGER"), ("doc_type", "TEXT DEFAULT 'invoice'"),
                   ("valid_until", "TEXT")):
        if c not in cols("invoices"):
            conn.execute(f"ALTER TABLE invoices ADD COLUMN {c} {ddl}")
    # invoice -> location link (per-location finance). On first add, backfill from
    # the linked visit's site so existing visit-invoices attribute to that location.
    if "site_id" not in cols("invoices"):
        conn.execute("ALTER TABLE invoices ADD COLUMN site_id INTEGER")
        conn.execute("UPDATE invoices SET site_id=(SELECT v.site_id FROM visits v WHERE v.id=invoices.visit_id) "
                     "WHERE visit_id IS NOT NULL")
    # token_version: bump to revoke a user's existing session tokens.
    # try/except guards against a race when two instances init the same DB at once.
    if "token_version" not in cols("users"):
        try:
            conn.execute("ALTER TABLE users ADD COLUMN token_version INTEGER NOT NULL DEFAULT 0")
        except sqlite3.OperationalError:
            pass  # another process added it first
    # Drop the old CHECK on invoices.status (rebuild) if present.
    ddl_row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='invoices'").fetchone()
    if ddl_row and "CHECK (status IN" in (ddl_row[0] or ""):
        conn.executescript("""
            PRAGMA foreign_keys=OFF;
            CREATE TABLE invoices_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                client_id INTEGER NOT NULL, visit_id INTEGER, contract_id INTEGER,
                doc_type TEXT NOT NULL DEFAULT 'invoice', number TEXT NOT NULL,
                issue_date TEXT NOT NULL, due_date TEXT, valid_until TEXT,
                amount REAL NOT NULL DEFAULT 0, tax REAL NOT NULL DEFAULT 0,
                total REAL NOT NULL DEFAULT 0, status TEXT NOT NULL DEFAULT 'draft',
                notes TEXT, created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
            INSERT INTO invoices_new (id,client_id,visit_id,contract_id,doc_type,number,
                issue_date,due_date,valid_until,amount,tax,total,status,notes,created_at)
                SELECT id,client_id,visit_id,contract_id,doc_type,number,issue_date,due_date,
                valid_until,amount,tax,total,status,notes,created_at FROM invoices;
            DROP TABLE invoices; ALTER TABLE invoices_new RENAME TO invoices;
            PRAGMA foreign_keys=ON;
        """)
    # Allow the 'issue' reason on inventory_transactions (engineer material
    # issues). Rebuild the table if its CHECK predates that value.
    inv_row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='inventory_transactions'").fetchone()
    if inv_row and "'issue'" not in (inv_row[0] or ""):
        conn.executescript("""
            PRAGMA foreign_keys=OFF;
            CREATE TABLE inventory_transactions_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                chemical_id INTEGER NOT NULL REFERENCES chemicals(id) ON DELETE CASCADE,
                change REAL NOT NULL,
                reason TEXT NOT NULL CHECK (reason IN ('purchase','usage','adjustment','issue')),
                reference TEXT, note TEXT,
                created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
            INSERT INTO inventory_transactions_new (id,chemical_id,change,reason,reference,note,created_at)
                SELECT id,chemical_id,change,reason,reference,note,created_at FROM inventory_transactions;
            DROP TABLE inventory_transactions; ALTER TABLE inventory_transactions_new RENAME TO inventory_transactions;
            PRAGMA foreign_keys=ON;
        """)
    # Chasing an overdue invoice is a relationship decision, so it is per
    # customer: some are chased, some are handled with a phone call.
    if "dunning" not in cols("clients"):
        conn.execute("ALTER TABLE clients ADD COLUMN dunning INTEGER NOT NULL DEFAULT 1")
    # Receipts live in the photos table, so its CHECK has to admit 'expense' (a
    # company cost) and 'cash' (pocket money an engineer spent). SQLite cannot
    # alter a CHECK — rebuild when it predates either value, carrying every
    # attachment across.
    ph_row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='photos'").fetchone()
    ph_sql = (ph_row[0] or "") if ph_row else ""
    if ph_row and ("'expense'" not in ph_sql or "'cash'" not in ph_sql):
        conn.executescript("""
            PRAGMA foreign_keys=OFF;
            CREATE TABLE photos_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                entity_type TEXT NOT NULL
                    CHECK (entity_type IN ('client','report','visit','chemical','expense','cash')),
                entity_id INTEGER NOT NULL,
                filename TEXT NOT NULL, original_name TEXT, caption TEXT,
                is_business_plan INTEGER NOT NULL DEFAULT 0,
                uploaded_by INTEGER REFERENCES users(id) ON DELETE SET NULL,
                uploaded_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
            INSERT INTO photos_new (id,entity_type,entity_id,filename,original_name,caption,
                is_business_plan,uploaded_by,uploaded_at)
                SELECT id,entity_type,entity_id,filename,original_name,caption,
                is_business_plan,uploaded_by,uploaded_at FROM photos;
            DROP TABLE photos; ALTER TABLE photos_new RENAME TO photos;
            CREATE INDEX IF NOT EXISTS idx_photos_filename ON photos(filename);
            PRAGMA foreign_keys=ON;
        """)
    # Consumable materials (UV lamps, glue boards, etc.) are real inventory items
    # so they can be issued to engineers and tracked against the report counters
    # that record their use. material_key ties an inventory row to its report
    # column. Only ensure them here when the catalog already has rows (existing
    # DBs); on a fresh DB seed.py adds them AFTER the real chemicals so ids stay
    # in seed order.
    if "material_key" not in cols("chemicals"):
        conn.execute("ALTER TABLE chemicals ADD COLUMN material_key TEXT")
    if conn.execute("SELECT COUNT(*) FROM chemicals").fetchone()[0] > 0:
        ensure_material_items(conn)
    # QR-coded devices: every marker gets an unguessable token printed as a QR
    # label. Scanning it deep-links to /scan/<token> for 2-second tap-to-inspect.
    if "qr_token" not in cols("map_markers"):
        conn.execute("ALTER TABLE map_markers ADD COLUMN qr_token TEXT")
        # Backfill a random token for existing devices (randomblob = 32 hex chars).
        conn.execute("UPDATE map_markers SET qr_token=lower(hex(randomblob(16))) "
                     "WHERE qr_token IS NULL")
    # Created here (not in SCHEMA) so it runs only after the column is guaranteed
    # to exist — on both fresh and migrated databases.
    conn.execute("CREATE UNIQUE INDEX IF NOT EXISTS idx_markers_qr ON map_markers(qr_token)")
    # Per-type follow-up fields captured when a device is scanned (JSON blob:
    # e.g. bait_status/consumption_pct for bait stations, fly_count for light
    # traps …). Nullable — legacy status-only inspections leave it NULL.
    if "details" not in cols("device_inspections"):
        conn.execute("ALTER TABLE device_inspections ADD COLUMN details TEXT")
    # Free-text note of exactly where inside the site a device sits, so the next
    # engineer can find it without hunting.
    if "placement" not in cols("devices"):
        conn.execute("ALTER TABLE devices ADD COLUMN placement TEXT")
    # Recurring billing columns on contracts. Default OFF for existing contracts
    # (auto_invoice=0, next_bill_date NULL) so the migration never retro-bills
    # history — billing is opt-in per contract via the contract form.
    ccols = cols("contracts")
    if "bill_every" not in ccols:
        conn.execute("ALTER TABLE contracts ADD COLUMN bill_every TEXT")
    if "next_bill_date" not in ccols:
        conn.execute("ALTER TABLE contracts ADD COLUMN next_bill_date TEXT")
    if "auto_invoice" not in ccols:
        conn.execute("ALTER TABLE contracts ADD COLUMN auto_invoice INTEGER NOT NULL DEFAULT 0")
    if "quote_id" not in ccols:
        # Which quote this contract came from, when it came from one. Keeps the
        # sales trail joined to the delivery record instead of the two being
        # separate stories about the same customer.
        conn.execute("ALTER TABLE contracts ADD COLUMN quote_id INTEGER "
                     "REFERENCES invoices(id) ON DELETE SET NULL")
    # Who brought the contract in, and on what commission. Existing contracts
    # are credited to NOBODY rather than to whoever happens to service them —
    # guessing here would pay a real person real money for somebody else's work.
    if "sold_by" not in ccols:
        conn.execute("ALTER TABLE contracts ADD COLUMN sold_by INTEGER "
                     "REFERENCES users(id) ON DELETE SET NULL")
    if "commission_rate" not in ccols:
        conn.execute("ALTER TABLE contracts ADD COLUMN commission_rate REAL")
    # After the ALTER, for the same reason as idx_markers_qr above.
    conn.execute("CREATE INDEX IF NOT EXISTS idx_contracts_sold_by ON contracts(sold_by)")
    # Tamper-evident scan trail: where (geo) and how (scan vs manual) each
    # inspection was recorded.
    me_cols = cols("marker_events")
    if "source" not in me_cols:
        conn.execute("ALTER TABLE marker_events ADD COLUMN source TEXT NOT NULL DEFAULT 'manual'")
    if "lat" not in me_cols:
        conn.execute("ALTER TABLE marker_events ADD COLUMN lat REAL")
    if "lng" not in me_cols:
        conn.execute("ALTER TABLE marker_events ADD COLUMN lng REAL")
    # Technician licensing/certification (surfaced on auditor Audit Packs).
    u_cols = cols("users")
    if "license_no" not in u_cols:
        conn.execute("ALTER TABLE users ADD COLUMN license_no TEXT")
    if "license_expiry" not in u_cols:
        conn.execute("ALTER TABLE users ADD COLUMN license_expiry TEXT")
    # Per-location client portal logins. Existing accounts stay NULL = they keep
    # seeing the whole company, so the migration changes nobody's access.
    if "site_id" not in u_cols:
        conn.execute("ALTER TABLE users ADD COLUMN site_id INTEGER REFERENCES sites(id) ON DELETE SET NULL")
    # Supervisors. users.role carries a CHECK and SQLite cannot alter one, so
    # admitting a role means rebuilding the table — the same shape as the
    # photos rebuild above. It MUST stay after every users ALTER in this
    # function, or the copy would drop a column added later on.
    # IDS ARE PRESERVED: session tokens embed the user id, every other table
    # references it, and the audit trail names it.
    #
    # The supervising role used to be one thing called 'leader': an engineer
    # holding parts of town. It is now two, and the old one is the AREA half —
    # every existing leader keeps exactly the areas and the sight they had, and
    # is renamed 'area_manager' in place. 'team_leader' is the new PEOPLE half
    # and starts out with nobody on it, so this migration changes no access.
    us_row = conn.execute(
        "SELECT sql FROM sqlite_master WHERE type='table' AND name='users'").fetchone()
    # Matched on the CHECK's role list rather than the word alone: the column
    # comment names the new roles too, and a comment must not be mistaken for
    # a constraint that admits them.
    if us_row and "'agent','area_manager','team_leader'" not in (us_row[0] or ""):
        conn.executescript("""
            PRAGMA foreign_keys=OFF;
            CREATE TABLE users_new (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                full_name TEXT NOT NULL,
                email TEXT NOT NULL UNIQUE,
                password_hash TEXT NOT NULL,
                role TEXT NOT NULL
                    CHECK (role IN ('admin','manager','agent','area_manager','team_leader','client')),
                phone TEXT,
                client_id INTEGER REFERENCES clients(id) ON DELETE SET NULL,
                site_id INTEGER REFERENCES sites(id) ON DELETE SET NULL,
                team_leader_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
                specialization TEXT, hire_date TEXT,
                license_no TEXT, license_expiry TEXT,
                lang TEXT NOT NULL DEFAULT 'en',
                active INTEGER NOT NULL DEFAULT 1,
                token_version INTEGER NOT NULL DEFAULT 0,
                created_at TEXT NOT NULL DEFAULT (datetime('now','localtime')));
            INSERT INTO users_new (id,full_name,email,password_hash,role,phone,client_id,
                site_id,team_leader_id,specialization,hire_date,license_no,license_expiry,
                lang,active,token_version,created_at)
                SELECT id,full_name,email,password_hash,
                CASE role WHEN 'leader' THEN 'area_manager' ELSE role END,
                phone,client_id,site_id,NULL,
                specialization,hire_date,license_no,license_expiry,lang,active,
                token_version,created_at FROM users;
            DROP TABLE users; ALTER TABLE users_new RENAME TO users;
            PRAGMA foreign_keys=ON;
        """)
    # A patch belongs to an area manager now. Same rows, same ids — only the
    # names say who holds them.
    # Normally the schema script above has already created the empty new table,
    # so the rows move across and the old one is retired. On a database opened
    # without that script (the migration tests do exactly this) the table is
    # renamed in place instead — either way the patches survive with their ids.
    if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                    "AND name='leader_areas'").fetchone():
        if conn.execute("SELECT 1 FROM sqlite_master WHERE type='table' "
                        "AND name='area_manager_areas'").fetchone():
            conn.execute("INSERT OR IGNORE INTO area_manager_areas(manager_id,area_id,created_at) "
                         "SELECT leader_id,area_id,created_at FROM leader_areas")
            conn.execute("DROP TABLE leader_areas")
        else:
            conn.execute("ALTER TABLE leader_areas RENAME TO area_manager_areas")
            conn.execute("ALTER TABLE area_manager_areas RENAME COLUMN leader_id TO manager_id")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_am_areas_manager "
                     "ON area_manager_areas(manager_id)")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_am_areas_area "
                     "ON area_manager_areas(area_id)")
    # Belt and braces: a database rebuilt before this column existed.
    if "team_leader_id" not in cols("users"):
        conn.execute("ALTER TABLE users ADD COLUMN team_leader_id INTEGER "
                     "REFERENCES users(id) ON DELETE SET NULL")
    # Automatic scheduling needs three facts per branch — where, when, how often —
    # and areas grouped into zones so "near" means something. All additive: an
    # existing branch gets no window and visits_per_week=0, which the generator
    # reads as "not on a routine cycle", so nothing is scheduled behind anyone's
    # back the moment this deploys.
    st_cols = cols("sites")
    if "service_from" not in st_cols:
        conn.execute("ALTER TABLE sites ADD COLUMN service_from TEXT")
    if "service_to" not in st_cols:
        conn.execute("ALTER TABLE sites ADD COLUMN service_to TEXT")
    if "visits_per_week" not in st_cols:
        conn.execute("ALTER TABLE sites ADD COLUMN visits_per_week REAL NOT NULL DEFAULT 0")
    if "visit_minutes" not in st_cols:
        # NULL on every existing branch = "use the company default", so adding
        # this changes no schedule until somebody types a length.
        conn.execute("ALTER TABLE sites ADD COLUMN visit_minutes INTEGER")
    if "weekdays" not in cols("agent_areas"):
        # NULL everywhere = "any day he works", which is how every engineer's
        # patches already behave, so this changes no plan until somebody names
        # the days for a patch that is a journey rather than a commute.
        conn.execute("ALTER TABLE agent_areas ADD COLUMN weekdays TEXT")
    if "own_day" not in cols("zones"):
        # 0 everywhere = every zone behaves as it did, so this changes no plan
        # until somebody ticks the box on a zone that really is a day's travel.
        conn.execute("ALTER TABLE zones ADD COLUMN own_day INTEGER NOT NULL DEFAULT 0")
    if "preferred_agent_id" not in st_cols:
        # NULL everywhere = "the roster decides", which is how every branch
        # already behaves, so adding this moves nothing until a name is typed.
        conn.execute("ALTER TABLE sites ADD COLUMN preferred_agent_id INTEGER")
    if "agent_id" not in cols("site_service_days"):
        conn.execute("ALTER TABLE site_service_days ADD COLUMN agent_id INTEGER")
    if "zone_id" not in cols("areas"):
        conn.execute("ALTER TABLE areas ADD COLUMN zone_id INTEGER")
    # Shifts with no set hours (see the column comment). Existing shift types
    # keep their hours — nothing about an established roster changes — and the
    # "Area cover" type below is added once so an office that works by area
    # rather than by clock has something to roster with out of the box.
    if "open_ended" not in cols("shift_types"):
        conn.execute("ALTER TABLE shift_types ADD COLUMN open_ended INTEGER NOT NULL DEFAULT 0")
    if conn.execute("SELECT COUNT(*) FROM shift_types").fetchone()[0] > 0:
        ensure_cover_shift(conn)
    # Fast per-file upload authorization: /uploads/<file> looks the file up by
    # name to decide who may read it, so index the column.
    conn.execute("CREATE INDEX IF NOT EXISTS idx_photos_filename ON photos(filename)")
    # Site geo-coordinates for smart dispatch + route optimization. Backfill from
    # any contract_sites.map_location already stored as a "lat,lng" string.
    s_cols = cols("sites")
    if "lat" not in s_cols:
        conn.execute("ALTER TABLE sites ADD COLUMN lat REAL")
    if "lng" not in s_cols:
        conn.execute("ALTER TABLE sites ADD COLUMN lng REAL")
        for cs in conn.execute(
                "SELECT site_id, map_location FROM contract_sites "
                "WHERE site_id IS NOT NULL AND map_location IS NOT NULL").fetchall():
            ll = _parse_latlng(cs[1])
            if ll:
                conn.execute("UPDATE sites SET lat=?, lng=? WHERE id=? AND lat IS NULL",
                             (ll[0], ll[1], cs[0]))
    # Which contract a visit was worked under. Needed to tell the owner whether
    # a contract earns its keep: without it a visit's materials, travel and
    # labour can only be pinned on the customer, never on the deal.
    if "contract_id" not in cols("visits"):
        conn.execute("ALTER TABLE visits ADD COLUMN contract_id INTEGER "
                     "REFERENCES contracts(id) ON DELETE SET NULL")
        _backfill_visit_contracts(conn)
    conn.execute("CREATE INDEX IF NOT EXISTS idx_visits_contract ON visits(contract_id)")
    # Weekly agent roster: seed the starter shift catalog so the Shifts page has
    # something to assign on both fresh and existing databases.
    ensure_shift_types(conn)
    # An agent may now hold more than one shift in a day (split AM/PM cover), so
    # retire the old one-per-day unique index. Overlapping hours are rejected in
    # the API instead, which the index could never express.
    conn.execute("DROP INDEX IF EXISTS idx_agent_shift_day")

    # THE CYCLE IS COUNTED IN MONTHS, NOT WEEKS. The office sells and thinks in
    # visits a month; asking it for a weekly number meant typing 0.5 for the
    # fortnightly branch and 0.25 for the monthly one, which is the kind of
    # arithmetic that gets a customer visited four times too often. The column
    # keeps the SAME rhythm across the rename — a branch on 1 a week becomes 4
    # a month — so nothing already booked changes meaning.
    if "visits_per_month" not in cols("sites"):
        conn.execute("ALTER TABLE sites RENAME COLUMN visits_per_week TO visits_per_month")
        conn.execute("UPDATE sites SET visits_per_month = "
                     "ROUND(COALESCE(visits_per_month, 0) * 4, 2)")
    # WHICH UNIT EACH BRANCH IS READ IN. Both are offered, because a restaurant
    # serviced twice a week and a warehouse serviced once a month are not
    # comfortably said in the same unit. A branch that was on the book BEFORE
    # the choice existed keeps reading in weeks — those are the numbers the
    # office typed, and they must still be on screen unchanged the next morning.
    if "freq_unit" not in cols("sites"):
        conn.execute("ALTER TABLE sites ADD COLUMN freq_unit TEXT NOT NULL DEFAULT 'week'")
        conn.execute("UPDATE sites SET freq_unit='week'")
    # A BRANCH CAN BE SWITCHED OFF. Every branch already on the book is one the
    # company services, so they all come across as active and no roster changes.
    if "status" not in cols("sites"):
        conn.execute("ALTER TABLE sites ADD COLUMN status TEXT NOT NULL "
                     "DEFAULT 'active' CHECK (status IN ('active','inactive'))")
    # The pasted map link, kept beside the pin it produced.
    if "map_url" not in cols("sites"):
        conn.execute("ALTER TABLE sites ADD COLUMN map_url TEXT")
    # WHAT EACH PERSON WANTS ON THE FRONT OF THEIR MENU. A PREFERENCE, never a
    # permission: the owner's sidebar carries thirty-odd sections because every
    # one of them is his by right, and the answer to "I never use most of
    # these" is to move them, not to take them away. Anything hidden here is
    # still his to open — see `nav_hidden` and the "More" section.
    conn.execute("""CREATE TABLE IF NOT EXISTS user_prefs (
        user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
        key     TEXT NOT NULL,
        value   TEXT,
        PRIMARY KEY (user_id, key)
    )""")
    # FIXED ASSIGNMENTS / RESIDENT POSTS. Hours the company has already sold to
    # one site — a man resident at a factory all day — kept deliberately APART
    # from availability. Availability is when a man CAN work; a post is time
    # already spoken for. The roster subtracts the second from the first before
    # it places anything, so those hours are never offered to ordinary work.
    conn.execute("""CREATE TABLE IF NOT EXISTS fixed_assignments (
        id               INTEGER PRIMARY KEY AUTOINCREMENT,
        site_id          INTEGER NOT NULL REFERENCES sites(id) ON DELETE CASCADE,
        primary_agent_id INTEGER NOT NULL REFERENCES users(id),
        relief_agent_id  INTEGER REFERENCES users(id),
        primary_weekdays TEXT NOT NULL DEFAULT '',
        relief_weekdays  TEXT NOT NULL DEFAULT '',
        from_time        TEXT NOT NULL,
        to_time          TEXT NOT NULL,
        start_date       TEXT,                    -- the contract's own period;
        end_date         TEXT,                    -- blank at either end = open
        active           INTEGER NOT NULL DEFAULT 1,
        created_at       TEXT NOT NULL DEFAULT (datetime('now','localtime'))
    )""")
    conn.execute("CREATE INDEX IF NOT EXISTS idx_fixed_site "
                 "ON fixed_assignments(site_id, active)")
    for c in ("start_date", "end_date"):          # posts that predate the period
        if c not in cols("fixed_assignments"):
            conn.execute(f"ALTER TABLE fixed_assignments ADD COLUMN {c} TEXT")
    # MORE THAN ONE WORKING WINDOW A DAY. A man may work 08:00-12:00 and again
    # 16:00-20:00 with the middle of the day his own, so the old
    # UNIQUE (agent_id, weekday) — one row per weekday — has to go. SQLite
    # cannot drop a constraint, so the table is rebuilt; every existing row is
    # carried across untouched and a single-window engineer is unchanged.
    if "UNIQUE (agent_id, weekday)" in (conn.execute(
            "SELECT sql FROM sqlite_master WHERE name='agent_availability'"
    ).fetchone() or [""])[0]:
        conn.execute("""CREATE TABLE agent_availability_new (
            id         INTEGER PRIMARY KEY AUTOINCREMENT,
            agent_id   INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            weekday    INTEGER NOT NULL CHECK (weekday BETWEEN 0 AND 6),
            start_time TEXT,
            end_time   TEXT
        )""")
        conn.execute("INSERT INTO agent_availability_new (id, agent_id, weekday, "
                     "start_time, end_time) SELECT id, agent_id, weekday, "
                     "start_time, end_time FROM agent_availability")
        conn.execute("DROP TABLE agent_availability")
        conn.execute("ALTER TABLE agent_availability_new RENAME TO agent_availability")
        conn.execute("CREATE INDEX IF NOT EXISTS idx_avail_agent "
                     "ON agent_availability(agent_id, weekday)")


def _backfill_visit_contracts(conn):
    """Attach existing visits to the contract they were worked under.

    Two passes, both conservative. Visits generated from a contract say so in
    their notes, which is exact. Everything else is only linked when the client
    has EXACTLY ONE contract covering that date whose service type matches (or
    which names no service type) — where there is any doubt the visit stays
    unattributed rather than crediting the wrong deal."""
    conn.execute(
        "UPDATE visits SET contract_id = CAST(replace(notes,"
        "'Auto-generated from contract #','') AS INTEGER) "
        "WHERE contract_id IS NULL AND notes LIKE 'Auto-generated from contract #%' "
        "AND EXISTS (SELECT 1 FROM contracts c WHERE c.id = CAST(replace(notes,"
        "'Auto-generated from contract #','') AS INTEGER))")
    rows = conn.execute(
        "SELECT id, client_id, service_type_id, date(scheduled_start) d FROM visits "
        "WHERE contract_id IS NULL").fetchall()
    for vid, cid, stid, day in rows:
        cands = conn.execute(
            "SELECT id FROM contracts WHERE client_id=? AND date(start_date) <= date(?) "
            "AND (end_date IS NULL OR date(end_date) >= date(?)) "
            "AND (service_type_id IS NULL OR service_type_id IS ?)",
            (cid, day, day, stid)).fetchall()
        if len(cands) == 1:
            conn.execute("UPDATE visits SET contract_id=? WHERE id=?", (cands[0][0], vid))


# Starter shift catalog, created once per database. Managers can rename these,
# change the hours or add their own from the Shifts page — the codes are only
# used to seed them, never looked up by name afterwards.
SHIFT_TYPES = (
    # code, name_en, name_ar, start, end, color, is_off
    ("morning", "Morning",  "صباحي",       "08:00", "16:00", "#1f74d6", 0),
    ("evening", "Evening",  "مسائي",       "16:00", "00:00", "#7c5cd6", 0),
    ("night",   "Night",    "ليلي",        "00:00", "08:00", "#334155", 0),
    ("off",     "Day Off",  "راحة",        None,    None,    "#94a3b8", 1),
    ("leave",   "Leave",    "إجازة",       None,    None,    "#d97706", 1),
)


def ensure_shift_types(conn):
    """Idempotently create the starter shift catalog (keyed on code)."""
    for i, (code, en, ar, start, end, color, is_off) in enumerate(SHIFT_TYPES):
        if not conn.execute("SELECT 1 FROM shift_types WHERE code=?", (code,)).fetchone():
            conn.execute(
                "INSERT INTO shift_types(code,name_en,name_ar,start_time,end_time,color,"
                "is_off,sort_order) VALUES(?,?,?,?,?,?,?,?)",
                (code, en, ar, start, end, color, is_off, i))
    # The hours-free area shift belongs to the starter catalog too, so a brand
    # new database has it without depending on the migration below running.
    ensure_cover_shift(conn)


# Consumable inventory items, keyed to their report counter column.
MATERIAL_ITEMS = (
    ("lamps_used",        "UV Lamp",                  "مصباح UV",      "pcs"),
    ("cables_used",       "Cable",                    "كابل",          "pcs"),
    ("transformers_used", "Transformer",              "محول",          "pcs"),
    ("light_sheets_used", "Light Sheet (Glue Board)", "لوح لاصق",      "pcs"),
    ("glo_pieces",        "Glo Board Piece",          "قطعة جلو",      "pcs"),
    ("flybase_bags",      "Flybase Bag",              "كيس فلاي بيس",  "bag"),
)


def ensure_cover_shift(conn):
    """Idempotently add the hours-free "Area cover" shift.

    It is what an office rosters with when the day is defined by WHERE someone
    works rather than by when: no start or end, so it never clashes and an
    engineer can hold two areas on the same day. Sorted first because for such
    an office it is the normal case, not the exception.

    THE TEST IS "is there an hours-free shift?", NOT "is the code 'cover'
    taken?". A live office renamed this very row into their own lineup — it
    became "After Midnight 1", 00:00-02:00, with the hours-free flag cleared —
    and because the code still existed this function did nothing, so the
    auto-roster went on rostering with a two-hour night shift. The moment one
    engineer needed two of them in a day the roster was refused as an overlap
    and the WHOLE week rolled back. Their shift is theirs; take a free code and
    make a new one rather than writing over it."""
    if conn.execute("SELECT 1 FROM shift_types WHERE open_ended=1 AND active=1").fetchone():
        return
    code, n = "cover", 2
    while conn.execute("SELECT 1 FROM shift_types WHERE code=?", (code,)).fetchone():
        code, n = f"area-cover-{n}", n + 1
    name = "Area cover"
    while conn.execute("SELECT 1 FROM shift_types WHERE name_en=?", (name,)).fetchone():
        name = f"Area cover {n}"
        n += 1
    conn.execute(
        "INSERT INTO shift_types(code,name_en,name_ar,start_time,end_time,color,is_off,"
        "open_ended,active,sort_order) VALUES(?,?,'تغطية منطقة',"
        "NULL,NULL,'#0f766e',0,1,1,-1)", (code, name))


def ensure_material_items(conn):
    """Idempotently create the consumable inventory items (keyed on material_key)."""
    for key, en, ar, unit in MATERIAL_ITEMS:
        if not conn.execute("SELECT 1 FROM chemicals WHERE material_key=?", (key,)).fetchone():
            conn.execute(
                "INSERT INTO chemicals(name_en,name_ar,unit,quantity_in_stock,reorder_level,material_key) "
                "VALUES(?,?,?,0,0,?)", (en, ar, unit, key))


_local = threading.local()


def _new_conn():
    # timeout lets a writer wait instead of failing instantly on a locked DB.
    conn = sqlite3.connect(DB_PATH, timeout=5.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON")
    # busy_timeout makes contending writers wait up to 5s rather than erroring.
    # (journal_mode=WAL is persisted in the DB file by init_db, so it need not
    # be re-issued per connection — that just adds latency to every query.)
    conn.execute("PRAGMA busy_timeout = 5000")
    # synchronous=NORMAL is durable under WAL and markedly faster on writes.
    conn.execute("PRAGMA synchronous = NORMAL")
    return conn


def get_conn():
    """One SQLite connection reused per thread. The server is threaded (one
    thread per keep-alive connection, each serving many queries), so caching the
    connection avoids reconnecting + re-issuing PRAGMAs on every single query.
    query()/execute()/transaction() always commit or roll back, so a cached
    connection is never left mid-transaction between calls. The connection is
    closed automatically when its thread ends (the threading.local is dropped)."""
    conn = getattr(_local, "conn", None)
    if conn is None:
        conn = _new_conn()
        _local.conn = conn
    return conn


def close_conn():
    """Close and drop this thread's cached connection (if any)."""
    conn = getattr(_local, "conn", None)
    if conn is not None:
        try:
            conn.close()
        finally:
            _local.conn = None


@contextlib.contextmanager
def transaction():
    """Run several statements on one connection, committed atomically.

    Usage:
        with db.transaction() as cx:
            cx.execute(...); cx.execute(...)
    On any exception the whole block is rolled back. cx.execute returns the
    cursor, so cx.execute(...).lastrowid gives the new id.
    """
    conn = get_conn()
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise


def _backfill_marker_events(conn):
    """Seed demo monitoring history once, so pest-trend charts are meaningful
    on existing databases. Only runs when there are markers but no events yet.
    Real events are recorded going forward whenever a device status is set."""
    has_events = conn.execute("SELECT 1 FROM marker_events LIMIT 1").fetchone()
    markers = conn.execute(
        "SELECT k.id, k.map_id, k.type, k.status, m.client_id "
        "FROM map_markers k JOIN maps m ON m.id=k.map_id").fetchall()
    if has_events or not markers:
        return
    import random
    random.seed(42)
    for mk in markers:
        # 6 monthly inspections; devices currently showing activity get
        # occasional historical detections so a trend emerges.
        prone = mk["status"] in ("activity", "needs_service")
        for months_ago in range(6, 0, -1):
            if prone and random.random() < 0.45:
                st = "activity"
            elif random.random() < 0.12:
                st = "needs_service"
            else:
                st = "ok"
            conn.execute(
                "INSERT INTO marker_events(marker_id,map_id,client_id,type,status,note,recorded_at) "
                "VALUES(?,?,?,?,?,?,datetime('now','localtime',?))",
                (mk["id"], mk["map_id"], mk["client_id"], mk["type"], st,
                 "Routine inspection", f"-{months_ago} months"))
        # a current-state event reflecting the device's present status
        conn.execute(
            "INSERT INTO marker_events(marker_id,map_id,client_id,type,status,note) "
            "VALUES(?,?,?,?,?,?)",
            (mk["id"], mk["map_id"], mk["client_id"], mk["type"], mk["status"], "Latest inspection"))


def init_db():
    os.makedirs(os.path.dirname(DB_PATH), exist_ok=True)
    # Use a throwaway connection (not the thread-local cache) so the one-off
    # setup close doesn't invalidate a cached connection for this thread.
    conn = _new_conn()
    # WAL persists in the DB file; setting it once here lets every later
    # connection inherit it (concurrent readers alongside a writer).
    conn.execute("PRAGMA journal_mode = WAL")
    conn.executescript(SCHEMA)
    _migrate(conn)
    _backfill_marker_events(conn)
    conn.commit()
    conn.close()


def query(sql, params=(), one=False):
    conn = get_conn()
    try:
        cur = conn.execute(sql, params)
        rows = cur.fetchall()
    except Exception:
        # Leave the reused connection clean for the next call on this thread.
        conn.rollback()
        raise
    if one:
        return dict(rows[0]) if rows else None
    return [dict(r) for r in rows]


def execute(sql, params=()):
    """Run an INSERT/UPDATE/DELETE. Returns lastrowid."""
    conn = get_conn()
    try:
        cur = conn.execute(sql, params)
        conn.commit()
        return cur.lastrowid
    except Exception:
        conn.rollback()
        raise


if __name__ == "__main__":
    init_db()
    print("Database initialized at", DB_PATH)
