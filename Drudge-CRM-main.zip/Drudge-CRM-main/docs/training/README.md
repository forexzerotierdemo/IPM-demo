# Fox CRM — training material / مواد تدريب فوكس CRM

Two self-contained pages. Both are **English and Arabic in one file** — the
`English / عربي` buttons at the top swap every word and flip the page
right-to-left, the same way the CRM itself does.

| File | What it is | Use it for |
|---|---|---|
| **`fox-crm-training.html`** | The course. Seven sections, one per audience, from "what is this system" to a setup checklist. | Teaching somebody the CRM from scratch. Read it start to finish. |
| **`fox-crm-pages.html`** | The reference. **42 pages** of the CRM documented one by one — purpose, what is on the page, how it works, and the traps. | Looking up one screen. Keep it open beside the CRM. |

Start people on the course; leave them the reference.

## How to use it

| To do this | Do that |
|---|---|
| **Read it** | Download the file and open it in any browser. Neither needs internet or a server. |
| **Make a PDF** | Open it, choose the language you want, then print (`Ctrl+P` / `⌘P`) and save as PDF. Print styling is built in — the toggle and menu are hidden and sections do not split across pages. |
| **Present it** | Open it full screen. The seven sections are the seven parts of a training session. |
| **Send it to somebody** | It is one file. Email it, put it on WhatsApp, or print it. |

## What is in the course (`fox-crm-training.html`)

1. **What this system does** — the flow from lead to invoice, and who uses what
2. **For the office** — setting it up in the right order, then the weekly one button
3. **For the engineer** — installing the app, the day step by step, working with no signal
4. **For the team leader** — their patch, their team, and what stays with the office
5. **For the customer** — the portal
6. **Uploading your data** — the spreadsheet import, and everything else you can upload
7. **Setup checklist & common problems** — what to tick off, and what each symptom means

## What is in the reference (`fox-crm-pages.html`)

Every sidebar item, grouped the way work flows, each with its purpose, a list of
what is actually on the page, and 💡 tips / ⚠️ traps where they matter:

1. **Everyday screens** — Dashboard, Search, Calendar, Workflow
2. **Customers and their branches** — Leads, Clients, the company folder, Branches, Areas
3. **Planning the work** — Branch schedule, Engineer availability, Shifts, Dispatch, Visit Schedule, My Day, My Team
4. **Doing the work** — the visit page, Device QR Codes, the scan screen, device history, Reports, Certificates, Requests
5. **Materials, stock and money in the field** — Chemicals & Inventory, Engineer Issue, Pocket Money, Transportation
6. **Money** — Invoices & Finance, Contracts, Finance & Costs, Analytics, Marketing Targets
7. **Setting the system up** — Engineers & Users, Permissions, Settings, Report Options, IPM File
8. **The customer's own screens** — My Traps, Requests, Company Folder
9. **Things that are on every screen** — the bell and its alert settings, language, working offline

Each page is badged with who sees it: Office, Engineer, Team leader, Customer or
Everyone — the sidebar only ever shows what that role may open.

## Keeping it accurate

The button and menu names quoted in the guide were taken from the CRM's own
translation file (`static/js/i18n.js`) in both languages, so what the guide tells
somebody to click is word for word what is on their screen. If a screen is
renamed in the CRM, update it here too — the text lives in the `DOC` object near
the bottom of the HTML file, with `en` and `ar` beside each other.

**This folder is documentation only.** Nothing here is served by the CRM or read
by it; changing these files cannot affect the running system.
