#!/usr/bin/env python3
"""Have next week's roster waiting for the office. Standard library only.

The auto-roster is one button. This is the step after that: nobody has to
remember to press it on a Thursday to find out that half the book cannot be
covered. Once a week this draws the plan for the week ahead and drops the
result in the office bell — how many visits it can book, how much of the work
it cannot place and why, and which branches are the reason.

It NEVER applies anything. Booking real customer visits stays a decision
somebody makes with the preview in front of them; this only makes sure the
preview exists before the week starts, while there is still time to move an
engineer or ring a customer.

Usage:
    python3 weekly_plan.py            # plan the coming week, notify the office
    python3 weekly_plan.py --dry-run  # print it, write no notification
    python3 weekly_plan.py --from 2026-09-05   # a specific week

Honors PESTCRM_DATA_DIR (same as the server). Schedule with
deploy/pestcrm-weekly-plan.timer.
"""
import os
import sys
import datetime

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Importing the server gives the real planner rather than a second copy of the
# rules that could drift from it. server.py only starts an HTTP listener under
# __main__, so this import is inert.
import database as db          # noqa: E402
import server                  # noqa: E402


def next_office_week(today=None):
    """Saturday to Friday of the week ahead — the week this office works to."""
    today = today or datetime.date.today()
    # Python: Monday=0 .. Saturday=5. Days until the NEXT Saturday (never today).
    ahead = (5 - today.weekday()) % 7 or 7
    start = today + datetime.timedelta(days=ahead)
    return start, start + datetime.timedelta(days=6)


def summarise(plan):
    """The three sentences an office actually needs, in plain words."""
    s = plan.get("summary") or {}
    unplaced = plan.get("unplaced") or []
    lines = [f"{s.get('visits', 0)} visit(s) can be booked across "
             f"{s.get('days', 0)} day(s) using {s.get('engineers', 0)} engineer(s)."]
    if s.get("travel_minutes"):
        lines.append(f"About {round(s['travel_minutes'] / 60.0, 1)}h of that is travelling.")
    if unplaced:
        by = {}
        for u in unplaced:
            by.setdefault(u["reason"], set()).add(u["name"])
        lines.append(f"{len(unplaced)} visit(s) could NOT be placed:")
        for reason, names in sorted(by.items(), key=lambda kv: -len(kv[1])):
            shown = ", ".join(sorted(names)[:4])
            more = f" (+{len(names) - 4} more)" if len(names) > 4 else ""
            lines.append(f"  · {reason.replace('_', ' ')}: {len(names)} branch(es) — {shown}{more}")
    capped = plan.get("capped") or []
    if capped:
        lines.append(f"{len(capped)} branch(es) are asking for more than they can be given.")
    if not unplaced and not capped and s.get("visits"):
        lines.append("Everything the branches asked for fits.")
    return "\n".join(lines)


def main():
    argv = sys.argv[1:]
    dry = "--dry-run" in argv
    start = None
    if "--from" in argv:
        try:
            start = datetime.date.fromisoformat(argv[argv.index("--from") + 1])
        except (IndexError, ValueError):
            print("--from needs a YYYY-MM-DD date")
            return 2
    if start:
        frm, to = start, start + datetime.timedelta(days=6)
    else:
        frm, to = next_office_week()

    db.init_db()
    try:
        plan = server._plan_auto_roster(frm.isoformat(), to.isoformat())
    except Exception as exc:                      # a broken plan must still report
        body = f"Next week's schedule could not be worked out: {exc}"
        print(body)
        if not dry:
            server._notify_roles(("admin", "manager"), "weekly_plan",
                                 "Next week's plan could not be drawn", body,
                                 "shifts", None, f"weekplanerr:{frm}")
        return 1

    body = summarise(plan)
    title = f"Next week's plan is ready ({frm} to {to})"
    print(title)
    print(body)
    if dry:
        print("\n(dry run — nothing written)")
        return 0
    # Deduped on the week, so re-running the timer cannot nag twice, and the
    # office gets one message per week whatever else happens.
    sent = server._notify_roles(("admin", "manager"), "weekly_plan", title, body,
                                "shifts", None, f"weekplan:{frm}")
    print(f"notified {sent} office user(s)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
