# PestCare CRM — *Powered by FoxSystems*

<p align="center"><img src="static/foxsyslogo.png" alt="FoxSystems" width="280"></p>

A complete, **bilingual (English / العربية)** CRM for a pest-control company.
The application is branded **FoxSystems** (login, sidebar and "Powered by FoxSystems"
mark); each operator's own company logo still appears on their invoices and certificates.
Built with **zero external dependencies** — pure Python 3 standard library on the
backend and vanilla HTML/CSS/JS on the frontend.

## Run it

```bash
cd pest-crm
python3 server.py            # serves on http://localhost:8000
# python3 server.py 9000     # custom port
```

The database (`data/crm.db`) is created and seeded with demo data on first launch.

## Demo logins

| Role | Email | Password |
|------|-------|----------|
| Admin | `admin@pestcrm.com` | `admin123` |
| Manager | `manager@pestcrm.com` | `manager123` |
| Agent (technician) | `agent1@pestcrm.com` / `agent2@pestcrm.com` | `agent123` |
| Client portal | `client@alnoor.com` | `client123` |

## Features

- **Bilingual UI** — full English & Arabic with automatic **RTL** layout; toggle anytime.
- **Roles & permissions (RBAC)** — Admin, Manager, Agent, Client portal — each sees only what it
  should. Admins get a **Permissions** screen to set the default access **per role** and override
  it **per user**, with view / create / edit / delete check-marks for every feature. Permissions are
  enforced on the server (not just hidden in the UI) and drive the navigation each user sees.
- **Client company folders** — every client is a folder you open: details, sites/locations,
  finance summary, recent visits and a **photo gallery** (upload from the browser).
- **Visit scheduling** — assign agents, service type, date/time, status workflow
  (scheduled → in progress → completed / cancelled), with filters by status / agent / date.
- **Visit reports** — summary, pests found, findings, recommendations, severity, next-visit
  due date, plus report photos. Each report also carries an **engineer service log** (from the
  field visit tracker): spare parts changed, lamps / cables / transformers / light sheets used,
  Fipronil (ml), Imidacloprid (gm), baits, Glo pieces, Flybase bags and any branch issue —
  entered by the technician on the visit and carried onto the service certificate.
- **Chemicals & inventory** — stock levels, reorder alerts (low-stock), hazard class,
  registration no., cost; stock purchases/adjustments are logged.
- **Chemicals used per visit** — record consumption per visit; stock auto-decrements and the
  movement is recorded in the inventory ledger.
- **Invoices & finance** — bilingual invoices, VAT/tax, payments, auto "paid" status,
  outstanding balances; clients see their own finance in the portal.
- **Photo uploads** — for client folders, visits and reports (images stored in `uploads/`).
- **Global search** — across clients, visits, chemicals and invoices (scoped by role).
- **Dashboard** — KPIs tailored to staff vs. client.
- **Company settings & branding** — editable company name/address/VAT/logo + default tax rate
  (feeds every invoice/quote PDF); optional SMTP config for email reminders.
- **Quotes & line-item invoices** — multi-line invoices/quotes with qty × unit price and auto
  VAT; quotes convert to invoices in one click. Tabs separate Invoices and Quotes.
- **Recurring contracts** — weekly→annual service contracts that auto-generate scheduled visits
  (runs on startup and on demand via "Generate Due Visits").
- **Calendar** — month grid of visits, agent filter, click-through to a visit; plus the existing
  list/schedule view.
- **Notifications & reminders** — in-app bell (upcoming visits for agents, overdue invoices for
  managers), auto-generated and de-duplicated; sends email too if SMTP is configured.
- **E-signatures** — capture customer & technician signatures on a visit via touch/mouse canvas;
  stored as images and shown on the report.
- **Analytics** — monthly invoiced-vs-paid, receivables aging, agent productivity, chemical
  consumption and service mix (rendered as bar charts). Per-client analytics also includes a
  **materials-consumed rollup** — totals of lamps, cables, transformers, light sheets, baits,
  Glo pieces, Flybase bags, Fipronil and Imidacloprid summed across the client's visits
  (from the engineer service log) — and a **pest-activity trends** section.
- **Site / branch maps** — upload a floor-plan image per client (optionally per site) and place
  **device markers** on it (bait stations, rodent traps, insect light traps, monitoring points,
  treatment areas). Each marker has a label, status (OK / needs service / pest activity / missing)
  and notes. Agents open the map in the field, see all devices, and update them; clients view
  their own maps read-only.
- **Compliance / service certificates** — one-click printable **Pest Control Service Certificate**
  per completed visit (bilingual EN/AR, print-to-PDF from the browser). Pulls in service details,
  report findings, severity, chemicals applied and captured customer/technician signatures — the
  document food-safety/HACCP audits ask for. The certificate wording (statement, footer, license /
  accreditation number) is **editable in Settings**, and every **client can browse and download**
  their own certificates from a dedicated *Certificates* page in the portal.
- **Pest-activity trends** — every device (bait station, trap, monitor…) status update is recorded
  as a monitoring event, and each client's analytics page gains a **trends** section: monthly
  inspections-vs-detections curve, detections by device type, and an **activity hotspots** table.
  Included in the analytics PDF export.
- **Deployment & data** — Dockerfile (zero-dependency image), CSV export of clients/visits/
  invoices/chemicals/payments, and a 27-check automated test suite.

## Docker

```bash
docker build -t pestcare-crm .
docker run -p 8000:8000 -v "$PWD/data:/app/data" -v "$PWD/uploads:/app/uploads" pestcare-crm
```

## Tests

```bash
python3 test_api.py     # spins up an isolated server + DB, runs 39 end-to-end checks
```

## Backups

`backup.py` makes a consistent online snapshot of the SQLite database (safe to
run while the server is up) and prunes old copies. The database is always taken
**whole** — it is the one thing nothing else can rebuild, and at ~3 MB a night
it is not what costs space.

Uploads are the opposite: ~100 MB of photos, signatures and site maps that only
grow, of which a normal day adds two or three. They are stored as one full base
archive plus a nightly archive of just what changed:

```
uploads-g<gen>-base.tar.gz              the full tree, once per generation
uploads-g<gen>-inc-<stamp>.tar.gz       only files added or changed since
uploads-g<gen>-manifest-<stamp>.tsv.gz  every file + SHA-256 at that run
```

The manifest is what makes this exact: it records what was there, so a restore
knows not only what to add but what to **remove** — a file deleted since the base
is deleted on the way back too. A fresh base rolls when the current one turns 30
days old or its increments outgrow it, and the previous generation is kept whole.

```bash
python3 backup.py                        # database only, keep last 14
python3 backup.py --uploads              # + incremental uploads (the nightly job)
python3 backup.py --uploads --full-uploads   # force a new base now
python3 backup.py --keep 30              # keep the last 30 db snapshots
python3 backup.py --base-age 14          # roll the base fortnightly
python3 backup.py --dest /mnt/bk         # write elsewhere
```

### Getting back

`restore.py` replays the whole chain in one command — database and uploads
together, to now or to a chosen moment:

```bash
python3 restore.py --list                             # what can be restored
python3 restore.py --into /tmp/restored               # newest
python3 restore.py --into /tmp/restored --at 20260901 # as it stood that day
python3 restore.py --into /tmp/restored --verify      # re-hash every file
```

It refuses to write over the live data directory. To go live, stop the service,
put `crm.db` and `uploads/` in place, and start it again — the command is printed
at the end of every restore.

`restore_drill.py` runs weekly and does all of that unattended: it restores the
newest backup, boots the CRM on it, checks the data is there and fresh, and
replays the uploads chain against its manifest. It exits non-zero, so a rotting
backup shows up in `systemctl --failed` rather than on the day it is needed.

Both are scheduled by the bundled systemd timers (`deploy/pestcrm-backup.*`,
`deploy/pestcrm-restore-drill.*`), or from cron, e.g. nightly at 02:30:

```cron
30 2 * * *  cd /path/to/pest-crm && /usr/bin/python3 backup.py --uploads >> data/backup.log 2>&1
```

## Project layout

```
pest-crm/
├── server.py        # HTTP server + REST API + routing + permissions
├── database.py      # SQLite schema & helpers
├── auth.py          # password hashing (PBKDF2) + signed tokens
├── multipart.py     # multipart/form-data parser (photo uploads)
├── seed.py          # demo data
├── test_api.py      # 27-check end-to-end API test suite
├── Dockerfile       # zero-dependency container image
├── data/            # SQLite DB + secret key (created at runtime)
├── uploads/         # uploaded photos
└── static/          # frontend (index.html, css/, js/)
```

## Extending it

The schema already includes `sites`, `service_types`, `inventory_transactions`,
`invoice`/`payments`, and a unified `photos` table keyed by `(entity_type, entity_id)`,
so adding new modules (contracts, recurring schedules, SLAs, e-signatures, PDF export,
multi-company tenancy, etc.) is mostly additive. API routes are registered with a simple
`@route(method, pattern)` decorator in `server.py`.
