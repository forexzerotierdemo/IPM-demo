#!/usr/bin/env bash
# Publish the latest Fox CRM APK at https://<crm>/fox-crm.apk so agents can
# sideload it by tapping one link.
#
# WHY THIS EXISTS: the GitHub repo is PRIVATE, so its release assets 404 for
# anyone without repo access — which is every field agent. The CRM serves the
# APK itself instead, publicly, no account needed.
#
# RUN THIS AFTER EVERY APK BUILD, or agents keep downloading the old one.
# The file is gitignored (build artifact, 2.6 MB a release).
#
#   deploy/publish-apk.sh <github-token>
#
# The token needs read access to the repo. It is used for this one request and
# never stored.
set -euo pipefail

TOKEN="${1:-}"
if [ -z "$TOKEN" ]; then
    echo "usage: $0 <github-token>" >&2
    exit 2
fi

REPO="itfoxinfo-maker/Drudge-CRM"
TAG="android-latest"
ASSET="fox-crm.apk"
DEST="$(cd "$(dirname "$0")/.." && pwd)/static/$ASSET"

echo "Finding $ASSET on $REPO@$TAG ..."
URL=$(curl -fsS -H "Authorization: Bearer $TOKEN" \
        "https://api.github.com/repos/$REPO/releases/tags/$TAG" \
      | python3 -c "
import json,sys
a=[a for a in json.load(sys.stdin)['assets'] if a['name']=='$ASSET']
if not a: sys.exit('asset $ASSET not found on the release')
print(a[0]['url'])")

TMP="$(mktemp)"
trap 'rm -f "$TMP"' EXIT
curl -fsSL -H "Authorization: Bearer $TOKEN" -H "Accept: application/octet-stream" \
     -o "$TMP" "$URL"

# A truncated download would replace a working APK with a broken one.
python3 - "$TMP" <<'PY'
import sys, zipfile
try:
    z = zipfile.ZipFile(sys.argv[1])
except Exception as e:
    sys.exit(f"downloaded file is not a valid APK: {e}")
if "AndroidManifest.xml" not in z.namelist():
    sys.exit("downloaded file has no AndroidManifest.xml - not an APK")
print(f"  looks like a real APK ({len(z.namelist())} entries)")
PY

mv "$TMP" "$DEST"
chmod 644 "$DEST"
trap - EXIT
echo "Published $(du -h "$DEST" | cut -f1) -> $DEST"
echo "Agents: https://drudge.foxsystemstech.com/$ASSET"
