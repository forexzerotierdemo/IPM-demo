"""Build the CRM's browser and PWA icons from the fox head the launcher uses.

Two treatments, because an icon is drawn at very different sizes:
 - 32px and up keep the real artwork (the circuit-trace fox);
 - 16px uses a solid silhouette of the same head, because at that size the
   traces average out into a blue smudge with no ears and no snout.
Everything sits on the brand navy the Android launcher icon uses, so the tab,
the home-screen icon and the app all read as the same thing.

Re-run (needs Pillow) only when the logo changes:  python3 deploy/make-favicon.py
The outputs are committed, so a normal deploy never needs this.
"""
from PIL import Image

NAVY = (10, 34, 54, 255)          # #0A2236
BLUE = (51, 168, 255, 255)        # the fox's own trace blue, at full strength
SRC = "/root/pest-crm/android/app/src/main/res/mipmap-xxxhdpi/ic_launcher_fg.png"
OUT = "/root/pest-crm/static"

fox = Image.open(SRC).convert("RGBA")
fox = fox.crop(fox.getbbox())      # the adaptive-icon safe zone leaves a lot of air

# Solid version: everything meaningfully opaque becomes one flat shape.
silhouette = Image.new("RGBA", fox.size, BLUE)
silhouette.putalpha(fox.split()[3].point(lambda v: 255 if v > 110 else 0))


def tile(size, fill=0.86, art=fox):
    """Fox head centred on a navy square, sized to `fill` of the tile."""
    canvas = Image.new("RGBA", (size, size), NAVY)
    scale = (size * fill) / max(art.size)
    small = art.resize((max(1, round(art.width * scale)),
                        max(1, round(art.height * scale))), Image.LANCZOS)
    canvas.alpha_composite(small, ((size - small.width) // 2, (size - small.height) // 2))
    return canvas


tile(180).save(f"{OUT}/icons/icon-180.png")            # apple-touch / pinned tab
tile(32).save(f"{OUT}/icons/favicon-32.png")
tile(16, fill=0.94, art=silhouette).save(f"{OUT}/icons/favicon-16.png")

# One .ico for the browsers and bookmark bars that ask for /favicon.ico
# directly instead of reading the <link> tags.
tile(48).save(f"{OUT}/favicon.ico", format="ICO",
              sizes=[(16, 16), (32, 32), (48, 48)],
              append_images=[tile(16, fill=0.94, art=silhouette), tile(32)])

# ---- PWA / home-screen icons (manifest.webmanifest) -------------------------
# These were the wide "fox + Fox Systems" logo letterboxed into a square, which
# at 48dp on a home screen is a smear with unreadable lettering. Same fox head,
# same navy, so the installed icon matches the tab and the Android app.
tile(192).save(f"{OUT}/icons/icon-192.png")
tile(512).save(f"{OUT}/icons/icon-512.png")
# Maskable: Android may crop this to a circle, squircle or rounded square, and
# only the middle 80% is guaranteed to survive, so it is drawn smaller than the
# others on purpose — the navy simply bleeds out to the edges. A filled square
# would have to stop at 0.8/sqrt2 ≈ 0.57; the head's corners are empty, so 0.64
# still clears a circle crop with room (checked against both crops).
tile(512, fill=0.64).save(f"{OUT}/icons/maskable-512.png")

print("written: favicon.ico (16/32/48), icons/favicon-16.png, "
      "icons/favicon-32.png, icons/icon-180.png, icons/icon-192.png, "
      "icons/icon-512.png, icons/maskable-512.png")
