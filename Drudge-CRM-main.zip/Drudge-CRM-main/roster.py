"""THE AUTO-ROSTER — rebuilt 2026-08-23, from six rules and nothing else.

The first planner grew a rule at a time, from a correction at a time, until
nobody could say what it would do with a branch before pressing the button.
The office asked for it to be started again, clean. These are the six rules it
was rebuilt to, in the order they bite. Everything in this file is one of them:

  1. TWO BOOKS. A branch whose window starts at 18:00 or later, or runs past
     midnight, is NIGHT work. Everything else is DAY work. An engineer is a
     night man or a day man, read from his own hours. Night work is never
     offered to a day man and a night man is never sent out at ten in the
     morning. A man with no hours typed at all works any hour — which is a
     statement about him, not a default the planner invented.

  2. EVERY BRANCH HAS AN OWNER. One engineer, named on the branch
     (`sites.preferred_agent_id`). The customer sees the same face, the
     engineer knows his own book, and the plan stops reshuffling the city every
     time the button is pressed. A branch nobody owns is given an owner by the
     balance pass below — the man with the least work who may work that patch
     on that shift — and the office can change it on the branch board.

  3. COVER WHEN THE OWNER CANNOT. Off that day, full, or the branch does not
     open on a day he works: the visit goes to another engineer of the same
     shift who may work that area, preferring one already in that zone that
     day. The plan says whose branch it really is, so nobody has to guess.

  4. THE WEEK IS FIXED, THE DAY IS FREE. `visits_per_month` decides WHICH of
     the four roster weeks a branch is due in — 4 a month is every week, 2 a
     month is weeks 1 and 3, 1 a month is its own week, spread by branch so the
     monthlies do not pile onto the same week. Inside that week the planner
     picks the day, from the days the branch opens.

  5. A DAY IS ONE JOURNEY. One zone a day. Every stop in an area is done
     before the next area is started, and an area is never returned to — the
     office watched the old planner drive to a patch, leave it, and come back
     to it in the afternoon. Where branches have coordinates the stops are
     ordered nearest-first from where he already is; where they do not, the
     area holds them together and the tightest closing time goes first.

     ALL THREE ARE PREFERENCES, NOT WALLS. They were absolute in every pass
     until the office ruled otherwise: "Customer visit comes first. Don't
     leave an owed visit unplaced just to make the route look perfect." They
     now give way on the LAST pass only, for a visit that would otherwise be
     lost, after the owner and every cover engineer have been tried cleanly —
     and the ceiling is lifted by exactly one patch, never thrown away. What
     it cost is reported per visit (`compromises`), so the office sees the
     bent round and can undo it.

  6. NOTHING IS SQUEEZED. A day is full when the hours are gone. What did not
     fit is reported by name with a reason a human can act on, never dropped
     and never crammed into a slot that cannot be driven.

     WHAT IS NOT A PREFERENCE, and never gives way to one: the engineer's own
     hours, the hours the branch is open, the length of the visit, who is
     allowed to work that patch on that shift, the travel ceiling, and one man
     in one place at one time. A visit that breaks any of those is not planned
     at all — it comes back named, with its reason.

The module writes NOTHING. It reads the book and returns a plan; `server.py`
owns the decision to apply it.
"""
import collections as _collections
import datetime as _dt
import itertools as _itertools
import math

DAY = 24 * 60                      # minutes in a day
WEEKS_PER_MONTH = 4                # the roster's month: four Saturday weeks
NIGHT_FROM = 18 * 60               # a window starting this late is night work


class RosterError(Exception):
    """Something the office typed cannot be planned. Carries a plain sentence."""


# ---------------------------------------------------------------- small tools
def hhmm_min(value):
    """'HH:MM' -> minutes past midnight, or None."""
    if not value:
        return None
    h, m = str(value).split(":")[:2]
    return int(h) * 60 + int(m)


def window_bounds(w_from, w_to):
    """A branch's window in minutes, with a closing time past midnight carried
    beyond 1440 rather than coming out negative. 22:00->02:00 is four hours."""
    f = hhmm_min(w_from)
    t = hhmm_min(w_to)
    if f is None and t is None:
        return 0, DAY                      # says nothing: any time of day
    if f is None:
        f = 0
    if t is None:
        t = DAY
    if t <= f:
        t += DAY
    return f, t


def avail_bounds(start, end):
    """An engineer's hours for one day. A BLANK BOX IS NO LIMIT ON THAT SIDE —
    blank to blank is the whole twenty-four hours, which is the office's own
    reading. Entered the other way round (20:00->06:00) it is the night."""
    s = hhmm_min(start) if start else 0
    e = hhmm_min(end) if end else DAY
    if e <= s:
        e += DAY
    return s, e


NIGHT_UNTIL = 8 * 60               # a window that is finished by then is night work
# A man allowed this many patches or fewer has nowhere else to go, so the work
# in them is his before it is anybody's.
AREA_TIED = 3
# The most breathing room one stop is given when the day's slack is shared out.
EASE_GAP_MAX = 90


def is_night_window(f, t):
    """Rule 1, for a branch. Three shapes, all of them night work:

      22:00 -> 02:00   crosses midnight
      20:00 -> 23:00   starts after six in the evening
      00:00 -> 06:00   starts AT midnight and is over before the town wakes

    The third is the one that matters most here and the one a first reading
    misses: the kitchens are serviced after they shut, and half of them are
    typed as starting at midnight rather than as running over from the night
    before. Read as day work they were offered to men who sleep through them.
    """
    return t > DAY or f >= NIGHT_FROM or t <= NIGHT_UNTIL


def hhmm(minutes):
    """Minutes (possibly past midnight) -> ('HH:MM', day offset)."""
    day, rest = divmod(int(minutes), DAY)
    return "%02d:%02d" % divmod(rest, 60), day


def haversine_km(a, b):
    """Straight-line km between two (lat, lng) pairs."""
    lat1, lng1 = a
    lat2, lng2 = b
    r = 6371.0
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp = math.radians(lat2 - lat1)
    dl = math.radians(lng2 - lng1)
    h = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * r * math.asin(math.sqrt(h))


def days_in_month(year, month):
    """How many days that month actually has — 28, 29, 30 or 31."""
    if month == 12:
        return 31
    return (_dt.date(year, month + 1, 1) - _dt.date(year, month, 1)).days


def months_in(d0, d1):
    """Every calendar month the range touches, as (year, month, first, last)
    where first/last are clipped to the range."""
    out = []
    y, m = d0.year, d0.month
    while _dt.date(y, m, 1) <= d1:
        n = days_in_month(y, m)
        first = max(d0, _dt.date(y, m, 1))
        last = min(d1, _dt.date(y, m, n))
        out.append((y, m, first, last))
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


def month_slots(vpm, year, month):
    """WHEN, INSIDE A CALENDAR MONTH, ITS VISITS ARE DUE.

    A contract of four a month is four visits in that month — in February and
    in October alike. The month is not four weeks and it is not thirty days: it
    is however many days it actually has, and the visits are spread evenly
    through them.

    Returns one date per owed visit, so the count IS the contract and cannot
    drift with the length of the month. Deterministic, so pressing the button
    again over the same month sees the same visits and adds nothing.

        4 a month, September (30 days) -> 4th, 12th, 19th, 27th
        4 a month, February  (28 days) -> 4th, 11th, 18th, 25th
        1 a month, October   (31 days) -> 16th
    """
    n = int(round(float(vpm or 0)))
    if n <= 0:
        return []
    span = days_in_month(year, month)
    out = []
    for k in range(n):
        day = int((k + 0.5) * span / n) + 1     # evenly spaced, 1-based
        out.append(_dt.date(year, month, min(span, max(1, day))))
    return out


def week_quota(vpm, week_index, offset=0):
    """Rule 4: how many visits this branch is owed in THIS roster week.

    The office asks in visits a MONTH and the roster deals a week at a time, so
    the month is shared out by running total — the only way that is right for
    every number the office can type:

        4 a month -> 1, 1, 1, 1        1 a month -> 0, 0, 0, 1
        8 a month -> 2, 2, 2, 2        2 a month -> 0, 1, 0, 1
        3 a month -> 1, 1, 1, 0

    `offset` rotates which week the sparse ones land in, per branch, so every
    monthly branch in the book does not queue up in the same week.
    """
    n = float(vpm or 0)
    if n <= 0:
        return 0
    i = (int(week_index) + int(offset)) % WEEKS_PER_MONTH
    before = int(n * i / WEEKS_PER_MONTH + 1e-9)
    after = int(n * (i + 1) / WEEKS_PER_MONTH + 1e-9)
    return max(0, after - before)


def owed_in_month(vpm, freq_unit, year, month, offset=0):
    """HOW MANY VISITS A BRANCH IS OWED IN ONE CALENDAR MONTH.

    The planner answers this every time the button is pressed (see _due_jobs);
    the office needs the same answer with no button pressed, so that a branch
    that has quietly dropped below its number can be SAID OUT LOUD. Both go
    through `month_slots` and `week_quota`, so the two cannot disagree about
    what a contract is worth.

      · 'month' — exactly that many visits in the month, 28 days or 31.
      · 'week'  — a weekly rhythm, so a month holding five roster weeks is
        five visits. Counted on the weeks that BEGIN inside the month, which
        is the same slicing rule 4 uses when it deals a week at a time.

    `offset` is the branch's own rotation (`site_id % WEEKS_PER_MONTH`), so the
    sparse weeks of a 1-a-month or 2-a-month weekly deal land where the planner
    puts them and not all in the same week of the book.
    """
    if freq_unit == "week":
        first = _dt.date(year, month, 1)
        last = _dt.date(year, month, days_in_month(year, month))
        total, wk = 0, week_start(first)
        while wk <= last:
            if wk >= first:                 # the week that BEGINS in this month
                total += week_quota(vpm, wk.toordinal() // 7, offset=offset)
            wk += _dt.timedelta(days=7)
        return total
    return len(month_slots(vpm, year, month))


def _week_of(date, start):
    """Which roster week a date falls in, counting seven-day blocks from the
    first day of the run."""
    return start + _dt.timedelta(days=((date - start).days // 7) * 7)


def span_of(frm, to):
    return (_dt.date.fromisoformat(to) - _dt.date.fromisoformat(frm)).days + 1


def week_start(date):
    """The Saturday on or before this date. The roster week is Sat -> Fri."""
    # Python: Monday=0 ... Saturday=5
    return date - _dt.timedelta(days=(date.weekday() - 5) % 7)


# ------------------------------------------------------------------ the people
class Engineer:
    """One man, his hours, and the patches he is allowed to work."""

    def __init__(self, row):
        self.id = row["id"]
        self.name = row["full_name"]
        self.days = {}             # weekday -> (start, end) in minutes
        self.areas = {}            # area_id -> set of weekdays, or None for any
        self.shift = "day"         # day | night | any
        self.load = 0.0            # minutes of owned work a month (balancing)
        self.owned = 0

    def windows(self, weekday):
        """EVERY working stretch he has that weekday, in order.

        A man may work 08:00-12:00 and again 16:00-20:00, with the middle of
        the day his own. That is EIGHT working hours, not twelve, and the four
        between are not capacity."""
        return self.days.get(weekday) or []

    def hours(self, weekday):
        """The ENVELOPE of his day — first opening to last close — or None if
        he does not work it. This is what the day is bounded by; where the work
        may actually START is `windows`, and only `Day` is allowed to decide
        that (see `Day._first_start`)."""
        wins = self.days.get(weekday)
        if not wins:
            return None
        return (min(a for a, _b in wins), max(b for _a, b in wins))

    def may_work(self, area_id, weekday):
        if area_id not in self.areas:
            return False
        days = self.areas[area_id]
        return days is None or weekday in days

    def works_shift(self, shift):
        return self.shift == "any" or shift == self.shift


class Branch:
    """One place to be serviced, and everything the planner needs about it."""

    def __init__(self, row):
        self.id = row["id"]
        self.client_id = row["client_id"]
        self.name = row["name"]
        self.client_en = row["client_en"]
        self.client_ar = row["client_ar"]
        self.area_id = row["area_id"]
        # A ZONE IS THE OFFICE'S OWN WORD for "these places are near each
        # other". Where they have not said it, the planner does not invent it:
        # an area in no zone is held together by the area ceiling and by never
        # going back, and nothing else.
        self.zone_id = row["zone_id"]
        # For sharing a man's WEEK out, though, an ungrouped area still has to
        # count as somewhere of its own, or every one of them competes for the
        # same days as if they were one place.
        self.group = row["zone_id"] if row["zone_id"] is not None else ("area", row["area_id"])
        self.vpm = float(row["visits_per_month"] or 0)
        # WHICH RHYTHM THAT NUMBER IS. 'month' means exactly this many visits
        # in the CALENDAR month, whether it has 28 days or 31. 'week' means a
        # weekly rhythm — a month with five of its weeks in it is five visits,
        # and squeezing that to four would be the same mistake the other way.
        self.freq_unit = (row["freq_unit"] or "month")
        self.minutes = int(row["visit_minutes"] or 0) or None
        self.owner_id = row["preferred_agent_id"]
        # NAMED BY THE OFFICE, or worked out by the balance pass? Either way
        # the branch is HIS: the planner offers it to nobody else while he can
        # take it, and a name the office typed is never overwritten. The
        # difference is only in how it is REPORTED — when a named man cannot
        # go, the answer the office needs is about him, not about the area.
        #
        # Cover applies to both. The office's later word: an owner "with
        # flexibility to change with any engineer if the specific engineer is
        # busy in that time or something else".
        self.owner_fixed = row["preferred_agent_id"] is not None
        self.geo = ((row["lat"], row["lng"])
                    if row["lat"] is not None and row["lng"] is not None else None)
        self.win = window_bounds(row["service_from"], row["service_to"])
        self.shift = "night" if is_night_window(*self.win) else "day"
        self.open_days = {}        # weekday -> (from, to); empty = any day
        self.day_agent = {}        # weekday -> engineer named for that day only

    def window_on(self, weekday):
        """Its window that weekday — a named day may carry its own hours."""
        own = self.open_days.get(weekday)
        return own if own else self.win

    def opens_on(self, weekday):
        return (not self.open_days) or weekday in self.open_days

    def job_minutes(self, slot):
        return self.minutes or slot


# ------------------------------------------------------------------ the loader
def load_book(db, frm, to):
    """Everything the planner reads, in one place, so the rules below are about
    scheduling and not about SQL."""
    areas = {a["id"]: dict(a) for a in db.query(
        "SELECT id, name_en, name_ar, zone_id FROM areas")}
    zones = {z["id"]: dict(z) for z in db.query("SELECT id, name_en, name_ar FROM zones")}

    branches = {}
    for row in db.query(
            "SELECT s.id, s.client_id, s.name, s.area_id, s.service_from, s.service_to, "
            "s.visits_per_month, s.freq_unit, s.visit_minutes, s.lat, s.lng, "
            "s.preferred_agent_id, "
            "c.name_en client_en, c.name_ar client_ar, a.zone_id "
            "FROM sites s JOIN clients c ON c.id=s.client_id "
            "LEFT JOIN areas a ON a.id=s.area_id "
            # Switched-off branches and customers are not work — see the
            # switched-off rule in server.py. A branch with no area belongs to
            # nobody and is reported as a gap on the Branches page, not here.
            "WHERE s.visits_per_month > 0 AND s.area_id IS NOT NULL "
            "AND s.status='active' AND c.status='active'"):
        branches[row["id"]] = Branch(row)
    for d in db.query("SELECT site_id, weekday, start_time, end_time, agent_id "
                      "FROM site_service_days"):
        b = branches.get(d["site_id"])
        if not b:
            continue
        b.open_days[d["weekday"]] = (window_bounds(d["start_time"], d["end_time"])
                                     if (d["start_time"] or d["end_time"]) else b.win)
        if d["agent_id"]:
            b.day_agent[d["weekday"]] = d["agent_id"]

    people = {}
    for row in db.query("SELECT id, full_name FROM users "
                        # Only engineers carry visits. Team leaders, managers
                        # and area managers are the office's standing rule.
                        "WHERE role='agent' AND active=1 ORDER BY full_name"):
        people[row["id"]] = Engineer(row)
    for a in db.query("SELECT agent_id, weekday, start_time, end_time FROM agent_availability"):
        p = people.get(a["agent_id"])
        if p is not None:
            p.days.setdefault(a["weekday"], []).append(
                avail_bounds(a["start_time"], a["end_time"]))
    for p in people.values():
        for wd in p.days:
            p.days[wd].sort()
    for a in db.query("SELECT agent_id, area_id, weekdays FROM agent_areas"):
        p = people.get(a["agent_id"])
        if p is None:
            continue
        raw = (a["weekdays"] or "").strip()
        p.areas[a["area_id"]] = ({int(x) for x in raw.split(",") if x.strip().isdigit()}
                                 if raw else None)
    for p in people.values():
        p.shift = _shift_of(p)

    # Work already in the diary for this range. Two different things: a visit
    # with an engineer on it is an obstacle in HIS day, and a visit with nobody
    # on it is a job this run should staff at the time the customer was already
    # promised.
    # WHAT IS ALREADY IN THE DIARY — over the whole WEEK either end of the
    # range, not just the range itself. The office re-runs a plan from
    # Wednesday whenever it fixes one branch; if Saturday's visits are not
    # loaded, the cycle cannot see that the week has already been served and
    # books every branch a second time, out of the hours another branch needed.
    lo = (week_start(_dt.date.fromisoformat(frm))).isoformat()
    hi = (week_start(_dt.date.fromisoformat(to)) + _dt.timedelta(days=6)).isoformat()
    booked = db.query(
        "SELECT id, client_id, site_id, agent_id, scheduled_start, scheduled_end, status "
        # WORK ALREADY DONE IS STILL WORK DONE. This read 'scheduled' and
        # 'in_progress' only, so a visit the field had COMPLETED stopped
        # counting against the month's owed number — and the next press of the
        # button in a worked month invented a replacement for work that had
        # already happened. Measured on a copy of the real book: marking one
        # September visit completed made the planner want to add a second visit
        # to that branch. A CANCELLED visit is deliberately still absent: that
        # one really is a gap, and the cycle should fill it.
        "FROM visits WHERE status IN ('scheduled','in_progress','completed') "
        "AND date(scheduled_start) BETWEEN ? AND ?", (lo, hi))
    # A DAY OFF IS THE ROSTER'S OWN WORD AND OUTRANKS THE PLANNER. Leave, a
    # rest day, a training day: somebody wrote it on the board deliberately,
    # and a plan that books over it is a plan the office has to unpick by hand.
    off = {(r["agent_id"], r["shift_date"]) for r in db.query(
        "SELECT s.agent_id, s.shift_date FROM agent_shifts s "
        "JOIN shift_types t ON t.id=s.shift_type_id "
        "WHERE t.is_off=1 AND s.shift_date BETWEEN ? AND ?", (frm, to))}
    # HOURS ALREADY SOLD TO ONE SITE. Kept apart from availability on purpose:
    # availability is when a man CAN work, a post is time the company has
    # already promised. They are subtracted in `plan`, before anything is placed.
    posts = []
    try:
        def _pdays(raw):
            return {int(x) for x in str(raw or "").split(",") if str(x).strip().isdigit()}
        for r in db.query("SELECT f.*, s.name AS site_name FROM fixed_assignments f "
                          "JOIN sites s ON s.id=f.site_id WHERE f.active=1"):
            posts.append({
                "id": r["id"], "site_id": r["site_id"], "site_name": r["site_name"],
                "primary": r["primary_agent_id"], "relief": r["relief_agent_id"],
                "primary_days": _pdays(r["primary_weekdays"]),
                "relief_days": _pdays(r["relief_weekdays"]),
                "from": hhmm_min(r["from_time"]), "to": hhmm_min(r["to_time"]),
                "from_text": r["from_time"], "to_text": r["to_time"],
                "start": r["start_date"], "end": r["end_date"]})
    except Exception:
        posts = []                     # a book from before posts existed
    return {"areas": areas, "zones": zones, "branches": branches, "off": off,
            "posts": posts,
            "from": _dt.date.fromisoformat(frm),
            "to": _dt.date.fromisoformat(to),
            "people": people, "booked": [dict(b) for b in booked]}


def _overlaps(a, b, c, d):
    return max(a, c) < min(b, d)


def _shift_of(person):
    """Rule 1, for an engineer — read from what his hours actually COVER, not
    from how they were typed.

    A man on 20:00->06:00 covers the night and nothing else. A man on
    06:00->18:00 covers the day. A man on 00:00->23:59 covers BOTH, and saying
    otherwise is how a branch that shuts at three in the morning went unvisited
    week after week while the one person awake at that hour sat idle.
    """
    if not person.days:
        return "none"
    # Judged against the CORE of each half of the clock, not its edges: a man
    # who works six in the morning to six at night touches 06:00, and that must
    # not read as "he covers the night".
    night_core = ((22 * 60, DAY + 6 * 60), (0, 6 * 60))
    day_core = ((9 * 60, 17 * 60), (DAY + 9 * 60, DAY + 17 * 60))
    night = day = False
    for s_, e_ in [w for wins in person.days.values() for w in wins]:
        if any(_overlaps(s_, e_, a, b) for a, b in night_core):
            night = True
        if any(_overlaps(s_, e_, a, b) for a, b in day_core):
            day = True
    if night and day:
        return "any"
    return "night" if night else "day"


# ------------------------------------------------------------------- the owner
def month_capacity(person, s, weeks=None):
    """Roughly how many minutes of work a month this man can absorb.

    Four roster weeks of the hours he actually works, with a blank "any time"
    day counted as ONE WORKING DAY and not twenty-four hours. Blank means the
    office has not fenced him in, not that he sleeps at the wheel — using the
    literal 1440 would make one untyped man look like the capacity of six.
    """
    total = 0
    for wd, wins in person.days.items():
        if wd == s["rest_day"] and wins == [(0, DAY)]:
            continue                       # Friday, and nothing typed for it
        # THE SUM OF THE STRETCHES HE ACTUALLY WORKS, never the envelope:
        # 08:00-12:00 plus 16:00-20:00 is eight hours, not twelve.
        span = sum(b - a for a, b in wins)
        total += min(span, 10 * 60)        # nobody is planned for a 24-hour day
    # HOW MANY WEEKS THERE ACTUALLY ARE IN THE MONTH BEING PLANNED — 4.0 in
    # February, 4.43 in a 31-day month. Balancing ownership against a month
    # that is always four weeks understates every man by a tenth in a long one.
    return max(1, total * (weeks if weeks else WEEKS_PER_MONTH))


def assign_owners(book, s, keep=True, weeks=None):
    """Rule 2. Every branch gets one engineer, and the office's choice always
    wins over the planner's.

    Two things decide it, in this order:

    **The zone.** A man who owns branches in six zones can only reach six zones
    on six different days — rule 5 sees to that — so scattering ownership by
    load alone quietly guarantees the work cannot be delivered. Ownership is
    therefore CLUSTERED: a man already working a zone is preferred for the next
    branch in it, and keeps being preferred until he is meaningfully busier
    than the alternatives.

    **The load.** Measured in MINUTES A MONTH against HIS OWN hours, not in
    branches: a factory that takes a whole day and a shop that takes forty
    minutes are not the same load, and counting branches is how one man ends up
    with every hotel in the city while another has ten corner shops.
    """
    people = book["people"]
    for p in people.values():
        p.capacity = month_capacity(p, s, weeks)
        p.zones_owned = set()
        p.clients_owned = set()
    proposed = {}
    # A FIXED POST IS WORK HE IS ALREADY CARRYING. It is no longer stored as
    # ordinary visits, so without this the balancer sees a resident engineer as
    # idle and hands his colleagues' branches to him — and, worse, hands the
    # branches he WOULD have owned to somebody whose day has no room for them.
    # (Converting Exception Factory to a post cost AMS Factory two visits
    # exactly this way: Alaa read as free, ownership shifted down the line, and
    # Amr Diab's three-hour Sunday filled up with work that pushed AMS out.)
    weeks_in = weeks if weeks else WEEKS_PER_MONTH
    for post in (book.get("posts") or []):
        for who, days_held in ((post["primary"], post["primary_days"]),
                               (post["relief"], post["relief_days"])):
            p = people.get(who)
            if p is None or not days_held:
                continue
            p.load += max(0, post["to"] - post["from"]) * len(days_held) * weeks_in
            p.posted = getattr(p, "posted", 0) + len(days_held)

    # What the office has already said, first — those are not up for balancing.
    for b in book["branches"].values():
        owner = people.get(b.owner_id) if keep else None
        if owner is not None:
            owner.load += b.vpm * (b.minutes or 60)
            owner.owned += 1
            owner.zones_owned.add(b.zone_id)
            owner.clients_owned.add((b.client_id, b.area_id))
        elif b.owner_id and keep:
            b.owner_id = None              # named somebody who has left
    # Then the rest: the busiest zones first, and inside a zone the heaviest
    # branch first, so the big jobs are placed while there is still room.
    todo = [b for b in book["branches"].values() if not b.owner_id]
    zone_weight = {}
    for b in todo:
        zone_weight[b.zone_id] = zone_weight.get(b.zone_id, 0) + b.vpm * (b.minutes or 60)
    todo.sort(key=lambda b: (-zone_weight.get(b.zone_id, 0), -(b.vpm * (b.minutes or 60))))
    for b in todo:
        cands = [p for p in people.values()
                 if p.works_shift(b.shift) and b.area_id in p.areas and p.days]
        if not cands:
            continue                       # reported as unplaced when it comes due
        # The zone bonus is worth a quarter of a man's month: enough to keep a
        # zone in one pair of hands, not enough to bury him.
        def score(p):
            ratio = p.load / p.capacity
            bonus = 0.0
            # ONE CUSTOMER IN ONE AREA IS ONE ADDRESS. Two units of the same
            # company on the same street are one call as far as the driving is
            # concerned; splitting them between two men buys the office a
            # second journey and buys the customer a second stranger.
            if (b.client_id, b.area_id) in p.clients_owned:
                bonus += 1.0
            elif b.zone_id in p.zones_owned:
                bonus += 0.25
            # A MAN WITH ONE PATCH KEEPS IT. The office's own question: "why
            # does an engineer allowed ONE area have one visit in it when men
            # allowed twenty-four are working his street?" Because they could
            # walk in and take it. He has nowhere else to go; they have.
            if len(p.areas) == fewest and len(p.areas) <= AREA_TIED:
                bonus += 0.35
            return (ratio - bonus, p.name)
        fewest = min(len(p.areas) for p in cands)
        # Nobody is given a branch while his month is already full and somebody
        # else's is not — the bonuses tilt the choice, they do not overrule it.
        room = [p for p in cands if p.load < p.capacity] or cands
        pick = min(room, key=score)
        b.owner_id = pick.id
        proposed[b.id] = pick.id
        pick.load += b.vpm * (b.minutes or 60)
        pick.owned += 1
        pick.zones_owned.add(b.zone_id)
        pick.clients_owned.add((b.client_id, b.area_id))
    return proposed


# -------------------------------------------------------------------- the plan
def plan(db, frm, to, settings=None, scope_areas=None):
    """Draw the roster for [frm, to]. Writes nothing.

    Returns the same shape the office's screen has always read:
      {days: [{date, assignments: [{agent_id, agent_name, areas, visits}]}],
       unplaced: [...], summary: {...}}
    """
    s = dict(DEFAULTS, **(settings or {}))
    # A maximum of zero is the office saying "charge nothing for the driving";
    # the in-area allowance cannot then be more than the maximum.
    s["travel_area"] = min(s["travel_area"], s["travel_max"])
    d0 = _dt.date.fromisoformat(frm)
    d1 = _dt.date.fromisoformat(to)
    if d1 < d0:
        raise RosterError("The end date is before the start date")
    if (d1 - d0).days > 92:
        raise RosterError("Plan at most a quarter at a time")

    book = load_book(db, frm, to)
    # A whole number of weeks, or any run of a fortnight or more, is counted
    # from the day the office asked for. Only a SHORT, ragged range — the
    # re-run of Wednesday to Friday after fixing one branch — falls back to the
    # calendar Saturday, because that one has to see the same weeks the last
    # run saw or every branch would be served twice.
    _span = span_of(frm, to)
    book["anchor"] = d0 if (_span % 7 == 0 or _span >= 14) else week_start(d0)
    # The month this run is planning, in weeks, so ownership is balanced
    # against the month the office actually has.
    _y, _m = d0.year, d0.month
    owners_set = assign_owners(book, s, weeks=days_in_month(_y, _m) / 7.0)
    people, branches = book["people"], book["branches"]

    # One Day object per engineer per date: his hours, what is already in them,
    # and the single zone the day is allowed to touch (rule 5).
    days = {}
    date = d0
    while date <= d1:
        for p in people.values():
            hrs = p.hours(date.weekday())
            wins = p.windows(date.weekday())
            # FRIDAY IS THE REST DAY. The cycle never deals onto it — unless
            # this man has actual Friday hours typed, which is the office
            # saying "he does work Fridays". A blank row is "any hour", not
            # "every day of the week".
            if date.weekday() == s["rest_day"] and wins == [(0, DAY)]:
                hrs = None
            if (p.id, date.isoformat()) in book["off"]:
                hrs = None                 # the board says he is off
            if hrs:
                days[(p.id, date)] = Day(p, date, hrs, s, days, windows=wins)
        date += _dt.timedelta(days=1)

    # THE POSTS COME OUT FIRST, before a single visit is considered. A man
    # resident at a factory from eight to four has those hours sold already;
    # offering them to ordinary work would be selling them twice. Where the man
    # who holds a post is not working that day, the post is REPORTED UNCOVERED
    # rather than quietly forgotten — that is the whole reason it is a thing.
    posts_out, uncovered = [], []
    date = d0
    while date <= d1:
        wd = date.weekday()
        for post in book.get("posts") or []:
            # A POST ONLY RUNS INSIDE ITS OWN PERIOD. Blank at either end
            # means open — most posts have no end in sight.
            iso = date.isoformat()
            if (post.get("start") and iso < post["start"]) or \
               (post.get("end") and iso > post["end"]):
                continue
            who = (post["primary"] if wd in post["primary_days"]
                   else post["relief"] if wd in post["relief_days"] else None)
            if who is None:
                continue
            day = days.get((who, date))
            if day is None:
                uncovered.append({"date": date.isoformat(), "site_id": post["site_id"],
                                  "site_name": post["site_name"], "agent_id": who,
                                  "from": post["from_text"], "to": post["to_text"],
                                  "reason": "agent_off"})
                continue
            day.reserve(post["from"], post["to"], post)
            posts_out.append({"date": date.isoformat(), "site_id": post["site_id"],
                              "site_name": post["site_name"], "agent_id": who,
                              "agent_name": people[who].name if who in people else None,
                              "from": post["from_text"], "to": post["to_text"]})
        date += _dt.timedelta(days=1)

    # Work already promised to a customer holds its time and blocks the man.
    # (And a round that runs past midnight holds the morning after — see
    # _carry_midnight, run once the rounds are drawn.)
    unplaced = []
    fixed, pending, in_range_counts, by_month = _place_booked(book, days, s, unplaced, frm, to)
    book["already_in_range"] = in_range_counts
    book["booked_by_month"] = by_month
    # The promised hours go in FIRST — they cannot move, and everything the
    # cycle invents has to be planned around them.
    _fill_days(pending, days, book, s, unplaced, promised=True)

    # Rule 4: what is due, week by week, and rule 2/3: who takes it.
    # The weekdays the company works AT ALL — leave and rest days aside. This
    # is what separates "asking for a day we never work" from "everybody was
    # off that Tuesday".
    worked_weekdays = {wd for p in book["people"].values() for wd in p.days
                       if not (wd == s["rest_day"] and p.days[wd] == [(0, DAY)])}
    jobs = _due_jobs(book, d0, d1, fixed, worked_weekdays)
    _fill_days(jobs, days, book, s, unplaced)
    # THE LAST WORD ON AN OWED VISIT — rearrange what is already booked rather
    # than leave it undelivered. Nothing here bends a hard rule (see
    # _rebalance); it only uses legal capacity better.
    rebalanced = _rebalance(days, book, s, unplaced)

    # Rule 5, part two: everything owed is now placed, so the thin days can be
    # dissolved onto rounds that are already going there. Move-only — see
    # _compact — so nothing above this line can be undone by it.
    compacted = _compact(days, book, s)

    capped = _capped(book, worked_weekdays, s, d0, d1)
    # A MANAGER IS WARNED ABOUT THEIR OWN PATCH AND NOBODY ELSE'S. A warning
    # names a customer, so a list drawn for somebody who does not hold that
    # area is both noise and a disclosure.
    if scope_areas is not None:
        keep = set(scope_areas)
        by_site = {b.id: b.area_id for b in book["branches"].values()}
        capped = [c for c in capped if by_site.get(c["site_id"]) in keep]
        unplaced = [u for u in unplaced if u.get("area_id") in keep]
    _ease(days, s)
    out = _render(days, book, owners_set, unplaced, s, frm, to, capped, compacted)
    out["summary"]["rebalanced"] = rebalanced["rescued"]
    out["rebalance"] = rebalanced
    out["posts"] = posts_out
    out["uncovered_posts"] = uncovered
    out["summary"]["posts"] = len(posts_out)
    out["summary"]["uncovered_posts"] = len(uncovered)
    return out


DEFAULTS = {
    "slot_minutes": 60,            # a visit that does not say how long it takes
    "travel_area": 20,             # minutes reserved inside one area
    "travel_max": 45,              # the longest journey the plan will ask of anybody
    "travel_kmh": 25,              # Cairo traffic, for measured hops
    "areas_per_day": 2,            # rule 5: two patches is a round, three is a tour
    "rest_day": 4,                 # Friday, unless a man has Friday hours typed
    # PHASE 4A: how far a visit may be nudged from its due date to join a round
    # already going to its patch. 0 turns the preference off completely.
    "cluster_days": 3,
    # PHASE 4B: the largest day the move-only compaction will try to dissolve.
    # 2 is "a thin day"; 0 turns the pass off and restores the plan exactly.
    "compact": 2,
    # THE LAST RESCUE: re-order a round, or move one flexible visit, to save a
    # visit nothing else could place. 0 turns it off and restores the plan
    # exactly, which is also how a before/after is measured.
    "rebalance": 1,
}


class Day:
    """One engineer's one date: his hours, his zone, and the stops in order."""

    def __init__(self, person, date, hours, s, days=None, windows=None):
        self.person = person
        self.all_days = days       # every day, so last night can hold this morning
        self.date = date
        self.weekday = date.weekday()
        self.start, self.end = hours
        # THE STRETCHES HE ACTUALLY WORKS, inside the envelope above. One
        # window is the ordinary case and behaves exactly as it always did;
        # two mean a break in the middle of his day that is his own.
        self.windows = sorted(windows) if windows else [(self.start, self.end)]
        # Hours a fixed post has already claimed. A window that ENDS where a
        # post begins may not be overrun — being late for a contracted post is
        # not the same as finishing a job as your own shift ends.
        self.hard_ends = set()
        self.post = None
        self.zone = None           # the ONE zone this day may touch (rule 5)
        self.group = None          # what his week reserved this day for
        self.areas = []            # areas in the order he drives them (rule 5)
        self.held = []             # patches a visit already booked puts him in
        self.booked = []           # branches the DIARY already has him at today
        self.stops = []            # placed visits, in order
        self.cursor = self.start   # when he is free again
        self.at = None             # (lat, lng) of the last stop, if known
        self.s = s

    # -- rule 5 ------------------------------------------------------------
    def accepts(self, branch, rescue=False):
        """Rule 5: one zone a day. Where the office has drawn no zone there is
        nothing to enforce — an ungrouped area is held by the area ceiling and
        by never going back. While the day is still empty its reservation is
        only a preference: a visit nobody else can take is worth more than a
        tidy plan for an empty day.

        `rescue` is the office's own priority, added after the rebuild: "don't
        leave an owed visit unplaced just to make the route look perfect". It
        is set ONLY on the last pass, for a visit that would otherwise be lost,
        and what it opens is reported (see _damage)."""
        if rescue:
            return True
        if not self.stops:
            return True
        if self.zone is not None and branch.zone_id is not None:
            return self.zone == branch.zone_id
        return True

    def accepts_area(self, area_id, rescue=False):
        """An area is open if he is standing in it, or has not been in it yet
        AND he has not already used up the day's patches.

        Two things, both rule 5. Going BACK to an area he has already left is
        the thing the office watched the old planner do all afternoon. And a
        day that touches three or four patches is not a round, it is a tour of
        the city — the ceiling is what stops the planner treating a zone as one
        big area.

        On the rescue pass both give way rather than lose a visit the company
        has sold — but the ceiling is lifted BY ONE, not thrown away: a third
        patch to save a call is a detour, a fourth is the tour of the city the
        office asked to be rid of."""
        if not self.areas:
            return True
        if self.areas[-1] == area_id:
            return True
        cap = max(1, int(self.s["areas_per_day"])) + (1 if rescue else 0)
        if area_id in self.areas:
            return bool(rescue)
        return len(self.areas) < cap

    def measured_between(self, a, b):
        return measured_minutes(a, b, self.s)

    def travel_between(self, a, b):
        return travel_minutes(a, b, self.s)

    def reserve(self, lo, hi, post=None):
        """TAKE THESE HOURS OUT OF HIS DAY. The post is not work the roster
        arranges — it is time already sold, so it is removed from what the
        planner may offer before the planner is asked anything."""
        out = []
        for a, b in self.windows:
            if b <= lo or a >= hi:
                out.append((a, b)); continue
            if a < lo:
                out.append((a, lo)); self.hard_ends.add(lo)
            if b > hi:
                out.append((hi, b))
        self.windows = sorted(out)
        if post is not None:
            self.post = post
        if self.windows:
            self.start, self.end = self.windows[0][0], self.windows[-1][1]
            self.cursor = max(self.cursor, self.start)
        else:
            self.start = self.end = self.cursor = lo

    def _cap_for(self, start):
        """THE LATEST A VISIT BEGINNING AT `start` MAY FINISH.

        Ordinarily his own close. But a stretch that ends where a POST begins
        is a hard edge — being late for a contracted post is not the same as
        finishing a job as your own shift ends — so a visit inside that stretch
        must be done before the post starts."""
        cap = self.end
        for a, b in self.windows:
            if a <= start < b and b in self.hard_ends:
                return min(cap, b)
        return cap

    def _first_start(self, t):
        """THE EARLIEST MOMENT FROM `t` THAT A VISIT MAY BEGIN, or None.

        His rule, and it is deliberately not symmetrical: a visit may only
        START inside a working window, but one that started legally may RUN ON
        past the end of it — 11:30 to 12:30 is a man finishing his job, not a
        man working his break. So this moves a start OUT of a gap and up to the
        next window; it never shortens a visit and never asks where it ends.

        It also refuses to park a visit early to "wait into" the next window:
        the answer is the next legal START, not a seat in the gap.
        """
        for a, b in self.windows:
            if t < a:
                return a               # the break is over at `a`, not before
            if t < b:
                return t               # already inside a stretch he works
        return None                    # nothing left of his day

    def _opens_at(self):
        """When he can actually start today. A round that ran to two in the
        morning holds the morning after: the man who finished a kitchen at two
        is not opening a warehouse at seven, and a plan that says he is has to
        be unpicked by hand."""
        start = self.start
        prev = (self.all_days or {}).get((self.person.id, self.date - _dt.timedelta(days=1)))
        if prev is not None and prev.stops:
            ends = prev.stops[-1]["start"] + prev.stops[-1]["dur"]
            if ends > DAY:
                start = max(start, ends - DAY)
        return start

    def _sequence(self, order):
        """Time a whole day, in this order, and say whether it can be driven.

        Returns [(start, travel), ...] or None. Every stop must sit inside its
        own window AND inside his hours, with the drive between them reserved —
        so this is also what refuses a round that only works on paper."""
        out = []
        cursor = self._opens_at()
        prev = None
        # The last stop whose position we ACTUALLY KNOW. A branch nobody has
        # pinned tells us nothing about where the man is standing, so it must
        # not be allowed to wipe out what the branch before it told us.
        anchor = None
        for branch, dur, win in order:
            gap = self.travel_between(prev, branch)
            if gap is None:
                return None
            # A MISSING PIN IS NOT A SHORT DRIVE.
            #
            # Between two ends that both carry a pin the hop is measured and
            # the ceiling refuses it if it is too far. Where a pin is missing
            # there is nothing to measure, so the flat allowance stands in —
            # and for two doors of one customer in one patch that allowance is
            # NOTHING. Put an unpinned branch between two pinned ones and the
            # round crossed the city in two free steps: neither hop was ever
            # measured, and forty kilometres cost nothing at all.
            #
            # So the distance is taken from the last stop we could actually
            # place, however many unpinned ones have gone by since. The drive
            # is at least that far whatever sits in between, and the round is
            # timed by the LONGER of the two answers — a plan may reserve more
            # time than the driving needs, never less.
            if branch.geo and anchor is not None and anchor is not prev:
                far = self.measured_between(anchor, branch)
                if far is None:
                    return None            # too far, whatever stood between
                gap = max(gap, far)
            w_from, w_to = win
            placed = None
            # A window written 00:00->06:00 is TONIGHT for a man whose shift
            # runs past midnight, so it is offered on both sides of the clock.
            for wf, wt in ((w_from, w_to), (w_from + DAY, w_to + DAY)):
                if wt > self.end + DAY:
                    continue
                start = max(cursor + gap, wf)
                # A VISIT MAY ONLY BEGIN INSIDE A WORKING WINDOW. Everything
                # else about this line is unchanged: the door's own closing
                # time and his final close still cap where it may finish, so a
                # man with ONE window is planned exactly as he was before.
                start = self._first_start(start)
                if start is None:
                    continue
                if start + dur <= min(self._cap_for(start), wt):
                    placed = start
                    break
            if placed is None:
                return None
            out.append((placed, gap))
            cursor = placed + dur
            prev = branch
            if branch.geo:
                anchor = branch
        return out

    def _areas_ok(self, order, rescue=False):
        """Rule 5 on the finished sequence: every area done in one go, never
        returned to, and no more patches in a day than a round can hold.

        On the rescue pass a patch may be returned to and one extra patch is
        allowed — the round is judged by how many PATCHES it holds, not by how
        many times he crosses between them."""
        seq = []
        for branch, _dur, _win in order:
            if not seq or seq[-1] != branch.area_id:
                if branch.area_id in seq and not rescue:
                    return False
                seq.append(branch.area_id)
        cap = max(1, int(self.s["areas_per_day"])) + (1 if rescue else 0)
        return len(set(seq)) <= cap

    def try_insert(self, branch, dur, win, rescue=False):
        """Where this visit would go in the day — anywhere in the round, not
        only on the end.

        Appending was the whole trouble: a man's Maadi night began with a
        branch that opens at midnight, so a restaurant open 22:00 to 02:00
        arrived to find the evening already spent, and went unplaced while he
        stood two streets away. A day is a journey that can be re-timed, so
        every position is tried and the one that costs the least time wins.
        """
        base = [(st["branch"], st["dur"], st["win"]) for st in self.stops]
        now = self._sequence(base)
        was = (now[-1][0] + base[-1][1]) if now else self._opens_at()
        best = None
        for i in range(len(base) + 1):
            trial = base[:i] + [(branch, dur, win)] + base[i:]
            if not self._areas_ok(trial, rescue):
                continue
            timed = self._sequence(trial)
            if timed is None:
                continue
            ends = timed[-1][0] + trial[-1][1]
            cost = ends - was
            if best is None or cost < best[0]:
                best = (cost, i, trial, timed)
        return best

    def commit(self, plan_, job):
        """Take the day the insertion worked out."""
        _cost, i, trial, timed = plan_
        stops = []
        for (branch, dur, win), (start, gap) in zip(trial, timed):
            old = next((st for st in self.stops if st["branch"].id == branch.id), None)
            stops.append({"branch": branch, "dur": dur, "win": win, "start": start,
                          "travel": gap, "job": old["job"] if old else job})
        self.stops = stops
        self.cursor = timed[-1][0] + trial[-1][1]
        self.areas = list(self.held)
        for st in stops:
            if not self.areas or self.areas[-1] != st["branch"].area_id:
                self.areas.append(st["branch"].area_id)
        last = stops[-1]["branch"]
        self.at = last.geo
        if last.zone_id is not None:
            self.zone = last.zone_id       # settled now, whatever was reserved

    def block(self, start, end, area_id=None, zone_id=None, site_id=None):
        """Time already promised to a customer. It cannot be moved, so the day
        simply starts after it — a plan is not allowed to re-time a visit the
        office has already told somebody about.

        And it says WHERE HE WILL BE STANDING. A visit already booked into a
        patch makes that patch his for the day: rule 5 counts it as the first
        leg of the journey, so the planner does not hand him a far patch at ten
        and leave him driving back across town for his own afternoon."""
        self.start = max(self.start, end)
        self.cursor = max(self.cursor, end)
        # ...AND IT EATS THE WINDOWS IT COVERS, so nothing is offered an hour
        # he has already been promised to somebody else. A window he is part
        # way through is clipped, not dropped.
        self.windows = [(max(a, end), b) for a, b in self.windows if b > end]
        if not self.windows:
            self.windows = [(self.start, max(self.start, self.end))]
        # AND WHICH DOOR IT IS. A visit already in the diary never becomes a
        # `stop`, so without this the plan cannot see that this branch is
        # already being served today and would send a second man to it.
        if site_id is not None and site_id not in self.booked:
            self.booked.append(site_id)
        if area_id is not None and area_id not in self.held:
            self.held.append(area_id)
            self.areas = self.held + [a for a in self.areas if a not in self.held]
        if zone_id is not None:
            self.zone = zone_id

    def has_branch(self, site_id):
        return any(st["branch"].id == site_id for st in self.stops)


# ------------------------------------------------------------------ the driving
# LIFTED OUT OF `Day` (2026-09-06) so that anything which needs to ask "how long
# is that hop" gets the PLANNER'S answer and not a second opinion. The
# "who can take this visit" screen in server.py suggests a time to send somebody,
# and a suggestion that ignored the drive would put a man in two places at once.
# The behaviour is unchanged; only the address moved.
def measured_minutes(a, b, s):
    """Minutes for a hop where BOTH ends carry a pin, so the distance is not a
    guess. None means it is longer than the plan will ever ask of anybody — let
    somebody nearer have it."""
    km = haversine_km(a.geo, b.geo)
    mins = int(round(km / max(1.0, s["travel_kmh"]) * 60))
    # A CEILING OF ZERO IS "CHARGE NOTHING FOR THE DRIVING", NOT "NO DRIVE IS
    # ALLOWED". Read the other way it quietly refuses every hop in the book and
    # leaves each man one call a day.
    cap = int(s["travel_max"])
    if cap <= 0:
        return 0
    if mins > cap:
        return None                        # let somebody nearer have it
    return min(max(5, mins), cap)


def travel_minutes(a, b, s):
    """Minutes to reserve for driving from one stop to the next. Measured where
    both ends have coordinates, otherwise the allowance for the kind of hop it
    is. None means the drive is longer than the plan will ever ask of anybody."""
    if a is None:
        return 0                           # he starts his day there
    if a.geo and b.geo:
        return measured_minutes(a, b, s)
    if a.client_id == b.client_id and a.area_id == b.area_id:
        return 0                           # two doors of one address
    if int(s["travel_max"]) <= 0:
        return 0                           # the office charges nothing for it
    return (s["travel_area"] if a.area_id == b.area_id else s["travel_max"])


# ------------------------------------------------------------- what is already in
def _place_booked(book, days, s, unplaced, frm, to):
    """Visits already in the diary. One with an engineer holds his time; one
    with nobody on it is staffed here, at the hour the customer was promised.

    Returns {(site_id, week_start): n} so rule 4 does not book a branch twice
    for the same week."""
    fixed = {}
    by_month = {}
    pending = []
    in_range_counts = {}
    for v in book["booked"]:
        b = book["branches"].get(v["site_id"])
        start = v["scheduled_start"]
        try:
            when = _dt.datetime.fromisoformat(str(start).replace(" ", "T"))
        except ValueError:
            continue
        date = when.date()
        end = when
        if v["scheduled_end"]:
            try:
                end = _dt.datetime.fromisoformat(str(v["scheduled_end"]).replace(" ", "T"))
            except ValueError:
                pass
        mins = max(15, int((end - when).total_seconds() // 60) or s["slot_minutes"])
        key = (v["site_id"], _week_of(date, book["anchor"]))
        fixed[key] = fixed.get(key, 0) + 1
        mkey = (v["site_id"], (date.year, date.month))
        by_month[mkey] = by_month.get(mkey, 0) + 1
        in_range = frm <= date.isoformat() <= to
        if in_range:
            in_range_counts[v["site_id"]] = in_range_counts.get(v["site_id"], 0) + 1
        if not v["agent_id"]:
            # A COMPLETED VISIT WITH NOBODY ON IT IS HISTORY, NOT A PROMISE.
            # It counts against the month (that is the whole point of loading
            # it), but staffing it would be sending an engineer to work that
            # has already been done.
            if not in_range or v["status"] == "completed":
                continue                   # counted against the cycle, nothing more
            # ALREADY PROMISED, NOBODY DRIVING. The office booked it (or a
            # customer asked for that hour) and left the engineer blank. The
            # plan must staff it AT THE TIME THE CUSTOMER WAS GIVEN — never
            # move it — so it goes in as a job with one date and one slot.
            if b is not None:
                at = when.hour * 60 + when.minute
                pending.append({"branch": b, "week": _week_of(date, book["anchor"]), "date": date,
                                "at": at, "minutes": mins, "visit_id": v["id"]})
            continue
        day = days.get((v["agent_id"], date))
        if day is None:
            # Its own date is outside the range — but a night that runs over
            # still holds the morning that IS in the range.
            if end.date() != when.date():
                nxt = days.get((v["agent_id"], end.date()))
                if nxt is not None:
                    nxt.block(0, end.hour * 60 + end.minute,
                              b.area_id if b else None, b.zone_id if b else None)
            continue
        st = when.hour * 60 + when.minute
        day.block(st, st + mins, b.area_id if b else None, b.zone_id if b else None,
                  site_id=v["site_id"])
        # A ROUND THAT RAN PAST MIDNIGHT HOLDS THE MORNING AFTER, even when the
        # night itself is outside the range being planned — the man who
        # finished a kitchen at half past one is not opening a warehouse at two.
        if end.date() != when.date():
            nxt = days.get((v["agent_id"], end.date()))
            if nxt is not None:
                nxt.block(0, end.hour * 60 + end.minute)
    return fixed, pending, in_range_counts, by_month


def _reach_map(book, worked_weekdays):
    """WHICH WEEKDAYS A BRANCH CAN ACTUALLY BE SERVED ON — one answer, shared.

    Rule 4 (what is due) and rule 6 (what the book makes impossible) must agree
    about this or visits fall between them. They used to disagree: rule 4 asked
    the branch's OWN people, rule 6 asked whether ANYBODY in the company worked
    that day. While both answers match nothing shows — but the day an engineer
    stops working a weekday that only HE covered for that patch, rule 4 deals
    fewer visits and rule 6 still calls the day worked, so the difference is
    neither booked, nor reported unplaced, nor named impossible. It simply
    leaves the arithmetic (2026-08-27: 15 of Exception Factory's visits did
    exactly that when one man's Friday was taken off the board).

    So there is now ONE function and both callers use it.

    THE DAYS THE BRANCH'S OWN PEOPLE WORK — not the days somebody, anywhere,
    works. A branch whose only eligible engineer is off on Fridays cannot be
    given a Friday visit because another man across the city works one.
    ...but a branch NOBODY can reach still has to be owed its visits, or rule 6
    has nothing to report and the office is told a patch with no engineer is
    simply fine. Where there is nobody, the company's own working days stand in.
    """
    cache = {}

    def reach(branch):
        key = (branch.area_id, branch.shift)
        if key not in cache:
            wds = set()
            for q in book["people"].values():
                if q.works_shift(branch.shift) and branch.area_id in q.areas:
                    wds |= {wd for wd in q.days if q.may_work(branch.area_id, wd)}
            if wds and worked_weekdays:
                cache[key] = wds & worked_weekdays
            else:
                cache[key] = wds or worked_weekdays or set(range(7))
        return cache[key]

    return reach


# ------------------------------------------------------------------ what is due
def _due_jobs(book, d0, d1, fixed, worked_weekdays):
    """Rule 4, counted on the CALENDAR. One entry per visit owed in the range.

    A branch's number is read in the unit it was typed in:

      · 'month' — EXACTLY that many visits in the calendar month, whether the
        month has 28 days or 31. The month's visits sit on fixed, evenly spread
        dates (month_slots), so the count cannot drift with the length of the
        month and pressing the button again sees the same visits.

      · 'week' — a weekly rhythm, dealt a week at a time. A month with five of
        its weeks in it is five visits; that is what a weekly contract means
        and squeezing it to four would be the same error in reverse.

    Nothing here invents a visit because a month is long. What the office sold
    is what the planner owes.
    """
    jobs = []
    anchor = book["anchor"]
    by_month = book.get("booked_by_month") or {}
    months = months_in(d0, d1)

    # The same answer rule 6 uses — see _reach_map, and the trap it closes.
    reachable_weekdays = _reach_map(book, worked_weekdays)

    def open_days_between(branch, first, last):
        """The days in [first, last] this branch opens and its own people work."""
        ok = reachable_weekdays(branch)
        n, day = 0, first
        while day <= last:
            if branch.opens_on(day.weekday()) and day.weekday() in ok:
                n += 1
            day += _dt.timedelta(days=1)
        return n

    for b in book["branches"].values():
        if b.freq_unit == "week":
            # ---- a weekly rhythm, week by week --------------------------
            wk = anchor
            while wk <= d1:
                owed = week_quota(b.vpm, wk.toordinal() // 7,
                                  offset=b.id % WEEKS_PER_MONTH)
                owed -= fixed.get((b.id, wk), 0)
                if worked_weekdays:
                    dts = _dates_of_week(wk, d0, d1)
                    if dts:
                        owed = min(owed, open_days_between(b, dts[0], dts[-1]))
                for _ in range(max(0, owed)):
                    jobs.append({"branch": b, "week": wk,
                                 "dates": _dates_of_week(wk, d0, d1)})
                wk += _dt.timedelta(days=7)
            continue
        # ---- a number of visits in the calendar month --------------------
        for (year, month, first, last) in months:
            slots = month_slots(b.vpm, year, month)
            # A slot counts as due here when the WEEK it falls in reaches into
            # the range — not only when the slot's own date does. The office
            # plans Thursday to Saturday after fixing one branch, and the visit
            # that week is still that week's visit; refusing it because the
            # even spread put its marker on the Monday would book nothing.
            inside = []
            for t in slots:
                if _dates_of_week(_week_of(t, anchor), d0, d1):
                    inside.append(t)
            # TWO CEILINGS, AND BOTH HAVE TO HOLD.
            #
            # The MONTH's own count, less whatever is already in the diary for
            # that month: four a month is four, and a re-run halfway through
            # must not start again.
            #
            # And THAT WEEK's share, less what is already booked in it: the
            # office re-runs Wednesday to Friday after fixing one branch, and a
            # week that has already had its visit must not collect a second one
            # merely because the month still has visits outstanding elsewhere.
            remaining = len(slots) - by_month.get((b.id, (year, month)), 0)
            per_week = {}
            for t in inside:
                per_week.setdefault(_week_of(t, anchor), []).append(t)
            # A SLOT IS A TARGET, NEVER A QUOTA. What its own week cannot
            # hold is not cancelled — it is carried here and re-offered across
            # the whole month below.
            deferred = []
            dealt = 0
            for wk in sorted(per_week):
                if remaining <= 0:
                    break
                targets = per_week[wk]
                dates = _dates_of_week(wk, d0, d1)
                owed = len(targets) - fixed.get((b.id, wk), 0)
                owed = min(owed, remaining)
                owed = max(0, owed)
                # A branch takes at most one visit a day, so this WEEK can
                # never hold more of them than it has open days in it.
                room = owed
                if dates:
                    # CLIPPED TO THIS MONTH'S OWN PORTION OF THE WEEK. A week
                    # that straddles two months belongs partly to each; letting
                    # both count the whole week's open days is how a branch on
                    # one visit a day collects seven of them in six days.
                    lo = max(dates[0], first)
                    hi = min(dates[-1], last)
                    room = min(owed, open_days_between(b, lo, hi) if lo <= hi else 0)
                for target in targets[:room]:
                    # Its own week first, so the month stays evenly spread;
                    # after that the whole month AND the rest of its own week —
                    # a week that straddles two months belongs to both, and
                    # cutting the fallback at the month boundary strands the
                    # last visit on the wrong side of it.
                    wide = sorted(set(_dates_between(max(first, d0), min(last, d1)))
                                  | set(dates))
                    jobs.append({"branch": b, "week": wk, "target": target,
                                 "dates": dates, "wide": wide})
                # The rhythm asked for more than this week can physically take.
                # THE VISIT IS STILL OWED; only its date is now open.
                deferred.extend((wk, t) for t in targets[room:owed])
                dealt += room
                remaining -= room
            # WHAT NO WEEK COULD HOLD IS STILL OWED TO THE MONTH.
            #
            # A calendar month is not a whole number of weeks: planning the 1st
            # to the 30th leaves a stub of two days at the end, and a slot that
            # lands in it on a branch that does not open on either day used to
            # be reduced to nothing and never offered anywhere else. No job was
            # made, so the placing passes never saw it, and because the
            # unplaced list only reports jobs that FAILED, it was not reported
            # either — 12 visits vanished that way across September to December
            # on the office's own book, every one of them with a free open day
            # still left in its month (2026-08-27).
            #
            # So each one is re-offered with the WHOLE MONTH to land in. It
            # keeps no due date: its rhythm slot could not be honoured, and
            # pretending otherwise would only drag it back to the same corner.
            # One visit a day per branch still holds, here as everywhere, so a
            # recovered visit can only take a day the branch does not already
            # have. If it still cannot be driven it comes back as an UNPLACED
            # ROW with its reason — a visit the office can see and chase, never
            # a silence.
            # ...BUT ONLY WHERE THERE IS A DAY LEFT TO PUT IT ON, and only
            # inside the stretch actually being planned. Two different things
            # look alike here and must not be confused:
            #
            #   · A VISIT THAT WAS LOST. Its week could not hold it, but the
            #     month still has an open day going spare. That is the bug, and
            #     it is recovered here.
            #
            #   · A BOOK THAT ASKS THE IMPOSSIBLE. A branch open two days a
            #     week cannot take twelve visits in a month however the dates
            #     are arranged. That is not unplaceable WORK, it is a number
            #     the office typed that no plan can honour, and rule 6 already
            #     names it with `asked` and `possible` (see _capped). Turning it
            #     into a fistful of unplaced rows every single month would bury
            #     the real ones.
            #
            # The office also re-runs a few DAYS at a time. A branch on
            # twenty-eight a month has most of its visits in weeks this run
            # does not cover; they are not owed HERE, and must not be dragged
            # into this range's worklist.
            lo_m, hi_m = max(first, d0), min(last, d1)
            portion_room = open_days_between(b, lo_m, hi_m) if lo_m <= hi_m else 0
            used = dealt + by_month.get((b.id, (year, month)), 0)
            extra = max(0, min(len(deferred), remaining, portion_room - used))
            month_dates = _dates_between(lo_m, hi_m)
            for wk, _target in deferred[:extra]:
                jobs.append({"branch": b, "week": wk, "target": None,
                             "dates": month_dates, "wide": month_dates})
            remaining -= extra
    # Heaviest and tightest first: a four-hour night window with a two-hour job
    # in it has fewer places to go than a branch that will take any afternoon.
    def tightness(job):
        b = job["branch"]
        return (b.win[1] - b.win[0]) - (b.minutes or 60)
    jobs.sort(key=lambda j: (j["week"], tightness(j), -(j["branch"].minutes or 60)))
    return jobs


def _dates_between(first, last):
    out, day = [], first
    while day <= last:
        out.append(day)
        day += _dt.timedelta(days=1)
    return out


def _visitable_days(branch, week, worked_weekdays, d0, d1):
    """The days of this week the branch opens and the company normally works.

    NORMALLY is the load-bearing word. A branch open only on Fridays, when
    nobody has Friday hours at all, is asking for something the roster can
    never give: that belongs in the warnings, not in a pile of unplaceable
    visits. But a Tuesday the whole team happens to be on leave IS a day the
    work was due and did not happen, and the office wants to see that."""
    return [d for d in _dates_of_week(week, d0, d1)
            if branch.opens_on(d.weekday()) and d.weekday() in worked_weekdays]


def _dates_of_week(week, d0, d1):
    """The dates of one roster week that are actually inside the range."""
    out = []
    for i in range(7):
        d = week + _dt.timedelta(days=i)
        if d0 <= d <= d1:
            out.append(d)
    return out


def _reserve_zones(person, dates, jobs, days):
    """Rule 5, decided for the WHOLE WEEK before a single visit is placed.

    A day may only touch one zone, so the question "which zone is Tuesday?"
    has to be answered by looking at everything this man owes that week — not
    by whichever branch happened to be tried first. Letting the first job claim
    the day is what left a man with four nights committed to one zone and every
    branch in his second zone unplaceable: his week was full of the wrong days.

    Each zone gets days in proportion to the work waiting in it, biggest first,
    by largest remainder — and a zone with any work at all gets at least one
    day while there are days left to give.
    """
    open_days = [d for d in dates if (person.id, d) in days and not days[(person.id, d)].stops]
    if not open_days:
        return
    # A BRANCH THAT OPENS ONE DAY A WEEK DECIDES THAT DAY. The customer has
    # already chosen it — a warehouse that takes visits on Wednesdays and
    # nowhere else cannot be moved to suit a round — so those weekdays are
    # settled before anything is shared out, and the heavier zone wins a day
    # two of them want.
    # A JOB HE CANNOT ACTUALLY WORK BUYS NO DAY. The office can take a patch
    # away from a man without taking his branches off him — the name on the
    # branch is theirs to keep — and a week that reserves Tuesday for a zone he
    # is no longer allowed into is a Tuesday nobody works at all.
    reachable = []
    for job in jobs:
        b = job["branch"]
        can = [d for d in open_days if b.opens_on(d.weekday())
               and person.may_work(b.area_id, d.weekday())]
        if can:
            reachable.append((job, can))
    jobs = [job for job, _can in reachable]
    if not jobs:
        return
    forced = {}
    for job, can in reachable:
        b = job["branch"]
        if len(can) == 1:
            got = forced.get(can[0])
            if got is None or (b.minutes or 60) > got[1]:
                forced[can[0]] = (b.group, b.minutes or 60)
    for date, (group, _w) in forced.items():
        days[(person.id, date)].group = group
    open_days = [d for d in open_days if d not in forced]
    weight = {}
    for job in jobs:
        b = job["branch"]
        if b.group in {z for z, _w in forced.values()}:
            # already has a day this week; it may still want more, but the
            # zones with nowhere to go come first.
            continue
        weight[b.group] = weight.get(b.group, 0) + (b.minutes or 60)
    if not weight or not open_days:
        return
    total = float(sum(weight.values()))
    share = sorted(weight.items(), key=lambda kv: -kv[1])
    # ONE DAY EACH FIRST, heaviest zone first, for as many zones as there are
    # days. A man allowed eight zones and working six days cannot reach them
    # all in one week — but the two that miss out must be the two with the
    # least work in them, not whichever the arithmetic rounded away.
    give = {z: 1 for z, _w in share[:len(open_days)]}
    left = len(open_days) - sum(give.values())
    # ...then the rest of the week goes where the work is.
    for z, w in share:
        if left <= 0:
            break
        extra = int(round(w / total * len(open_days)))
        extra = min(max(0, extra - give.get(z, 0)), left)
        give[z] = give.get(z, 0) + extra
        left -= extra
    if left > 0 and share:
        give[share[0][0]] = give.get(share[0][0], 0) + left
    # Spread each zone's days through the week rather than in a block: a branch
    # that opens on two named days needs its zone to fall on one of them.
    slots = []
    for z, n in sorted(give.items(), key=lambda kv: -weight.get(kv[0], 0)):
        slots.extend([z] * n)
    for date, group in zip(open_days, slots):
        days[(person.id, date)].group = group


Claims = _collections.namedtuple("Claims", "door branch")


def _claim(days):
    """Who is already where today, in the two senses the planner needs.

    `door`  — {(date, client, area): agent_id}. ONE CUSTOMER IN ONE AREA IS ONE
              ADDRESS. Three units of the same company on one street are one
              call as far as the driving goes. This one is a PREFERENCE: it
              binds while there is still another day to try and lets go in the
              later passes, because as a wall it cost real visits (a day man at
              one door turned the night men away from ANOTHER door of the same
              customer).

    `branch` — {(date, site_id): agent_id}. ONE BRANCH, ONE DAY, ONE MAN, and
              this one NEVER gives way. Asked of every engineer at once, which
              is the whole point: the planner's older question — "is this
              branch already on THIS man's day?" (`Day.has_branch`) — cannot
              see two different engineers sent to one door, and on the office's
              September book that happened nine times, every one of them an
              owner plus somebody covering for that same owner. There is no
              route preference worth two vans at one address, so unlike `door`
              it is enforced in the cover pass and in the rescue pass too.

    Both include what the DIARY already holds (`Day.booked`), not only what
    this run has placed."""
    door, branch = {}, {}
    for (agent_id, date), day in days.items():
        for st in day.stops:
            door[(date, st["branch"].client_id, st["branch"].area_id)] = agent_id
            branch[(date, st["branch"].id)] = agent_id
        for site_id in day.booked:
            branch[(date, site_id)] = agent_id
    return Claims(door, branch)


def _fill_days(jobs, days, book, s, unplaced, promised=False):
    """Rules 2, 3 and 5 together: the owner first, cover second, and every
    candidate day must still be one journey through one zone."""
    people = book["people"]
    # Answer "which zone is which day" for every man, one week at a time,
    # BEFORE any visit is placed.
    by_week = {}
    for job in jobs:
        by_week.setdefault(job["week"], []).append(job)
    for week, week_jobs in (() if promised else sorted(by_week.items())):
        dates = week_jobs[0].get("dates") or _dates_of_week(week, *_range_of(days, book))
        owned = {}
        for job in week_jobs:
            owned.setdefault(job["branch"].owner_id, []).append(job)
        for agent_id, their_jobs in owned.items():
            person = people.get(agent_id)
            if person is not None:
                _reserve_zones(person, dates, their_jobs, days)
    # TWO PASSES OVER THE WHOLE LIST, and the order matters more than it looks.
    #
    # In the first, every branch may only use the days its owner's week set
    # aside for its zone. In the second, what is left over may go anywhere he
    # has room, and then to anybody who can cover.
    #
    # One pass would let a branch with more visits than its reserved days take
    # the days belonging to the NEXT zone before that zone is ever tried — one
    # patch worked six days running while the patch next door, in another zone,
    # went unvisited all week. That is the office's own complaint, arriving by
    # a different route.
    leftovers = []
    stranded = []
    for job in jobs:
        b = job["branch"]
        dates = ([job["date"]] if promised
                 else job.get("dates")
                 or _dates_of_week(job["week"], *_range_of(days, book)))
        owner = people.get(b.owner_id)
        if owner is not None and _try_engineer(owner, b, job, dates, days, s,
                                               claims=_claim(days), respect=True):
            continue
        leftovers.append((job, dates, owner))

    for job, dates, owner in leftovers:
        b = job["branch"]
        # THE WHOLE MONTH, NOW. Its own week was preferred so the month stays
        # evenly spread; a visit is not lost because that one week was awkward.
        if not promised and job.get("wide"):
            dates = job["wide"]
        claims = _claim(days)
        placed = False
        if owner is not None:
            placed = _try_engineer(owner, b, job, dates, days, s, claims=claims)
        if not placed:
            # Rule 3: somebody else of the same shift who may work the patch,
            # preferring a man already standing in that zone that day.
            for p in _cover_order(people, b, owner):
                if _try_engineer(p, b, job, dates, days, s, cover_for=owner, claims=claims):
                    placed = True
                    break
        if not placed:
            stranded.append((job, dates, owner))

    # THIRD PASS — THE CUSTOMER'S VISIT BEATS A TIDY ROUND.
    #
    # Everything above has been tried cleanly: the owner on his own reserved
    # days, the owner anywhere in the month, then every engineer who could
    # cover. What is left would be REPORTED UNPLACED — a visit the company
    # sold and did not deliver — and the office's ruling is that a route
    # preference is not worth that: "Customer visit comes first. Don't leave an
    # owed visit unplaced just to make the route look perfect."
    #
    # So rule 5's three clauses give way here, and ONLY here: a third patch, a
    # patch returned to, a second zone in the day. Nothing else moves. His
    # hours, the branch's opening window, the length of the visit, who is
    # allowed to work the patch, the travel ceiling and double-booking are not
    # preferences and are enforced exactly as before — a visit that cannot be
    # driven still comes back unplaced with its reason.
    #
    # Every visit saved this way is reported with what it cost (see _damage),
    # so a bent round is something the office can see and undo, never a quiet
    # change in what the planner does.
    for job, dates, owner in stranded:
        b = job["branch"]
        claims = _claim(days)
        placed = False
        if owner is not None:
            placed = _try_engineer(owner, b, job, dates, days, s, claims=claims,
                                   rescue=True)
        if not placed:
            for p in _cover_order(people, b, owner):
                if _try_engineer(p, b, job, dates, days, s, cover_for=owner,
                                 claims=claims, rescue=True):
                    placed = True
                    break
        if not placed:
            # Several instances of one branch in a week fail for DIFFERENT
            # reasons — Monday's door is open for an hour, Tuesday's whole team
            # is off — so each row is dated on its own open day rather than
            # repeating the first one.
            nth = sum(1 for u in unplaced if u["site_id"] == b.id)
            unplaced.append(_why(b, job, owner, dates, days, people, s, nth))
            # KEEP THE JOB ITSELF, not only the sentence about it. The
            # rebalance pass below is given one more go at these, and a `_why`
            # row cannot be re-placed — it is a report, not a piece of work.
            book.setdefault("_stranded", []).append(
                (job, dates, owner, len(unplaced) - 1))


def _seat(day, items):
    """The best legal running order for this exact set of stops, or nothing.

    Legality is `Day._sequence` and nothing else: every door's window (offered
    on both sides of midnight), his own hours, the length of each visit, the
    drive between them against the ceiling, and never two stops at once.

    Rule 5 is a PREFERENCE here, exactly as it is in the rescue pass: an order
    that keeps the round tidy wins, but a visit the company sold is not thrown
    away to avoid a second patch. The caller is told which it got.
    """
    n = len(items)
    if n <= 6:
        cands = _itertools.permutations(items)
    else:
        # Beyond six stops every ordering is far too many, so only the ones a
        # round is actually driven in are tried: roughly by opening time, and
        # the day as it already stands — each of them also with any ONE stop
        # pulled to the front, which is the move a scarce early door needs.
        def _spread(seq):
            seq = list(seq)
            yield seq
            for i in range(1, len(seq)):
                yield [seq[i]] + seq[:i] + seq[i + 1:]

        base_orders = (sorted(items, key=lambda x: (x[2][0], x[2][1])),
                       sorted(items, key=lambda x: (x[2][1], x[2][0])),
                       list(items))
        cands = (o for b in base_orders for o in _spread(b))
    best = None
    for order in cands:
        order = list(order)
        timed = day._sequence(order)
        if timed is None:
            continue
        tidy = day._areas_ok(order, rescue=True)
        rank = (0 if tidy else 1, sum(g for _st, g in timed))
        if best is None or rank < best[0]:
            best = (rank, order, timed, bool(tidy))
    return best


def _items_of(day):
    return [(st["branch"], st["dur"], st["win"]) for st in day.stops]


def _reorder_commit(day, order, timed, job_for_new=None):
    """Take a re-timed day, keeping every stop's own job row."""
    old_jobs = {st["branch"].id: st["job"] for st in day.stops}
    stops = []
    for (branch, dur, win), (start, gap) in zip(order, timed):
        stops.append({"branch": branch, "dur": dur, "win": win, "start": start,
                      "travel": gap,
                      "job": old_jobs.get(branch.id, job_for_new or {})})
    day.stops = sorted(stops, key=lambda st: st["start"])
    day.cursor = day.stops[-1]["start"] + day.stops[-1]["dur"]
    day.areas = list(day.held)
    for st in day.stops:
        if not day.areas or day.areas[-1] != st["branch"].area_id:
            day.areas.append(st["branch"].area_id)
    last = day.stops[-1]["branch"]
    day.at = last.geo
    if last.zone_id is not None:
        day.zone = last.zone_id


def _rebalance(days, book, s, unplaced):
    """THE LAST RESCUE: use the capacity that is already there, better.

    Everything above has been tried — the owner, cover, and the rescue pass
    that gives up rule 5's route preferences. What is still unplaced is work
    the company sold and did not deliver. Before writing it off, three more
    questions are asked of every one of them, in this order:

      1. can it simply be dropped in now (a day may have changed since);
      2. can the engineer's EXISTING round be RE-ORDERED to make room —
         `try_insert` offers a visit every position but never re-sequences the
         stops already in the day, and on the office's own book that alone
         loses visits (1980 coffee Galleria 40, 2026-11-28: no insertion works,
         yet putting it first does);
      3. can ONE already-booked visit move to another legal day of its own, so
         the scarce one can have the hour it cannot get anywhere else. A visit
         with nine open days must give way to one with a single narrow morning.

    THE SCARCE VISIT GOES FIRST — fewest open days, then fewest men who may
    take it, then the narrowest window. Whatever is rearranged, NOTHING is
    given up: every window, every man's hours, the travel ceiling, one visit a
    day per branch and one man at a door are all still hard, and a displaced
    visit must land somewhere legal or it does not move at all. No branch ever
    loses a visit to pay for another's.
    """
    out = {"rescued": 0, "direct": 0, "reorder": 0, "swap": 0,
           "moved": 0, "travel": 0, "route_compromises": 0, "rows": []}
    if not int(s.get("rebalance", 1)):
        return out                     # the office has switched the pass off
    stranded = book.get("_stranded") or []
    if not stranded:
        return out
    people, branches = book["people"], book["branches"]

    # who is standing at which door, so a rescue never sends a second van
    at_door = {}
    for (agent_id, date), day in days.items():
        for st in day.stops:
            at_door.setdefault((date, st["branch"].id), set()).add(agent_id)

    def may_take(p, b, date):
        """Everything except whether the day has room."""
        wd = date.weekday()
        if not b.opens_on(wd) or b.area_id not in p.areas:
            return False
        if not p.may_work(b.area_id, wd):
            return False
        if p.id != b.owner_id and not p.works_shift(b.shift):
            return False
        named = b.day_agent.get(wd)
        if named and named != p.id:
            return False
        held = at_door.get((date, b.id), set()) - {p.id}
        return not held

    def slots(b, skip=()):
        out_ = []
        for (agent_id, date), day in days.items():
            if (agent_id, date) in skip:
                continue
            p = people.get(agent_id)
            if p is None or not may_take(p, b, date):
                continue
            if any(st["branch"].id == b.id for st in day.stops):
                continue                       # one visit a day per branch
            out_.append((p, date, day))
        out_.sort(key=lambda t: (t[1], t[0].id))
        return out_

    def scarcity(entry):
        job = entry[0]
        b = job["branch"]
        opens = [w for w in range(7) if b.opens_on(w)]
        widths = [b.window_on(w)[1] - b.window_on(w)[0] for w in opens] or [DAY]
        elig = sum(1 for p in people.values()
                   if b.area_id in p.areas and p.days
                   and (p.id == b.owner_id or p.works_shift(b.shift)))
        return (len(opens), elig, min(widths), b.id)

    def note(row):
        out["rows"].append(row)
        out["rescued"] += 1

    done = set()
    for job, _dates, _owner, idx in sorted(stranded, key=scarcity):
        if idx in done:
            continue
        b = job["branch"]
        dur = job.get("minutes") or b.job_minutes(s["slot_minutes"])
        placed = False
        for p, date, day in slots(b):
            item = (b, dur, b.window_on(date.weekday()))
            base = _items_of(day)
            before = sum(st["travel"] for st in day.stops)
            # ---- 1 and 2: as it stands, then re-sequenced --------------
            got = _seat(day, base + [item])
            if got is not None:
                _rank, order, timed, tidy = got
                kind = ("direct" if [x[0].id for x in order[:len(base)]]
                        == [x[0].id for x in base] else "reorder")
                _reorder_commit(day, order, timed, job)
                at_door.setdefault((date, b.id), set()).add(p.id)
                out[kind] += 1
                out["travel"] += sum(g for _st, g in timed) - before
                out["route_compromises"] += 0 if tidy else 1
                note({"site_id": b.id, "site_name": b.name, "how": kind,
                      "date": date.isoformat(), "agent_id": p.id, "moved": []})
                placed = True
                break
            # ---- 3: move the booked visits that have somewhere else to go -
            #
            # ONE IS NOT ALWAYS ENOUGH. A branch nothing can be driven with —
            # AMS Factory's nearest neighbour is 39 minutes away, past the
            # ceiling — needs the day CLEARED, not thinned: two half-hour calls
            # that could be done on any of six other days will each refuse to
            # share the round with it. So a scarce visit may displace more than
            # one flexible call, provided every one of them lands somewhere
            # legal. All or nothing: if any cannot be rehomed, nothing moves.
            for k in (1, 2, 3):
                if placed:
                    break
                if k > len(day.stops):
                    break
                for combo in _itertools.combinations(range(len(day.stops)), k):
                    victims = [day.stops[i] for i in combo]
                    rest = [x for j, x in enumerate(base) if j not in combo]
                    got = _seat(day, rest + [item])
                    if got is None:
                        continue
                    homes, ok = [], True
                    taken = {(p.id, date)}
                    for victim in victims:
                        vb = victim["branch"]
                        _held = at_door.get((date, vb.id))
                        if _held is not None:
                            _held.discard(p.id)
                        spot = None
                        for p2, date2, day2 in slots(vb, skip=taken):
                            extra = [h for h in homes if h[0] is day2]
                            got2 = _seat(day2, _items_of(day2)
                                         + [x[3] for x in extra]
                                         + [(vb, victim["dur"],
                                             vb.window_on(date2.weekday()))])
                            if got2 is None:
                                continue
                            spot = (day2, p2, date2,
                                    (vb, victim["dur"], vb.window_on(date2.weekday())),
                                    got2, victim)
                            break
                        if spot is None:
                            if _held is not None:
                                _held.add(p.id)
                            ok = False
                            break
                        homes.append(spot)
                        taken.add((spot[1].id, spot[2]))
                    if not ok:
                        continue
                    _r1, order1, timed1, tidy1 = got
                    _reorder_commit(day, order1, timed1, job)
                    at_door.setdefault((date, b.id), set()).add(p.id)
                    for day2, p2, date2, _it, got2, victim in homes:
                        _r2, order2, timed2, tidy2 = got2
                        _reorder_commit(day2, order2, timed2, victim["job"])
                        at_door.setdefault((date2, victim["branch"].id), set()).add(p2.id)
                        out["route_compromises"] += 0 if tidy2 else 1
                    out["swap"] += 1
                    out["moved"] += len(homes)
                    out["route_compromises"] += 0 if tidy1 else 1
                    note({"site_id": b.id, "site_name": b.name, "how": "swap",
                          "date": date.isoformat(), "agent_id": p.id,
                          "moved": [{"site_id": v[5]["branch"].id,
                                     "site_name": v[5]["branch"].name,
                                     "from": date.isoformat(),
                                     "to": v[2].isoformat(), "agent_id": v[1].id}
                                    for v in homes]})
                    placed = True
                    break
            if placed:
                break
            if placed:
                break
        if placed:
            done.add(idx)

    # Every visit saved here stops being a line on the worklist. The office's
    # arithmetic must still close: owed = booked + what is still unplaced.
    if done:
        for i in sorted(done, reverse=True):
            if 0 <= i < len(unplaced):
                unplaced.pop(i)
    return out


def _range_of(days, book=None):
    """The dates the plan covers. Taken from the RUN, not from the days people
    happen to work — on a book where nobody has hours yet there are no days at
    all, and a worklist whose rows carry no date is a worklist the office
    cannot open."""
    if book and book.get("from") and book.get("to"):
        return book["from"], book["to"]
    dates = [d for (_a, d) in days] or [_dt.date.today()]
    return min(dates), max(dates)


def _cover_order(people, branch, owner):
    """Who is offered a branch that its owner could not take."""
    out = [p for p in people.values()
           if p.id != (owner.id if owner else None)
           and p.works_shift(branch.shift) and branch.area_id in p.areas and p.days]
    out.sort(key=lambda p: (p.load, p.name))
    return out


def _try_engineer(person, branch, job, dates, days, s, cover_for=None, claims=None,
                  respect=None, rescue=False):
    """Put this visit on this man's best day, or say no.

    `respect` limits it to the days his own week set aside for this zone; None
    tries that first and then everything else."""
    """Put this visit on this man's best day, or say no. Rule 5 does most of
    the refusing: the day must already be in this zone (or empty), and the area
    must be one he is in now or has not left yet."""
    dur = job.get("minutes") or branch.job_minutes(s["slot_minutes"])
    # HIS WEEK WAS SHARED OUT BEFORE ANY VISIT WAS PLACED (_reserve_zones), and
    # that share has to hold. A day reserved for one zone is still EMPTY when
    # the first branch of another zone comes looking, and letting it take the
    # day means the zone processed first eats the whole week while the other
    # goes unvisited — which is exactly what "both patches are worked" means.
    #
    # So: his own zone's reserved days first. Only if none of them can take it
    # is a day reserved for something else considered at all.
    tries = (True, False) if respect is None else (respect,)
    for strict in tries:
        if _place_on(person, branch, job, dates, days, s, cover_for, claims, dur,
                     strict, rescue):
            return True
    return False


# Rule 5's three clauses, in the order the office minds them: a third patch is
# a detour, going back is a wasted drive, a second zone is a drive across town.
DAMAGE = {None: 0, "extra_patch": 1, "revisit_patch": 2, "second_zone": 3}


def _damage(order, s):
    """What this round would break, judged on the FINISHED sequence — not on
    the day as it stood before, because a stop can be inserted in the middle
    and change which patches end up next to each other.

    Returns the worst of: nothing, a patch too many, a patch returned to, or a
    second zone in one day. This is what the office is shown for every visit
    the plan had to bend a preference to save."""
    seq, zones = [], set()
    for branch, _dur, _win in order:
        if not seq or seq[-1] != branch.area_id:
            seq.append(branch.area_id)
        if branch.zone_id is not None:
            zones.add(branch.zone_id)
    worst = None
    if len(set(seq)) > max(1, int(s["areas_per_day"])):
        worst = "extra_patch"
    if len(seq) > len(set(seq)):
        worst = "revisit_patch"
    if len(zones) > 1:
        worst = "second_zone"
    return worst


def _place_on(person, branch, job, dates, days, s, cover_for, claims, dur, respect,
              rescue=False):
    # An hour already promised to a customer is not a window to be searched —
    # it is the answer. Offer that exact slot or nothing.
    fixed_at = job.get("at")
    best = None
    for date in dates:
        wd = date.weekday()
        if not branch.opens_on(wd) or not person.may_work(branch.area_id, wd):
            continue
        # A branch that names an engineer for THIS weekday means it: that day
        # is his and nobody else's, whoever owns the branch the rest of the week.
        named = branch.day_agent.get(wd)
        if named and named != person.id:
            continue
        # ONE CUSTOMER IN ONE AREA IS ONE ADDRESS — a PREFERENCE, never a wall.
        #
        # If somebody is already at that address today, the first pass leaves
        # the call to him: two vans at one door at nine o'clock is the office's
        # own complaint. But this may not COST the visit, and as a hard block it
        # did, twice over on his real book:
        #   · a DAY man at one door blocked the NIGHT men from another door of
        #     the same customer — two rounds that could never have met;
        #   · Alaa Abdelsamad's standing 07:00-15:00 shift at Exception Factory
        #     is at that address EVERY day, so Exception CBC Warehouse — open
        #     Saturdays only — could never be visited by anyone at all.
        # So it binds while there is still another day to try, and lets go in
        # the second pass: "never leave a visit unplaced just because its owner
        # is unavailable if a suitable engineer can cover it".
        at_door = claims.door.get((date, branch.client_id, branch.area_id)) if claims else None
        if respect and at_door is not None and at_door != person.id:
            continue
        # ONE BRANCH, ONE DAY, ONE MAN — AND THIS ONE IS A WALL.
        #
        # The preference above is about an ADDRESS and gives way; this is about
        # the SAME DOOR and does not, in any pass. Rule 5's route preferences
        # bend to save an owed visit; sending a second van to a branch another
        # engineer is already serving saves nothing — the visit is not gained,
        # it is duplicated, and the day it should have had is lost. Asked of
        # every engineer at once, because `has_branch` below asks only about
        # this man's own day and cannot see the other van (2026-08-26).
        #
        # The ONE exception is an hour already promised to a customer: a visit
        # the office has booked must be staffed at the hour it was given, never
        # dropped, and that promise is the office's own to make.
        held_by = claims.branch.get((date, branch.id)) if claims else None
        if held_by is not None and held_by != person.id and fixed_at is None:
            continue
        day = days.get((person.id, date))
        if day is None:
            continue
        if day.has_branch(branch.id) and fixed_at is None:
            continue                       # rule: one visit a day per branch
        if (not day.accepts(branch, rescue)
                or not day.accepts_area(branch.area_id, rescue)):
            continue
        if (respect and not day.stops and day.group is not None
                and day.group != branch.group):
            continue                       # that day is spoken for
        win = (fixed_at, fixed_at + dur) if fixed_at is not None else branch.window_on(wd)
        spot = day.try_insert(branch, dur, win, rescue)
        if spot is None:
            continue
        cost, _pos, _trial, timed = spot
        # WHAT IT WOULD COST THE ROUND. Outside the rescue pass nothing is
        # allowed to break, so this is always 0 and the score is unchanged.
        harm = _damage(_trial, s) if rescue else None
        start = timed[_pos][0]
        # NEAREST TO THE DAY THIS VISIT IS DUE, first of all. The calendar month
        # spread its visits evenly (month_slots); if every visit of a branch
        # then picks its day purely by round-shape they all crowd onto the same
        # two days and the last one falls off the end of the week — six visits
        # chasing six days and one of them homeless. The target is a preference,
        # not a booking: any day of its week will do, nearest first.
        target = job.get("target")
        near = abs((date - target).days) if target else 0
        # ONE DISTRICT, ONE DAY — WHEN IT COSTS NOTHING TO ARRANGE (Phase 4A).
        #
        # `month_slots` spreads each branch's visits by its OWN monthly count,
        # so four-a-month falls due on the 4th, 12th, 19th and 27th while
        # three-a-month falls due on the 6th, 16th and 26th. Two branches at one
        # address, a couple of days out of step, and the planner sends a man to
        # that district on six days instead of three. The office measured a
        # month of District 5 and found THIRTY of its fifty-five engineer-days
        # carrying one or two calls and nothing else — a whole day in New Cairo
        # for a single visit.
        #
        # The answer is a TIE-BREAK, never a wall. Inside a band of
        # `cluster_days` around the due date every day is equally on time, so a
        # day already going to that patch is preferred; outside the band the due
        # date still decides on its own, and `near` breaks what is left. So a
        # visit is never dragged further than the band to tidy a round, and
        # nothing about WHICH visits are owed is touched.
        #
        # It is off in the rescue pass, where the only question left is whether
        # the visit happens at all — and a dial of 0 restores the old order
        # exactly, which is what makes it safe to switch off.
        # AND THE BAND IS THE BRANCH'S OWN, NOT A FLAT THREE DAYS. A branch on
        # four visits a month is due about every seven days, so moving it three
        # is a nudge. One on twelve a month is due every two and a half days,
        # and moving it three would put two treatments back to back — which is
        # not a routing decision, it is a change to the service. So the nudge is
        # capped at rather less than half the branch's own interval, which
        # leaves the high-frequency branches where the month put them and lets
        # the occasional ones come to THEM. (Measured: without this, eight
        # branches went from a seven-day gap to three, and 1980 Central kitchen
        # from three days to one.)
        cl = int(s.get("cluster_days", 0))
        own = cl
        if target is not None and branch.vpm:
            interval = days_in_month(target.year, target.month) / float(branch.vpm)
            own = max(0, int(interval // 2) - 1)
        cl = min(cl, own)
        if rescue or cl <= 0:
            band, mate = near, 0
        else:
            band = 0 if near <= cl else near
            mate = 0 if branch.area_id in day.areas else 1
        # Then the day that is already going there — that is what makes a
        # round a round — and then the FULLEST such day, not the emptiest.
        # Spreading four stops over four days is four journeys across Cairo to
        # do one call; the office is paying for the drive either way.
        # The day that is already going there wins; after that, the day this
        # visit costs the least time to add to — which is the same question as
        # "whose round does it belong on".
        # THE LEAST DAMAGE FIRST, always. A day that can take the visit without
        # bending anything beats one that needs a third patch, which beats one
        # that needs a drive to another zone — so the rescue never reaches for
        # a long cross-city round while a tidy one is still on offer.
        score = (DAMAGE[harm], band, mate, near,
                 0 if branch.area_id in day.areas else
                 1 if (day.zone == branch.zone_id or day.group == branch.group) else 2,
                 cost, -len(day.stops))
        if best is None or score < best[0]:
            best = (score, day, spot, harm)
    if best is None:
        return False
    _score, day, spot, harm = best
    day.commit(spot, {"cover_for": cover_for.name if cover_for else None,
                      "owner_id": branch.owner_id, "week": job["week"],
                      "visit_id": job.get("visit_id"),
                      # The date the month made this visit due, carried onto the
                      # stop so a later pass can tell how far it has been moved.
                      # Nothing here reads it; it changes no placement.
                      "target": job.get("target"),
                      "compromise": harm})
    return True


class _NoDay:
    """Stands in for a day an engineer does not work, so the reason-finder can
    ask about it without a special case."""
    zone = None
    group = None
    areas = ()


_NO = _NoDay()


def _why(branch, job, owner, dates, days, people, s, nth=0):
    """Rule 6: WHY, as a code the office's screen can group and act on.

    Checked in the order the office would check it, so the first thing that is
    actually wrong is what comes back. Each code has a different fix, which is
    the whole reason they are told apart:

      no_engineer       nobody may work that patch on that shift
      window_too_short  the door is open for less time than the visit takes
      nobody_working    the whole team is off that day
      not_reached       somebody had the hours, but his round was elsewhere
      day_full          everybody who could go had run out of hours
    """
    wd_open = [d for d in dates if branch.opens_on(d.weekday())]
    dur = branch.job_minutes(s["slot_minutes"])
    eligible_ids = [p.id for p in people.values()
                    if p.works_shift(branch.shift) and branch.area_id in p.areas and p.days]
    eligible = [p for p in people.values() if p.id in eligible_ids]
    # Date the row where the story is. A week with one day nobody is working,
    # or one day whose door is only open for an hour, is a week whose failure
    # belongs on THAT day — saying "Saturday" because Saturday came first
    # tells the office nothing it can act on.
    # A rest day is not a failure — it is in the warnings — so a row is never
    # dated on one. Only days the company normally works can carry the story.
    normal = {wd for p in people.values() for wd in p.days}
    wd_open = [d for d in wd_open if d.weekday() in normal] or wd_open
    hard = [d for d in wd_open
            if not any(days.get((pid, d)) for pid in eligible_ids)
            or (lambda w: w[1] - w[0] < dur)(branch.window_on(d.weekday()))]
    when = ((hard[nth % len(hard)] if hard else wd_open[nth % len(wd_open)])
            if wd_open else (dates[0] if dates else None))
    code = "day_full"
    # A BRANCH WHOSE OWNER IS THE ONLY MAN WHO COULD GO belongs to him, so the
    # answer is about HIM — being sent to look at the area is the wrong end of
    # the problem entirely.
    #
    # But once every branch in the book has an owner, saying "his day would not
    # hold it" about ALL of them hides the real constraint: cover was tried too,
    # and if the men who could have covered were in other zones that day, THAT
    # is what the office has to act on. So this answer is only given when
    # nobody else was eligible in the first place.
    #
    # AND ONLY WHEN HE COULD ACTUALLY HAVE GONE. A branch may name an engineer
    # who is not permitted in its patch at all — the office's AMS Factory names
    # a day man who has never been allowed in area 67 — and blaming his hours
    # then sends somebody to look at a diary when the answer is a permission.
    # If the named man is not PERMITTED there, he is not the story: the checks
    # below are, and they say `no_engineer` (2026-08-27).
    #
    # PERMISSION, NOT AVAILABILITY, is the test — and permission to the PATCH
    # specifically. A man who may work the patch but has no days on the board
    # IS the answer: that is `agent_off`, and it is exactly what the office
    # needs to see. (His shift is deliberately not asked about here. A man with
    # no hours typed has no shift at all, and he is still the right answer.)
    if (branch.owner_fixed and owner is not None and len(eligible) <= 1
            and branch.area_id in owner.areas):
        his = [d for d in (wd_open or dates) if days.get((owner.id, d))]
        return {"date": (when.isoformat() if when else None),
                "site_id": branch.id, "site_name": branch.name, "name": branch.name,
                "client_en": branch.client_en, "client_ar": branch.client_ar,
                "area_id": branch.area_id, "minutes": dur,
                "owner_id": branch.owner_id, "owner_name": owner.name,
                "reason": "agent_busy" if his else "agent_off"}
    look = [when] if when in wd_open else (wd_open or dates)
    if not eligible:
        code = "no_engineer"
    elif when is not None and when in wd_open and (
            lambda w: w[1] - w[0] < dur)(branch.window_on(when.weekday())):
        code = "window_too_short"
    elif not any(days.get((p.id, d)) for p in eligible for d in look):
        code = "nobody_working"
    else:
        # Did anybody who could have taken it have a day in the wrong zone?
        # That is a different sentence from "there were no hours left".
        elsewhere = any((days.get((p.id, d)) or _NO).zone not in (None, branch.zone_id)
                        for p in eligible for d in look) and branch.zone_id is not None
        if elsewhere:
            code = "not_reached"
    return {"date": when.isoformat() if when else None,
            "site_id": branch.id, "site_name": branch.name, "name": branch.name,
            "client_en": branch.client_en, "client_ar": branch.client_ar,
            "area_id": branch.area_id, "minutes": dur,
            "owner_id": branch.owner_id,
            "owner_name": owner.name if owner else None,
            "reason": code}


# ------------------------------------------------------------------ the answer
# --------------------------------------------------------- rule 5, part two
# PHASE 4B — A THIN DAY IS NOT A ROUND.
#
# The office audited a September plan and found 848 visits spread over 298
# engineer-days — 2.8 calls a day where the median shift could hold six — with
# 162 of those days carrying one or two calls and ten hours idle, and 108 of
# them carrying a single call.
#
# THE CAUSE IS NOT A BUG, AND IT IS NOT A MISSING RULE: it is that the planner
# has no first-visit decision at all. Which visit lands on a day first is
# whichever the job order happened to reach first, and day density is the LAST
# term in the placement score — below the due date, which means a visit will
# open a brand-new day in a patch rather than join a round already going there
# one day later. Phase 4A pulls neighbours together only inside a branch's own
# band and only for the SAME patch, so two branches a street apart in different
# patches still keep a solo day each.
#
# The answer the office chose is a MOVE-ONLY pass that runs after everything
# else has been placed:
#
#   · it can never create or delete an owed visit, because the only thing it
#     can do is move one that is already in the plan. Demand generation,
#     ownership, Phases 1, 2, 3 and 4A are untouched and run first, exactly as
#     they did;
#   · it dissolves a thin day ENTIRELY or leaves it exactly as it was — a
#     half-emptied day is still a day, so a move that does not remove one is
#     not worth making;
#   · TWO STAGES, in the office's own order: another day of HIS OWN first, and
#     only if his own week cannot do it, an eligible engineer takes it as
#     COVER. Ownership never changes — the visit carries `cover_for` and the
#     branch stays his;
#   · it gets NO MORE ROPE THAN CLUSTERING: a visit may not be moved further
#     from its due date than Phase 4A's own band allows, and a branch's closest
#     two visits may never end up closer together than they already were;
#   · and nothing hard bends. His hours, the branch's window, the length of the
#     visit, who may work that patch, the travel ceiling and one man in one
#     place at one time are all enforced by the same `try_insert` / `accepts`
#     the placement passes use, with no rescue allowance — the compaction is a
#     tidy-up, and a tidy-up that has to bend a rule is not tidy.
#
# `auto_compact = 0` switches it off and restores the previous plan exactly.


def _reseat(day, stops):
    """Re-time a day from this list of stops, or say it can no longer be driven.

    `Day.commit` is how a visit goes ON to a day; this is the other direction —
    what the day looks like once something has been taken OFF it, and the only
    way to put one back when a move has to be undone."""
    if not stops:
        day.stops = []
        day.areas = list(day.held)
        day.cursor = day.start
        day.at = None
        if not day.held:
            day.zone = None
        return True
    order = [(st["branch"], st["dur"], st["win"]) for st in stops]
    if not day._areas_ok(order):
        return False
    timed = day._sequence(order)
    if timed is None:
        return False
    for st, (start, gap) in zip(stops, timed):
        st["start"], st["travel"] = start, gap
    day.stops = list(stops)
    day.cursor = timed[-1][0] + order[-1][1]
    day.areas = list(day.held)
    for st in day.stops:
        if not day.areas or day.areas[-1] != st["branch"].area_id:
            day.areas.append(st["branch"].area_id)
    day.at = day.stops[-1]["branch"].geo
    if day.stops[-1]["branch"].zone_id is not None:
        day.zone = day.stops[-1]["branch"].zone_id
    return True


def _settle_after(day, days):
    """A round that ends after midnight holds the morning after (Day._opens_at),
    so a day whose end has MOVED forces every following day that already has
    work to be timed again — and if one of them no longer fits, the move that
    caused it is not allowed. The placement passes never had to think about
    this because they only ever add to the end of the plan they have built;
    this one reaches back into days that are already drawn."""
    cur = day
    for _ in range(7):
        nxt = days.get((cur.person.id, cur.date + _dt.timedelta(days=1)))
        if nxt is None or not nxt.stops:
            return True
        if not _reseat(nxt, list(nxt.stops)):
            return False
        cur = nxt
    return True


def _band_of(branch, job, s):
    """How far Phase 4A would let this visit be nudged from its due date. The
    compaction is a route preference like any other and gets no more rope than
    clustering does — including none at all for a branch on eight visits a
    month, whose treatments the month has already spaced as tightly as it can.

    A visit with no due date of its own (a weekly rhythm) may not change date
    here at all; its week is its promise, and only its ENGINEER may change."""
    target = job.get("target")
    if target is None:
        return None, 0
    cl = int(s.get("cluster_days", 0))
    if branch.vpm:
        interval = days_in_month(target.year, target.month) / float(branch.vpm)
        cl = min(cl, max(0, int(interval // 2) - 1))
    return target, max(0, cl)


def _spacing_ok(seats, was_gap, branch, from_date, to_date):
    """A day saved is not worth two treatments back to back. Measured against
    the plan as it stood BEFORE any compaction, so a branch cannot be walked
    tighter one move at a time."""
    ds = list(seats.get(branch.id, []))
    if from_date in ds:
        ds.remove(from_date)
    ds.append(to_date)
    ds.sort()
    if len(ds) < 2:
        return True
    gap = min((y - x).days for x, y in zip(ds, ds[1:]))
    was = was_gap.get(branch.id)
    return was is None or gap >= was


def _best_seat(st, key, days, s, seats, was_gap, allow_cover, held=None):
    """The day this visit should move to, or nothing. Same patch first — that
    is what makes a round a round — then his own hands over another man's, then
    the owner's over a stranger's, then the day it costs the least to add to
    and the fullest such day."""
    b = st["branch"]
    target, band = _band_of(b, st["job"], s)
    best = None
    for hkey in sorted(days):
        if hkey == key:
            continue
        host = days[hkey]
        # NEVER OPEN A NEW DAY. Moving a call from one empty morning to another
        # is not density, it is churn.
        if not host.stops:
            continue
        if not allow_cover and hkey[0] != key[0]:
            continue
        date = hkey[1]
        if target is None:
            if date != key[1]:
                continue
        elif abs((date - target).days) > band:
            continue
        wd = date.weekday()
        person = host.person
        if not b.opens_on(wd) or not person.may_work(b.area_id, wd):
            continue
        # THE REST DAY IS NOT A ROUND TO BE FILLED. A man with Friday hours
        # typed does work Fridays, and a branch that opens on nothing else must
        # still be served — but a branch with six other days to choose from is
        # never dragged onto the seventh to tidy a round.
        if wd == int(s.get("rest_day", 4)) and any(
                b.opens_on(w) for w in range(7) if w != wd):
            continue
        if b.area_id not in person.areas:
            continue
        # Rule 3: a man who is not the owner may only cover on his own shift.
        if hkey[0] != b.owner_id and not person.works_shift(b.shift):
            continue
        named = b.day_agent.get(wd)
        if named and named != person.id:
            continue
        if host.has_branch(b.id):
            continue
        # ONE BRANCH, ONE DAY, ONE MAN — the same wall the placing passes hold
        # (see `_claim`). Tidying a round is never worth two vans at one door,
        # and moving a call onto ANOTHER engineer's day is exactly how a
        # compaction could put them there: `has_branch` above only ever asks
        # about the host's own day.
        if held is not None:
            who = held.get((date, b.id))
            if who is not None and who != hkey[0]:
                continue
        if not host.accepts(b) or not host.accepts_area(b.area_id):
            continue
        if not _spacing_ok(seats, was_gap, b, key[1], date):
            continue
        win = b.window_on(wd)
        if win is None:
            continue
        spot = host.try_insert(b, st["dur"], win)
        if spot is None:
            continue
        rank = (0 if b.area_id in host.areas else
                1 if (host.zone == b.zone_id or host.group == b.group) else 2,
                0 if hkey[0] == key[0] else 1,
                0 if hkey[0] == b.owner_id else 1,
                spot[0], -len(host.stops), hkey[1], hkey[0])
        if best is None or rank < best[0]:
            best = (rank, hkey, spot)
    return (best[1], best[2]) if best else (None, None)


def _dissolve(key, days, s, seats, was_gap, people, allow_cover):
    """Try to take EVERY visit off this day. All of them or none: a day that
    keeps one call is still a day, and the man is still driving to it."""
    donor = days[key]
    original = list(donor.stops)
    snapshots = []
    if not _reseat(donor, []):
        return 0
    # WHO IS AT EACH DOOR ALREADY, everybody's day at once — minus this one,
    # which is being emptied and is therefore giving its calls away rather
    # than holding them.
    held = {}
    for hkey2, hday in days.items():
        if hkey2 == key:
            continue
        for st2 in hday.stops:
            held[(hkey2[1], st2["branch"].id)] = hkey2[0]
        for sid2 in hday.booked:
            held[(hkey2[1], sid2)] = hkey2[0]
    ok = True
    for st in original:
        hkey, spot = _best_seat(st, key, days, s, seats, was_gap, allow_cover, held)
        if hkey is None:
            ok = False
            break
        host = days[hkey]
        snapshots.append((hkey, list(host.stops)))
        job = dict(st["job"])
        # OWNERSHIP DOES NOT MOVE WITH THE VISIT. Whoever drives it, the branch
        # is still his owner's, and the screen says who is standing in.
        owner = people.get(job.get("owner_id"))
        job["cover_for"] = (owner.name if owner and owner.id != hkey[0] else None)
        host.commit(spot, job)
        if not _settle_after(host, days):
            ok = False
            break
        if key[1] in seats.get(st["branch"].id, []):
            seats[st["branch"].id].remove(key[1])
        seats.setdefault(st["branch"].id, []).append(hkey[1])
        held[(hkey[1], st["branch"].id)] = hkey[0]
    if ok:
        return len(original)
    # UNDO, in reverse, and re-time whatever the undone move had shifted.
    for hkey, before in reversed(snapshots):
        host = days[hkey]
        moved_ids = [x["branch"].id for x in host.stops]
        _reseat(host, before)
        _settle_after(host, days)
        for sid in moved_ids:
            if sid in seats and hkey[1] in seats[sid] and sid not in [
                    x["branch"].id for x in before]:
                seats[sid].remove(hkey[1])
                seats[sid].append(key[1])
    _reseat(donor, original)
    _settle_after(donor, days)
    return 0


def _compact(days, book, s):
    """PHASE 4B, the whole of it. Returns (visits moved, days dissolved)."""
    cap = int(s.get("compact", 0))
    if cap <= 0:
        return 0, 0
    people = book["people"]
    seats = {}
    for (_agent_id, date), day in days.items():
        for st in day.stops:
            seats.setdefault(st["branch"].id, []).append(date)
    was_gap = {}
    for sid, when in seats.items():
        ds = sorted(when)
        was_gap[sid] = (min((y - x).days for x, y in zip(ds, ds[1:]))
                        if len(ds) > 1 else None)
    # The thinnest days first — a day carrying one call is the one worth
    # dissolving, and emptying it may be what makes the next one possible.
    order = sorted((k for k, d in days.items() if d.stops),
                   key=lambda k: (len(days[k].stops), k[1], k[0]))
    moved = dissolved = 0
    for key in order:
        donor = days[key]
        # A day holding time already promised to a customer cannot be given
        # back to him, so emptying the rest of it saves nobody a journey.
        if donor.held or not donor.stops or len(donor.stops) > cap:
            continue
        if any(st["job"].get("visit_id") or st["job"].get("at") is not None
               for st in donor.stops):
            continue
        for allow_cover in (False, True):
            n = _dissolve(key, days, s, seats, was_gap, people, allow_cover)
            if n:
                moved += n
                dissolved += 1
                break
    return moved, dissolved


def _ease(days, s):
    """THE WINDOW IS AVAILABILITY, NOT URGENCY.

    Once the day is DECIDED the hurry is over. A round packed nose to tail into
    the first two hours of a nine-hour day is not a promise anybody can keep —
    and the customer whose door is open all afternoon was never asking to be
    first. The slack in the day is shared out between the stops, up to an hour
    and a half a stop, breaking nobody's window and moving nobody's promised
    hour. A night round is left exactly as it is: the hours it can use are the
    hours the kitchens are shut.
    """
    for day in days.values():
        if len(day.stops) < 1 or day.end > DAY:
            continue
        last = day.stops[-1]
        slack = min(day.end, last["win"][1]) - (last["start"] + last["dur"])
        if slack <= 0:
            continue
        share = min(EASE_GAP_MAX, slack // len(day.stops))
        if share <= 0:
            continue
        # How far each stop could move on its own: its own window and his hours.
        # An hour already promised to a customer cannot move at all.
        room = []
        for st in day.stops:
            if st["job"].get("at") is not None:
                room.append(0)
            else:
                # ...and never past the hour a post takes him away.
                room.append(max(0, min(day._cap_for(st["start"]), st["win"][1])
                                - (st["start"] + st["dur"])))
        # A STOP CAN NEVER MOVE FURTHER THAN THE ONE AFTER IT. Otherwise easing
        # eats the very gap it exists to protect: push the ten o'clock call to
        # eleven while the eleven o'clock cannot move, and the journey between
        # them has nowhere to happen.
        for i in range(len(room) - 2, -1, -1):
            room[i] = min(room[i], room[i + 1])
        for i, st in enumerate(day.stops):
            moved = st["start"] + min(room[i], share * (i + 1))
            # BREATHING ROOM MUST NOT BECOME A START IN HIS BREAK. Easing only
            # ever moves a stop LATER, so if the new time lands in a gap the
            # stop simply keeps the legal hour it already had.
            if (day._first_start(moved) == moved
                    and moved + st["dur"] <= day._cap_for(moved)):
                st["start"] = moved
        day.cursor = day.stops[-1]["start"] + day.stops[-1]["dur"]


def _carry_midnight(days):
    """A round that ends after midnight holds the morning after.

    The man who finished a kitchen at two is not opening a warehouse at seven,
    and a plan that says he is has to be unpicked by hand."""
    for (agent_id, date), day in days.items():
        if not day.stops:
            continue
        ends = day.stops[-1]["start"] + day.stops[-1]["dur"]
        if ends <= DAY:
            continue
        nxt = days.get((agent_id, date + _dt.timedelta(days=1)))
        if nxt is not None and not nxt.stops:
            nxt.start = max(nxt.start, ends - DAY)
            nxt.cursor = max(nxt.cursor, nxt.start)


def _capped(book, worked_weekdays, s, d0=None, d1=None):
    """RULE 6, BEFORE THE PLAN IS EVEN DRAWN: what the book asks for that
    cannot be delivered by arithmetic, whoever is free.

    Two shapes, both of them the office's to fix and nobody else's:

      · A DOOR OPEN FOR LESS TIME THAN THE VISIT TAKES. Nothing can ever be
        booked into it. Counted across midnight — 23:50 to 00:10 is twenty
        minutes, not minus twenty-three hours.

      · MORE VISITS THAN THE BRANCH OPENS FOR. A branch takes at most ONE visit
        a day, so a place open two days a week can take eight or nine in a
        month — counted on the CALENDAR month being planned, not on a nominal
        four weeks, because February and October do not offer the same number
        of Tuesdays.
    """
    worked = set(worked_weekdays)
    # THE SAME ANSWER RULE 4 DEALS BY. Asking "does anybody in the company work
    # that day" instead of "can THIS branch's own people work it" is what let
    # visits fall between the two rules and out of the arithmetic entirely.
    reach = _reach_map(book, worked)
    ref = d0 or _dt.date.today()
    ndays = days_in_month(ref.year, ref.month)
    first = _dt.date(ref.year, ref.month, 1)
    out = []
    for b in book["branches"].values():
        job = b.job_minutes(s["slot_minutes"])
        wins = [b.win] + [w for w in b.open_days.values() if w]
        shortest = min((t - f) for f, t in wins)
        if shortest < job:
            f, t = min(wins, key=lambda w: w[1] - w[0])
            out.append({"site_id": b.id, "site_name": b.name, "reason": "window",
                        "asked": b.vpm, "possible": 0, "needs_days": 0,
                        "window_minutes": t - f, "needs_minutes": job,
                        "month_days": ndays,
                        "overnight": 1 if t > DAY else 0})
            continue
        # How many days of THIS month the branch actually opens AND ITS OWN
        # PEOPLE work — that is the ceiling on a month's visits, one a day.
        can = reach(b)
        open_in_month = 0
        for i in range(ndays):
            day = first + _dt.timedelta(days=i)
            if b.opens_on(day.weekday()) and day.weekday() in can:
                open_in_month += 1
        if b.freq_unit == "week":
            needs = max(week_quota(b.vpm, i, offset=b.id % WEEKS_PER_MONTH)
                        for i in range(WEEKS_PER_MONTH))
            possible = len({d for d in range(7)
                            if (not b.open_days or d in b.open_days) and d in can})
            flag = needs > possible
        else:
            needs = int(round(b.vpm))          # the month's contracted number
            possible = open_in_month
            flag = needs > possible
        if flag:
            out.append({"site_id": b.id, "site_name": b.name, "reason": "days",
                        "asked": b.vpm, "possible": possible, "needs_days": needs,
                        "window_minutes": shortest, "needs_minutes": job,
                        "month_days": ndays,
                        "overnight": 1 if b.win[1] > DAY else 0})
    return out


def _render(days, book, owners_set, unplaced, s, frm, to, capped, compacted=(0, 0)):
    """The plan in the shape the screen and the apply path already read."""
    areas, zones = book["areas"], book["zones"]
    out_days = {}
    total = travel_total = 0
    # WHAT THE PLAN HAD TO BEND, and for which customer. A rescued visit is a
    # visit that would otherwise have been lost, so it is good news — but it is
    # a longer day for somebody, and the office decides whether it is worth it.
    compromises = []
    for (agent_id, date), day in sorted(days.items(), key=lambda kv: (kv[0][1], kv[0][0])):
        if not day.stops:
            continue
        visits = []
        for st in day.stops:
            b = st["branch"]
            start, s_day = hhmm(st["start"])
            end, e_day = hhmm(st["start"] + st["dur"])
            visits.append({
                "site_id": b.id, "client_id": b.client_id, "site_name": b.name,
                "client_en": b.client_en, "client_ar": b.client_ar,
                "visit_id": st["job"].get("visit_id"),
                "minutes": st["dur"], "travel": st["travel"],
                "start": start, "end": end, "start_day": s_day, "end_day": e_day,
                "overdue": 0,
                # Rule 2 and 3, on the face of the plan: whose branch it is, and
                # who is standing in for him today.
                "owner_id": st["job"].get("owner_id"),
                "cover_for": st["job"].get("cover_for"),
                "compromise": st["job"].get("compromise"),
            })
            total += 1
            travel_total += st["travel"]
            if st["job"].get("compromise"):
                compromises.append({
                    "date": date.isoformat(), "agent_id": agent_id,
                    "agent_name": day.person.name, "site_id": b.id,
                    "site_name": b.name, "client_en": b.client_en,
                    "client_ar": b.client_ar, "area_id": b.area_id,
                    "kind": st["job"]["compromise"]})
        row = {"agent_id": agent_id, "agent_name": day.person.name,
               "areas": [{"id": a, "name_en": (areas.get(a) or {}).get("name_en"),
                          "name_ar": (areas.get(a) or {}).get("name_ar")}
                         for a in day.areas],
               "zone": ({"id": day.zone,
                         "name_en": (zones.get(day.zone) or {}).get("name_en"),
                         "name_ar": (zones.get(day.zone) or {}).get("name_ar")}
                        if day.zone else None),
               "visits": visits}
        out_days.setdefault(date.isoformat(), []).append(row)
    days_out = [{"date": d, "assignments": rows} for d, rows in sorted(out_days.items())]
    # One line per date for the screen's own summary: how much of that day the
    # plan could not place. The rows below say which branches and why.
    per_date = {}
    for u in unplaced:
        if u.get("date"):
            per_date[u["date"]] = per_date.get(u["date"], 0) + 1
    problems = [{"date": d, "unplaced": n} for d, n in sorted(per_date.items())]
    return {
        "from": frm, "to": to, "days": days_out, "unplaced": unplaced,
        "problems": problems, "capped": capped, "compromises": compromises,
        "travel_minutes": travel_total,
        "owners_assigned": owners_set,
        "summary": {"days": len(days_out), "visits": total,
                    # What the contracts owed inside this window — booked plus
                    # unplaced — so nobody has to work it out from the calendar.
                    "owed": total + len(unplaced),
                    "travel_minutes": travel_total,
                    "engineers": len({r["agent_id"] for d in days_out
                                      for r in d["assignments"]}),
                    "unplaced": len(unplaced),
                    # How many of those visits only fit because a route
                    # preference gave way — 0 on a book that fits.
                    "compromises": len(compromises),
                    # PHASE 4B: how many visits the compaction moved, and how
                    # many thin days that emptied altogether.
                    "compacted": compacted[0],
                    "days_dissolved": compacted[1],
                    "owners_assigned": len(owners_set),
                    "slot_minutes": s["slot_minutes"]},
    }
