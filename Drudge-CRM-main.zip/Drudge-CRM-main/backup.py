#!/usr/bin/env python3
"""Online backup of the CRM: a full database snapshot, and uploads incrementally.

The database is small and irreplaceable, so it is snapshotted WHOLE every night
through SQLite's online backup API — a consistent copy even while the server is
running under WAL. That safety is not traded away for space.

The uploads folder is the opposite: a hundred megabytes of photos, signatures
and site maps that only ever grow, of which a normal day adds two or three. So
uploads are stored as ONE full base archive plus a small nightly archive of just
what changed since the last run:

    uploads-g<gen>-base.tar.gz              the full tree, once per generation
    uploads-g<gen>-inc-<stamp>.tar.gz       only files added or changed since
    uploads-g<gen>-manifest-<stamp>.tsv.gz  the complete file list at that run

The manifest is what makes this exact rather than approximate: it records every
file with its size and SHA-256 at the moment of the backup, so a restore knows
not only what to add but what to REMOVE — a file deleted since the base is
deleted on the way back too. `restore.py` walks base + increments + manifest and
rebuilds the tree byte for byte.

A fresh base is rolled when the current one gets old (--base-age, default 30
days) or when its increments have grown past it — whichever comes first — so the
chain a restore has to replay stays short. The previous generation is kept whole
until the new base has been written, then pruned to its base alone: still a
complete, standalone restore point, just an older one.

Usage:
    python3 backup.py                      # database only, keep last 14
    python3 backup.py --uploads            # + incremental uploads (nightly)
    python3 backup.py --uploads --full-uploads   # force a new base now
    python3 backup.py --keep 30            # keep the last 30 db snapshots
    python3 backup.py --base-age 14        # roll the uploads base fortnightly
    python3 backup.py --dest /mnt/bk       # write backups elsewhere

Honors PESTCRM_DATA_DIR (same as the server) to locate crm.db.

Schedule it nightly with the bundled systemd timer (deploy/pestcrm-backup.*),
or from cron, e.g. at 02:30:
    30 2 * * *  cd /path/to/pest-crm && /usr/bin/python3 backup.py --uploads >> data/backup.log 2>&1
"""
import os
import re
import sys
import glob
import gzip
import time
import hashlib
import tarfile
import sqlite3

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATA_DIR = os.environ.get("PESTCRM_DATA_DIR", os.path.join(BASE_DIR, "data"))
DB_PATH = os.path.join(DATA_DIR, "crm.db")
UPLOAD_DIR = os.path.join(BASE_DIR, "uploads")
DEFAULT_DEST = os.path.join(DATA_DIR, "backups")
DEFAULT_KEEP = 14
DEFAULT_BASE_AGE_DAYS = 30
# Generations to keep. 1 = only the live chain; 2 = also the previous base, as a
# standalone fallback in case the current base is ever found corrupt.
DEFAULT_GENERATIONS = 2

GEN_RE = re.compile(r"^uploads-g(\d{8}-\d{6})-")


def _unique_stamp(dest):
    """A stamp no earlier run has already used.

    Two backups inside the same second must not land on the same filename: the
    second would overwrite the first's increment while the manifest still
    described the files it held, leaving a chain that cannot be replayed. The
    stamp stays exactly %Y%m%d-%H%M%S — every name in here is compared and
    sorted as text, so a same-width stamp is the only kind that keeps a
    generation's archives in the order they must be replayed. A collision
    borrows the next free second instead.
    """
    t = time.time()
    try:
        taken = os.listdir(dest)
    except OSError:
        taken = []
    while True:
        stamp = time.strftime('%Y%m%d-%H%M%S', time.localtime(t))
        if not any(stamp in f for f in taken):
            return stamp
        t += 1


def _prune(dest, pattern, keep):
    """Keep only the most recent `keep` files matching pattern (0 = keep all)."""
    if not keep or keep <= 0:
        return
    for old in sorted(glob.glob(os.path.join(dest, pattern)))[:-keep]:
        os.remove(old)
        print(f"Pruned old backup: {os.path.basename(old)}")


# ---------------------------------------------------------------- uploads ----

def _scan(root):
    """Every file under root as {relpath: (size, sha256)}. Content, not mtime:
    a touched file is not a changed file, and a rewritten one always is."""
    out = {}
    for dirpath, _dirs, names in os.walk(root):
        for n in names:
            full = os.path.join(dirpath, n)
            if not os.path.isfile(full) or os.path.islink(full):
                continue
            rel = os.path.relpath(full, root)
            h = hashlib.sha256()
            try:
                with open(full, "rb") as fh:
                    for chunk in iter(lambda: fh.read(1 << 20), b""):
                        h.update(chunk)
                out[rel] = (os.path.getsize(full), h.hexdigest())
            except OSError as e:                 # a file vanishing mid-backup
                print(f"  skipped {rel}: {e}")
    return out


def _write_manifest(path, entries):
    with gzip.open(path, "wt", encoding="utf-8", newline="\n") as fh:
        fh.write("# relpath\tsize\tsha256\n")
        for rel in sorted(entries):
            size, sha = entries[rel]
            fh.write(f"{rel}\t{size}\t{sha}\n")


def read_manifest(path):
    """{relpath: (size, sha256)} from a manifest written by _write_manifest."""
    out = {}
    with gzip.open(path, "rt", encoding="utf-8") as fh:
        for line in fh:
            if line.startswith("#") or not line.strip():
                continue
            rel, size, sha = line.rstrip("\n").split("\t")
            out[rel] = (int(size), sha)
    return out


def generations(dest):
    """Generation stamps present in dest, oldest first."""
    gens = set()
    for f in os.listdir(dest):
        m = GEN_RE.match(f)
        if m:
            gens.add(m.group(1))
    return sorted(gens)


def manifests(dest, gen):
    """This generation's manifests, oldest first."""
    return sorted(glob.glob(os.path.join(dest, f"uploads-g{gen}-manifest-*.tsv.gz")))


def _gen_bytes(dest, gen, kind):
    return sum(os.path.getsize(f)
               for f in glob.glob(os.path.join(dest, f"uploads-g{gen}-{kind}*.tar.gz")))


def _tar(out, root, rels):
    with tarfile.open(out, "w:gz") as tf:
        for rel in sorted(rels):
            tf.add(os.path.join(root, rel), arcname=os.path.join("uploads", rel))
    return os.path.getsize(out)


def _needs_new_base(dest, gen, base_age_days):
    """A base is rolled when it is old, or when replaying it has got expensive."""
    base = os.path.join(dest, f"uploads-g{gen}-base.tar.gz")
    if not os.path.exists(base):
        return True, "no base archive"
    age_d = (time.time() - os.path.getmtime(base)) / 86400.0
    if base_age_days and age_d >= base_age_days:
        return True, f"base is {age_d:.0f} days old"
    if _gen_bytes(dest, gen, "inc-") > os.path.getsize(base):
        return True, "increments have outgrown the base"
    return False, ""


def _prune_generations(dest, keep):
    """Keep the newest `keep` generations whole, and drop anything older.

    A generation is only restorable as base + all of its increments, so they
    live and die together. Keeping two means every day of roughly the last two
    base cycles can still be reconstructed, and a base found corrupt is not the
    end of the line.
    """
    if not keep or keep <= 0:
        return
    for gen in generations(dest)[:-keep]:
        for f in sorted(glob.glob(os.path.join(dest, f"uploads-g{gen}-*"))):
            os.remove(f)
            print(f"Pruned old generation: {os.path.basename(f)}")


def backup_uploads(dest, stamp, force_full=False,
                   base_age_days=DEFAULT_BASE_AGE_DAYS,
                   keep_generations=DEFAULT_GENERATIONS):
    """Archive uploads as a base, or as an increment against the last manifest."""
    if not os.path.isdir(UPLOAD_DIR):
        print("No uploads directory — nothing to archive")
        return
    now = _scan(UPLOAD_DIR)
    total_mb = sum(s for s, _ in now.values()) / 1048576

    gens = generations(dest)
    gen = gens[-1] if gens else None
    full, why = (True, "forced") if force_full else (
        (True, "no generation yet") if gen is None
        else _needs_new_base(dest, gen, base_age_days))

    if full:
        gen = stamp
        out = os.path.join(dest, f"uploads-g{gen}-base.tar.gz")
        size = _tar(out, UPLOAD_DIR, now.keys())
        print(f"Uploads BASE written ({why}): {os.path.basename(out)} "
              f"({size / 1048576:.1f} MB, {len(now)} files, {total_mb:.1f} MB on disk)")
    else:
        prev = read_manifest(manifests(dest, gen)[-1])
        changed = [r for r, v in now.items() if prev.get(r) != v]
        gone = sorted(set(prev) - set(now))
        out = os.path.join(dest, f"uploads-g{gen}-inc-{stamp}.tar.gz")
        size = _tar(out, UPLOAD_DIR, changed)
        print(f"Uploads increment: {os.path.basename(out)} ({size / 1024:.0f} KB, "
              f"{len(changed)} changed, {len(gone)} deleted, {len(now)} files total)")

    _write_manifest(os.path.join(dest, f"uploads-g{gen}-manifest-{stamp}.tsv.gz"), now)
    _prune_generations(dest, keep_generations)

    held = sum(os.path.getsize(f) for f in glob.glob(os.path.join(dest, "uploads-g*")))
    print(f"Uploads history now holds {held / 1048576:.1f} MB "
          f"across {len(generations(dest))} generation(s)")


# --------------------------------------------------------------------- run ---

def run(dest=DEFAULT_DEST, keep=DEFAULT_KEEP, uploads=False, full_uploads=False,
        base_age_days=DEFAULT_BASE_AGE_DAYS, keep_generations=DEFAULT_GENERATIONS):
    if not os.path.exists(DB_PATH):
        print(f"No database at {DB_PATH}", file=sys.stderr)
        return 1
    os.makedirs(dest, exist_ok=True)
    stamp = _unique_stamp(dest)

    # The database is always taken WHOLE. It is the one thing that cannot be
    # rebuilt from anything else, and at ~3 MB a night it is not what costs.
    out = os.path.join(dest, f"crm-{stamp}.db")
    src = sqlite3.connect(DB_PATH)
    dst = sqlite3.connect(out)
    try:
        with dst:
            src.backup(dst)              # consistent online snapshot
    finally:
        dst.close()
        src.close()
    print(f"Backup written: {out} ({os.path.getsize(out) / 1024:.0f} KB)")
    _prune(dest, "crm-2*.db", keep)

    # Uploaded files (photos, signatures, site maps, logo) live outside the DB,
    # so a DB-only backup would lose them.
    if uploads:
        backup_uploads(dest, stamp, force_full=full_uploads,
                       base_age_days=base_age_days,
                       keep_generations=keep_generations)

    return 0


def _parse_args(argv):
    opts = dict(dest=DEFAULT_DEST, keep=DEFAULT_KEEP, uploads=False,
                full_uploads=False, base_age_days=DEFAULT_BASE_AGE_DAYS,
                keep_generations=DEFAULT_GENERATIONS)
    i = 0
    while i < len(argv):
        if argv[i] == "--keep" and i + 1 < len(argv):
            opts["keep"] = int(argv[i + 1]); i += 2
        elif argv[i] == "--dest" and i + 1 < len(argv):
            opts["dest"] = argv[i + 1]; i += 2
        elif argv[i] == "--base-age" and i + 1 < len(argv):
            opts["base_age_days"] = float(argv[i + 1]); i += 2
        elif argv[i] == "--keep-generations" and i + 1 < len(argv):
            opts["keep_generations"] = int(argv[i + 1]); i += 2
        elif argv[i] == "--uploads":
            opts["uploads"] = True; i += 1
        elif argv[i] == "--full-uploads":
            opts["uploads"] = True; opts["full_uploads"] = True; i += 1
        else:
            print(__doc__); sys.exit(2)
    return opts


if __name__ == "__main__":
    sys.exit(run(**_parse_args(sys.argv[1:])))
