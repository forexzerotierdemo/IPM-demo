// Thin fetch wrapper that injects the auth token and parses JSON.
// Reads fall back to the offline read cache (store.js) whenever the network
// cannot answer; writes fall into the offline queue (offline.js).

// A CDN challenge page is not our API answering — treat it like no answer.
function _isEdgeChallenge(res) {
  if (res.status !== 403 && res.status !== 429 && res.status !== 503) return false;
  if (res.headers.get("cf-mitigated")) return true;
  return (res.headers.get("content-type") || "").indexOf("html") !== -1;
}

function _readStoredUser() {
  try { return JSON.parse(localStorage.getItem("user") || "null"); }
  catch (e) { return null; }
}
const API = {
  token: localStorage.getItem("token") || null,
  user: _readStoredUser(),

  setAuth(token, user) {
    this.token = token;
    this.user = user;
    localStorage.setItem("token", token);
    localStorage.setItem("user", JSON.stringify(user));
  },
  clearAuth() {
    this.token = null;
    this.user = null;
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    // The read cache is NOT dropped here. clearAuth also runs when a token
    // simply expires, and an agent who has been in the field past the TTL must
    // not lose the data they are working from as well as their session. Cache
    // keys carry the user id, so nobody else can read it either way; the logout
    // button clears it explicitly.
  },

  // A GET answered from the read cache tells the app how old the data is, so
  // the page can say so instead of pretending it is live.
  async _cached(path) {
    if (!window.ReadStore) return null;
    const row = await window.ReadStore.get(path);
    if (!row) return null;
    window.dispatchEvent(new CustomEvent("rs-stale", { detail: { path, ts: row.ts } }));
    return row.data;
  },

  async request(method, path, body) {
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    const opts = { method, headers };
    if (body !== undefined) {
      headers["Content-Type"] = "application/json";
      opts.body = JSON.stringify(body);
    }
    const mutating = method !== "GET";
    let res;
    try {
      res = await fetch("/api" + path, opts);
    } catch (e) {
      // Network failure: queue mutations for later sync, and serve reads from
      // the last answer this device received. A read with nothing cached says
      // so plainly rather than looking like a server error.
      if (mutating && window.OfflineQueue) {
        await window.OfflineQueue.enqueue({ kind: "json", method, path, body: body || {} });
        return { __queued: true };
      }
      if (!mutating) {
        const hit = await this._cached(path);
        if (hit !== null) return hit;
        throw new Error("offline_no_data");
      }
      throw new Error("offline");
    }
    if (res.status === 401 && this.token) {
      this.clearAuth();
      location.reload();
      return;
    }
    // The server is reachable but not answering properly (a 502 from the proxy,
    // a Cloudflare interstitial, a restart mid-request). For a read that is the
    // same situation as being offline, so fall back rather than blanking the page.
    if (!mutating && (res.status >= 500 || _isEdgeChallenge(res))) {
      const hit = await this._cached(path);
      if (hit !== null) return hit;
    }
    let data = null;
    try { data = await res.json(); } catch (e) {}
    if (!res.ok) throw new Error((data && data.error) || "Request failed");
    // Keep the answer for the next time this device has no signal.
    if (!mutating && data !== null && window.ReadStore) {
      window.ReadStore.put(path, data);
      window.dispatchEvent(new CustomEvent("rs-fresh", { detail: { path } }));
    }
    return data;
  },

  get(p) { return this.request("GET", p); },
  post(p, b) { return this.request("POST", p, b); },
  put(p, b) { return this.request("PUT", p, b); },
  del(p) { return this.request("DELETE", p); },

  async uploadPhoto(entityType, entityId, file, caption, businessPlan) {
    const fd = new FormData();
    fd.append("entity_type", entityType);
    fd.append("entity_id", entityId);
    if (caption) fd.append("caption", caption);
    if (businessPlan) fd.append("business_plan", "1");
    fd.append("file", file);
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    let res;
    try {
      res = await fetch("/api/photos", { method: "POST", headers, body: fd });
    } catch (e) {
      // Offline: queue the photo (Blob is stored in IndexedDB) for later sync.
      if (window.OfflineQueue) {
        await window.OfflineQueue.enqueue({
          kind: "photo", method: "POST", path: "/photos",
          entity_type: entityType, entity_id: entityId, caption: caption || "",
          business_plan: businessPlan ? "1" : "",
          file, filename: file.name || "photo.jpg",
        });
        return { __queued: true };
      }
      throw new Error("offline");
    }
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.error) || "Upload failed");
    return data;
  },

  // Generic multipart POST (IPM library documents). Not offline-queued: these
  // are office uploads, and a 25 MB PDF has no business sitting in IndexedDB.
  async uploadDoc(path, file, fields) {
    const fd = new FormData();
    Object.entries(fields || {}).forEach(([k, v]) => fd.append(k, v));
    fd.append("file", file);
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    const res = await fetch("/api" + path, { method: "POST", headers, body: fd });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.error) || "Upload failed");
    return data;
  },

  async uploadSiteMap(siteId, file) {
    const fd = new FormData();
    fd.append("file", file);
    const headers = {};
    if (this.token) headers["Authorization"] = "Bearer " + this.token;
    const res = await fetch(`/api/sites/${siteId}/map`, { method: "POST", headers, body: fd });
    const data = await res.json().catch(() => null);
    if (!res.ok) throw new Error((data && data.error) || "Upload failed");
    return data;
  },
};
