#!/usr/bin/env python3
"""SEPTEMBER TO DECEMBER, WITH AND WITHOUT THE REBALANCE PASS. Copy only."""
import collections, json, os, shutil, sqlite3, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [(2026, 9), (2026, 10), (2026, 11), (2026, 12)]
work = tempfile.mkdtemp(prefix="rbdry-")
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server
BASE = server._roster_settings()


def run(on):
    S = dict(BASE, rebalance=1 if on else 0)
    tot = collections.Counter()
    per_unpl = collections.Counter()
    names = {}
    rows = []
    for (Y, M) in MONTHS:
        span = roster.days_in_month(Y, M)
        p = roster.plan(db, "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span), S)
        bk = roster.load_book(db, "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span))
        owed = 0
        for sid, b in bk["branches"].items():
            names[sid] = b.name
            owed += (roster.owed_in_month(b.vpm, "week", Y, M,
                                          offset=sid % roster.WEEKS_PER_MONTH)
                     if b.freq_unit == "week" else int(round(float(b.vpm or 0))))
        tot["owed"] += owed
        tot["booked"] += p["summary"]["visits"]
        tot["unplaced"] += p["summary"]["unplaced"]
        tot["travel"] += p["summary"]["travel_minutes"]
        at = collections.defaultdict(set)
        for day in p["days"]:
            for a in day["assignments"]:
                for v in a["visits"]:
                    at[(day["date"], v["site_id"])].add(a["agent_id"])
        tot["clashes"] += sum(1 for w in at.values() if len(w) > 1)
        for u in p["unplaced"]:
            per_unpl[u["site_id"]] += 1
        rb = p.get("rebalance") or {}
        for k in ("rescued", "direct", "reorder", "swap", "moved", "route_compromises"):
            tot[k] += rb.get(k, 0)
        rows += rb.get("rows", [])
    return tot, per_unpl, names, rows


off, off_u, names, _ = run(False)
on, on_u, names2, rows = run(True)
names.update(names2)
print("=" * 74)
print("REBALANCE RESCUE — September to December, planned on a copy")
print("=" * 74)
print("%-26s %10s %10s" % ("", "pass OFF", "pass ON"))
for k in ("owed", "booked", "unplaced"):
    print("%-26s %10d %10d" % (k, off[k], on[k]))
print("%-26s %10d %10d" % ("silently missing",
                           off["owed"] - off["booked"] - off["unplaced"],
                           on["owed"] - on["booked"] - on["unplaced"]))
print("%-26s %10d %10d" % ("two vans at one door", off["clashes"], on["clashes"]))
print("%-26s %10d %10d" % ("travel minutes", off["travel"], on["travel"]))
print("\nrescued %d  (direct %d, by re-ordering a day %d, by one swap %d)"
      % (on["rescued"], on["direct"], on["reorder"], on["swap"]))
print("existing visits moved: %d     rule-5 compromises: %d     added travel: %+d min"
      % (on["moved"], on["route_compromises"], on["travel"] - off["travel"]))
print("\nper-branch unplaced, OFF -> ON:")
for sid in sorted(set(off_u) | set(on_u), key=lambda x: -off_u.get(x, 0)):
    a, b = off_u.get(sid, 0), on_u.get(sid, 0)
    print("   %-34s %3d -> %3d   %s" % (names.get(sid, sid)[:34], a, b,
                                        "" if a == b else "<<<"))
os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
json.dump({"rows": rows}, open(os.path.join(HERE, "out", "rebalance-dryrun.json"), "w"),
          indent=1, default=str)
