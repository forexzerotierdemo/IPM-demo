#!/usr/bin/env python3
"""ONE SCENARIO, ONE FRESH COPY OF THE BOOK, ONE JSON ANSWER.

    python3 scenario.py <name>      -> JSON on stdout

Each scenario runs in its own process against its own throwaway copy, so
nothing an earlier scenario did can leak into a later one. The live book is
opened READ-ONLY and never written to.

Scenarios:
  base      the book exactly as it is
  clu       + Abdullah shukry may work area 37   (Cluture House El Haram)
  A1        clu + Ahmed Ashraf may work area 67  (AMS stays SUNDAY-ONLY)
  A2        A1 + Ahmed Ashraf's Sunday runs to 18:00
  A3        clu + Mustafa Abdellah may work area 67 (AMS stays SUNDAY-ONLY)
  B1        clu + Mustafa Abdellah may work area 67 + AMS also opens Saturday
  B2        clu + Ahmed Ashraf   may work area 67 + AMS also opens Saturday
"""
import collections, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [(2026, 9), (2026, 10), (2026, 11), (2026, 12)]
AMS = 218
name = sys.argv[1]

work = tempfile.mkdtemp(prefix="scen-%s-" % name)
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

ids = {r["full_name"]: r["id"] for r in db.query("SELECT id, full_name FROM users")}


def area(who, a, weekdays=None):
    """`weekdays` narrows the permission to those days only — the table has
    carried that column all along, so a man can be let into a patch for one
    day a week without being handed it for the whole week."""
    db.execute("INSERT OR IGNORE INTO agent_areas (agent_id, area_id, weekdays) "
               "VALUES (?,?,?)", (ids[who], a, weekdays))


def sunday_to(who, end):
    db.execute("UPDATE agent_availability SET end_time=? WHERE agent_id=? AND weekday=6",
               (end, ids[who]))


def ams_also_saturday():
    db.execute("INSERT INTO site_service_days (site_id, weekday) VALUES (?,5)", (AMS,))


NARROW = name.endswith("_n")
_base = name[:-2] if NARROW else name
if name != "base" and not (_base.startswith("P") or _base.startswith("S")):
    # Cluture House El Haram opens SATURDAY only, so the narrow form of the
    # permission is Saturday only.
    area("Abdullah shukry", 37, "5" if NARROW else None)
def prefer(site, who):
    """Hand a branch to a different engineer. NO new permission — he is already
    allowed in that patch; the branch was simply pinned to somebody else."""
    db.execute("UPDATE sites SET preferred_agent_id=? WHERE id=?", (ids[who], site))


def set_hours(who, wd, f, t):
    db.execute("UPDATE agent_availability SET start_time=?, end_time=? "
               "WHERE agent_id=? AND weekday=?", (f, t, ids[who], wd))


def drop_day(who, wd):
    db.execute("DELETE FROM agent_availability WHERE agent_id=? AND weekday=?",
               (ids[who], wd))


CBC = 13                       # Exception CBC Warehouse
CLU = 147                      # Cluture House - GSK El Haram


def add_day(site, wd):
    db.execute("INSERT INTO site_service_days (site_id, weekday) VALUES (?,?)", (site, wd))


if _base == "S1":
    # the odd day out: his Monday is 11:00-19:00 while the rest of his week is
    # 06:00-16:00, which is why he can never reach a 07:00-08:30 door on a Monday
    set_hours("Mohamed Abdeelhady", 0, "06:00", "16:00")
elif _base == "S2":
    # the only man permitted in AMS's patch is a NIGHT man; give him a Sunday
    # day shift and see what it costs his night work
    set_hours("Amr Diab", 6, "14:00", "19:00")
elif _base == "S3":
    # the only day-man with FRIDAY hours typed, on the company's rest day
    drop_day("Ahmed Ashraf", 4)
elif _base == "S5":
    # BOTH shift corrections that cost nobody anything
    set_hours("Mohamed Abdeelhady", 0, "06:00", "16:00")
    set_hours("Amr Diab", 6, "14:00", "19:00")
elif _base == "S6":
    # ...and the second service day on Cluture House on top
    set_hours("Mohamed Abdeelhady", 0, "06:00", "16:00")
    set_hours("Amr Diab", 6, "14:00", "19:00")
    add_day(CLU, 3)
elif _base == "S4":
    set_hours("Mohamed Abdeelhady", 0, "06:00", "16:00")
    set_hours("Ahmed Ashraf", 6, "08:00", "18:00")
elif _base == "P5":
    add_day(CLU, 3)            # a second service day: Thursday
elif _base == "P6":
    add_day(CLU, 0)            # a second service day: Monday
elif _base == "P7":
    add_day(CBC, 3)            # give CBC the second day instead, freeing Saturday
elif _base == "P1":
    prefer(CBC, "Alaa Abdelsamad")
elif _base == "P2":
    prefer(CBC, "Abdullah shukry")
elif _base == "A1":
    area("Ahmed Ashraf", 67, "6" if NARROW else None)
elif _base == "A2":
    area("Ahmed Ashraf", 67, "6" if NARROW else None); sunday_to("Ahmed Ashraf", "18:00")
elif _base == "A3":
    area("Mustafa Abdellah", 67, "6" if NARROW else None)
elif _base == "B1":
    area("Mustafa Abdellah", 67, "5,6" if NARROW else None); ams_also_saturday()
elif _base == "B2":
    area("Ahmed Ashraf", 67, "5,6" if NARROW else None); ams_also_saturday()

S = server._roster_settings()
owed = collections.Counter()
booked = collections.Counter()
unplaced = collections.Counter()
names = {}
clashes = 0
for (Y, M) in MONTHS:
    span = roster.days_in_month(Y, M)
    p = roster.plan(db, "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span), S)
    book = roster.load_book(db, "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span))
    for sid, b in book["branches"].items():
        names[sid] = b.name
        owed[sid] += (roster.owed_in_month(b.vpm, "week", Y, M,
                                           offset=sid % roster.WEEKS_PER_MONTH)
                      if b.freq_unit == "week" else int(round(float(b.vpm or 0))))
    at = collections.defaultdict(set)
    for day in p["days"]:
        for a in day["assignments"]:
            for v in a["visits"]:
                booked[v["site_id"]] += 1
                at[(day["date"], v["site_id"])].add(a["agent_id"])
    clashes += sum(1 for w in at.values() if len(w) > 1)
    for u in p["unplaced"]:
        unplaced[u["site_id"]] += 1

print(json.dumps({
    "scenario": name,
    "owed": dict(owed), "booked": dict(booked), "unplaced": dict(unplaced),
    "names": names, "clashes": clashes,
    "tot_owed": sum(owed.values()), "tot_booked": sum(booked.values()),
    "tot_unplaced": sum(unplaced.values()),
}))
