#!/usr/bin/env python3
"""EVERY UNPLACED VISIT, PROVED — is the capacity really gone, or did the
planner just not find it?  Writes nothing, changes nothing.

    python3 capacity_audit.py [YYYY-MM ...]

"Free hours" is not usable capacity, so nothing here trusts a total. For every
unplaced row it walks EVERY engineer and EVERY day that branch opens, and tries
the visit for real with the planner's own `Day.try_insert` — the same code that
enforces his hours, the door's window, the length of the visit, the travel
ceiling and not being in two places at once.

A visit that CAN be seated that way, without breaking a hard rule and without
sending a second van to a door another man already has that day, is a PLANNER
FAILURE and is printed with the assignment that would have worked.
"""
import collections, copy, datetime as dt, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = sys.argv[1:] or ["2026-09", "2026-10", "2026-11", "2026-12"]

work = tempfile.mkdtemp(prefix="cap-")
src = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
dst = sqlite3.connect(os.path.join(work, "crm.db"))
src.backup(dst); dst.commit(); dst.close(); src.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

S = server._roster_settings()
GRAB = {}
_orig_render = roster._render


def _spy(days, book, owners_set, unplaced, s, frm, to, capped, compacted=(0, 0)):
    GRAB["days"] = days
    GRAB["book"] = book
    return _orig_render(days, book, owners_set, unplaced, s, frm, to, capped, compacted)


roster._render = _spy
WD = "Mon Tue Wed Thu Fri Sat Sun".split()
summary = {}
failures = []

for key in MONTHS:
    Y, M = int(key[:4]), int(key[5:7])
    span = roster.days_in_month(Y, M)
    d0, d1 = dt.date(Y, M, 1), dt.date(Y, M, span)
    plan = roster.plan(db, d0.isoformat(), d1.isoformat(), S)
    days, book = GRAB["days"], GRAB["book"]
    people, branches = book["people"], book["branches"]

    # ---- capacity that is genuinely left over -------------------------
    free_days = 0
    unused_min = 0
    for (aid, date), day in days.items():
        cap = day.end - day.start
        used = sum(st["dur"] + st["travel"] for st in day.stops)
        if not day.stops:
            free_days += 1
        unused_min += max(0, cap - used)

    # who is already at each door, so a proposal never makes two vans
    at_door = {}
    for (aid, date), day in days.items():
        for st in day.stops:
            at_door.setdefault((date, st["branch"].id), set()).add(aid)

    rows = []
    for u in plan["unplaced"]:
        b = branches.get(u["site_id"])
        if b is None:
            continue
        dur = b.job_minutes(S["slot_minutes"])
        usable = [d0 + dt.timedelta(days=i) for i in range(span)
                  if b.opens_on((d0 + dt.timedelta(days=i)).weekday())]
        elig, verdicts, fixable = [], [], []
        for p in people.values():
            why = None
            if not p.works_shift(b.shift):
                why = "shift/day-night: his shift is not this branch's"
            elif b.area_id not in p.areas:
                why = "area permission: not allowed in this patch"
            elif not p.days:
                why = "no working days on the board"
            if why:
                verdicts.append((p.name, why, None))
                continue
            elig.append(p)
            best, reasons = None, collections.Counter()
            for date in usable:
                wd = date.weekday()
                if not p.may_work(b.area_id, wd):
                    reasons["not permitted to work that weekday"] += 1
                    continue
                day = days.get((p.id, date))
                if day is None:
                    reasons["off that day (rest day / leave / no hours)"] += 1
                    continue
                held = at_door.get((date, b.id), set())
                if held - {p.id}:
                    reasons["another engineer already at that door that day"] += 1
                    continue
                if day.has_branch(b.id):
                    reasons["he is already at that branch that day"] += 1
                    continue
                win = b.window_on(wd)
                if min(win[1], day.end) - max(win[0], day.start) < dur:
                    reasons["door's window and his hours do not overlap long enough"] += 1
                    continue
                spot = day.try_insert(b, dur, win, rescue=True)
                if spot is None:
                    # travel ceiling, or simply no gap left?
                    # WAS IT THE DRIVING? Ask the same day again with the
                    # driving free — travel_max of 0 is the planner's own way
                    # of saying "charge nothing for the journey". If it fits
                    # then, the ceiling is what stopped it and the office can
                    # act on that; if it still will not fit, the hours are
                    # genuinely spoken for. (Free travel is NOT a legal plan —
                    # it is only the question being asked.)
                    keep = day.s
                    day.s = dict(S, travel_max=0, travel_area=0)
                    again = day.try_insert(b, dur, win, rescue=True)
                    day.s = keep
                    reasons["travel ceiling (%d min) — fits only if the drive were free"
                            % S["travel_max"]
                            if again else "his hours in that window are already taken"] += 1
                    continue
                start = spot[3][spot[1]][0]
                cand = (date, p, start)
                if best is None:
                    best = cand
            if best:
                fixable.append(best)
            else:
                top = reasons.most_common(1)
                verdicts.append((p.name, top[0][0] if top else "no usable day", None))
        row = {
            "month": key, "branch": b.name, "site_id": b.id,
            "reason": u.get("reason"), "row_date": u.get("date"),
            "window": "%s-%s" % (roster.hhmm(b.win[0])[0], roster.hhmm(b.win[1])[0]),
            "minutes": dur,
            "open_weekdays": [WD[w] for w in range(7) if b.opens_on(w)],
            "usable_days": len(usable),
            "eligible": [p.name for p in elig],
            "verdicts": verdicts,
            "placeable": bool(fixable),
            "proposal": None,
        }
        if fixable:
            date, p, start = fixable[0]
            row["proposal"] = "%s %s  %s  %s-%s" % (
                date.isoformat(), WD[date.weekday()], p.name,
                roster.hhmm(start)[0], roster.hhmm(start + dur)[0])
            failures.append(row)
        rows.append(row)

    summary[key] = {
        "owed": plan["summary"]["owed"], "booked": plan["summary"]["visits"],
        "unplaced": plan["summary"]["unplaced"],
        "free_engineer_days": free_days,
        "unused_hours": round(unused_min / 60.0, 1),
        "rows": rows,
    }

os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
json.dump(summary, open(os.path.join(HERE, "out", "capacity-audit.json"), "w"),
          indent=1, default=str)

print("=" * 78)
print("EVERY UNPLACED VISIT, PROVED")
print("=" * 78)
tot = collections.Counter()
for key, m in summary.items():
    tot["owed"] += m["owed"]; tot["booked"] += m["booked"]
    tot["unplaced"] += m["unplaced"]; tot["free"] += m["free_engineer_days"]
    tot["hours"] += m["unused_hours"]
    print("\n-- %s   owed %d  booked %d  unplaced %d   |   free engineer-days %d, "
          "unused %.0f h" % (key, m["owed"], m["booked"], m["unplaced"],
                             m["free_engineer_days"], m["unused_hours"]))
    byreason = collections.Counter(r["reason"] for r in m["rows"])
    print("   reasons: " + ", ".join("%s x%d" % (k, v) for k, v in byreason.most_common()))
    for r in m["rows"]:
        mark = "  *** PLANNER FAILURE" if r["placeable"] else ""
        print("   %-30s %-13s open=%-14s win=%-11s %dmin  usable days=%d%s"
              % (r["branch"][:30], r["reason"], ",".join(r["open_weekdays"]),
                 r["window"], r["minutes"], r["usable_days"], mark))
        blockers = collections.Counter(v[1] for v in r["verdicts"])
        for b_, n in blockers.most_common(3):
            print("        %2d engineer(s): %s" % (n, b_))
        if r["proposal"]:
            print("        COULD HAVE BEEN: %s" % r["proposal"])

print("\n" + "=" * 78)
print("TOTALS ACROSS %s" % ", ".join(MONTHS))
print("  true owed .................. %5d" % tot["owed"])
print("  booked ..................... %5d" % tot["booked"])
print("  unplaced ................... %5d" % tot["unplaced"])
print("  silently missing ........... %5d" % (tot["owed"] - tot["booked"] - tot["unplaced"]))
print("  free engineer working-days . %5d" % tot["free"])
print("  total unused engineer hours  %5.0f" % tot["hours"])
print("  PLANNER FAILURES (placeable) %5d" % len(failures))
