#!/usr/bin/env python3
"""PUT THE CRM'S OWN CLOCK ON CAIRO TIME — WITHOUT MOVING ONE ROW OF THE BOOK.

The box this runs on is UTC, and SQLite's `datetime('now')` is UTC by
definition whatever the machine's timezone says. So every stamp the CRM writes
by itself — when a visit was created, when a code was scanned, when an engineer
checked in without their phone supplying the time, every line of the audit trail
— was filed three hours behind the office's own wall clock.

TWO KINDS OF TIME LIVE IN THIS DATABASE AND ONLY ONE OF THEM IS WRONG:

  · TYPED TIMES — `scheduled_start`, `scheduled_end`, `service_from`, a visit's
    date. The office typed "2026-09-29T10:30" meaning half past ten in Cairo.
    There is no timezone in that text and none is applied to it. **Nothing here
    touches them: no schedule, no visit time, no report moves by one minute.**

  · MACHINE STAMPS — the `datetime('now')` defaults on `created_at`,
    `recorded_at`, `paid_at`, `uploaded_at`. These are the three-hours-behind
    ones, and these are what this changes — FOR ROWS WRITTEN FROM NOW ON.

WHAT IT ACTUALLY DOES: rewrites the DEFAULT expression stored in each table's
definition from `datetime('now')` to `datetime('now','localtime')`. That is a
change to the schema TEXT only — no row is read, written, moved or copied, which
is why it is safe on a live book and why it finishes instantly. Existing stamps
keep the value they already have: history is left exactly as it was recorded.

Run it against a copy first. Against the live book it demands --yes.

    python3 tools/clock_to_cairo.py /path/to/copy/crm.db
    python3 tools/clock_to_cairo.py --live --yes
"""
import os
import sqlite3
import sys

HERE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, HERE)

OLD_DT, NEW_DT = "datetime('now')", "datetime('now','localtime')"
OLD_D, NEW_D = "date('now')", "date('now','localtime')"

# Every column whose value the machine stamps. Their CONTENT is never touched;
# they are listed so the run can prove, byte for byte, that it did not.
def _stamp_columns(cx):
    out = []
    for (tbl,) in cx.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%'").fetchall():
        for row in cx.execute(f"PRAGMA table_info({tbl})").fetchall():
            col = row[1]
            if col.endswith(("_at", "_on")) or col in ("created_at", "recorded_at"):
                out.append((tbl, col))
    return out


def _fingerprint(cx):
    """Row counts and a checksum of every stamp column, so 'nothing moved' is
    a measurement rather than a promise."""
    counts, sums = {}, {}
    for (tbl,) in cx.execute(
            "SELECT name FROM sqlite_master WHERE type='table' "
            "AND name NOT LIKE 'sqlite_%'").fetchall():
        counts[tbl] = cx.execute(f"SELECT COUNT(*) FROM {tbl}").fetchone()[0]
    for tbl, col in _stamp_columns(cx):
        try:
            sums[f"{tbl}.{col}"] = cx.execute(
                f"SELECT COUNT({col}), COALESCE(SUM(LENGTH({col})),0), "
                f"MIN({col}), MAX({col}) FROM {tbl}").fetchone()
        except sqlite3.Error:
            pass
    return counts, sums


def convert(path, apply=True):
    cx = sqlite3.connect(path)
    before_counts, before_sums = _fingerprint(cx)
    rows = [r for r in cx.execute(
        "SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL").fetchall()
        if OLD_DT in r[2] or OLD_D in r[2]]
    if not rows:
        print("Already on Cairo time — no UTC default left to change.")
        cx.close()
        return 0
    print(f"{len(rows)} table definition(s) still stamp in UTC:")
    for _t, name, sql in rows:
        n = sql.count(OLD_DT) + sql.count(OLD_D)
        print(f"  {name}: {n} default(s)")
    if not apply:
        cx.close()
        return len(rows)

    ver = cx.execute("PRAGMA schema_version").fetchone()[0]
    cx.execute("PRAGMA writable_schema=ON")
    for typ, name, sql in rows:
        new = sql.replace(OLD_DT, NEW_DT).replace(OLD_D, NEW_D)
        cx.execute("UPDATE sqlite_master SET sql=? WHERE type=? AND name=?",
                   (new, typ, name))
    cx.execute(f"PRAGMA schema_version={ver + 1}")
    cx.execute("PRAGMA writable_schema=OFF")
    cx.commit()
    cx.close()

    # Reopen: the schema is re-read from scratch, which is the real test that
    # what was written back is valid SQL and not a bricked book.
    cx = sqlite3.connect(path)
    ok = cx.execute("PRAGMA integrity_check").fetchone()[0]
    left = [r[1] for r in cx.execute(
        "SELECT type, name, sql FROM sqlite_master WHERE sql IS NOT NULL").fetchall()
        if OLD_DT in r[2] or OLD_D in r[2]]
    after_counts, after_sums = _fingerprint(cx)
    now_utc = cx.execute("SELECT datetime('now')").fetchone()[0]
    now_loc = cx.execute("SELECT datetime('now','localtime')").fetchone()[0]
    cx.close()

    print()
    print(f"integrity_check           : {ok}")
    print(f"UTC defaults left          : {len(left)}")
    print(f"row counts unchanged       : {before_counts == after_counts}")
    print(f"every stamp column unchanged: {before_sums == after_sums}")
    print(f"the DB's UTC clock         : {now_utc}")
    print(f"the DB's local clock       : {now_loc}   <- what it will stamp with")
    bad = (ok != "ok" or left or before_counts != after_counts
           or before_sums != after_sums)
    print("\n" + ("FAILED — see above" if bad else "DONE — schema only, not one row touched"))
    return 1 if bad else 0


if __name__ == "__main__":
    argv = sys.argv[1:]
    if "--live" in argv:
        import database as db
        target = db.DB_PATH
        if "--yes" not in argv:
            print(f"Refusing to touch the live book without --yes:\n  {target}")
            sys.exit(2)
    else:
        target = next((a for a in argv if not a.startswith("-")), None)
        if not target:
            print(__doc__)
            sys.exit(2)
    print(f"Target: {target}\n")
    sys.exit(convert(target, apply="--dry-run" not in argv))
