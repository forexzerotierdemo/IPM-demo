#!/usr/bin/env python3
"""FINAL ACCEPTANCE — every approved fix together, on a copy of the live book.

  exact monthly owed (the stub-week recovery) · same-branch / two-vans guard ·
  rebalance rescue · correct unplaced reporting · the shift/day accounting fix

Then the same book again with the two proposed operational shifts.
Nothing is written to live and no shift is changed there.
"""
import collections, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [(2026, 9), (2026, 10), (2026, 11), (2026, 12)]
WD = "Mon Tue Wed Thu Fri Sat Sun".split()

work = tempfile.mkdtemp(prefix="final-")
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

S = dict(roster.DEFAULTS, **server._roster_settings())
S["rebalance"] = 1
IDS = {r["full_name"]: r["id"] for r in db.query("SELECT id, full_name FROM users")}
NAME = {v: k for k, v in IDS.items()}
ORIG = {(r["agent_id"], r["weekday"]): (r["start_time"], r["end_time"])
        for r in db.query("SELECT agent_id, weekday, start_time, end_time "
                          "FROM agent_availability")}


def set_hours(who, wd, f, t):
    db.execute("UPDATE agent_availability SET start_time=?, end_time=? "
               "WHERE agent_id=? AND weekday=?", (f, t, IDS[who], wd))


def restore(who, wd):
    f, t = ORIG[(IDS[who], wd)]
    set_hours(who, wd, f, t)


def run():
    owed = collections.Counter(); booked = collections.Counter()
    unpl = collections.Counter(); capshort = collections.Counter()
    names = {}; per_agent = collections.Counter(); per_min = collections.Counter()
    avail = collections.Counter(); agent_days = collections.Counter()
    clashes = 0; travel = 0; cover = 0; compromises = 0
    rb = collections.Counter()
    for (Y, M) in MONTHS:
        span = roster.days_in_month(Y, M)
        frm, to = "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span)
        p = roster.plan(db, frm, to, S)
        bk = roster.load_book(db, frm, to)
        for sid, b in bk["branches"].items():
            names[sid] = b.name
            owed[sid] += (roster.owed_in_month(b.vpm, "week", Y, M,
                                               offset=sid % roster.WEEKS_PER_MONTH)
                          if b.freq_unit == "week" else int(round(float(b.vpm or 0))))
        at = collections.defaultdict(set)
        for day in p["days"]:
            for a in day["assignments"]:
                for v in a["visits"]:
                    booked[v["site_id"]] += 1
                    per_agent[a["agent_id"]] += 1
                    per_min[a["agent_id"]] += v["minutes"] + (v.get("travel") or 0)
                    at[(day["date"], v["site_id"])].add(a["agent_id"])
                    if v.get("cover_for"):
                        cover += 1
        clashes += sum(1 for w in at.values() if len(w) > 1)
        travel += p["summary"]["travel_minutes"]
        compromises += len(p.get("compromises") or [])
        for u in p["unplaced"]:
            unpl[u["site_id"]] += 1
        for c in p.get("capped", []):
            if c.get("reason") == "days":
                capshort[c["site_id"]] += max(0, int(round(c["asked"])) - int(c["possible"]))
        r = p.get("rebalance") or {}
        for k in ("rescued", "direct", "reorder", "swap", "moved", "route_compromises"):
            rb[k] += r.get(k, 0)
        # how much of each man's working time exists at all
        for (aid, d), day in _grab["days"].items():
            avail[aid] += max(0, day.end - day.start)
            if day.stops:
                agent_days[aid] += 1
    silent = {s: owed[s] - booked.get(s, 0) - unpl.get(s, 0) - capshort.get(s, 0)
              for s in owed}
    return {"owed": owed, "booked": booked, "unpl": unpl, "cap": capshort,
            "names": names, "clashes": clashes, "travel": travel, "cover": cover,
            "compromises": compromises, "rb": rb, "per_agent": per_agent,
            "per_min": per_min, "avail": avail, "agent_days": agent_days,
            "silent": {k: v for k, v in silent.items() if v},
            "tot_owed": sum(owed.values()), "tot_booked": sum(booked.values()),
            "tot_unpl": sum(unpl.values()), "tot_cap": sum(capshort.values())}


_grab = {"days": {}}
_orig_render = roster._render


def _spy(days, book, ow, un, s, f, t, c, cm=(0, 0)):
    _grab["days"] = days
    return _orig_render(days, book, ow, un, s, f, t, c, cm)


roster._render = _spy


def report(tag, r):
    print("\\n" + "=" * 76)
    print(tag)
    print("=" * 76)
    print("  true owed .................. %5d" % r["tot_owed"])
    print("  booked ..................... %5d" % r["tot_booked"])
    print("  unplaced (reported) ........ %5d" % r["tot_unpl"])
    print("  named impossible (rule 6) .. %5d" % r["tot_cap"])
    print("  SILENTLY MISSING ........... %5d" % sum(r["silent"].values()))
    print("  two vans at one door ....... %5d" % r["clashes"])
    print("  travel minutes ............. %5d" % r["travel"])
    print("  cover visits ............... %5d" % r["cover"])
    print("  rule-5 compromises ......... %5d" % r["compromises"])
    print("  rebalance: rescued %d (reorder %d, swap %d), moved %d, route bends %d"
          % (r["rb"]["rescued"], r["rb"]["reorder"], r["rb"]["swap"],
             r["rb"]["moved"], r["rb"]["route_compromises"]))
    if r["tot_unpl"] or r["tot_cap"]:
        print("  remaining by branch:")
        for sid in sorted(set(r["unpl"]) | set(r["cap"]), key=lambda x: -r["unpl"].get(x, 0)):
            print("     %-34s unplaced %d  named-impossible %d"
                  % (r["names"].get(sid, sid)[:34], r["unpl"].get(sid, 0),
                     r["cap"].get(sid, 0)))
    print("\\n  %-24s %7s %9s %9s %7s" % ("engineer", "visits", "worked", "available", "used"))
    for aid in sorted(r["per_agent"], key=lambda a: -r["per_agent"][a]):
        av = r["avail"].get(aid, 0)
        pct = (100.0 * r["per_min"][aid] / av) if av else 0
        print("  %-24s %7d %8dh %8dh %6.0f%%"
              % (NAME.get(aid, aid)[:24], r["per_agent"][aid],
                 r["per_min"][aid] // 60, av // 60, pct))


base = run()
report("A. BASELINE — all approved planner fixes, live shift data unchanged", base)

PROPOSED = [("Amr Diab", 6, "15:00", "18:00"),
            ("Youssef Ahmed", 5, "06:00", "16:00")]
for who, wd, f, t in PROPOSED:
    set_hours(who, wd, f, t)
prop = run()
for who, wd, _f, _t in PROPOSED:
    restore(who, wd)
report("B. WITH THE TWO PROPOSED OPERATIONAL SHIFTS (simulated only)", prop)

print("\\n" + "=" * 76)
print("C. THE ACCOUNTING INVARIANT UNDER EVERY WORKING-DAY REMOVAL")
print("=" * 76)
print("  Every engineer, every weekday he works, removed one at a time.")
print("  A day taken off the board must turn into REPORTED demand, never silence.")
bad = []
for (aid, wd) in sorted(ORIG):
    db.execute("DELETE FROM agent_availability WHERE agent_id=? AND weekday=?", (aid, wd))
    r = run()
    db.execute("INSERT INTO agent_availability (agent_id,weekday,start_time,end_time) "
               "VALUES (?,?,?,?)", (aid, wd, ORIG[(aid, wd)][0], ORIG[(aid, wd)][1]))
    sm = sum(r["silent"].values())
    if sm:
        bad.append((NAME.get(aid, aid), WD[wd], sm,
                    {r["names"].get(k, k): v for k, v in r["silent"].items()}))
    print("   %-22s %-4s removed -> booked %4d  unplaced %3d  named %3d  SILENT %d"
          % (NAME.get(aid, aid)[:22], WD[wd], r["tot_booked"], r["tot_unpl"],
             r["tot_cap"], sm))
print("\\n  configurations that still lose demand silently: %d" % len(bad))
for x in bad:
    print("     !!", x)
os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
json.dump({"silent_configs": bad}, open(os.path.join(HERE, "out", "final-acceptance.json"), "w"),
          indent=1, default=str)
