#!/usr/bin/env python3
"""PRESS THE BUTTON ON THE RUNNING CRM — preview only, nothing is applied.

This is the acceptance test the office asked for: the September plan drawn by
the planner that is actually deployed, in the process that is actually serving
the business, over the real HTTP route the Auto-Roster button uses.

`apply` is deliberately absent from the body, so the server returns the plan
and writes nothing. The session token is minted locally from the server's own
secret (auth.make_token) rather than by resetting anybody's password, which
would sign the owner out of his own CRM.
"""
import json, os, sys, time, urllib.request

os.environ.setdefault("PESTCRM_DATA_DIR", "/root/pest-crm/data")
sys.path.insert(0, "/root/pest-crm")
import auth

OUT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "out", "NEW_plan_live.json")
token = auth.make_token(1, 19)                      # the live admin, id 1

body = json.dumps({"from": "2026-09-01", "to": "2026-09-30"}).encode()
req = urllib.request.Request(
    "http://127.0.0.1:8000/api/shifts/auto", data=body,
    headers={"Content-Type": "application/json",
             "Authorization": "Bearer " + token})

t0 = time.time()
with urllib.request.urlopen(req, timeout=600) as r:
    raw = r.read()
    print("HTTP %s in %.1fs, %d bytes" % (r.status, time.time() - t0, len(raw)))

plan = json.loads(raw)
assert plan.get("applied") is False, "the server thinks it APPLIED this — stop"
json.dump(plan, open(OUT, "w"))
print("applied:", plan["applied"])
print("summary:", json.dumps(plan["summary"], indent=1))
print("saved to", OUT)
