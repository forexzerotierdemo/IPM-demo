#!/usr/bin/env python3
"""ENGINEER SHIFTS, READ THE WAY THE PLANNER READS THEM. Changes nothing.

    python3 shift_audit.py

A shift typed 20:00 -> 04:00 must mean eight hours starting on day D and
finishing at four the next morning. It must NOT become "available all morning
on day D", and the part after midnight must not be silently dropped. This
prints, for every engineer and every weekday, the RAW pair the office typed and
the MINUTES the planner actually derives from it, so the two can be compared
line by line.
"""
import collections, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
work = tempfile.mkdtemp(prefix="shift-")
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

S = server._roster_settings()
WD = "Mon Tue Wed Thu Fri Sat Sun".split()
DAY = roster.DAY
book = roster.load_book(db, "2026-09-01", "2026-09-30")
raw = collections.defaultdict(dict)
for r in db.query("SELECT agent_id, weekday, start_time, end_time FROM agent_availability"):
    raw[r["agent_id"]][r["weekday"]] = (r["start_time"], r["end_time"])


def shape(f, t):
    """What the office typed, named."""
    if f in (None, "") and t in (None, ""):
        return "blank/blank -> ANY HOUR"
    fm, tm = roster.hhmm_min(f), roster.hhmm_min(t)
    if fm is None or tm is None:
        return "half-blank"
    if tm == fm:
        return "same time both sides -> ANY HOUR"
    if tm < fm:
        return "CROSSES MIDNIGHT"
    if fm == 0:
        return "starts AT midnight (small hours of that day)"
    return "plain day shift"


print("=" * 79)
print("HOW EVERY TYPED SHIFT IS READ")
print("=" * 79)
suspicious = []
for p in sorted(book["people"].values(), key=lambda x: x.name):
    rows = raw.get(p.id, {})
    if not rows:
        continue
    print("\n%s  (id %d)   planner shift class: %s" % (p.name, p.id, p.shift))
    spans, kinds = {}, set()
    for w in sorted(rows):
        f, t = rows[w]
        lo, hi = roster.avail_bounds(f, t)
        crosses = hi > DAY
        real = "%s day D  ->  %s day D%s" % (
            roster.hhmm(lo)[0], roster.hhmm(hi)[0], "+1" if crosses else "")
        kinds.add(shape(f, t))
        spans[w] = (lo, hi)
        print("   %s  typed %-5s-%-5s  = minutes %4d-%4d  (%s)  %s%s"
              % (WD[w], f or "--", t or "--", lo, hi, real, shape(f, t),
                 "   <-- post-midnight part kept" if crosses else ""))
        # THE THING THAT MUST NEVER HAPPEN: a night shift that also offers the
        # morning of the SAME day.
        if crosses and lo < 12 * 60:
            suspicious.append((p.name, WD[w], "night shift also opens the morning of day D"))
    # a week that is not one shape is worth a second look
    if len({(v[0], v[1]) for v in spans.values()}) > 1:
        pairs = sorted({(v[0], v[1]) for v in spans.values()})
        odd = [w for w in spans if list(spans.values()).count(spans[w]) == 1]
        if odd:
            for w in odd:
                lo, hi = spans[w]
                suspicious.append((p.name, WD[w],
                                   "the odd day out: %s-%s while the rest of his week differs"
                                   % (roster.hhmm(lo)[0], roster.hhmm(hi)[0])))
    if len(kinds) > 1:
        suspicious.append((p.name, "week", "mixes shapes: " + "; ".join(sorted(kinds))))

print("\n" + "=" * 79)
print("SHIFTS THAT LOOK SUSPICIOUS OR INCONSISTENT")
print("=" * 79)
if not suspicious:
    print("  none")
seen = set()
for name, when, why in suspicious:
    k = (name, when, why)
    if k in seen:
        continue
    seen.add(k)
    print("  %-22s %-5s %s" % (name, when, why))
