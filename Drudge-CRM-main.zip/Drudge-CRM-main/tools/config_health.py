#!/usr/bin/env python3
"""ROSTER CONFIGURATION HEALTH — what the book itself makes impossible,
found BEFORE the button is pressed. Reads only; changes nothing, ever.

    python3 config_health.py [YYYY-MM ...]

Auto Roster can only ever report what it FAILED to do. By then the office is
reading a worklist and cannot tell a bad round from a branch that was never
deliverable on the day it was sold. Every check here is arithmetic on the book
— frequency against open days, a shift against a door's window, a map against
the travel ceiling — so each answer names a FIELD SOMEBODY CAN EDIT.

GRADES, worst first. A branch is given the worst one that fits:

  no_eligible_coverage   nobody may work its patch on its shift, or nobody
                         whose hours reach its window for the whole visit.
                         No plan can ever serve it.
  window_too_short       the door is open for less time than the visit takes.
  frequency_impossible   more visits a month than it has usable open days,
                         and one branch takes at most one visit a day.
  travel_isolated        nothing else in the book is inside the travel ceiling
                         on a day it opens, so every visit is a lone trip.
  zero_slack             visits owed EXACTLY equals usable open days. It can
                         still be done — but lose one day and it cannot.
  single_point           exactly one engineer can ever serve it. His leave is
                         the branch's outage.
  healthy                room to breathe.
"""
import collections, datetime as dt, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [a for a in sys.argv[1:] if not a.startswith("--")] or \
         ["2026-09", "2026-10", "2026-11", "2026-12"]
WD = "Mon Tue Wed Thu Fri Sat Sun".split()

work = tempfile.mkdtemp(prefix="health-")
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

S = server._roster_settings()
CEIL = int(S["travel_max"])
report = {}

for key in MONTHS:
    Y, M = int(key[:4]), int(key[5:7])
    span = roster.days_in_month(Y, M)
    d0, d1 = dt.date(Y, M, 1), dt.date(Y, M, span)
    book = roster.load_book(db, d0.isoformat(), d1.isoformat())
    # OWNERSHIP IS DECIDED BEFORE ANY VISIT IS PLACED, and it matters here:
    # the shift rule binds COVER, never a branch's own man. Without this the
    # check condemns branches the planner serves perfectly well (Impryal
    # Factory is a night door owned by a day man, and it gets all 16).
    roster.assign_owners(book, S, weeks=span / 7.0)
    people, branches = book["people"], book["branches"]
    month_days = [d0 + dt.timedelta(days=i) for i in range(span)]
    rest = int(S.get("rest_day", 4))

    rows = []
    for sid, b in branches.items():
        dur = b.job_minutes(S["slot_minutes"])
        owed = (roster.owed_in_month(b.vpm, "week", Y, M,
                                     offset=sid % roster.WEEKS_PER_MONTH)
                if b.freq_unit == "week" else int(round(float(b.vpm or 0))))
        open_wd = [w for w in range(7) if b.opens_on(w)]

        # ---- 2. ENGINEER COVERAGE -------------------------------------
        # Not "is somebody allowed in the patch" but "could somebody actually
        # stand at that door for the whole visit" — the shift, the weekday and
        # the overlap of his hours with the door's window, all at once.
        eligible = []
        for p in people.values():
            if b.area_id not in p.areas or not p.days:
                continue
            # Rule 3: a man who is not the owner may only cover on his own
            # shift. The owner himself is not bound by it.
            if p.id != b.owner_id and not p.works_shift(b.shift):
                continue
            usable_wd = []
            for w in open_wd:
                if not p.may_work(b.area_id, w):
                    continue
                hrs = p.hours(w)
                if hrs is None:
                    continue
                win = b.window_on(w)
                # A WINDOW THAT BELONGS TO THE SMALL HOURS IS REACHED FROM THE
                # NIGHT BEFORE. "Open 00:00-02:00" is worked by the man whose
                # shift began at ten the previous evening, and the planner
                # places it at 00:00(+1) inside his 22:00-06:00 day. Comparing
                # the two as plain minutes says they never meet and would
                # condemn every night branch in the book as uncoverable.
                overlap = max(min(hrs[1], win[1]) - max(hrs[0], win[0]),
                              min(hrs[1], win[1] + roster.DAY)
                              - max(hrs[0], win[0] + roster.DAY))
                if overlap >= dur:
                    usable_wd.append(w)
            if usable_wd:
                eligible.append((p, usable_wd))

        # ---- 1. FREQUENCY FEASIBILITY ---------------------------------
        # Days this branch opens AND somebody who may serve it is working.
        # One visit a day per branch, so this IS the ceiling on the month.
        served_wd = set()
        for _p, wds in eligible:
            served_wd |= set(wds)
        usable_days = [d for d in month_days if d.weekday() in served_wd]
        # ...and what it would be if only the branch's own days mattered, so a
        # book problem is told apart from a rota problem.
        open_days_ignoring_staff = [d for d in month_days
                                    if b.opens_on(d.weekday()) and d.weekday() != rest]

        # ---- 3. TRAVEL ISOLATION --------------------------------------
        neighbours = []
        if b.geo:
            for other in branches.values():
                if other.id == sid or not other.geo:
                    continue
                km = roster.haversine_km(b.geo, other.geo)
                mins = int(round(km / max(1.0, S["travel_kmh"]) * 60))
                if mins <= CEIL:
                    neighbours.append((mins, other))
        # a neighbour is only useful if it can share a DAY with this branch
        same_day = [(m, o) for m, o in neighbours
                    if any(o.opens_on(w) for w in open_wd)]

        # ---- grade ----------------------------------------------------
        # ONLY THE WINDOWS THAT ARE ACTUALLY USED. A branch open Saturdays
        # carries a default window too, and judging it by a default it never
        # opens on condemns a door that is perfectly serviceable.
        wins = [b.window_on(w) for w in open_wd] or [b.win]
        shortest = min((t - f) for f, t in wins)   # already carried past midnight
        grade, note = "healthy", ""
        if shortest < dur:
            grade = "window_too_short"
            note = "door open %d min, visit needs %d" % (shortest, dur)
        elif not eligible:
            grade = "no_eligible_coverage"
            permitted = [p.name for p in people.values() if b.area_id in p.areas]
            note = ("nobody may work area %s on the %s shift with hours reaching %s-%s"
                    % (b.area_id, b.shift, roster.hhmm(b.win[0])[0],
                       roster.hhmm(b.win[1])[0]))
            if permitted:
                note += "; permitted but unusable: " + ", ".join(permitted[:3])
        elif owed > len(usable_days):
            grade = "frequency_impossible"
            note = ("%d a month but only %d usable day(s) (%s); one visit a day"
                    % (owed, len(usable_days), ",".join(WD[w] for w in sorted(served_wd))))
        elif b.geo and not same_day:
            grade = "travel_isolated"
            nearest = min(neighbours)[0] if neighbours else None
            note = ("no other branch within %d min opens on %s — every visit is a "
                    "lone trip%s" % (CEIL, "/".join(WD[w] for w in open_wd),
                                     "" if nearest is None else
                                     "; nearest neighbour %d min but on other days" % nearest))
        elif owed == len(usable_days):
            grade = "zero_slack"
            note = "%d a month against exactly %d usable day(s)" % (owed, len(usable_days))
        elif len(eligible) == 1:
            grade = "single_point"
            note = "only %s can ever serve it" % eligible[0][0].name

        rows.append({
            "site_id": sid, "name": b.name, "client": b.client_en,
            "area_id": b.area_id, "grade": grade, "note": note,
            "owed": owed, "usable_days": len(usable_days),
            "own_open_days": len(open_days_ignoring_staff),
            "eligible": [p.name for p, _w in eligible],
            "eligible_n": len(eligible),
            "neighbours_in_ceiling": len(neighbours),
            "neighbours_same_day": len(same_day),
            "open_weekdays": [WD[w] for w in open_wd],
            "minutes": dur,
        })
    report[key] = rows

os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
json.dump(report, open(os.path.join(HERE, "out", "config-health.json"), "w"),
          indent=1, default=str)

ORDER = ["no_eligible_coverage", "window_too_short", "frequency_impossible",
         "travel_isolated", "zero_slack", "single_point", "healthy"]
print("=" * 79)
print("ROSTER CONFIGURATION HEALTH — the book graded before the button is pressed")
print("=" * 79)
for key, rows in report.items():
    by = collections.Counter(r["grade"] for r in rows)
    print("\n-- %s   %d active branches" % (key, len(rows)))
    for g in ORDER:
        if by.get(g):
            print("     %-22s %3d" % (g, by[g]))
    for g in ORDER[:-1]:
        bad = [r for r in rows if r["grade"] == g]
        if not bad:
            continue
        print("   %s:" % g.upper().replace("_", " "))
        for r in sorted(bad, key=lambda r: r["name"])[:12]:
            print("     %-32s %s" % (r["name"][:32], r["note"]))
        if len(bad) > 12:
            print("     ... and %d more" % (len(bad) - 12))
print("\nfull detail: tools/out/config-health.json")
