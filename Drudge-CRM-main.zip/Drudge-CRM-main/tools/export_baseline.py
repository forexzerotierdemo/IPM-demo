#!/usr/bin/env python3
"""OLD BASELINE EXPORT — the September roster exactly as it stands, read-only.

Writes three files: the visits, the shifts, the branch owners, plus a header
naming the run that made them. Nothing here can write to the database."""
import csv, json, sqlite3, sys, hashlib, datetime as dt

DB = sys.argv[1] if len(sys.argv) > 1 else "/root/pest-crm/data/crm.db"
OUT = sys.argv[2] if len(sys.argv) > 2 else "."

cx = sqlite3.connect("file:%s?mode=ro" % DB, uri=True)
cx.row_factory = sqlite3.Row
q = lambda s, *a: cx.execute(s, a).fetchall()

# ---- the run that made the September book -------------------------------
runs = [dict(r) for r in q("SELECT * FROM roster_runs WHERE undone_at IS NULL")]

# ---- visits -------------------------------------------------------------
visits = [dict(r) for r in q("""
    SELECT v.id, v.site_id, s.name AS site_name, s.area_id, a.name_en AS area,
           a.zone_id, z.name_en AS zone, v.client_id, c.name_en AS client,
           v.agent_id, u.full_name AS agent, s.preferred_agent_id AS owner_id,
           uo.full_name AS owner, v.scheduled_start, v.scheduled_end, v.status,
           s.visits_per_month, s.freq_unit, s.visit_minutes,
           s.service_from, s.service_to
      FROM visits v
      LEFT JOIN sites s   ON s.id = v.site_id
      LEFT JOIN areas a   ON a.id = s.area_id
      LEFT JOIN zones z   ON z.id = a.zone_id
      LEFT JOIN clients c ON c.id = v.client_id
      LEFT JOIN users u   ON u.id = v.agent_id
      LEFT JOIN users uo  ON uo.id = s.preferred_agent_id
     ORDER BY v.scheduled_start, v.agent_id, v.id""")]

shifts = [dict(r) for r in q("""
    SELECT sh.id, sh.agent_id, u.full_name AS agent, sh.shift_date,
           sh.shift_type_id, t.name_en AS shift_type, sh.area_id,
           a.name_en AS area, sh.start_time, sh.end_time
      FROM agent_shifts sh
      LEFT JOIN users u ON u.id = sh.agent_id
      LEFT JOIN areas a ON a.id = sh.area_id
      LEFT JOIN shift_types t ON t.id = sh.shift_type_id
     ORDER BY sh.shift_date, sh.agent_id, sh.id""")]

owners = [dict(r) for r in q("""
    SELECT s.id AS site_id, s.name AS site_name, s.preferred_agent_id AS owner_id,
           u.full_name AS owner, s.area_id, a.name_en AS area, s.status,
           s.visits_per_month, s.freq_unit
      FROM sites s
      LEFT JOIN users u ON u.id = s.preferred_agent_id
      LEFT JOIN areas a ON a.id = s.area_id
     ORDER BY s.id""")]

unplaced = [dict(r) for r in q("""
    SELECT ru.*, s.name AS site_name FROM roster_run_unplaced ru
      LEFT JOIN sites s ON s.id = ru.site_id ORDER BY ru.id""")]

def dump_csv(rows, name):
    if not rows:
        open("%s/%s.csv" % (OUT, name), "w").write("")
        return
    with open("%s/%s.csv" % (OUT, name), "w", newline="") as fh:
        w = csv.DictWriter(fh, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)

for rows, name in ((visits, "OLD_visits"), (shifts, "OLD_shifts"),
                   (owners, "OLD_owners"), (unplaced, "OLD_unplaced")):
    dump_csv(rows, name)

meta = {
    "captured_at": dt.datetime.now().isoformat(timespec="seconds"),
    "db_sha256": hashlib.sha256(open(DB, "rb").read()).hexdigest(),
    "live_runs_not_undone": runs,
    "counts": {"visits": len(visits), "shifts": len(shifts),
               "owners_set": sum(1 for o in owners if o["owner_id"]),
               "sites": len(owners), "unplaced_rows": len(unplaced)},
}
json.dump({"meta": meta, "visits": visits, "shifts": shifts,
           "owners": owners, "unplaced": unplaced},
          open("%s/OLD_baseline.json" % OUT, "w"), indent=1, default=str)
print(json.dumps(meta, indent=1, default=str))
