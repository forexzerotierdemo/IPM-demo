#!/usr/bin/env python3
"""OWED, COUNTED THREE WAYS — an audit. Writes nothing, changes nothing.

    python3 owed_audit.py

Three numbers exist for "how many visits does this branch owe this month":

  CONFIGURED  what the office typed. For a monthly branch that is the number
              itself: 8 a month is 8, in a 28-day month and a 31-day one.
  GAP WARNING `roster.owed_in_month` — what /api/service-gaps compares against.
  PLANNER     the jobs `_due_jobs` actually deals out when the button is
              pressed. This is the one that decides what gets booked, and the
              one nobody has been reading.

Runs the planner on a COPY of the live book, month by month, and reports every
branch where the three disagree.
"""
import collections, datetime as dt, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [(2026, 9), (2026, 10), (2026, 11), (2026, 12)]

work = tempfile.mkdtemp(prefix="owed-")
src = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
dst = sqlite3.connect(os.path.join(work, "crm.db"))
src.backup(dst); dst.commit(); dst.close(); src.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

S = server._roster_settings()

# ---- capture the jobs the planner actually deals -------------------------
CAUGHT = {}
_orig_due = roster._due_jobs


def _spy(book, d0, d1, fixed, worked_weekdays):
    jobs = _orig_due(book, d0, d1, fixed, worked_weekdays)
    CAUGHT["jobs"] = jobs
    CAUGHT["book"] = book
    return jobs


roster._due_jobs = _spy

report = {}
for (Y, M) in MONTHS:
    span = roster.days_in_month(Y, M)
    frm, to = "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span)
    plan = roster.plan(db, frm, to, S)
    book, jobs = CAUGHT["book"], CAUGHT["jobs"]

    planner_owed = collections.Counter(j["branch"].id for j in jobs)
    booked = collections.Counter()
    for day in plan["days"]:
        for a in day["assignments"]:
            for v in a["visits"]:
                booked[v["site_id"]] += 1
    unplaced = collections.Counter(u["site_id"] for u in plan["unplaced"])

    rows = []
    for sid, b in book["branches"].items():
        if b.freq_unit == "week":
            configured = roster.owed_in_month(b.vpm, "week", Y, M,
                                              offset=sid % roster.WEEKS_PER_MONTH)
        else:
            configured = int(round(float(b.vpm or 0)))
        gap = roster.owed_in_month(b.vpm, b.freq_unit or "month", Y, M,
                                   offset=sid % roster.WEEKS_PER_MONTH)
        rows.append({
            "site_id": sid, "name": b.name, "vpm": b.vpm, "unit": b.freq_unit,
            "open_days": sorted(w for w in range(7) if b.opens_on(w)),
            "configured": configured, "gap_warning": gap,
            "planner": planner_owed.get(sid, 0),
            "booked": booked.get(sid, 0), "unplaced": unplaced.get(sid, 0),
        })
    report["%04d-%02d" % (Y, M)] = rows

os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
json.dump(report, open(os.path.join(HERE, "out", "owed-audit.json"), "w"),
          indent=1, default=str)

print("=" * 78)
print("OWED, COUNTED THREE WAYS — %s" % ", ".join(report))
print("=" * 78)
grand = collections.Counter()
for key, rows in report.items():
    mono = [r for r in rows if r["unit"] != "week"]
    short = [r for r in rows if r["planner"] < r["configured"]]
    over = [r for r in rows if r["planner"] > r["configured"]]
    gapdiff = [r for r in rows if r["gap_warning"] != r["configured"]]
    tot_conf = sum(r["configured"] for r in rows)
    tot_plan = sum(r["planner"] for r in rows)
    tot_book = sum(r["booked"] for r in rows)
    tot_unpl = sum(r["unplaced"] for r in rows)
    invisible = tot_conf - tot_plan
    grand["configured"] += tot_conf; grand["planner"] += tot_plan
    grand["booked"] += tot_book; grand["unplaced"] += tot_unpl
    grand["invisible"] += invisible
    print("\n-- %s  (%d branches, %d on a monthly number)" % (key, len(rows), len(mono)))
    print("   TRUE OWED (as configured) ......... %4d" % tot_conf)
    print("   planner dealt ..................... %4d" % tot_plan)
    print("     booked .......................... %4d" % tot_book)
    print("     genuinely unplaced .............. %4d" % tot_unpl)
    print("   MISSING AND INVISIBLE ............. %4d   (never dealt, never reported)"
          % invisible)
    print("   branches short at the planner ..... %4d" % len(short))
    print("   branches the planner OVER-deals ... %4d" % len(over))
    print("   branches where the GAP WARNING differs from configured ... %d" % len(gapdiff))
    for r in sorted(short, key=lambda r: (r["configured"] - r["planner"], r["name"]),
                    reverse=True)[:14]:
        print("      -%d  %-34s %s/%s open=%s  planner=%d booked=%d unplaced=%d"
              % (r["configured"] - r["planner"], r["name"][:34], r["vpm"], r["unit"],
                 r["open_days"], r["planner"], r["booked"], r["unplaced"]))
    if len(short) > 14:
        print("      ... and %d more" % (len(short) - 14))

print("\n" + "=" * 78)
print("ALL FOUR MONTHS")
print("  TRUE OWED (as configured) ..... %5d" % grand["configured"])
print("  planner dealt ................. %5d" % grand["planner"])
print("    booked ...................... %5d" % grand["booked"])
print("    genuinely unplaced .......... %5d" % grand["unplaced"])
print("  MISSING AND INVISIBLE ......... %5d" % grand["invisible"])
print("  copy: %s" % work)
