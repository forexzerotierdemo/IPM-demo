#!/usr/bin/env python3
"""OLD -> NEW for September, both measured by metrics.py.

    python3 compare.py <data_dir_holding_the_OLD_diary> <data_dir_to_plan_in>

The first is opened READ-ONLY for the old book. The second is where the planner
runs; it must be a COPY with September already cleared, never the live dir.
"""
import collections, datetime as dt, json, os, sqlite3, sys

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE)
sys.path.insert(0, "/root/pest-crm")
YEAR, MONTH = 2026, 9
LIVE_DIR = "/root/pest-crm/data"

old_dir, plan_dir = sys.argv[1], sys.argv[2]
allow_live = "--live" in sys.argv


# ---------------------------------------------------------------- OLD stops
def old_stops(db_path, people):
    """The diary read back as rounds — see rounds.py, and the round-trip test
    that proves the reading against the planner's own output."""
    import rounds
    cx = sqlite3.connect("file:%s?mode=ro" % db_path, uri=True)
    shift_days = {(a, d) for a, d in cx.execute(
        "SELECT agent_id, shift_date FROM agent_shifts")}
    rows = [(a, dt.datetime.fromisoformat(s), dt.datetime.fromisoformat(e), sid)
            for a, s, e, sid in cx.execute(
                "SELECT agent_id, scheduled_start, scheduled_end, site_id FROM visits "
                "WHERE status IN ('scheduled','in_progress')")]
    stops, report = rounds.rounds_from_diary(rows, shift_days, people)
    return stops, shift_days, report


# --------------------------------------------------------------- NEW stops
def new_plan(data_dir):
    if not allow_live and os.path.realpath(data_dir) == os.path.realpath(LIVE_DIR):
        sys.exit("refusing to plan in the LIVE data directory without --live")
    os.environ["PESTCRM_DATA_DIR"] = data_dir
    import database as db
    db.init_db()
    import roster, server
    s = server._roster_settings()
    import calendar
    last = calendar.monthrange(YEAR, MONTH)[1]
    plan = roster.plan(db, "%04d-%02d-01" % (YEAR, MONTH),
                       "%04d-%02d-%02d" % (YEAR, MONTH, last), s)
    stops = []
    for day in plan["days"]:
        d = dt.date.fromisoformat(day["date"])
        for a in day["assignments"]:
            for v in a["visits"]:
                sm = int(v["start"][:2]) * 60 + int(v["start"][3:5]) + 1440 * (v.get("start_day") or 0)
                stops.append({"agent_id": a["agent_id"], "date": d,
                              "site_id": v["site_id"], "start": sm,
                              "dur": v["minutes"]})
    return plan, stops, s, db, roster


plan, new_st, S, db, roster = new_plan(plan_dir)
book = roster.load_book(db, "%04d-09-01" % YEAR, "%04d-09-30" % YEAR)
import metrics

old_st, shift_days, old_report = old_stops(os.path.join(old_dir, "crm.db"), book["people"])
old_unplaced = sqlite3.connect("file:%s?mode=ro" % os.path.join(old_dir, "crm.db"), uri=True) \
    .execute("SELECT count(*) FROM roster_run_unplaced ru JOIN roster_runs r ON r.id=ru.run_id "
             "WHERE r.undone_at IS NULL").fetchone()[0]

OLD = metrics.measure(old_st, [None] * old_unplaced, book, YEAR, MONTH, S)
NEW = metrics.measure(new_st, plan["unplaced"], book, YEAR, MONTH, S)

# The reconstruction is only trustworthy if it reproduces the planner's OWN day
# count when run over the planner's own output. Prove it, do not assume it.
NEW["planner_says_days"] = plan["summary"]["days"]
NEW["planner_says_visits"] = plan["summary"]["visits"]
NEW["planner_says_travel"] = plan["summary"]["travel_minutes"]
NEW["compromises_reported"] = plan["summary"]["compromises"]
NEW["compacted"] = plan["summary"]["compacted"]
NEW["days_dissolved"] = plan["summary"]["days_dissolved"]
OLD["shift_day_count"] = len({(a, d) for a, d in shift_days})

names = {r["id"]: r["full_name"] for r in db.query("SELECT id, full_name FROM users")}
bnames = {b.id: b.name for b in book["branches"].values()}
json.dump({"OLD": OLD, "NEW": NEW,
           "names": names, "bnames": bnames,
           "unplaced_rows": plan["unplaced"],
           "compromises": plan["compromises"],
           "capped": plan["capped"]},
          open(os.path.join(HERE, "out", "compare.json"), "w"),
          indent=1, default=str)


# Which direction is GOOD for each column. Anything not named here is just
# reported; nothing is called an improvement because it merely moved.
LOWER_IS_BETTER = {
    "unplaced", "over_serviced_branches", "over_serviced_visits",
    "under_serviced_branches", "under_serviced_visits", "engineer_days",
    "thin_days", "solo_days", "bent_rounds", "rounds_two_zones",
    "rounds_over_patch_cap", "rounds_revisiting_a_patch", "district_changes",
    "charged_hops", "travel_minutes", "travel_hours", "minutes_per_hop",
    "spacing_watch", "same_day_doubles", "due_dev_avg", "due_dev_worst",
    "due_dev_over_3", "double_bookings", "outside_engineer_hours",
    "outside_branch_window",
}
HIGHER_IS_BETTER = {"booked", "visits_per_day", "due_dev_on_the_day",
                    "spacing_min_gap_avg", "onsite_hours"}


def show(label, keys):
    print("\n== %s" % label)
    for k, title in keys:
        o, n = OLD.get(k), NEW.get(k)
        mark = ""
        if o != n and isinstance(o, (int, float)) and isinstance(n, (int, float)):
            if k in LOWER_IS_BETTER:
                mark = "  BETTER" if n < o else "  WORSE"
            elif k in HIGHER_IS_BETTER:
                mark = "  BETTER" if n > o else "  WORSE"
            else:
                mark = "  changed"
            mark += "  (%+g)" % (n - o)
        print("   %-28s %10s  ->  %10s%s" % (title, o, n, mark))


show("THE CONTRACT", [("owed", "owed"), ("booked", "booked"), ("unplaced", "unplaced"),
                      ("over_serviced_branches", "over-serviced branches"),
                      ("over_serviced_visits", "over-serviced visits"),
                      ("under_serviced_branches", "under-serviced branches"),
                      ("under_serviced_visits", "under-serviced visits")])
show("THE WORKING MONTH", [("engineer_days", "engineer-days"),
                           ("thin_days", "thin days (<=2)"),
                           ("solo_days", "solo days (1 visit)"),
                           ("visits_per_day", "visits per day"),
                           ("engineers_used", "engineers used")])
show("WHO DRIVES IT", [("cover_visits", "COVER assignments"),
                       ("cover_branches", "branches covered")])
show("THE ROUNDS", [("bent_rounds", "bent/rescued rounds"),
                    ("rounds_two_zones", "rounds crossing 2 zones"),
                    ("rounds_over_patch_cap", "rounds over patch cap"),
                    ("rounds_revisiting_a_patch", "rounds revisiting a patch"),
                    ("district_changes", "district changes (total)")])
show("THE DRIVING", [("charged_hops", "charged travel hops"),
                     ("travel_minutes", "travel minutes"),
                     ("travel_hours", "travel hours"),
                     ("minutes_per_hop", "minutes per hop"),
                     ("onsite_hours", "on-site hours")])
show("RHYTHM", [("spacing_watch", "spacing watch (branches)"),
                ("spacing_min_gap_avg", "avg closest gap (days)"),
                ("same_day_doubles", "branches twice in a day"),
                ("due_dev_avg", "due-date deviation avg"),
                ("due_dev_worst", "due-date deviation worst"),
                ("due_dev_over_3", "visits >3 days off due"),
                ("due_dev_on_the_day", "visits on the due day")])
show("THE HARD RULES", [("double_bookings", "double bookings"),
                        ("outside_engineer_hours", "outside engineer hours"),
                        ("outside_branch_window", "outside branch windows")])

print("\n== CROSS-CHECK (the ruler against the planner's own bookkeeping)")
print("   NEW engineer-days   ruler %s   planner %s" % (NEW["engineer_days"], NEW["planner_says_days"]))
print("   NEW visits          ruler %s   planner %s" % (NEW["booked"], NEW["planner_says_visits"]))
print("   NEW travel minutes  ruler %s   planner %s" % (NEW["travel_minutes"], NEW["planner_says_travel"]))
print("   OLD engineer-days   ruler %s   shift rows say %s" % (OLD["engineer_days"], OLD["shift_day_count"]))
print("   OLD read-back       %s  unresolved %s" % ({k: v for k, v in old_report.items() if k != "unresolved"}, len(old_report["unresolved"])))
print("   NEW compromises reported by planner: %s" % NEW["compromises_reported"])
print("   NEW compaction: %s visits moved, %s thin days dissolved" % (NEW["compacted"], NEW["days_dissolved"]))
