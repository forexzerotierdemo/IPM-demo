#!/usr/bin/env python3
"""SPLIT SHIFTS — does anything change for a book that has none? Reads only.

Every engineer on the live book works ONE window a day, so the new rule must
produce the SAME plan. This runs the released planner and the new one over the
same copy and compares visit by visit.
"""
import collections, importlib.util, os, shutil, sqlite3, sys, tempfile
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [(2026, 9), (2026, 10), (2026, 11), (2026, 12)]
OLD = sys.argv[1] if len(sys.argv) > 1 else None

work = tempfile.mkdtemp(prefix="split-")
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import server


def load(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    m = importlib.util.module_from_spec(spec)
    sys.modules[name] = m
    spec.loader.exec_module(m)
    return m


def run(rost):
    S = dict(rost.DEFAULTS, **server._roster_settings())
    S["rebalance"] = 1
    vis = {}
    tot = collections.Counter()
    per = collections.Counter()
    avail = collections.Counter()
    for (Y, M) in MONTHS:
        span = rost.days_in_month(Y, M)
        p = rost.plan(db, "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span), S)
        tot["booked"] += p["summary"]["visits"]; tot["unplaced"] += p["summary"]["unplaced"]
        tot["travel"] += p["summary"]["travel_minutes"]
        for day in p["days"]:
            for a in day["assignments"]:
                for v in a["visits"]:
                    vis[(day["date"], v["site_id"], a["agent_id"])] = (
                        v["start"], v["end"], v.get("start_day") or 0)
                    per[a["agent_name"]] += v["minutes"] + (v.get("travel") or 0)
        bk = rost.load_book(db, "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span))
        for q in bk["people"].values():
            for i in range(span):
                import datetime as dt
                wd = (dt.date(Y, M, 1) + dt.timedelta(days=i)).weekday()
                wins = q.windows(wd) if hasattr(q, "windows") else (
                    [q.days[wd]] if wd in q.days else [])
                avail[q.name] += sum(b - a for a, b in wins)
    return vis, tot, per, avail


new = load("/root/pest-crm/roster.py", "roster_new")
nv, nt, npr, nav = run(new)
print("NEW  booked %d  unplaced %d  travel %d" % (nt["booked"], nt["unplaced"], nt["travel"]))
if OLD:
    old = load(OLD, "roster_old")
    ov, ot, opr, oav = run(old)
    print("HEAD booked %d  unplaced %d  travel %d" % (ot["booked"], ot["unplaced"], ot["travel"]))
    same = sum(1 for k in nv if k in ov and nv[k] == ov[k])
    print("\nvisit-by-visit: %d identical, %d only in NEW, %d only in HEAD, %d retimed"
          % (same, len(set(nv) - set(ov)), len(set(ov) - set(nv)),
             sum(1 for k in nv if k in ov and nv[k] != ov[k])))
    print("\n  %-24s %10s %10s   %s" % ("engineer", "HEAD min", "NEW min", "available (sum of windows)"))
    for n in sorted(npr, key=lambda x: -npr[x]):
        flag = "" if npr[n] == opr.get(n, 0) else "   <<< CHANGED"
        print("  %-24s %10d %10d   %6dh vs %6dh%s"
              % (n[:24], opr.get(n, 0), npr[n], oav.get(n, 0) // 60, nav.get(n, 0) // 60, flag))
