#!/usr/bin/env python3
"""CLEAR THE GENERATED SEPTEMBER ROSTER — and nothing else.

WHAT IT TOUCHES, and only this:
  * visits that a roster run CREATED (roster_run_items.kind='visit_created')
    for a run that has not been undone, that are still 'scheduled', that
    nobody has checked in or completed, and that fall in the September window;
  * the shift rows the same runs created on September dates;
  * the run's own bookkeeping rows, marked undone rather than deleted.

WHAT IT WILL NOT TOUCH: customers, branches, contracts, branch OWNERS
(sites.preferred_agent_id), engineer hours, areas, zones, settings, any visit
a human made, any visit already started or done, and any visit outside the
window. It refuses and changes nothing if it finds a single row it is unsure of.

THE WINDOW is 1 September to 1 October 06:00 — the tail of the 30 September
night round belongs to September and is cleared with it.

    python3 clear_september.py <data_dir> [--commit]
Without --commit it reports what it would do and rolls back.
"""
import sqlite3, sys, datetime as dt

data_dir = sys.argv[1]
commit = "--commit" in sys.argv
DB = data_dir.rstrip("/") + "/crm.db"

FROM = "2026-09-01T00:00"
TO   = "2026-10-01T06:00"          # the overnight tail of 30 September

cx = sqlite3.connect(DB)
cx.row_factory = sqlite3.Row
cx.execute("PRAGMA foreign_keys=ON")
q = lambda s, *a: cx.execute(s, a).fetchall()

live_runs = [r["id"] for r in q("SELECT id FROM roster_runs WHERE undone_at IS NULL")]
print("runs still standing:", live_runs)

made = {r["ref_id"] for r in q(
    "SELECT ref_id FROM roster_run_items WHERE kind='visit_created' AND run_id IN (%s)"
    % ",".join("?" * len(live_runs)), *live_runs)} if live_runs else set()

allv = {r["id"]: dict(r) for r in q("SELECT * FROM visits")}

# ---- the four questions asked of every visit in the book -----------------
in_window   = {i for i, v in allv.items() if FROM <= v["scheduled_start"] <= TO}
generated   = {i for i in allv if i in made}
untouched   = {i for i, v in allv.items()
               if v["status"] == "scheduled" and not v["completed_at"]
               and not v["checkin_at"] and not v["checkout_at"]}
safe = in_window & generated & untouched

refuse = []
for i, v in allv.items():
    if i in in_window and i not in safe:
        why = []
        if i not in generated:
            why.append("not made by a roster run — somebody booked it")
        if i not in untouched:
            why.append("status %s / checked in or completed" % v["status"])
        refuse.append((i, v["scheduled_start"], v["site_id"], "; ".join(why)))

print("visits in the book              :", len(allv))
print("inside the September window     :", len(in_window))
print("of those, made by a live run    :", len(in_window & generated))
print("of those, never started/done    :", len(safe))
print("SAFE TO CLEAR                   :", len(safe))
print("IN WINDOW BUT KEPT              :", len(refuse))
for r in refuse[:30]:
    print("     keep visit %s %s site %s — %s" % r)
outside = len(allv) - len(in_window)
print("OUTSIDE THE WINDOW, untouched   :", outside)
for i, v in sorted(allv.items()):
    if i not in in_window:
        print("     keep visit %s %s" % (i, v["scheduled_start"]))

shifts = [r["id"] for r in q(
    "SELECT s.id FROM agent_shifts s JOIN roster_run_items ri "
    "  ON ri.kind='shift_created' AND ri.ref_id = s.id "
    " WHERE ri.run_id IN (%s) AND s.shift_date BETWEEN '2026-09-01' AND '2026-09-30'"
    % ",".join("?" * len(live_runs)), *live_runs)] if live_runs else []
other_shifts = q("SELECT count(*) n FROM agent_shifts WHERE id NOT IN (%s)"
                 % (",".join("?" * len(shifts)) or "NULL"), *shifts)[0]["n"]
print("generated September shift rows  :", len(shifts))
print("shift rows KEPT                 :", other_shifts)

# ---- the guard: nothing outside these two lists may change ---------------
before = {t: q("SELECT count(*) n FROM %s" % t)[0]["n"] for t in
          ("clients", "sites", "contracts", "contract_sites", "users",
           "agent_availability", "agent_areas", "areas", "zones", "settings",
           "site_service_days", "service_types", "shift_types")}
owners_before = q("SELECT count(*) n FROM sites WHERE preferred_agent_id IS NOT NULL")[0]["n"]
owner_sig = q("SELECT group_concat(id||':'||coalesce(preferred_agent_id,'-'),',') g "
              "FROM (SELECT id, preferred_agent_id FROM sites ORDER BY id)")[0]["g"]

try:
    cx.execute("BEGIN")
    if safe:
        cx.execute("DELETE FROM visits WHERE id IN (%s)" % ",".join("?" * len(safe)),
                   tuple(safe))
    if shifts:
        cx.execute("DELETE FROM agent_shifts WHERE id IN (%s)" % ",".join("?" * len(shifts)),
                   tuple(shifts))
    now = dt.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    for rid in live_runs:
        cx.execute("UPDATE roster_runs SET undone_at=?, undone_by=created_by, kept=? "
                   "WHERE id=?", (now, len(refuse), rid))

    after = {t: cx.execute("SELECT count(*) FROM %s" % t).fetchone()[0] for t in before}
    owners_after = cx.execute(
        "SELECT count(*) FROM sites WHERE preferred_agent_id IS NOT NULL").fetchone()[0]
    sig_after = cx.execute(
        "SELECT group_concat(id||':'||coalesce(preferred_agent_id,'-'),',') "
        "FROM (SELECT id, preferred_agent_id FROM sites ORDER BY id)").fetchone()[0]
    drift = {t: (before[t], after[t]) for t in before if before[t] != after[t]}
    if drift or owners_before != owners_after or owner_sig != sig_after:
        raise SystemExit("REFUSING: something outside the roster moved: %s owners %s->%s "
                         "signature changed=%s"
                         % (drift, owners_before, owners_after, owner_sig != sig_after))
    print("\nguard: every other table unchanged; %d branch owners unchanged, "
          "signature identical" % owners_after)
    print("visits left:", cx.execute("SELECT count(*) FROM visits").fetchone()[0],
          " shifts left:", cx.execute("SELECT count(*) FROM agent_shifts").fetchone()[0])
    if commit:
        cx.commit(); print("\nCOMMITTED to", DB)
    else:
        cx.rollback(); print("\nDRY RUN — rolled back, nothing written to", DB)
except Exception:
    cx.rollback(); raise
