#!/usr/bin/env python3
"""DRY RUN ON A COPY — can the Clear button still eat the book?

Boots a throwaway CRM on a COPY of the live data (never the live dir, and the
data dir is passed explicitly so it cannot land on it), then replays the exact
shapes of request the browser used to be able to send on 2026-08-24, plus the
new ones. Nothing here touches the live database.

    python3 dryrun_clear_guard.py
"""
import json, os, shutil, subprocess, sys, tempfile, time, urllib.error, urllib.request

HERE = "/root/pest-crm"
LIVE = "/root/pest-crm/data"
PORT = 8931

tmp = tempfile.mkdtemp(prefix="clearguard-")
for f in ("crm.db", "crm.db-wal", "crm.db-shm"):
    src = os.path.join(LIVE, f)
    if os.path.exists(src):
        shutil.copy2(src, os.path.join(tmp, f))
print("copy of the live book at", tmp)

env = dict(os.environ, PESTCRM_DATA_DIR=tmp,
           PESTCRM_UPLOAD_DIR=os.path.join(tmp, "uploads"))
proc = subprocess.Popen([sys.executable, "server.py", str(PORT)], cwd=HERE, env=env,
                        stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
BASE = "http://127.0.0.1:%d/api" % PORT


def call(method, path, token, body=None):
    data = json.dumps(body).encode() if body is not None else None
    req = urllib.request.Request(BASE + path, data=data, method=method,
                                 headers={"Content-Type": "application/json",
                                          "Authorization": "Bearer " + (token or "")})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw or b"null")
        except Exception:
            return e.code, {"raw": raw[:200].decode("utf8", "replace")}


try:
    for _ in range(80):
        try:
            urllib.request.urlopen("http://127.0.0.1:%d/" % PORT, timeout=1)
            break
        except Exception:
            time.sleep(0.25)

    sys.path.insert(0, HERE)
    os.environ["PESTCRM_DATA_DIR"] = tmp
    import auth
    admin = auth.make_token(1, 19)

    _, book = call("POST", "/schedule/clear", admin,
                   {"from": "2026-09-01", "to": "2026-09-30"})
    total = book["visits"]
    print("\nthe copy holds %d clearable September visits, %d shift rows"
          % (total, book["shifts"]))

    print("\n-- THE 2026-08-24 SHAPES, REPLAYED --")
    for label, body in (
            ('what the browser sent at 07:46 (no filters at all)', {}),
            ('the same with the old "all" flag', {"all": True}),
            ('"Every date" as the old button built it', {"from": "", "to": "", "all": True}),
            ('a customer, no dates', {"client_id": 1}),
            ('an engineer, no dates', {"agent_id": 11}),
    ):
        st, r = call("POST", "/schedule/clear", admin, body)
        print("  %-46s HTTP %s  %s" % (label, st, (r or {}).get("error")
                                       or (r or {}).get("message") or ""))

    print("\n-- WHAT A NORMAL CLEAR DOES NOW --")
    st, sep = call("POST", "/schedule/clear", admin,
                   {"from": "2026-09-01", "to": "2026-09-30"})
    print("  September preview        : %d visits, %d shifts, scope=%s, range %s..%s"
          % (sep["visits"], sep["shifts"], sep["scope"],
             sep["range"]["from"], sep["range"]["to"]))
    print("  runs it would cut into   : %s" % (sep["runs_affected"] or "-"))
    tail = [v for v in sep["sample_ids"]]
    st, oct1 = call("POST", "/schedule/clear", admin,
                    {"from": "2026-10-01", "to": "2026-10-01"})
    print("  the 30 Sept night tail   : September now reaches %d visits "
          "(the old date bound reached 846); a clear of 1 Oct alone finds %d"
          % (sep["visits"], oct1["visits"]))

    print("\n-- APPLYING TAKES THE COUNTS BACK --")
    st, _ = call("POST", "/schedule/clear", admin,
                 {"from": "2026-09-01", "to": "2026-09-30", "apply": True})
    print("  apply with no echoed counts        : HTTP %s" % st)
    st, _ = call("POST", "/schedule/clear", admin,
                 {"from": "2026-09-01", "to": "2026-09-30", "apply": True,
                  "expect_visits": sep["visits"] - 3, "expect_shifts": sep["shifts"]})
    print("  apply with a stale count           : HTTP %s" % st)

    print("\n-- THE WHOLE BOOK, THE NEW WAY --")
    st, whole = call("POST", "/schedule/clear", admin, {"scope": "everything"})
    print("  preview as the owner               : HTTP %s, %d visits across every month"
          % (st, (whole or {}).get("visits", -1)))
    st, _ = call("POST", "/schedule/clear", admin,
                 {"scope": "everything", "apply": True,
                  "expect_visits": whole["visits"], "expect_shifts": whole["shifts"]})
    print("  apply without the word             : HTTP %s" % st)

    print("\n-- AND IT STILL WORKS WHEN IT IS MEANT TO --")
    st, sep2 = call("POST", "/schedule/clear", admin,
                    {"from": "2026-09-01", "to": "2026-09-30"})
    st, done = call("POST", "/schedule/clear", admin,
                    {"from": "2026-09-01", "to": "2026-09-30", "apply": True,
                     "expect_visits": sep2["visits"], "expect_shifts": sep2["shifts"]})
    print("  September cleared for real         : HTTP %s, %d visits, %d shifts"
          % (st, done["visits"], done["shifts"]))
    print("  runs reconciled                    : %s"
          % json.dumps(done.get("runs_reconciled")))
    _, runs = call("GET", "/shifts/auto/runs", admin)
    for r in (runs or [])[:2]:
        print("     run %s: undone_at=%s cleared_at=%s cleared_visits=%s"
              % (r["id"], r["undone_at"], r.get("cleared_at"), r.get("cleared_visits")))
    _, left = call("POST", "/schedule/clear", admin, {"scope": "everything"})
    print("  anything left anywhere on the book : %d visits" % left["visits"])
finally:
    proc.terminate()
    proc.wait(timeout=10)
    print("\nthrowaway server stopped; live data never opened")
    print("copy left at", tmp)
