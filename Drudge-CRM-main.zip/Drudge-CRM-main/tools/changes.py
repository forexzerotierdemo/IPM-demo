#!/usr/bin/env python3
"""WHAT MOVED, BY NAME — the branches and the people to look at on the screen."""
import collections, json, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
c = json.load(open(os.path.join(HERE, "out", "compare.json")))
OLD, NEW = c["OLD"], c["NEW"]
names = {int(k): v for k, v in c["names"].items()}
bn = {int(k): v for k, v in c["bnames"].items()}
nm = lambda i: names.get(int(i), "agent %s" % i)


def main_hand(assign, sid):
    """Who actually drives that branch this month, and how split it is."""
    ctr = assign.get(str(sid)) or assign.get(sid) or {}
    ctr = {int(k): v for k, v in ctr.items()}
    if not ctr:
        return None, 0, {}
    top = max(ctr.items(), key=lambda kv: kv[1])
    return top[0], sum(ctr.values()), ctr


sids = {int(k) for k in OLD["assignment"]} | {int(k) for k in NEW["assignment"]}
handovers, splits, count_moves = [], [], []
for sid in sorted(sids):
    o_top, o_n, o_c = main_hand(OLD["assignment"], sid)
    n_top, n_n, n_c = main_hand(NEW["assignment"], sid)
    if o_c == n_c:
        continue          # the same hands, the same share — max() ties are not news
    if o_top != n_top and o_c.get(n_top, 0) != n_c.get(n_top, 0):
        handovers.append((bn.get(sid, sid), nm(o_top) if o_top else "-",
                          nm(n_top) if n_top else "-", o_n, n_n))
    elif set(o_c) != set(n_c):
        splits.append((bn.get(sid, sid), sorted(nm(a) for a in o_c),
                       sorted(nm(a) for a in n_c)))
    if o_n != n_n:
        count_moves.append((bn.get(sid, sid), o_n, n_n))

print("=" * 74)
print("BRANCHES THAT CHANGE HANDS  (main engineer for the month)  — %d" % len(handovers))
print("=" * 74)
for b, o, n, on, nn in sorted(handovers):
    print("   %-34s %-16s -> %-16s  (%d visits)" % (b[:34], o[:16], n[:16], nn))

print("\n" + "=" * 74)
print("BRANCHES WHOSE MONTH IS SHARED DIFFERENTLY (same main hand) — %d" % len(splits))
print("=" * 74)
for b, o, n in sorted(splits):
    print("   %-34s %s -> %s" % (b[:34], ", ".join(x[:14] for x in o),
                                 ", ".join(x[:14] for x in n)))

print("\n" + "=" * 74)
print("BRANCHES WHOSE VISIT COUNT CHANGES — %d" % len(count_moves))
print("=" * 74)
for b, o, n in sorted(count_moves):
    print("   %-34s %d -> %d" % (b[:34], o, n))

print("\n" + "=" * 74)
print("LOAD PER ENGINEER   visits (days)")
print("=" * 74)
ov = {int(k): v for k, v in OLD["per_engineer"].items()}
nv = {int(k): v for k, v in NEW["per_engineer"].items()}
od = {int(k): v for k, v in OLD["per_engineer_days"].items()}
nd = {int(k): v for k, v in NEW["per_engineer_days"].items()}
rows = []
for a in sorted(set(ov) | set(nv), key=lambda x: -(nv.get(x, 0))):
    rows.append((nm(a), ov.get(a, 0), nv.get(a, 0), od.get(a, 0), nd.get(a, 0)))
print("   %-22s %14s   %14s" % ("engineer", "OLD", "NEW"))
for n, a, b, c_, d in rows:
    flag = ""
    if abs(b - a) >= 15 or (a and abs(b - a) / a >= 0.3):
        flag = "   <-- LOOK"
    print("   %-22s %5d v %3d d   %5d v %3d d%s" % (n[:22], a, c_, b, d, flag))

print("\n" + "=" * 74)
print("SPACING WATCH — branches tighter than half their own interval")
print("=" * 74)
o_names = {t[0] for t in OLD["spacing_watch_list"]}
n_names = {t[0] for t in NEW["spacing_watch_list"]}
for t in NEW["spacing_watch_list"]:
    mark = "  <-- NEW THIS PLAN" if t[0] not in o_names else ""
    print("   %-34s %5s/month  closest %s day(s)  normal %s%s" % (t[0][:34], t[1], t[2], t[3], mark))
gone = o_names - n_names
print("   dropped off the watch: %s" % (", ".join(sorted(gone)) if gone else "none"))
print("   appeared on the watch: %s" % (", ".join(sorted(n_names - o_names)) or "none"))

print("\n" + "=" * 74)
print("UNDER-SERVICED / OVER-SERVICED")
print("=" * 74)
print("   OLD under:", OLD["under_serviced_list"], "\n   NEW under:", NEW["under_serviced_list"])
print("   OLD over :", OLD["over_serviced_list"], "\n   NEW over :", NEW["over_serviced_list"])

print("\n" + "=" * 74)
print("WHAT THE NEW PLAN HAD TO BEND (rescued visits) — %d" % len(c["compromises"]))
print("=" * 74)
for x in c["compromises"]:
    print("   %s  %-18s %-30s %s" % (x["date"], x["agent_name"][:18], x["site_name"][:30], x["kind"]))

print("\n" + "=" * 74)
print("NEW PLAN, LEFT UNPLACED — %d" % len(c["unplaced_rows"]))
print("=" * 74)
for x in c["unplaced_rows"]:
    print("   ", x)
print("\nCAPPED (what the book asks that arithmetic cannot give) — %d" % len(c["capped"]))
for x in c["capped"]:
    print("   ", x)
