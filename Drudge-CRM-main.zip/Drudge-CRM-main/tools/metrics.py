#!/usr/bin/env python3
"""ONE RULER FOR BOTH PLANS.

Every number the office asked for is computed here, from a plain list of
stops, so the OLD book (read out of the diary) and the NEW plan (read out of
the preview) are measured by exactly the same code. Nothing here writes.

A STOP is: (agent_id, round_date, site_id, start_min, dur_min) where start_min
is minutes from midnight of round_date and may run past 1440 for a night round.
"""
import calendar, collections, datetime as dt

DAY = 1440


def group_days(stops):
    d = collections.defaultdict(list)
    for st in stops:
        d[(st["agent_id"], st["date"])].append(st)
    for v in d.values():
        v.sort(key=lambda s: s["start"])
    return d


def measure(stops, unplaced, book, year, month, s):
    """Every column, from the stops and the book the planner itself loaded."""
    branches, areas = book["branches"], book["areas"]
    people = book["people"]
    days = group_days(stops)
    span = calendar.monthrange(year, month)[1]
    first, last = dt.date(year, month, 1), dt.date(year, month, span)
    m = {}

    # ---- 1-4 the contract columns ---------------------------------------
    m["booked"] = len(stops)
    m["unplaced"] = len(unplaced)
    m["owed"] = len(stops) + len(unplaced)

    per_branch = collections.Counter(st["site_id"] for st in stops)
    over = []
    for sid, n in per_branch.items():
        b = branches.get(sid)
        if not b or not b.vpm:
            continue
        quota = len(month_slots_for(b, year, month))
        if n > quota:
            over.append((b.name, quota, n))
    m["over_serviced_branches"] = len(over)
    m["over_serviced_visits"] = sum(n - q for _name, q, n in over)
    m["over_serviced_list"] = sorted(over, key=lambda x: -(x[2] - x[1]))
    under = []
    for sid, b in branches.items():
        quota = len(month_slots_for(b, year, month))
        n = per_branch.get(sid, 0)
        if quota and n < quota:
            under.append((b.name, quota, n))
    m["under_serviced_branches"] = len(under)
    m["under_serviced_visits"] = sum(q - n for _x, q, n in under)
    m["under_serviced_list"] = sorted(under, key=lambda x: -(x[1] - x[2]))

    # ---- 5-7 the shape of the working month ------------------------------
    sizes = [len(v) for v in days.values()]
    m["engineer_days"] = len(days)
    m["thin_days"] = sum(1 for n in sizes if n <= 2)
    m["solo_days"] = sum(1 for n in sizes if n == 1)
    m["visits_per_day"] = round(len(stops) / len(days), 2) if days else 0
    m["engineers_used"] = len({a for a, _d in days})

    # ---- 8 cover ---------------------------------------------------------
    cover = [st for st in stops
             if branches.get(st["site_id"]) is not None
             and branches[st["site_id"]].owner_id
             and branches[st["site_id"]].owner_id != st["agent_id"]]
    m["cover_visits"] = len(cover)
    m["cover_branches"] = len({st["site_id"] for st in cover})

    # ---- 9 bent rounds, 12 zone/district ---------------------------------
    bent = zone_cross = three_patch = revisit = 0
    district_changes = 0
    for key, sts in days.items():
        seq = [branches[st["site_id"]].area_id for st in sts
               if st["site_id"] in branches]
        zs = {branches[st["site_id"]].zone_id for st in sts
              if st["site_id"] in branches and branches[st["site_id"]].zone_id}
        runs = [a for i, a in enumerate(seq) if i == 0 or a != seq[i - 1]]
        district_changes += max(0, len(runs) - 1)
        n_patch = len(set(seq))
        rev = len(runs) > n_patch
        big = n_patch > int(s["areas_per_day"])
        crossed = len(zs) > 1
        zone_cross += crossed
        three_patch += big
        revisit += rev
        bent += (rev or big or crossed)
    m["bent_rounds"] = bent
    m["rounds_two_zones"] = zone_cross
    m["rounds_over_patch_cap"] = three_patch
    m["rounds_revisiting_a_patch"] = revisit
    m["district_changes"] = district_changes

    # ---- 13 travel --------------------------------------------------------
    hops = travel = 0
    for key, sts in days.items():
        prev = None
        for st in sts:
            b = branches.get(st["site_id"])
            if b is None:
                continue
            if prev is not None:
                hops += 1
                travel += travel_between(prev, b, s)
            prev = b
    m["charged_hops"] = hops
    m["travel_minutes"] = travel
    m["travel_hours"] = round(travel / 60.0, 1)
    m["minutes_per_hop"] = round(travel / hops, 1) if hops else 0
    m["onsite_hours"] = round(sum(st["dur"] for st in stops) / 60.0, 1)

    # ---- 10 spacing / rhythm ---------------------------------------------
    when = collections.defaultdict(list)
    for st in stops:
        when[st["site_id"]].append(dt.date.fromordinal(st["date"].toordinal()))
    tight = []
    gaps_all = []
    for sid, ds in when.items():
        b = branches.get(sid)
        if not b or not b.vpm or len(ds) < 2:
            continue
        ivl = (7.0 / b.vpm) if b.freq_unit == "week" else (span / float(b.vpm))
        ds = sorted(ds)
        gap = min((y - x).days for x, y in zip(ds, ds[1:]))
        gaps_all.append(gap)
        if gap < ivl / 2:
            tight.append((b.name, b.vpm, gap, round(ivl, 1)))
    m["spacing_watch"] = len(tight)
    m["spacing_watch_list"] = sorted(tight, key=lambda t: t[2])
    m["spacing_min_gap_avg"] = round(sum(gaps_all) / len(gaps_all), 2) if gaps_all else 0
    m["same_day_doubles"] = sum(1 for g in gaps_all if g == 0)

    # ---- 11 due-date deviation -------------------------------------------
    devs = []
    for sid, ds in when.items():
        b = branches.get(sid)
        if not b:
            continue
        want = month_slots_for(b, year, month)
        if not want:
            continue
        got = sorted(ds)
        for a, bb in zip(want, got):
            devs.append(abs((bb - a).days))
    m["due_dev_avg"] = round(sum(devs) / len(devs), 2) if devs else 0
    m["due_dev_worst"] = max(devs) if devs else 0
    m["due_dev_over_3"] = sum(1 for d in devs if d > 3)
    m["due_dev_on_the_day"] = sum(1 for d in devs if d == 0)

    # ---- 14-16 the hard rules --------------------------------------------
    dbl = []
    by_agent = collections.defaultdict(list)
    for st in stops:
        o = dt.datetime.combine(st["date"], dt.time()) + dt.timedelta(minutes=st["start"])
        by_agent[st["agent_id"]].append((o, o + dt.timedelta(minutes=st["dur"]), st))
    for a, l in by_agent.items():
        l.sort()
        for (s1, e1, x1), (s2, e2, x2) in zip(l, l[1:]):
            if s2 < e1:
                dbl.append((a, x1["site_id"], x2["site_id"], s1.isoformat(), s2.isoformat()))
    m["double_bookings"] = len(dbl)
    m["double_booking_list"] = dbl[:20]

    out_hours, out_window = [], []
    for st in stops:
        b = branches.get(st["site_id"])
        p = people.get(st["agent_id"])
        wd = st["date"].weekday()      # Monday=0, the planner's own convention
        if p is not None:
            hrs = p.hours(wd)
            if hrs is None:
                out_hours.append((st, "not working that day"))
            else:
                lo, hi = hrs
                if st["start"] < lo or st["start"] + st["dur"] > hi:
                    out_hours.append((st, "%d-%d vs %d-%d" %
                                      (st["start"], st["start"] + st["dur"], lo, hi)))
        if b is not None:
            wf, wt = b.window_on(wd)
            ok = any(st["start"] >= f and st["start"] + st["dur"] <= t
                     for f, t in ((wf, wt), (wf + DAY, wt + DAY)))
            if not ok:
                out_window.append((st, "%d-%d vs %d-%d" %
                                   (st["start"], st["start"] + st["dur"], wf, wt)))
    m["outside_engineer_hours"] = len(out_hours)
    m["outside_branch_window"] = len(out_window)
    m["outside_hours_list"] = [(branches[x["site_id"]].name if x["site_id"] in branches
                                else x["site_id"], x["date"].isoformat(), why)
                               for x, why in out_hours[:20]]
    m["outside_window_list"] = [(branches[x["site_id"]].name if x["site_id"] in branches
                                 else x["site_id"], x["date"].isoformat(), why)
                                for x, why in out_window[:20]]

    # ---- who carries what -------------------------------------------------
    m["per_engineer"] = collections.Counter(st["agent_id"] for st in stops)
    m["per_engineer_days"] = collections.Counter(a for a, _d in days)
    m["assignment"] = {}
    for st in stops:
        m["assignment"].setdefault(st["site_id"], collections.Counter())[st["agent_id"]] += 1
    return m


def month_slots_for(b, year, month):
    import roster
    if b.freq_unit == "week":
        return []                       # a weekly rhythm has no fixed due date
    return roster.month_slots(b.vpm, year, month)


def travel_between(a, b, s):
    import roster
    if a.geo and b.geo:
        km = roster.haversine_km(a.geo, b.geo)
        mins = int(round(km / max(1.0, s["travel_kmh"]) * 60))
        cap = int(s["travel_max"])
        if cap <= 0:
            return 0
        return min(max(5, mins), cap)
    if a.client_id == b.client_id and a.area_id == b.area_id:
        return 0
    if int(s["travel_max"]) <= 0:
        return 0
    return s["travel_area"] if a.area_id == b.area_id else s["travel_max"]
