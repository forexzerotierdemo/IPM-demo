#!/usr/bin/env python3
"""VERIFY THE CLEAR GUARD ON THE RUNNING CRM — WITHOUT CLEARING ANYTHING.

Every call here is either a refusal (the server answers 4xx and writes nothing)
or a PREVIEW (`apply` is deliberately absent, so the route returns counts and
returns early). Nothing in this file can delete a visit: the word `apply` never
appears in a request body, which is the only thing that makes the route write.

    python3 verify_clear_guard_live.py
"""
import json, os, sys, urllib.error, urllib.request

os.environ.setdefault("PESTCRM_DATA_DIR", "/root/pest-crm/data")
sys.path.insert(0, "/root/pest-crm")
import auth

BASE = "http://127.0.0.1:8000/api"
admin = auth.make_token(1, 19)              # the live owner, id 1


def call(path, token, body):
    assert "apply" not in body, "this script must never apply anything"
    req = urllib.request.Request(
        BASE + path, data=json.dumps(body).encode(), method="POST",
        headers={"Content-Type": "application/json", "Authorization": "Bearer " + token})
    try:
        with urllib.request.urlopen(req, timeout=300) as r:
            return r.status, json.loads(r.read() or b"null")
    except urllib.error.HTTPError as e:
        raw = e.read()
        try:
            return e.code, json.loads(raw or b"null")
        except Exception:
            return e.code, {}


def msg(r):
    return (r or {}).get("error") or (r or {}).get("message") or ""


ok = True


def show(label, got, want):
    global ok
    good = got == want
    ok = ok and good
    print("  %-52s %-22s %s" % (label, got, "OK" if good else "*** EXPECTED %s ***" % want))


print("1. A NORMAL BOUNDED CLEAR STILL PREVIEWS")
st, sep = call("/schedule/clear", admin, {"from": "2026-09-01", "to": "2026-09-30"})
show("September preview", "HTTP %s" % st, "HTTP 200")
print("     %d visits, %d shifts, scope=%s, range %s..%s, runs %s"
      % (sep["visits"], sep["shifts"], sep["scope"],
         sep["range"]["from"], sep["range"]["to"], sep["runs_affected"]))

print("\n2. AN UNBOUNDED CLEAR IS REFUSED")
for label, body in (("no filters at all (the 07:46 shape)", {}),
                    ("the old 'all' flag", {"all": True}),
                    ("a customer, no dates", {"client_id": 1}),
                    ("an engineer, no dates", {"agent_id": 11}),
                    ("only a start date", {"from": "2026-09-01"})):
    st, r = call("/schedule/clear", admin, body)
    show(label, "HTTP %s" % st, "HTTP 400")
print("     server says: %s" % msg(call("/schedule/clear", admin, {})[1]))

print("\n3. A MANAGER CANNOT ASK FOR THE WHOLE BOOK")
import database as db
db.init_db()
# The token version is the user's OWN — minting one with somebody else's just
# gets a 401, which would prove nothing about permissions.
rows = db.query("SELECT id, full_name, token_version FROM users "
                "WHERE role='manager' AND active=1 LIMIT 1")
if rows:
    tok = auth.make_token(rows[0]["id"], rows[0]["token_version"])
    st, r = call("/schedule/clear", tok, {"scope": "everything"})
    show("manager '%s' asks for everything" % rows[0]["full_name"], "HTTP %s" % st, "HTTP 403")
    st, r = call("/schedule/clear", tok, {"from": "2026-09-01", "to": "2026-09-30"})
    show("but the same manager may preview a month", "HTTP %s" % st, "HTTP 200")
else:
    print("  (no manager on the books to test with)")

print("\n4. THE OWNER'S WHOLE-BOOK CLEAR NEEDS THE WORD")
st, whole = call("/schedule/clear", admin, {"scope": "everything"})
show("owner previews the whole book", "HTTP %s" % st, "HTTP 200")
print("     it would reach %d visits across every month (scope=%s)"
      % (whole["visits"], whole["scope"]))
print("     an apply without the word EVERYTHING is refused by the same route —")
print("     not exercised here, because this script never sends `apply`.")

print("\n5. SEPTEMBER INCLUDES THE OVERNIGHT TAIL")
tail = db.query("SELECT id, agent_id, scheduled_start FROM visits "
                "WHERE scheduled_start >= '2026-10-01'")
inside = [t["id"] for t in tail if t["id"] in set(sep["sample_ids"])]
show("the 30 Sept night-tail stops", "%d of %d in range" % (len(inside), len(tail)),
     "%d of %d in range" % (len(tail), len(tail)))
for t in tail:
    print("     visit %s agent %s starts %s -> %s"
          % (t["id"], t["agent_id"], t["scheduled_start"],
             "IN the September clear" if t["id"] in inside else "ORPHANED"))
st, oct1 = call("/schedule/clear", admin, {"from": "2026-10-01", "to": "2026-10-01"})
show("a 1-October-only clear finds", "%d visits" % oct1["visits"], "0 visits")
show("September reaches", "%d visits" % sep["visits"], "848 visits")

print("\n%s" % ("ALL CHECKS OK" if ok else "*** SOMETHING IS NOT AS EXPECTED ***"))
print("nothing was cleared: no request in this file carried `apply`")
sys.exit(0 if ok else 1)
