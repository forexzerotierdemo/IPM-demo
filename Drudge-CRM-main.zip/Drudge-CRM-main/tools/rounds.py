#!/usr/bin/env python3
"""READING ROUNDS BACK OUT OF THE DIARY, EXACTLY.

The apply path writes a stop as `round_date + start_day`, so a visit sitting at
00:15 on the 11th is either the first call of the 11th or the last call of the
10th, and the row itself does not say which. Two things decide it and both come
from the planner's own model:

  * the run wrote a shift row for every (engineer, round date) it used, so a
    date that carries no shift row of his was never a round of his;
  * a round is timed inside the man's hours for its own date, so a stop that
    would fall outside them on one reading belongs to the other.

Where both readings survive, the stop joins the round it is CONTIGUOUS with —
the planner never leaves a hole in a day it could close.
"""
import datetime as dt

DAY = 1440


def rounds_from_diary(visits, shift_days, people):
    """visits: (agent_id, start_dt, end_dt, site_id). Returns stops + a report."""
    out, report = [], {"own_day": 0, "night_tail": 0, "ambiguous": 0, "unresolved": []}
    by_agent = {}
    for a, s, e, sid in visits:
        by_agent.setdefault(a, []).append((s, e, sid))
    for a, rows in by_agent.items():
        rows.sort()
        person = people.get(a)
        placed = {}
        for s, e, sid in rows:
            d = s.date()
            prev = d - dt.timedelta(days=1)
            tod = s.hour * 60 + s.minute
            dur = int((e - s).total_seconds() // 60)
            cands = []
            for rd, start in ((d, tod), (prev, tod + DAY)):
                if (a, rd.isoformat()) not in shift_days:
                    continue
                hrs = person.hours(rd.weekday()) if person else (0, DAY)
                if hrs is None:
                    continue
                lo, hi = hrs
                if start >= lo and start + dur <= hi:
                    cands.append((rd, start))
            if not cands:
                report["unresolved"].append((a, s.isoformat(), sid))
                rd, start = (d, tod) if (a, d.isoformat()) in shift_days else (prev, tod + DAY)
                cands = [(rd, start)]
            elif len(cands) > 1:
                # Both readings hold. Take the one that continues a round
                # already running — a day the planner built has no gap in it
                # that the next stop could not have filled.
                report["ambiguous"] += 1
                cands.sort(key=lambda c: -(placed.get(c[0]) or -10 ** 9))
            rd, start = cands[0]
            report["night_tail" if rd != s.date() else "own_day"] += 1
            placed[rd] = max(placed.get(rd, -10 ** 9), start + dur)
            out.append({"agent_id": a, "date": rd, "site_id": sid,
                        "start": start, "dur": dur})
    return out, report
