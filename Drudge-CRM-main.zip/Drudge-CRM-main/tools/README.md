# tools — measuring the roster, and proving a change before it ships

These are the scripts the September 2026 acceptance test and the Clear-Schedule
guard were built with. They were kept outside the repo while the work was in
flight; they are here now because several of them are the only honest way to
answer a question that comes up every time the planner or the diary changes.

## READ THIS FIRST — most of these can see the LIVE book

Several scripts default to `/root/pest-crm/data`, which is the **live database
the business runs on**. The standing rule is that live data is never written to
except on the owner's explicit word.

* Scripts that only ever **read** live: `verify_clear_guard_live.py`,
  `preview_on_live_server.py`, `export_baseline.py`.
* Scripts that **write** if you let them: `clear_september.py` (needs
  `--commit`; without it, it reports and rolls back).
* Scripts that work on a **copy** and never touch live: `dryrun_clear_guard.py`,
  `compare.py` (which refuses the live dir outright unless passed `--live`).

When booting a throwaway server against a copy, **always** pass
`PESTCRM_DATA_DIR` explicitly, or it lands on live.

## What each one is for

| script | what it does |
|---|---|
| `rounds.py` | Reads the diary back as **rounds**. A night round writes onto two dates and the row does not say which one it belongs to; this decides it from the run's own shift rows plus the man's hours. `roundtrip_test.py` proves it by feeding the planner's own output through and getting every round and stop back exactly. |
| `metrics.py` | One ruler for both plans — every column the office asks for (owed, booked, unplaced, engineer-days, thin/solo days, cover, rounds, driving, rhythm, the hard rules), computed from a plain list of stops so an old book and a new plan are measured by identical code. |
| `compare.py` | OLD → NEW for a month, both measured by `metrics.py`. Takes the dir holding the old diary and a dir to plan in. Refuses to plan in the live dir. |
| `roundtrip_test.py` | Proves `rounds.py` against the planner's own output. Run it before trusting any engineer-day number. |
| `changes.py` | Which branches and engineers change hands between two plans — the list to eyeball before applying. |
| `export_baseline.py` | Exports the current diary as CSV/JSON so a plan can be compared against it later. |
| `clear_september.py` | Clears only the **generated** visits in a window, refusing if it finds a single row it is unsure of. Dry-run by default. |
| `preview_on_live_server.py` | Presses the Auto-Roster button on the running CRM in **preview** shape — `apply` is deliberately absent, so it writes nothing. |
| `dryrun_clear_guard.py` | Boots a throwaway CRM on a **copy** of the live book and replays every shape of Clear request, including the ones that took a month off the book on 2026-08-24. |
| `verify_clear_guard_live.py` | Checks the Clear guard on the **running** CRM without clearing anything — it asserts that no request it sends carries `apply`. |

## Added with the roster release (2026-08-27)

| script | what it does |
|---|---|
| `config_health.py` | **Run this before pressing Auto Roster.** Grades every active branch on what the BOOK makes impossible — `no_eligible_coverage`, `window_too_short`, `frequency_impossible`, `travel_isolated`, `zero_slack`, `single_point`, `healthy` — so a problem is found as a field somebody can edit rather than as a worklist afterwards. Three traps it had to be calibrated for are in its docstring; read them before trusting a change to it. |
| `owed_audit.py` | Owed counted three ways — what the office typed, what the gap warning compares against, and what the planner actually deals — with every branch where they disagree. |
| `capacity_audit.py` | For every unplaced visit, tries it against EVERY engineer on EVERY open day with the planner's own `Day.try_insert`, and names the blocker. Proves whether capacity really is gone. |
| `doors.py` | Scans a plan GLOBALLY for one branch given to two engineers on one date — the check `metrics.py` has no column for. |
| `rebalance_dryrun.py` | September-December with the rebalance rescue on and off, side by side. |
| `scenario.py` | One named what-if per process on its own fresh copy, so nothing leaks between runs. `owed = booked + unplaced` is checked PER BRANCH. |
| `shift_audit.py` | Every typed shift and the minutes the planner derives from it, so a 22:00-06:00 can be read against what it actually means. Flags odd days. |
| `system_review.py` | The whole operating picture as one JSON: engineers, areas, difficult branches and the scenario comparison. |
| `final_acceptance.py` | The release gate: all fixes together, then the proposed shifts, then every engineer-weekday removal one at a time to prove no configuration loses demand silently. |
| `apply_scenario_c.py` | The two approved shift changes. Dry-run by default; refuses to write unless the live rows are exactly what was audited; backs up first and prints the undo. |

## Not here

`apply_on_live_server.py` stays with the approved plan it guards, in
`/root/sept-acceptance-2026-08-24/`. It refuses to apply unless the plan the
server draws is byte-identical to that JSON, so it is meaningless without it.
