#!/usr/bin/env python3
"""TWO VANS AT ONE DOOR — the September dry run, before and after.

    python3 doors.py <label>            # plans on a COPY of live, never live

Plans the month on a throwaway copy of the book, measures it with the same
ruler both plans use (metrics.py), and adds the one column metrics.py has no
opinion about: a branch handed to TWO DIFFERENT ENGINEERS on one date. That
scan is GLOBAL — every engineer against every other — because the bug it
exists for is invisible from inside any single man's day.

Writes tools/out/doors-<label>.json so a before can be held against an after.
"""
import calendar, collections, datetime as dt, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
YEAR, MONTH = 2026, 9
# Matched loosely on purpose: his book spells one of these
# "1980 Coffee  park street", with two spaces and no capital.
WATCH = ["new giza", "coffee maadi", "park street"]

label = sys.argv[1] if len(sys.argv) > 1 else "run"


def copy_of_live():
    """A CONSISTENT copy, taken through SQLite's own backup so a half-written
    page can never be read, and never a byte written back to live."""
    work = tempfile.mkdtemp(prefix="doors-")
    src = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
    dst = sqlite3.connect(os.path.join(work, "crm.db"))
    src.backup(dst); dst.commit(); dst.close(); src.close()
    for extra in ("secret.key",):
        p = os.path.join(LIVE, extra)
        if os.path.exists(p):
            shutil.copy(p, work)
    return work


work = copy_of_live()
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server, metrics

S = server._roster_settings()
last = calendar.monthrange(YEAR, MONTH)[1]
frm, to = "%04d-%02d-01" % (YEAR, MONTH), "%04d-%02d-%02d" % (YEAR, MONTH, last)
t0 = dt.datetime.now()
plan = roster.plan(db, frm, to, S)
secs = (dt.datetime.now() - t0).total_seconds()
book = roster.load_book(db, frm, to)

stops = []
for day in plan["days"]:
    d = dt.date.fromisoformat(day["date"])
    for a in day["assignments"]:
        for v in a["visits"]:
            sm = (int(v["start"][:2]) * 60 + int(v["start"][3:5])
                  + 1440 * (v.get("start_day") or 0))
            stops.append({"agent_id": a["agent_id"], "date": d, "site_id": v["site_id"],
                          "start": sm, "dur": v["minutes"]})

M = metrics.measure(stops, plan["unplaced"], book, YEAR, MONTH, S)

# ---------------------------------------------------------------- THE SCAN
# Asked of the WHOLE PLAN at once. Two engineers, one branch, one date is a
# clash whether or not their hours overlap: the planner's own rule is one
# visit a day per branch, and the office's complaint was two vans at the door.
at_door = collections.defaultdict(list)
for st in stops:
    at_door[(st["date"], st["site_id"])].append(st)
clashes, overlapping = [], []
for (d, sid), l in sorted(at_door.items()):
    who = {st["agent_id"] for st in l}
    if len(who) < 2:
        continue
    row = {"date": d.isoformat(), "site_id": sid,
           "branch": book["branches"][sid].name if sid in book["branches"] else str(sid),
           "engineers": sorted(who),
           "visits": sorted((st["agent_id"], st["start"], st["start"] + st["dur"])
                            for st in l)}
    clashes.append(row)
    l2 = sorted(l, key=lambda s: s["start"])
    if any(y["start"] < x["start"] + x["dur"] and x["agent_id"] != y["agent_id"]
           for x, y in zip(l2, l2[1:])):
        overlapping.append(row)
M["door_clashes"] = len(clashes)
M["door_clashes_overlapping"] = len(overlapping)
M["door_clash_list"] = clashes

# ------------------------------------------------- the branches he named
when = collections.defaultdict(list)
for st in stops:
    when[st["site_id"]].append(st["date"])
watch = {}
for sid, b in book["branches"].items():
    if not any(w in " ".join(b.name.lower().split()) for w in WATCH):
        continue
    ds = sorted(when.get(sid, []))
    gaps = [(y - x).days for x, y in zip(ds, ds[1:])]
    watch[b.name] = {
        "owed": len(metrics.month_slots_for(b, YEAR, MONTH)),
        "booked": len(ds),
        "vpm": b.vpm, "freq_unit": b.freq_unit,
        "distinct_days": len(set(ds)),
        "span_days": (ds[-1] - ds[0]).days + 1 if ds else 0,
        "dates": [d.isoformat() for d in ds],
        "min_gap": min(gaps) if gaps else None,
        "engineers": sorted({st["agent_id"] for st in stops if st["site_id"] == sid}),
        "two_vans": [c["date"] for c in clashes if c["site_id"] == sid],
    }
M["watch"] = watch
M["seconds"] = round(secs, 1)
M["planner_summary"] = plan["summary"]

os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
out = os.path.join(HERE, "out", "doors-%s.json" % label)
json.dump(M, open(out, "w"), indent=1, default=str)

print("== %s   (%s .. %s, planned on a copy in %ss)" % (label, frm, to, M["seconds"]))
print("   booked %-5d unplaced %-4d owed %-5d" % (M["booked"], M["unplaced"], M["owed"]))
print("   TWO VANS AT ONE DOOR: %d  (of which hours overlap: %d)"
      % (M["door_clashes"], M["door_clashes_overlapping"]))
print("   cover visits %-5d cover branches %-4d" % (M["cover_visits"], M["cover_branches"]))
print("   travel %s h over %d hops (%s min/hop)"
      % (M["travel_hours"], M["charged_hops"], M["minutes_per_hop"]))
print("   under-serviced %d branches / %d visits    double-booked engineers %d"
      % (M["under_serviced_branches"], M["under_serviced_visits"], M["double_bookings"]))
for c in clashes:
    print("     ! %s  %-34s %s" % (c["date"], c["branch"][:34], c["engineers"]))
for name, w in watch.items():
    print("   %-24s owed %-3s booked %-3s on %-2s distinct days, span %-3s min gap %-4s two-vans %s"
          % (name, w["owed"], w["booked"], w["distinct_days"], w["span_days"],
             w["min_gap"], len(w["two_vans"])))
print("   copy: %s" % work)
