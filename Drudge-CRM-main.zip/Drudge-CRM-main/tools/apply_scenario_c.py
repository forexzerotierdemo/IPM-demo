#!/usr/bin/env python3
"""SCENARIO C — the two approved operational shift changes.

    python3 apply_scenario_c.py            # DRY RUN: shows, writes nothing
    python3 apply_scenario_c.py --commit   # writes to the LIVE book

    Amr Diab       Sunday    22:00-06:00 -> 15:00-18:00   (AMS Factory 16/16)
    Youssef Ahmed  Saturday  22:00-06:00 -> 06:00-16:00   (Cluture House 14/14)

Nothing else is touched: no permission, no customer service day, no visit, no
travel ceiling. It refuses to write unless the rows are EXACTLY what the audit
measured, so a book that has moved on since is never quietly overwritten.
It takes its own backup first, and prints how to undo.
"""
import os, sqlite3, sys, datetime as dt

LIVE = "/root/pest-crm/data/crm.db"
COMMIT = "--commit" in sys.argv
WD = "Mon Tue Wed Thu Fri Sat Sun".split()

# engineer, weekday, EXPECTED current, proposed
CHANGES = [("Amr Diab", 6, ("22:00", "06:00"), ("15:00", "18:00")),
           ("Youssef Ahmed", 5, ("22:00", "06:00"), ("06:00", "16:00"))]

cx = sqlite3.connect(LIVE)
cx.row_factory = sqlite3.Row
ids = {r["full_name"]: r["id"] for r in cx.execute("SELECT id, full_name FROM users")}

plan = []
stop = False
for who, wd, expect, want in CHANGES:
    if who not in ids:
        print("  !! no engineer named %r on the live book" % who); stop = True; continue
    row = cx.execute("SELECT id, start_time, end_time FROM agent_availability "
                     "WHERE agent_id=? AND weekday=?", (ids[who], wd)).fetchone()
    if row is None:
        print("  !! %s has no %s row at all — the book has changed" % (who, WD[wd]))
        stop = True; continue
    now = (row["start_time"], row["end_time"])
    ok = now == expect
    print("  %-16s %-4s  %s-%s  ->  %s-%s   %s"
          % (who, WD[wd], now[0], now[1], want[0], want[1],
             "OK" if ok else "!! EXPECTED %s-%s — REFUSING" % expect))
    if not ok:
        stop = True
    else:
        plan.append((row["id"], who, wd, now, want))

if stop:
    print("\nThe live book does not match what was audited. Nothing written.")
    sys.exit(1)
if not COMMIT:
    print("\nDRY RUN — nothing written. Re-run with --commit to apply.")
    sys.exit(0)

stamp = dt.datetime.now().strftime("%Y%m%d-%H%M%S")
backup = "%s.bak-scenarioC-%s" % (LIVE, stamp)
# THROUGH SQLITE'S OWN BACKUP, never a plain file copy. The live book runs in
# WAL mode, so copying crm.db alone captures whatever was last checkpointed and
# silently loses every write still sitting in the -wal — a "backup" that looks
# fine and is hours stale (proved on 2026-08-27, when a plain copy showed the
# night shifts that had been changed that morning).
_src = sqlite3.connect("file:%s?mode=ro" % LIVE, uri=True)
_dst = sqlite3.connect(backup)
_src.backup(_dst)
_dst.commit(); _dst.close(); _src.close()
print("\nbackup: %s" % backup)
for rid, who, wd, now, want in plan:
    cx.execute("UPDATE agent_availability SET start_time=?, end_time=? WHERE id=?",
               (want[0], want[1], rid))
cx.commit()
print("written: %d row(s)" % len(plan))
print("\nTO UNDO, run:")
for _rid, who, wd, now, _want in plan:
    print("   UPDATE agent_availability SET start_time='%s', end_time='%s' "
          "WHERE agent_id=%d AND weekday=%d;   -- %s %s"
          % (now[0], now[1], ids[who], wd, who, WD[wd]))
print("   (or restore the whole file from the backup above)")
