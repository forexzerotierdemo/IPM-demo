#!/usr/bin/env python3
"""PROVE THE RULER BEFORE TRUSTING IT.

Take the plan the planner just drew, write it out the way Apply would write it
into the diary (a date and a clock time, the round's own date thrown away),
then read it back with the same code that reads the OLD book. If the rounds
that come back are not the rounds that went in, every engineer-day number in
the comparison is guesswork."""
import datetime as dt, os, sys
HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
os.environ["PESTCRM_DATA_DIR"] = sys.argv[1]
import database as db
db.init_db()
import roster, server, rounds

s = server._roster_settings()
plan = roster.plan(db, "2026-09-01", "2026-09-30", s)
book = roster.load_book(db, "2026-09-01", "2026-09-30")

truth, diary, shift_days = {}, [], set()
for day in plan["days"]:
    d = dt.date.fromisoformat(day["date"])
    for a in day["assignments"]:
        aid = a["agent_id"]
        shift_days.add((aid, d.isoformat()))       # Apply writes one per area
        for v in a["visits"]:
            sm = int(v["start"][:2]) * 60 + int(v["start"][3:5]) + 1440 * (v.get("start_day") or 0)
            truth.setdefault((aid, d), []).append((v["site_id"], sm))
            o = dt.datetime.combine(d, dt.time()) + dt.timedelta(minutes=sm)
            diary.append((aid, o, o + dt.timedelta(minutes=v["minutes"]), v["site_id"]))

got_stops, report = rounds.rounds_from_diary(diary, shift_days, book["people"])
got = {}
for st in got_stops:
    got.setdefault((st["agent_id"], st["date"]), []).append((st["site_id"], st["start"]))

for k in truth: truth[k].sort()
for k in got: got[k].sort()
print("planner rounds      :", len(truth))
print("reconstructed rounds:", len(got))
print("reconstruction report:", {k: v for k, v in report.items() if k != "unresolved"},
      "unresolved:", len(report["unresolved"]))
print("stops in :", sum(len(v) for v in truth.values()), " stops out:", len(got_stops))
same = truth == got
print("ROUND-TRIP EXACT    :", same)
if not same:
    for k in sorted(set(truth) | set(got), key=str):
        if truth.get(k) != got.get(k):
            print("   MISMATCH", k, "\n     planner:", truth.get(k), "\n     read   :", got.get(k))
