#!/usr/bin/env python3
"""SYSTEM-LEVEL ROSTER REVIEW — the whole operating picture, as data.
Reads live read-only, plans on a throwaway copy, changes nothing anywhere.
"""
import collections, json, os, shutil, sqlite3, sys, tempfile

HERE = os.path.dirname(os.path.abspath(__file__))
sys.path.insert(0, HERE); sys.path.insert(0, "/root/pest-crm")
LIVE = "/root/pest-crm/data"
MONTHS = [(2026, 9), (2026, 10), (2026, 11), (2026, 12)]
WD = "Mon Tue Wed Thu Fri Sat Sun".split()
work = tempfile.mkdtemp(prefix="sysrev-")
s_ = sqlite3.connect("file:%s/crm.db?mode=ro" % LIVE, uri=True)
d_ = sqlite3.connect(os.path.join(work, "crm.db"))
s_.backup(d_); d_.commit(); d_.close(); s_.close()
shutil.copy(os.path.join(LIVE, "secret.key"), work)
os.environ["PESTCRM_DATA_DIR"] = work
import database as db
db.init_db()
import roster, server

S = dict(roster.DEFAULTS, **server._roster_settings()); S["rebalance"] = 1
CEIL = int(S["travel_max"])
IDS = {r["full_name"]: r["id"] for r in db.query("SELECT id, full_name FROM users")}
NAME = {v: k for k, v in IDS.items()}
ORIG_H = {(r["agent_id"], r["weekday"]): (r["start_time"], r["end_time"])
          for r in db.query("SELECT agent_id,weekday,start_time,end_time FROM agent_availability")}
GRAB = {}
_o = roster._render


def spy(days, book, ow, un, s, f, t, c, cm=(0, 0)):
    GRAB["days"] = days; GRAB["book"] = book
    return _o(days, book, ow, un, s, f, t, c, cm)


roster._render = spy


def measure():
    owed = collections.Counter(); booked = collections.Counter()
    unpl = collections.Counter(); cap = collections.Counter()
    per_ag = collections.Counter(); per_min = collections.Counter()
    avail = collections.Counter(); free_days = collections.Counter()
    night_v = collections.Counter(); day_v = collections.Counter()
    cover = 0; clashes = 0; travel = 0; comp = 0
    names = {}
    for (Y, M) in MONTHS:
        span = roster.days_in_month(Y, M)
        frm, to = "%04d-%02d-01" % (Y, M), "%04d-%02d-%02d" % (Y, M, span)
        p = roster.plan(db, frm, to, S)
        bk = GRAB["book"]; dys = GRAB["days"]
        for sid, b in bk["branches"].items():
            names[sid] = b.name
            owed[sid] += (roster.owed_in_month(b.vpm, "week", Y, M,
                                               offset=sid % roster.WEEKS_PER_MONTH)
                          if b.freq_unit == "week" else int(round(float(b.vpm or 0))))
        at = collections.defaultdict(set)
        for day in p["days"]:
            for a in day["assignments"]:
                for v in a["visits"]:
                    booked[v["site_id"]] += 1; per_ag[a["agent_id"]] += 1
                    per_min[a["agent_id"]] += v["minutes"] + (v.get("travel") or 0)
                    at[(day["date"], v["site_id"])].add(a["agent_id"])
                    if v.get("cover_for"):
                        cover += 1
                    sm = int(v["start"][:2]) * 60 + 1440 * (v.get("start_day") or 0)
                    (night_v if (sm % 1440) >= 1080 or (sm % 1440) < 480 else day_v)[a["agent_id"]] += 1
        clashes += sum(1 for w in at.values() if len(w) > 1)
        travel += p["summary"]["travel_minutes"]; comp += len(p.get("compromises") or [])
        for u in p["unplaced"]:
            unpl[u["site_id"]] += 1
        for c in p.get("capped", []):
            if c.get("reason") == "days":
                cap[c["site_id"]] += max(0, int(round(c["asked"])) - int(c["possible"]))
        for (aid, d), dd in dys.items():
            avail[aid] += max(0, dd.end - dd.start)
            if not dd.stops:
                free_days[aid] += 1
    silent = sum(owed[s] - booked.get(s, 0) - unpl.get(s, 0) - cap.get(s, 0) for s in owed)
    return {"owed": dict(owed), "booked": dict(booked), "unpl": dict(unpl), "cap": dict(cap),
            "names": names, "per_ag": dict(per_ag), "per_min": dict(per_min),
            "avail": dict(avail), "free_days": dict(free_days),
            "night_v": dict(night_v), "day_v": dict(day_v),
            "cover": cover, "clashes": clashes, "travel": travel, "comp": comp,
            "tot_owed": sum(owed.values()), "tot_booked": sum(booked.values()),
            "tot_unpl": sum(unpl.values()), "tot_cap": sum(cap.values()), "silent": silent}


def set_h(who, wd, f, t):
    db.execute("UPDATE agent_availability SET start_time=?,end_time=? WHERE agent_id=? AND weekday=?",
               (f, t, IDS[who], wd))


def add_area(who, a):
    db.execute("INSERT OR IGNORE INTO agent_areas (agent_id,area_id,weekdays) VALUES (?,?,?)",
               (IDS[who], a, None))


def del_area(who, a):
    db.execute("DELETE FROM agent_areas WHERE agent_id=? AND area_id=?", (IDS[who], a))


SCEN = {}
SCEN["A"] = measure()

add_area("Abdullah shukry", 37); add_area("Ahmed Ashraf", 67)
SCEN["B"] = measure()
del_area("Abdullah shukry", 37); del_area("Ahmed Ashraf", 67)

set_h("Amr Diab", 6, "15:00", "18:00"); set_h("Youssef Ahmed", 5, "06:00", "16:00")
SCEN["C"] = measure()

add_area("Abdullah shukry", 37)
SCEN["D"] = measure()
del_area("Abdullah shukry", 37)
for w, wd in (("Amr Diab", 6), ("Youssef Ahmed", 5)):
    f, t = ORIG_H[(IDS[w], wd)]; set_h(w, wd, f, t)

# E — the geographically correct minimum: Cluture by PERMISSION (shukry is
# 28 min away), AMS by the ONE shift nobody else can substitute for.
add_area("Abdullah shukry", 37); set_h("Amr Diab", 6, "15:00", "18:00")
SCEN["E"] = measure()
del_area("Abdullah shukry", 37)
f, t = ORIG_H[(IDS["Amr Diab"], 6)]; set_h("Amr Diab", 6, f, t)

# F — permission for Cluture only, nothing else (what one change alone buys)
add_area("Abdullah shukry", 37)
SCEN["F"] = measure()
del_area("Abdullah shukry", 37)
for w, wd in (("Amr Diab", 6), ("Youssef Ahmed", 5)):
    f, t = ORIG_H[(IDS[w], wd)]; set_h(w, wd, f, t)

# ---------------- reference data ----------------------------------------
roster.plan(db, "2026-09-01", "2026-09-30", S)
book = GRAB["book"]; days = GRAB["days"]
people, branches = book["people"], book["branches"]
roster.assign_owners(book, S, weeks=30 / 7.0)
worked = {wd for p in people.values() for wd in p.days
          if not (wd == S["rest_day"] and p.days[wd] == [(0, roster.DAY)])}
reach = roster._reach_map(book, worked)

engineers = []
for p in sorted(people.values(), key=lambda x: x.name):
    wk = {}
    for wd in sorted(p.days):
        wk[WD[wd]] = " + ".join(
            "%s-%s%s" % (roster.hhmm(lo)[0], roster.hhmm(hi)[0],
                         " (+1)" if hi > roster.DAY else "")
            for lo, hi in p.windows(wd))
    engineers.append({
        "name": p.name, "id": p.id, "class": p.shift, "week": wk,
        "crosses_midnight": any(hi > roster.DAY for (lo, hi) in p.days.values()),
        "areas": sorted(p.areas),
        "avail_h": round(SCEN["A"]["avail"].get(p.id, 0) / 60.0),
        "planned_h": round(SCEN["A"]["per_min"].get(p.id, 0) / 60.0),
        "util": round(100.0 * SCEN["A"]["per_min"].get(p.id, 0)
                      / max(1, SCEN["A"]["avail"].get(p.id, 1))),
        "visits": SCEN["A"]["per_ag"].get(p.id, 0),
        "night_visits": SCEN["A"]["night_v"].get(p.id, 0),
        "day_visits": SCEN["A"]["day_v"].get(p.id, 0),
        "free_days": SCEN["A"]["free_days"].get(p.id, 0),
    })

by_area = collections.defaultdict(list)
for b in branches.values():
    by_area[b.area_id].append(b)
areas = []
for a, bs in sorted(by_area.items()):
    perm = [p for p in people.values() if a in p.areas]
    usable = [p.name for p in perm if p.days and any(
        p.works_shift(x.shift) or p.id == x.owner_id for x in bs)]
    owners = collections.Counter(NAME.get(x.owner_id) for x in bs if x.owner_id)
    areas.append({"area_id": a, "branches": len(bs),
                  "permitted": [p.name for p in perm],
                  "usable": usable,
                  "primary": owners.most_common(1)[0][0] if owners else None,
                  "backup": [n for n, _c in owners.most_common()[1:4]],
                  "single_point": sum(1 for x in bs if len(
                      [p for p in perm if p.days and
                       (p.id == x.owner_id or p.works_shift(x.shift))]) <= 1)})

hard = []
for b in branches.values():
    owed_m = int(round(float(b.vpm or 0)))
    can = reach(b)
    usable_days = sum(1 for i in range(30)
                      if b.opens_on((roster._dt.date(2026, 9, 1)
                                     + roster._dt.timedelta(days=i)).weekday())
                      and (roster._dt.date(2026, 9, 1)
                           + roster._dt.timedelta(days=i)).weekday() in can)
    elig = [p.name for p in people.values()
            if b.area_id in p.areas and p.days
            and (p.id == b.owner_id or p.works_shift(b.shift))]
    nb = []
    if b.geo:
        for o in branches.values():
            if o.id != b.id and o.geo:
                m = int(round(roster.haversine_km(b.geo, o.geo) / max(1.0, S["travel_kmh"]) * 60))
                if m <= CEIL:
                    nb.append((m, o.name, [WD[w] for w in range(7) if o.opens_on(w)]))
    nb.sort()
    unp = SCEN["A"]["unpl"].get(b.id, 0)
    flags = []
    if not elig:
        flags.append("no eligible engineer")
    if owed_m > usable_days:
        flags.append("frequency impossible")
    if owed_m == usable_days:
        flags.append("zero slack")
    if b.geo and not any(any(o.opens_on(w) for w in range(7) if b.opens_on(w))
                         for _m, _n, _d in [] ) and not nb:
        flags.append("travel isolated")
    if b.geo and nb and not any(set(d) & {WD[w] for w in range(7) if b.opens_on(w)}
                                for _m, _n, d in nb):
        flags.append("travel isolated (neighbours open other days)")
    if len(elig) == 1:
        flags.append("single point: %s" % elig[0])
    if unp:
        flags.append("unplaced %d" % unp)
    if not flags:
        continue
    hard.append({
        "client": b.client_en, "branch": b.name, "area": b.area_id,
        "geo": list(b.geo) if b.geo else None, "vpm": b.vpm,
        "days": [WD[w] for w in range(7) if b.opens_on(w)],
        "window": "%s-%s" % (roster.hhmm(b.win[0])[0], roster.hhmm(b.win[1])[0]),
        "minutes": b.job_minutes(S["slot_minutes"]),
        "owner": NAME.get(b.owner_id), "eligible": elig,
        "usable_days": usable_days, "owed": owed_m,
        "nearest": [{"min": m, "branch": n, "opens": d} for m, n, d in nb[:4]],
        "unplaced": unp, "flags": flags})

out = {"scenarios": {k: {kk: v[kk] for kk in
                         ("tot_owed", "tot_booked", "tot_unpl", "tot_cap", "silent",
                          "clashes", "travel", "cover", "comp")}
                     for k, v in SCEN.items()},
       "per_agent": {k: {"visits": v["per_ag"], "util": {
           str(a): round(100.0 * v["per_min"].get(a, 0) / max(1, v["avail"].get(a, 1)))
           for a in v["per_ag"]}} for k, v in SCEN.items()},
       "unplaced_by_scen": {k: {v["names"].get(s, s): n for s, n in v["unpl"].items()}
                            for k, v in SCEN.items()},
       "engineers": engineers, "areas": areas, "hard": hard, "names": NAME}
os.makedirs(os.path.join(HERE, "out"), exist_ok=True)
json.dump(out, open(os.path.join(HERE, "out", "system-review.json"), "w"),
          indent=1, default=str)
print("SCENARIOS  (owed / booked / unplaced / named / silent / two-vans / travel / cover / rule5)")
for k in ("A", "B", "C", "D", "E", "F"):
    v = SCEN[k]
    print("  %s  %5d %5d %4d %4d %4d %4d %7d %5d %5d"
          % (k, v["tot_owed"], v["tot_booked"], v["tot_unpl"], v["tot_cap"],
             v["silent"], v["clashes"], v["travel"], v["cover"], v["comp"]))
    print("      unplaced: " + (", ".join("%s %d" % (v["names"].get(s, s)[:28], n)
                                          for s, n in v["unpl"].items()) or "none"))
print("\nengineers %d   areas %d   difficult branches %d"
      % (len(engineers), len(areas), len(hard)))
