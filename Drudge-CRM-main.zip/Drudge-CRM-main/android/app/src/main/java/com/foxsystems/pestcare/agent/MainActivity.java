package com.foxsystems.pestcare.agent;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.provider.MediaStore;
import android.text.InputType;
import android.view.MotionEvent;
import android.view.ViewConfiguration;
import android.app.DownloadManager;
import android.webkit.CookieManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.MimeTypeMap;
import android.webkit.URLUtil;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import java.io.File;

/**
 * Thin native shell around the live PestCare CRM web app. Because it loads the
 * site from the server, any change deployed to the CRM appears instantly — no
 * rebuild / reinstall. The server URL can be changed on-device (long-press the
 * top-left corner) so even moving to a new domain/HTTPS needs no reinstall.
 */
public class MainActivity extends AppCompatActivity {

    // Default address the app loads on first run (changeable in-app).
    // HTTPS is not cosmetic here: the in-page camera (QR scanner) and
    // geolocation only run on a secure origin, so a plain-http address
    // silently disables device scanning and geo-stamped inspections.
    private static final String DEFAULT_URL = "https://drudge.foxsystemstech.com";
    // Installs from before the domain existed still hold this in prefs; they
    // are moved across on next launch so nobody has to retype a URL.
    private static final String LEGACY_URL = "http://95.216.189.8:8000";
    private static final String PREFS = "pestcare";
    private static final String KEY_URL = "server_url";
    private static final int REQ_PERMS = 100;

    /**
     * Injected after every page load. The CRM is a single-page app, so this
     * self-installs listeners (history, resize, DOM changes) and re-fits on its
     * own as the agent navigates — no further injection needed.
     *
     * It lays the page out at a DESKTOP width rather than the device's own, then
     * lets the WebView zoom the whole thing down to fit the screen. That is the
     * difference between a CRM squeezed into one tall column and the real
     * layout — cards, two-column forms, full tables — shrunk but intact, with
     * pinch-zoom to read any part of it. If real content still overflows that
     * width (a very wide table), the viewport grows to match so the page fits
     * side to side either way.
     *
     * PHONES NO LONGER USE ANY OF THIS. The CRM now ships a real phone layout
     * (html.pc-phone) that is laid out at the device's own width at normal text
     * size, so index.html sets window.__pcFit before this script is injected and
     * the first line below makes it stand down — which is why the phone layout
     * reached the installed 1.5 APK with no rebuild. What is left here is the
     * TABLET path: too wide for the phone layout, so it still gets the desktop
     * one, zoomed to fit. Do not rename __pcFit.
     *
     * The width is NOT hardcoded here: the page may set window.__pcFitWidth, so
     * it can be retuned by shipping web code alone — no new APK. It must stay
     * above the CRM's 860px single-column breakpoint to be worth anything.
     * A 0.2 minimum-scale floor keeps very wide pages reachable, and a short
     * lock guards against the resize our own viewport change fires, so it
     * cannot oscillate.
     */
    private static final String FIT_JS =
            "(function(){" +
            "if(window.__pcFit)return;window.__pcFit=true;" +
            "var TAIL=', minimum-scale=0.2, maximum-scale=5, user-scalable=yes';" +
            "function base(){var w=parseInt(window.__pcFitWidth,10);" +
            "return (w>=320&&w<=3000)?w:900;}" +
            "var t,lock=0;" +
            "function mv(){var m=document.querySelector('meta[name=viewport]');" +
            "if(!m){m=document.createElement('meta');m.name='viewport';(document.head||document.documentElement).appendChild(m);}return m;}" +
            "function fit(){var m=mv();var b=base();lock=Date.now();" +
            "m.setAttribute('content','width='+b+TAIL);" +
            "requestAnimationFrame(function(){var w=Math.ceil(document.documentElement.scrollWidth);" +
            "m.setAttribute('content','width='+(w>b+2?w:b)+TAIL);" +
            "lock=Date.now();});}" +
            "function sch(){if(Date.now()-lock<800)return;clearTimeout(t);t=setTimeout(fit,250);}" +
            "addEventListener('resize',sch);addEventListener('orientationchange',sch);" +
            "addEventListener('hashchange',sch);addEventListener('popstate',sch);" +
            "var p=history.pushState;history.pushState=function(){var r=p.apply(this,arguments);sch();return r;};" +
            "var rp=history.replaceState;history.replaceState=function(){var r=rp.apply(this,arguments);sch();return r;};" +
            "var v=document.getElementById('view')||document.body;" +
            "if(window.MutationObserver&&v){new MutationObserver(sch).observe(v,{childList:true,subtree:true});}" +
            "fit();})();";

    private WebView web;
    private SwipeRefreshLayout swipe;
    private ValueCallback<Uri[]> filePathCallback;
    private Uri cameraImageUri;
    // Held while a print job renders/spools so its WebView isn't garbage-collected.
    private WebView printWeb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        swipe = findViewById(R.id.swipe);
        web = findViewById(R.id.web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setGeolocationEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        // Fit the web page to the screen width (no sideways scroll) and let the
        // injected fit script (see FIT_JS) zoom the whole page down when its
        // content is wider than the device. useWideViewPort + overview make the
        // WebView honour the viewport width we set from JS and scale to fit.
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        // Keep pinch-zoom available as a manual backup, but hide the +/- buttons.
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(true);
        s.setDisplayZoomControls(false);
        s.setCacheMode(WebSettings.LOAD_DEFAULT);

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest req) {
                // Keep everything in-app (same server); let the WebView handle it.
                return false;
            }
            @Override
            public void onReceivedError(WebView view, WebResourceRequest req, WebResourceError err) {
                if (req.isForMainFrame()) {
                    Toast.makeText(MainActivity.this,
                            getString(R.string.cant_reach), Toast.LENGTH_LONG).show();
                }
            }
            @Override
            public void onPageFinished(WebView view, String url) {
                swipe.setRefreshing(false);
                // Squeeze the page to fit the screen width so there's no
                // horizontal scrolling (re-runs itself on in-app navigation).
                view.evaluateJavascript(FIT_JS, null);
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            // Photo / file upload from report screens (gallery + camera).
            @Override
            public boolean onShowFileChooser(WebView webView,
                                             ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                openFileChooser();
                return true;
            }
            // Allow the CRM to use the device location.
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin,
                                                           GeolocationPermissions.Callback cb) {
                cb.invoke(origin, true, false);
            }
            // Allow getUserMedia (camera/mic) when the site is served over HTTPS.
            @Override
            public void onPermissionRequest(final PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
        });

        // A WebView cannot render a PDF or a spreadsheet: it turns the link into
        // a download, and with no DownloadListener that download was dropped on
        // the floor — tapping "Open" in the IPM library did nothing at all,
        // while the same link worked on a desktop browser. The CRM renders PDFs
        // and images in-page itself; this is the way out for everything it
        // cannot draw, and for the times the in-page viewer fails. The file goes
        // to the phone's Downloads folder and Android opens it with whatever the
        // user has, so the session cookie has to travel with the request.
        web.setDownloadListener((url, userAgent, contentDisposition, mimeType, contentLength) -> {
            try {
                DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
                String cookie = CookieManager.getInstance().getCookie(url);
                if (cookie != null) req.addRequestHeader("Cookie", cookie);
                req.addRequestHeader("User-Agent", userAgent);
                String name = URLUtil.guessFileName(url, contentDisposition, mimeType);
                // guessFileName falls back to .bin when the server says nothing;
                // the extension in our own /uploads path is the better guess.
                String ext = MimeTypeMap.getFileExtensionFromUrl(url);
                if (name.endsWith(".bin") && ext != null && !ext.isEmpty()) {
                    name = name.substring(0, name.length() - 4) + "." + ext;
                }
                req.setTitle(name);
                req.setMimeType(mimeType);
                req.setNotificationVisibility(
                        DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
                req.setDestinationInExternalPublicDir(
                        android.os.Environment.DIRECTORY_DOWNLOADS, name);
                DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
                if (dm == null) throw new IllegalStateException("no download manager");
                dm.enqueue(req);
                Toast.makeText(this, getString(R.string.downloading), Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                // Last resort: hand the address to another app rather than
                // failing silently, which is the behaviour being fixed here.
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
                } catch (Exception ignored) {
                    Toast.makeText(this, getString(R.string.download_failed),
                            Toast.LENGTH_LONG).show();
                }
            }
        });

        // Native print bridge: WebViews don't implement window.print(), so the
        // web app hands us the full print document and we route it to Android's
        // PrintManager (see printHtmlDoc() in app.js). Safe because the WebView
        // only ever loads our own CRM.
        web.addJavascriptInterface(new PrintBridge(), "PestPrint");

        // Pull-to-refresh is OFF: a stray upward swipe while reading a form used
        // to reload the whole WebView and throw the typing away. The CRM has a ↻
        // button in its own topbar, which re-fetches the screen without a reload.
        swipe.setEnabled(false);
        swipe.setOnRefreshListener(() -> web.reload());

        // The hidden settings affordance (long-press the top-left corner to
        // change the server URL) used to be an invisible 56dp View laid over
        // that corner. A long-clickable View CONSUMES every touch that lands on
        // it, so it also ate ordinary taps — and the CRM's ☰ menu button sits
        // in exactly that corner, which is why ☰ did nothing in the app while
        // working in a phone browser and on desktop. The overlay is gone; the
        // long-press is watched in dispatchTouchEvent below, which never takes
        // a touch away from the WebView.

        requestRuntimePermissions();

        if (savedInstanceState != null) {
            web.restoreState(savedInstanceState);
        } else {
            web.loadUrl(getServerUrl());
        }
    }

    private String getServerUrl() {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        String url = p.getString(KEY_URL, DEFAULT_URL);
        if (LEGACY_URL.equals(url)) {          // one-time move to the https host
            url = DEFAULT_URL;
            p.edit().putString(KEY_URL, url).apply();
        }
        return url;
    }

    private void showUrlDialog() {
        final EditText input = new EditText(this);
        input.setInputType(InputType.TYPE_TEXT_VARIATION_URI);
        input.setText(getServerUrl());
        new AlertDialog.Builder(this)
                .setTitle(R.string.server_url)
                .setView(input)
                .setPositiveButton(R.string.save, (d, w) -> {
                    String url = input.getText().toString().trim();
                    if (!url.isEmpty()) {
                        getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                                .putString(KEY_URL, url).apply();
                        web.loadUrl(url);
                    }
                })
                .setNegativeButton(R.string.cancel, null)
                .show();
    }

    private void requestRuntimePermissions() {
        String[] perms;
        if (Build.VERSION.SDK_INT >= 33) {
            perms = new String[]{Manifest.permission.CAMERA,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.READ_MEDIA_IMAGES};
        } else {
            perms = new String[]{Manifest.permission.CAMERA,
                    Manifest.permission.ACCESS_FINE_LOCATION,
                    Manifest.permission.READ_EXTERNAL_STORAGE};
        }
        boolean need = false;
        for (String p : perms) {
            if (ContextCompat.checkSelfPermission(this, p) != PackageManager.PERMISSION_GRANTED) {
                need = true; break;
            }
        }
        if (need) ActivityCompat.requestPermissions(this, perms, REQ_PERMS);
    }

    // ---- file chooser (gallery + camera) ----
    private void openFileChooser() {
        Intent gallery = new Intent(Intent.ACTION_GET_CONTENT);
        gallery.addCategory(Intent.CATEGORY_OPENABLE);
        gallery.setType("*/*");
        gallery.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"image/*", "application/pdf",
                "application/vnd.ms-excel",
                "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"});

        Intent camera = null;
        try {
            File photo = File.createTempFile("photo_", ".jpg", getExternalCacheDir());
            cameraImageUri = FileProvider.getUriForFile(this,
                    getPackageName() + ".fileprovider", photo);
            camera = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
            camera.putExtra(MediaStore.EXTRA_OUTPUT, cameraImageUri);
            camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION);
        } catch (Exception e) {
            cameraImageUri = null;
        }

        Intent chooser = Intent.createChooser(gallery, getString(R.string.choose));
        if (camera != null) {
            chooser.putExtra(Intent.EXTRA_INITIAL_INTENTS, new Intent[]{camera});
        }
        startActivityForResult(chooser, REQ_PERMS + 1);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQ_PERMS + 1) return;
        if (filePathCallback == null) return;
        Uri[] results = null;
        if (resultCode == Activity.RESULT_OK) {
            if (data != null && data.getData() != null) {
                results = new Uri[]{data.getData()};          // picked from gallery/files
            } else if (cameraImageUri != null) {
                results = new Uri[]{cameraImageUri};            // captured with camera
            }
        }
        filePathCallback.onReceiveValue(results);
        filePathCallback = null;
        cameraImageUri = null;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // No-op: permissions are optional; features degrade gracefully if denied.
    }

    @Override
    public void onBackPressed() {
        // The CRM is a single page, so the WebView has no history of its own —
        // ask the app itself to step back through the screens the user opened
        // (window.pcGoBack), and only leave when it says there is nowhere left.
        web.evaluateJavascript(
                "(function(){try{return (window.pcCanGoBack&&window.pcCanGoBack())"
                        + "?(window.pcGoBack(),true):false;}catch(e){return false;}})()",
                value -> {
                    if ("true".equals(value)) return;
                    if (web.canGoBack()) web.goBack();
                    else finish();
                });
    }

    @Override
    protected void onSaveInstanceState(@NonNull Bundle outState) {
        super.onSaveInstanceState(outState);
        web.saveState(outState);
    }

    // ---- hidden settings affordance: long-press the top-left corner --------
    // Watched here rather than through a View on top of the WebView: this only
    // OBSERVES the touch stream (it always returns the result of super), so
    // whatever the page draws in that corner keeps working normally.
    private static final int CORNER_DP = 56;      // the corner that listens
    private static final long CORNER_HOLD_MS = 700;
    private final Handler cornerHandler = new Handler(Looper.getMainLooper());
    private Runnable cornerPending;
    private float cornerDownX, cornerDownY;

    private void cancelCornerHold() {
        if (cornerPending != null) {
            cornerHandler.removeCallbacks(cornerPending);
            cornerPending = null;
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        final float px = CORNER_DP * getResources().getDisplayMetrics().density;
        switch (ev.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                cancelCornerHold();
                cornerDownX = ev.getX();
                cornerDownY = ev.getY();
                if (cornerDownX <= px && cornerDownY <= px) {
                    cornerPending = () -> { cornerPending = null; showUrlDialog(); };
                    cornerHandler.postDelayed(cornerPending, CORNER_HOLD_MS);
                }
                break;
            case MotionEvent.ACTION_MOVE:
                // A finger that has started travelling is a scroll, not a hold.
                float slop = ViewConfiguration.get(this).getScaledTouchSlop();
                if (Math.abs(ev.getX() - cornerDownX) > slop
                        || Math.abs(ev.getY() - cornerDownY) > slop) cancelCornerHold();
                break;
            default:
                cancelCornerHold();
                break;
        }
        return super.dispatchTouchEvent(ev);
    }

    // ---- native printing bridge (exposed to the CRM as window.PestPrint) ----
    private class PrintBridge {
        /** Called from JS with a complete HTML document to print. */
        @JavascriptInterface
        public void printHtml(final String html) {
            runOnUiThread(() -> startWebPrint(html));
        }

        /**
         * Which APK this is. The web app reads it to tell whether it is running
         * on a build that still swallows the top-left corner (anything without
         * this method), so a workaround can retire itself the moment the fixed
         * app is installed. Do not remove.
         */
        @JavascriptInterface
        public String appVersion() {
            try {
                return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
            } catch (PackageManager.NameNotFoundException e) {
                return "";
            }
        }
    }

    /**
     * Render the given HTML in an off-screen WebView and, once loaded, hand it
     * to Android's PrintManager. Uses the current server as the base URL so the
     * document's relative assets (logo, /uploads/…) resolve.
     */
    private void startWebPrint(String html) {
        final WebView pw = new WebView(this);
        pw.getSettings().setJavaScriptEnabled(true);
        pw.getSettings().setAllowFileAccess(true);
        pw.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                // Give web fonts / the logo a moment to paint before spooling.
                new Handler(Looper.getMainLooper()).postDelayed(
                        () -> createPrintJob(view), 700);
            }
        });
        printWeb = pw;   // keep a strong reference during the job
        pw.loadDataWithBaseURL(getServerUrl(), html, "text/html", "UTF-8", null);
    }

    private void createPrintJob(WebView view) {
        PrintManager pm = (PrintManager) getSystemService(Context.PRINT_SERVICE);
        if (pm == null) {
            Toast.makeText(this, R.string.print_unavailable, Toast.LENGTH_LONG).show();
            return;
        }
        String jobName = getString(R.string.app_name) + " Document";
        PrintDocumentAdapter adapter = view.createPrintDocumentAdapter(jobName);
        pm.print(jobName, adapter, new PrintAttributes.Builder().build());
    }
}
