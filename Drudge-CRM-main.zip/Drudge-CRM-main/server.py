#!/usr/bin/env python3
"""Pest Control CRM — standard-library HTTP server.

Serves a JSON REST API + a bilingual (AR/EN) single-page frontend, with photo
uploads stored on disk. Run:  python3 server.py [port]
"""
import json
import os
import re
import sys
import uuid
import time
import threading
import traceback
import mimetypes
import gzip
import math
import hashlib
import urllib.request
import shutil
import sqlite3
import tarfile
import tempfile
import datetime as _dt_mod
from urllib.parse import urlparse, parse_qs, quote
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

import database as db
import roster
import auth
from multipart import parse_multipart

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
# Uploads live beside the code, NOT under the data dir — so a test server
# pointed at a scratch database still wrote its photos into the real folder,
# and a restore would have copied files over the live ones. The override lets a
# throwaway instance keep its files to itself; unset, nothing moves.
UPLOAD_DIR = os.environ.get("PESTCRM_UPLOAD_DIR") or os.path.join(BASE_DIR, "uploads")
mimetypes.add_type("application/manifest+json", ".webmanifest")  # PWA manifest
# Android only offers to install a download it recognises as a package; served
# with a generic type the phone just saves a file the agent cannot open.
mimetypes.add_type("application/vnd.android.package-archive", ".apk")
mimetypes.add_type("application/vnd.openxmlformats-officedocument.spreadsheetml.sheet", ".xlsx")
mimetypes.add_type("application/vnd.ms-excel", ".xls")
ALLOWED_IMG = {".jpg", ".jpeg", ".png", ".gif", ".webp"}
ALLOWED_DOC = {".pdf", ".xls", ".xlsx"}          # report attachments
ALLOWED_UPLOAD = ALLOWED_IMG | ALLOWED_DOC
MAX_UPLOAD_BYTES = 25 * 1024 * 1024   # 25 MB per uploaded file
MAX_RESTORE_BYTES = 2 * 1024 * 1024 * 1024   # a whole-system restore archive
# Content types worth gzip-compressing (text assets); images are already packed.
_COMPRESSIBLE = {
    "text/html", "text/css", "text/plain", "text/javascript",
    "application/javascript", "application/json", "image/svg+xml",
    "application/manifest+json",
}

# --------------------------------------------------------------------------
# PUBLIC ORIGIN / HTTPS
# --------------------------------------------------------------------------
# TLS is terminated in front of this process (Cloudflare), which then forwards
# to plain HTTP here — so the socket's own scheme is never https and the proxy
# headers are the only signal that the visitor is on a secure connection.
# Everything that needs a secure context (camera, geolocation, service worker,
# Secure cookies) hangs off this.
_LOCAL_HOSTS = {"localhost", "127.0.0.1", "::1", "[::1]", "0.0.0.0"}


def _forwarded_https(headers) -> bool:
    """True when the visitor reached the proxy over https."""
    if (headers.get("X-Forwarded-Proto", "").split(",")[0].strip().lower() == "https"):
        return True
    # Cloudflare also sends CF-Visitor: {"scheme":"https"}
    if '"scheme":"https"' in (headers.get("CF-Visitor") or "").replace(" ", ""):
        return True
    return "proto=https" in (headers.get("Forwarded") or "").replace(" ", "").lower()


# Canonical public address, cached from the `public_url` setting so the hot
# request path never touches the DB. Empty = no canonical host configured and
# nothing below changes behaviour (the default for any other deployment).
_public_url = ""
_public_host = ""


def refresh_public_url():
    """Re-read the `public_url` setting into the module cache."""
    global _public_url, _public_host
    try:
        row = db.query("SELECT value FROM settings WHERE key='public_url'", one=True)
        url = ((row["value"] if row else "") or "").strip().rstrip("/")
    except Exception:
        url = ""
    # Only an https address is worth redirecting to.
    _public_url = url if url.lower().startswith("https://") else ""
    _public_host = urlparse(_public_url).netloc.lower() if _public_url else ""
    return _public_url


def _sniff_image(data: bytes) -> bool:
    """True if the bytes start with a known image signature (JPEG/PNG/GIF/WEBP)."""
    if len(data) < 12:
        return False
    if data[:3] == b"\xff\xd8\xff":                      # JPEG
        return True
    if data[:8] == b"\x89PNG\r\n\x1a\n":                  # PNG
        return True
    if data[:6] in (b"GIF87a", b"GIF89a"):               # GIF
        return True
    if data[:4] == b"RIFF" and data[8:12] == b"WEBP":    # WEBP
        return True
    return False


def _sniff_doc(ext: str, data: bytes) -> bool:
    """True if the bytes match the expected signature for a PDF or Excel file."""
    if ext == ".pdf":
        return data[:5] == b"%PDF-"
    if ext == ".xlsx":                              # OOXML = zip container
        return data[:4] == b"PK\x03\x04"
    if ext == ".xls":                               # legacy OLE2 compound file
        return data[:8] == b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
    return False


def _validate_image_upload(f):
    """Validate an uploaded image dict from parse_multipart: extension, size and
    actual content signature. Raises ApiError on any problem."""
    ext = os.path.splitext(f["filename"])[1].lower()
    if ext not in ALLOWED_IMG:
        raise ApiError(400, "Only image files are allowed")
    data = f["data"]
    if not data:
        raise ApiError(400, "Empty file")
    if len(data) > MAX_UPLOAD_BYTES:
        raise ApiError(413, f"File too large (max {MAX_UPLOAD_BYTES // (1024 * 1024)} MB)")
    if not _sniff_image(data):
        raise ApiError(400, "File is not a valid image")
    return ext


def _validate_upload(f):
    """Validate an attachment: image, PDF or Excel. Checks extension, size and the
    actual content signature so a renamed/forged file can't slip through."""
    ext = os.path.splitext(f["filename"])[1].lower()
    if ext not in ALLOWED_UPLOAD:
        raise ApiError(400, "Only image, PDF or Excel files are allowed")
    data = f["data"]
    if not data:
        raise ApiError(400, "Empty file")
    if len(data) > MAX_UPLOAD_BYTES:
        raise ApiError(413, f"File too large (max {MAX_UPLOAD_BYTES // (1024 * 1024)} MB)")
    ok = _sniff_image(data) if ext in ALLOWED_IMG else _sniff_doc(ext, data)
    if not ok:
        raise ApiError(400, "File content does not match its type")
    return ext


ALLOWED_LIBRARY = {".pdf"} | ALLOWED_IMG     # IPM shelf: documents and pictures


def _validate_library_upload(f):
    """Validate an IPM library document: a PDF or an image (a scanned licence or
    a certificate photo is as much a company document as a manual). Size-capped
    and signature-checked, so a renamed .exe can't be published to every client."""
    ext = os.path.splitext(f["filename"])[1].lower()
    if ext not in ALLOWED_LIBRARY:
        raise ApiError(400, "Only PDF or image files are allowed")
    data = f["data"]
    if not data:
        raise ApiError(400, "Empty file")
    if len(data) > MAX_UPLOAD_BYTES:
        raise ApiError(413, f"File too large (max {MAX_UPLOAD_BYTES // (1024 * 1024)} MB)")
    ok = _sniff_image(data) if ext in ALLOWED_IMG else _sniff_doc(ext, data)
    if not ok:
        raise ApiError(400, "File content does not match its type")
    return ext


class ApiError(Exception):
    def __init__(self, status, message):
        self.status = status
        self.message = message


class Ctx:
    def __init__(self, user, params, query, body, raw_body, content_type, ip=None):
        self.user = user
        self.params = params          # regex path groups
        self.query = query            # dict of query string (single values)
        self.body = body              # parsed JSON dict (or {})
        self.raw_body = raw_body      # raw bytes (for uploads)
        self.content_type = content_type
        self.ip = ip                  # client IP (for login throttling)


ROUTES = []


def route(method, pattern, auth_required=True):
    regex = re.compile("^" + pattern + "$")

    def deco(fn):
        ROUTES.append((method, regex, fn, auth_required))
        return fn
    return deco


# --------------------------------------------------------------------------
# permission helpers
# --------------------------------------------------------------------------
def client_scope_id(user):
    """For client users, the client_id they are limited to."""
    return user.get("client_id") if user["role"] == "client" else None


def client_site_scope_id(user):
    """For a client login pinned to one of its company's locations, that site_id.

    NULL/absent means the account sees the whole company (every portal user
    before this existed). Rows that carry no site at all stay visible to a
    pinned user: an untagged invoice or visit is company-level paperwork, not
    another branch's — what we hide is a row that names a DIFFERENT location."""
    return user.get("site_id") if user["role"] == "client" else None


def _client_site_clause(user, col):
    """(sql, params) restricting `col` to a pinned client user's location."""
    sid = client_site_scope_id(user)
    if not sid:
        return "", []
    return f" AND ({col} IS NULL OR {col}=?)", [sid]


# --------------------------------------------------------------------------
# SUPERVISORS: AREA MANAGERS AND TEAM LEADERS
# Two different questions, two different roles.
#
#   An AREA MANAGER answers for a PLACE. They hold the parts of town listed in
#   area_manager_areas, and everything standing in them — the branches, the
#   diary, the reports, the traps — is theirs. Nobody is permanently under
#   them: whoever the roster puts on one of their areas is working under them
#   THAT DAY, read from agent_shifts.area_id and never stored on the person.
#
#   A TEAM LEADER answers for PEOPLE. Their team is the engineers whose
#   users.team_leader_id points at them — a standing list that does not move
#   with the roster. What they see is their team's diary and their team's
#   reports, wherever in town that work happens to be.
#
# Both still carry visits themselves, so every clause below also lets a
# supervisor see their OWN job wherever it is.
# --------------------------------------------------------------------------
def area_manager_area_ids(user):
    """The areas an area manager covers, [] for every other role.

    A manager holding NO area answers for nothing yet — they still see their
    own jobs, but no oversight rows. Fail closed: an empty patch must never
    read as "everywhere"."""
    if not user or user.get("role") != "area_manager":
        return []
    return [r["area_id"] for r in
            db.query("SELECT area_id FROM area_manager_areas WHERE manager_id=? ORDER BY area_id",
                     (user["id"],))]


def set_area_manager_areas(manager_id, area_ids):
    """Replace a manager's areas with exactly this set (the office re-picks the
    whole list every time it edits, so a diff would only add ways to disagree).
    Unknown areas are rejected rather than quietly dropped."""
    clean = []
    for raw in (area_ids or []):
        aid = _coerce_area_id(raw)
        if aid and aid not in clean:
            clean.append(aid)
    with db.transaction() as cx:
        cx.execute("DELETE FROM area_manager_areas WHERE manager_id=?", (manager_id,))
        for aid in clean:
            cx.execute("INSERT INTO area_manager_areas(manager_id,area_id) VALUES(?,?)",
                       (manager_id, aid))
    return clean


def team_member_ids(user, date=None):
    """Who this supervisor answers for.

    A TEAM LEADER's team is the standing one: every active engineer whose
    team_leader_id points at them, the same list on any date.

    An AREA MANAGER's team is whoever the roster puts on one of their areas on
    the given day, so it is exactly the dispatch board's notion of who is out
    where. A shift with no area is NOT counted: an engineer nobody tied to a
    patch is not silently claimed by every manager."""
    if not user:
        return []
    if user.get("role") == "team_leader":
        return [r["id"] for r in db.query(
            "SELECT id FROM users WHERE team_leader_id=? AND active=1 ORDER BY full_name",
            (user["id"],))]
    areas = area_manager_area_ids(user)
    if not areas:
        return []
    day = date or _today()
    marks = ",".join("?" for _ in areas)
    return [r["agent_id"] for r in db.query(
        f"SELECT DISTINCT agent_id FROM agent_shifts WHERE shift_date=? "
        f"AND area_id IN ({marks})", (day, *areas))]


def set_team_members(leader_id, member_ids):
    """Replace a team leader's team with exactly this set of engineers.

    Membership lives on the ENGINEER (users.team_leader_id), so moving somebody
    to another team is one write and nobody ends up on two. Only field roles
    can be on a team — the office is not anybody's crew."""
    clean = []
    for raw in (member_ids or []):
        try:
            mid = int(raw)
        except (TypeError, ValueError):
            continue
        if mid and mid != leader_id and mid not in clean:
            clean.append(mid)
    if clean:
        marks = ",".join("?" for _ in clean)
        rows = db.query(f"SELECT id, role FROM users WHERE id IN ({marks})", clean)
        found = {r["id"]: r["role"] for r in rows}
        for mid in clean:
            if mid not in found:
                raise ApiError(400, "Unknown team member")
            if found[mid] not in FIELD_ROLES:
                raise ApiError(400, "Only engineers can be on a team")
    with db.transaction() as cx:
        cx.execute("UPDATE users SET team_leader_id=NULL WHERE team_leader_id=?", (leader_id,))
        for mid in clean:
            cx.execute("UPDATE users SET team_leader_id=? WHERE id=?", (leader_id, mid))
    return clean


# A visit's area, derived the same way VISIT_AREA_SQL derives it (the branch's
# area, falling back to the client's) but as a correlated subquery, so it can be
# bolted onto any query that has the visits row aliased — no extra JOINs to keep
# in step across a dozen call sites.
_VISIT_AREA_EXPR = ("COALESCE((SELECT area_id FROM sites WHERE id={v}.site_id),"
                    "(SELECT area_id FROM clients WHERE id={v}.client_id))")


def _sup_visit_clause(user, v="v"):
    """(clause, params) restricting a visit query to what a supervisor may see.

    An area manager gets their areas' work; a team leader gets their team's
    work. Both also get their own jobs wherever those happen to be — somebody
    sent to cover another patch for a day must still be able to open the visit
    they are standing in. The clause carries no leading AND, so it drops
    straight into the where-lists these endpoints already build. Returns
    (None, []) for every other role, which is the "no restriction" answer
    callers test for."""
    role = user.get("role")
    if role not in SUPERVISOR_ROLES:
        return None, []
    if role == "team_leader":
        ids = team_member_ids(user)
        if not ids:
            return f"{v}.agent_id=?", [user["id"]]
        marks = ",".join("?" for _ in [*ids, user["id"]])
        return f"{v}.agent_id IN ({marks})", [*ids, user["id"]]
    areas = area_manager_area_ids(user)
    if not areas:
        return f"{v}.agent_id=?", [user["id"]]
    expr = _VISIT_AREA_EXPR.format(v=v)
    marks = ",".join("?" for _ in areas)
    return f"({expr} IN ({marks}) OR {v}.agent_id=?)", [*areas, user["id"]]


def _sup_covers_visit(user, visit):
    """Whether a supervisor may open this one visit (their patch or their team,
    or their own job)."""
    if visit.get("agent_id") == user["id"]:
        return True
    if user.get("role") == "team_leader":
        return visit.get("agent_id") in team_member_ids(user)
    areas = area_manager_area_ids(user)
    if not areas:
        return False
    area_id = None
    if visit.get("site_id"):
        row = db.query("SELECT area_id FROM sites WHERE id=?", (visit["site_id"],), one=True)
        area_id = row["area_id"] if row else None
    if area_id is None and visit.get("client_id"):
        row = db.query("SELECT area_id FROM clients WHERE id=?", (visit["client_id"],), one=True)
        area_id = row["area_id"] if row else None
    return area_id in areas


def _sup_client_clause(user, c="clients"):
    """(clause, params) limiting a client query to what a supervisor may see.

    For an area manager: the companies tagged to one of their areas, or with a
    BRANCH in one. A company with branches in two parts of town is legitimately
    both managers' business. For a team leader: the companies their team is
    actually sent to. Their own customers come too in both cases — somebody
    holding a job at a company outside their scope still has to be able to open
    that folder to do the work."""
    role = user.get("role")
    if role not in SUPERVISOR_ROLES:
        return None, []
    if role == "team_leader":
        ids = [*team_member_ids(user), user["id"]]
        marks = ",".join("?" for _ in ids)
        return (f"EXISTS (SELECT 1 FROM visits v WHERE v.client_id={c}.id "
                f"AND v.agent_id IN ({marks}))", ids)
    areas = area_manager_area_ids(user)
    own = (f"EXISTS (SELECT 1 FROM visits v WHERE v.client_id={c}.id AND v.agent_id=?)",
           [user["id"]])
    if not areas:
        return own[0], own[1]
    marks = ",".join("?" for _ in areas)
    return (f"({c}.area_id IN ({marks}) OR EXISTS (SELECT 1 FROM sites s "
            f"WHERE s.client_id={c}.id AND s.area_id IN ({marks})) OR {own[0]})",
            [*areas, *areas, *own[1]])


def _sup_covers_client(user, client_id):
    """Whether a supervisor may open one client folder — same rule as the list."""
    clause, params = _sup_client_clause(user)
    if clause is None:
        return True
    return bool(db.query(f"SELECT 1 FROM clients WHERE id=? AND {clause}",
                         (client_id, *params), one=True))


# --------------------------------------------------------------------------
# RBAC: feature catalog, role defaults and permission resolution
# --------------------------------------------------------------------------
# The catalog drives both the admin matrix UI and backend enforcement.
# Each module exposes a set of actions; a permission key is "module.action".
PERMISSION_CATALOG = [
    {"module": "dashboard",    "actions": ["view"]},
    {"module": "clients",      "actions": ["view", "create", "edit", "delete"]},
    {"module": "leads",        "actions": ["view", "create", "edit", "delete"]},
    {"module": "visits",       "actions": ["view", "create", "edit", "delete"]},
    # Dispatch is the planner's board (who works where, route optimization).
    # Kept out of visits.* so a field agent can still edit their own visits
    # without seeing — or reordering — everyone else's day.
    {"module": "dispatch",     "actions": ["view"]},
    # The visit-request inbox is front-desk work: the client asks, the office
    # answers. It used to ride on visits.* — which every field agent has — so
    # engineers saw the whole company's incoming requests. Its own module now,
    # so granting it back to a specific agent is an RBAC override, not a rule.
    {"module": "requests",     "actions": ["view", "create", "edit"]},
    {"module": "calendar",     "actions": ["view"]},
    {"module": "shifts",       "actions": ["view", "create", "edit", "delete"]},
    # WIPING THE WHOLE BOOK, in one press, across every month there is. Its own
    # module and, by default, the owner's alone — the same reasoning as finance
    # below. shifts.edit is the permission for clearing a WEEK, which the office
    # does all the time; this is the permission for clearing EVERYTHING, which
    # they should do about once a year and never by accident. Keeping the two on
    # one permission is what let a single mis-click take an applied month off the
    # book on 2026-08-24.
    {"module": "schedule",     "actions": ["clear_all"]},
    {"module": "chemicals",    "actions": ["view", "create", "edit", "delete"]},
    # issues.create = raise a materials request (an engineer may do this for
    # themselves); issues.approve = release the stock, which is the office's call.
    {"module": "issues",       "actions": ["view", "create", "approve", "delete"]},
    # Pocket money: the float an engineer carries for a taxi, a part, a repair.
    # cash.create files a claim (the engineer's own), cash.approve is the
    # office agreeing to it and is what actually moves a balance.
    {"module": "cash",         "actions": ["view", "create", "approve", "delete"]},
    {"module": "invoices",     "actions": ["view", "create", "edit", "delete"]},
    {"module": "payments",     "actions": ["view", "create", "delete"]},
    {"module": "contracts",    "actions": ["view", "create", "edit", "delete"]},
    # What the company SPENDS — rent, salaries, tax, the profit left over.
    # Deliberately its own module and, by default, the owner's alone: invoices
    # tell a manager what the customers owe, this tells them what the business
    # earns. Granting it to a manager is a decision the owner makes in the
    # permission matrix, not a side effect of running the office.
    {"module": "finance",      "actions": ["view", "create", "edit", "delete"]},
    # Marketing targets: what each engineer is asked to bring in, and the
    # commission standing on the contracts they brought. Its own module because
    # an engineer must be able to see THEIR OWN number (the server scopes them
    # to it) without that opening the company's payroll to them.
    {"module": "targets",      "actions": ["view", "edit"]},
    {"module": "analytics",    "actions": ["view"]},
    {"module": "transport",    "actions": ["view"]},
    {"module": "certificates", "actions": ["view"]},
    # The IPM file library: company-wide PDFs (IPM manual, policies, licences).
    # Its own module because it is the one shelf every role — clients included —
    # reads from, while only the office may publish to it.
    {"module": "ipm",          "actions": ["view", "create", "edit", "delete"]},
    {"module": "maps",         "actions": ["view", "create", "edit", "delete"]},
    # The QR device registry (generate/assign/print codes) is back-office work.
    # Scanning a code in the field stays on maps.* so engineers keep it.
    {"module": "devices",      "actions": ["view", "create", "edit", "delete"]},
    {"module": "users",        "actions": ["view", "create", "edit", "delete"]},
    {"module": "settings",     "actions": ["view", "edit"]},
    {"module": "permissions",  "actions": ["view", "edit"]},
]

ROLES = ["admin", "manager", "agent", "area_manager", "team_leader", "client"]

# The roles that actually go out and work a job. Both supervising roles carry
# visits like an engineer on top of what they answer for, so wherever the
# question is "who can be sent to this job" or "who is on the roster", all
# three answer it.
FIELD_ROLES = ("agent", "area_manager", "team_leader")

# The two supervising roles. One answers for a PLACE (the areas in
# area_manager_areas), the other for PEOPLE (the engineers whose
# team_leader_id points at them). Every scoping helper below takes both.
SUPERVISOR_ROLES = ("area_manager", "team_leader")


def all_perms():
    return [f"{m['module']}.{a}" for m in PERMISSION_CATALOG for a in m["actions"]]


def _expand(spec):
    """Build a {perm: bool} map for a role from a compact spec.
    spec maps module -> True (all actions) | False (none) | list-of-actions.
    Any module not mentioned defaults to no access.
    """
    out = {}
    for m in PERMISSION_CATALOG:
        rule = spec.get(m["module"], False)
        for a in m["actions"]:
            if rule is True:
                out[f"{m['module']}.{a}"] = True
            elif rule is False:
                out[f"{m['module']}.{a}"] = False
            else:
                out[f"{m['module']}.{a}"] = a in rule
    return out


# Built-in per-role defaults. admin is a superuser (also hard-bypassed below).
ROLE_DEFAULTS = {
    "admin": _expand({m["module"]: True for m in PERMISSION_CATALOG}),
    "manager": _expand({
        "dashboard": True, "clients": True, "leads": True, "visits": True,
        "dispatch": True, "requests": True, "calendar": True, "shifts": True, "chemicals": True, "issues": True, "cash": True, "invoices": True, "payments": True,
        "contracts": True, "analytics": True, "certificates": True, "maps": True,
        "transport": True, "users": True, "settings": True, "devices": True,
        # finance.* stays off: running the office does not mean seeing the
        # payroll and the profit. The owner grants it per person if they want to.
        "ipm": True, "permissions": False, "finance": False,
        # Setting and chasing the team's targets is running the office; the
        # payroll behind them stays on finance.*, which a manager does not hold.
        "targets": True,
    }),
    "agent": _expand({
        # No chemicals.* — the stock book is not the engineer's business; they
        # see what they were issued on the Issues page instead. The chemical
        # CATALOG (names/units) still reaches them via issues.view, so the
        # usage + issue pickers keep working. No devices.* either: they scan
        # codes (maps.*), they don't generate or assign them. No requests.*:
        # the visit-request inbox is the office's, not the engineer's.
        "dashboard": ["view"], "clients": ["view"], "visits": ["view", "edit"],
        "calendar": ["view"], "shifts": ["view"], "certificates": ["view"],
        "issues": ["view", "create"], "cash": ["view", "create"],
        "maps": ["view", "create", "edit"],
        "transport": ["view"], "ipm": ["view"],
        # Their own target and their own commission, and nobody else's — the
        # endpoint pins a field role to their own row.
        "targets": ["view"],
    }),
    # An area manager is an engineer with a patch. Everything an agent holds, so
    # they can work their own jobs, plus the oversight of the areas in
    # area_manager_areas: the whole area's branches, visits and reports (not
    # just their own), the roster, the dispatch board and the analytics for it.
    # What they are NOT given is the office: no invoices/payments/contracts, no
    # finance, no chemicals stock book, no user accounts or permissions. They
    # also do not APPROVE — cash.approve and issues.approve stay the office's,
    # so a manager claims pocket money like anyone else but does not sign off
    # their own crew's claims.
    "area_manager": _expand({
        "dashboard": ["view"], "clients": ["view"],
        "visits": ["view", "edit"], "calendar": ["view"],
        "dispatch": True, "shifts": ["view", "create", "edit"],
        "issues": ["view", "create"], "cash": ["view", "create"],
        "maps": ["view", "create", "edit"], "devices": ["view"],
        "certificates": ["view"], "transport": ["view"], "ipm": ["view"],
        "analytics": ["view"], "targets": ["view"],
    }),
    # A team leader is the same engineer-plus-oversight shape, but pointed at
    # PEOPLE instead of places: their team's diary, their team's reports, their
    # team's roster line. Every screen they open is filtered to the engineers
    # who report to them, so the permission set is the area manager's — minus
    # devices.view, which is the trap REGISTRY and belongs to whoever answers
    # for the sites the traps stand at. Scanning stays theirs via maps.*.
    "team_leader": _expand({
        "dashboard": ["view"], "clients": ["view"],
        "visits": ["view", "edit"], "calendar": ["view"],
        "dispatch": True, "shifts": ["view", "create", "edit"],
        "issues": ["view", "create"], "cash": ["view", "create"],
        "maps": ["view", "create", "edit"],
        "certificates": ["view"], "transport": ["view"], "ipm": ["view"],
        "analytics": ["view"], "targets": ["view"],
    }),
    "client": _expand({
        # requests view+create = the portal's "request a visit"; the office
        # still owns requests.edit (approve / decline).
        # ipm.view is the company file shelf — on by default for every client,
        # which is the whole point of publishing a document there.
        "dashboard": ["view"], "visits": ["view"], "invoices": ["view"],
        "contracts": ["view"], "certificates": ["view"], "ipm": ["view"],
        "requests": ["view", "create"],
    }),
}


def _role_overrides(role):
    return {r["perm"]: bool(r["allowed"])
            for r in db.query("SELECT perm, allowed FROM role_permissions WHERE role=?", (role,))}


def _user_overrides(user_id):
    return {r["perm"]: bool(r["allowed"])
            for r in db.query("SELECT perm, allowed FROM user_permissions WHERE user_id=?", (user_id,))}


def effective_role_perms(role):
    """Resolved {perm: bool} for a role = defaults overlaid with role overrides."""
    perms = dict(ROLE_DEFAULTS.get(role, {}))
    perms.update(_role_overrides(role))
    return perms


def effective_user_perms(user):
    """Resolved {perm: bool} for a specific user = role perms + user overrides.
    admin is always granted everything."""
    if user["role"] == "admin":
        return {p: True for p in all_perms()}
    perms = effective_role_perms(user["role"])
    perms.update(_user_overrides(user["id"]))
    return perms


def has_perm(user, perm):
    if user["role"] == "admin":
        return True
    return effective_user_perms(user).get(perm, False)


def require_perm(user, perm):
    if not has_perm(user, perm):
        raise ApiError(403, "You do not have permission for this action")


def audit(ctx, action, entity=None, entity_id=None, detail=None):
    """Append an entry to the audit trail. Never raises (best-effort)."""
    try:
        u = ctx.user or {}
        db.execute(
            "INSERT INTO audit_log(user_id,user_name,action,entity,entity_id,detail,ip) "
            "VALUES(?,?,?,?,?,?,?)",
            (u.get("id"), u.get("full_name"), action, entity,
             None if entity_id is None else str(entity_id), detail, getattr(ctx, "ip", None)))
    except Exception:
        traceback.print_exc()


def _paginate(ctx, base_sql, params, order_sql, default_limit=25, max_limit=200):
    """Page a query when the request asks for it.

    base_sql: a complete SELECT (with any WHERE) but no ORDER BY / LIMIT.
    order_sql: the ORDER BY clause string.
    Returns the plain row list when neither ?page nor ?limit is given (keeps
    existing callers/dropdowns working); otherwise an envelope
    {items, total, page, pages, limit}.
    """
    params = list(params)
    q = ctx.query
    if "page" not in q and "limit" not in q:
        return db.query(f"{base_sql} {order_sql}", params)
    try:
        limit = min(max(int(q.get("limit", default_limit)), 1), max_limit)
    except (TypeError, ValueError):
        limit = default_limit
    try:
        page = max(int(q.get("page", 1)), 1)
    except (TypeError, ValueError):
        page = 1
    total = db.query(f"SELECT COUNT(*) c FROM ({base_sql})", params, one=True)["c"]
    rows = db.query(f"{base_sql} {order_sql} LIMIT ? OFFSET ?", params + [limit, (page - 1) * limit])
    pages = (total + limit - 1) // limit if limit else 1
    return {"items": rows, "total": total, "page": page, "pages": pages, "limit": limit}


# ?sort=asc|desc for the dated lists (Schedule, Reports). The office reads a
# diary forwards — the soonest visit is the one being worked on — so ASC is the
# default here; "desc" is there for anyone who wants the latest at the top.
def _sort_dir(ctx, default="ASC"):
    s = str(ctx.query.get("sort", "")).strip().lower()
    if s in ("asc", "old", "oldest", "soonest", "up"):
        return "ASC"
    if s in ("desc", "new", "newest", "latest", "down"):
        return "DESC"
    return default


# A photo's required permission depends on the entity it is attached to.
_PHOTO_ENTITY_PERM = {
    "client": "clients.edit", "report": "visits.edit",
    "visit": "visits.edit", "chemical": "chemicals.edit",
    # A receipt against a company cost: finance-only, like the cost itself.
    "expense": "finance.edit",
    # A receipt for pocket money: the engineer who spent it attaches it, so it
    # rides on cash.create rather than on the approver's permission.
    "cash": "cash.create",
}


# --------------------------------------------------------------------------
# AUTH
# --------------------------------------------------------------------------
# In-memory login throttle: lock an (email|ip) key after repeated failures.
LOGIN_MAX_FAILS = 5
LOGIN_WINDOW = 300       # seconds to accumulate failures
LOGIN_LOCK_SECS = 300    # lockout duration once the threshold is hit
_login_lock = threading.Lock()
_login_attempts = {}     # key -> [fail_count, window_start, locked_until]


def _login_locked_for(key):
    """Return seconds remaining if the key is currently locked, else 0."""
    now = time.time()
    with _login_lock:
        rec = _login_attempts.get(key)
        if rec and rec[2] > now:
            return int(rec[2] - now) + 1
    return 0


def _login_register_fail(key):
    now = time.time()
    with _login_lock:
        # Opportunistically drop stale entries so the map can't grow unbounded
        # under a spray of distinct email|ip keys.
        if len(_login_attempts) > 256:
            for k in [k for k, v in _login_attempts.items()
                      if v[2] < now and now - v[1] > LOGIN_WINDOW]:
                _login_attempts.pop(k, None)
        rec = _login_attempts.get(key)
        if not rec or now - rec[1] > LOGIN_WINDOW:
            rec = [0, now, 0]
        rec[0] += 1
        if rec[0] >= LOGIN_MAX_FAILS:
            rec[2] = now + LOGIN_LOCK_SECS
        _login_attempts[key] = rec


def _login_register_ok(key):
    with _login_lock:
        _login_attempts.pop(key, None)


# Generic fixed-window, per-key rate limiter (in-memory, best-effort). Blunts
# abuse of unauthenticated endpoints such as the payment webhook. Login has its
# own lockout logic above; authenticated endpoints (e.g. /api/scan/*) are gated
# by session + permission and are intentionally NOT throttled here, so shared
# office/NAT IPs don't lock out legitimate field agents.
_rate_lock = threading.Lock()
_rate_hits = {}          # key -> [count, window_start]


def rate_limit(key, max_hits, window=60):
    """Return True if `key` is still within its budget for the window, else
    False (caller should reject with 429). Evicts stale keys to bound memory."""
    now = time.time()
    with _rate_lock:
        if len(_rate_hits) > 4096:
            for k in [k for k, v in _rate_hits.items() if now - v[1] > window]:
                _rate_hits.pop(k, None)
        rec = _rate_hits.get(key)
        if not rec or now - rec[1] > window:
            rec = [0, now]
        rec[0] += 1
        _rate_hits[key] = rec
        return rec[0] <= max_hits


@route("GET", r"/api/health", auth_required=False)
def health(ctx):
    """Liveness probe for monitor.py: proves the HTTP loop and DB both answer.
    Unauthenticated by design; returns no business data."""
    db.query("SELECT 1 AS ok", one=True)
    return {"ok": True, "db": "ok"}


@route("POST", r"/api/auth/login", auth_required=False)
def login(ctx):
    email = (ctx.body.get("email") or "").strip().lower()
    password = ctx.body.get("password") or ""
    key = f"{email}|{ctx.ip or '?'}"
    locked = _login_locked_for(key)
    if locked:
        raise ApiError(429, f"Too many failed attempts. Try again in {locked} seconds.")
    user = db.query("SELECT * FROM users WHERE lower(email)=? AND active=1", (email,), one=True)
    if not user or not auth.verify_password(password, user["password_hash"]):
        _login_register_fail(key)
        raise ApiError(401, "Invalid email or password")
    _login_register_ok(key)
    token = auth.make_token(user["id"], user["token_version"] or 0)
    return {"token": token, "user": _me_payload(user)}


@route("GET", r"/api/auth/me")
def me(ctx):
    return _me_payload(ctx.user)


@route("POST", r"/api/auth/logout")
def logout(ctx):
    # Bump token_version so every outstanding token for this user is rejected.
    db.execute("UPDATE users SET token_version = token_version + 1 WHERE id=?", (ctx.user["id"],))
    return {"ok": True}


def _me_payload(u):
    """Public profile plus the user's resolved permission map (for UI gating)."""
    return _public_user(u) | {"permissions": effective_user_perms(u)}


def _public_user(u):
    out = {k: u[k] for k in ("id", "full_name", "email", "role", "phone",
                             "client_id", "site_id", "specialization", "license_no",
                             "license_expiry", "lang")}
    # An area manager's patch travels with the account: the user list, the
    # profile the SPA logs in with, and the edit form all read it from here.
    if out["role"] == "area_manager":
        out["area_ids"] = [r["area_id"] for r in db.query(
            "SELECT la.area_id FROM area_manager_areas la JOIN areas a ON a.id=la.area_id "
            "WHERE la.manager_id=? ORDER BY a.sort_order, a.id", (u["id"],))]
        out["areas"] = db.query(
            "SELECT a.id, a.name_en, a.name_ar FROM area_manager_areas la JOIN areas a ON a.id=la.area_id "
            "WHERE la.manager_id=? ORDER BY a.sort_order, a.id", (u["id"],))
    # A team leader's team travels the same way, and so does an engineer's own
    # line of report — the edit form shows both sides of the same fact.
    if out["role"] == "team_leader":
        out["member_ids"] = [r["id"] for r in db.query(
            "SELECT id FROM users WHERE team_leader_id=? AND active=1 ORDER BY full_name",
            (u["id"],))]
        out["members"] = db.query(
            "SELECT id, full_name, role FROM users WHERE team_leader_id=? AND active=1 "
            "ORDER BY full_name", (u["id"],))
    elif out["role"] in FIELD_ROLES:
        out["team_leader_id"] = dict(u).get("team_leader_id")
    return out


# --------------------------------------------------------------------------
# DASHBOARD
# --------------------------------------------------------------------------
@route("GET", r"/api/dashboard")
def dashboard(ctx):
    u = ctx.user
    if u["role"] == "client":
        cid = u["client_id"]
        # A portal login pinned to one location counts only that location's work.
        vs, vp = _client_site_clause(u, "site_id")
        return {
            "role": "client",
            "upcoming_visits": db.query(
                "SELECT COUNT(*) c FROM visits WHERE client_id=? AND status IN('scheduled','in_progress')" + vs,
                (cid, *vp), one=True)["c"],
            "completed_visits": db.query(
                "SELECT COUNT(*) c FROM visits WHERE client_id=? AND status='completed'" + vs,
                (cid, *vp), one=True)["c"],
            "outstanding": _client_outstanding(cid, client_site_scope_id(u)),
            "open_invoices": db.query(
                "SELECT COUNT(*) c FROM invoices WHERE client_id=? AND status IN('sent','overdue')" + vs,
                (cid, *vp), one=True)["c"],
        }
    if u["role"] == "agent":
        return _agent_dashboard(u)
    if u["role"] in SUPERVISOR_ROLES:
        return _supervisor_dashboard(u)
    stats = {
        "role": "staff",
        "clients": db.query("SELECT COUNT(*) c FROM clients", one=True)["c"],
        "agents": db.query("SELECT COUNT(*) c FROM users WHERE role IN ('agent','area_manager','team_leader') AND active=1",
                            one=True)["c"],
        "visits_today": db.query(
            "SELECT COUNT(*) c FROM visits WHERE date(scheduled_start)=date('now','localtime')", one=True)["c"],
        "scheduled": db.query(
            "SELECT COUNT(*) c FROM visits WHERE status IN('scheduled','in_progress')", one=True)["c"],
        "low_stock": db.query(
            "SELECT COUNT(*) c FROM chemicals WHERE quantity_in_stock <= reorder_level", one=True)["c"],
        # products already expired or expiring within 60 days
        "expiring": db.query(
            "SELECT COUNT(*) c FROM chemicals WHERE COALESCE(expiry_date,'')<>'' "
            "AND date(expiry_date) <= date('now','localtime','+60 days')", one=True)["c"],
        "outstanding": db.query(
            "SELECT COALESCE(SUM(total),0)-COALESCE((SELECT SUM(amount) FROM payments),0) v "
            "FROM invoices WHERE status IN('sent','overdue','paid')", one=True)["v"],
    }
    # Owner cockpit: a single-glance KPI block (revenue, overdue billing, SLA
    # health, technician utilization) for admins/managers who can see finance +
    # analytics. Agents/clients never get it.
    if has_perm(u, "analytics.view"):
        stats["cockpit"] = _owner_cockpit()
    stats["devices"] = _device_overview()
    return stats


def _agent_dashboard(u):
    """Field-agent home: the agent's OWN workload and nothing else.

    Deliberately excludes every company-wide figure (client/agent counts, whole-
    fleet visit totals, stock levels) and all finance — an agent has no business
    seeing outstanding balances or revenue.
    """
    aid = u["id"]
    one = lambda sql: db.query(sql, (aid,), one=True)["c"]
    return {
        "role": "agent",
        # today's list, whatever its status
        "visits_today": one("SELECT COUNT(*) c FROM visits WHERE agent_id=? "
                            "AND date(scheduled_start)=date('now','localtime')"),
        # still open (scheduled or started) on any day
        "my_visits": one("SELECT COUNT(*) c FROM visits WHERE agent_id=? "
                         "AND status IN('scheduled','in_progress')"),
        "in_progress": one("SELECT COUNT(*) c FROM visits WHERE agent_id=? AND status='in_progress'"),
        "completed_month": one(
            "SELECT COUNT(*) c FROM visits WHERE agent_id=? AND status='completed' "
            "AND strftime('%Y-%m',COALESCE(completed_at,scheduled_start))=strftime('%Y-%m','now','localtime')"),
        # paperwork the agent still owes: a completed visit with no report at
        # all, or one whose report is still a draft
        "reports_due": one(
            "SELECT COUNT(*) c FROM visits v WHERE v.agent_id=? AND v.status='completed' "
            "AND NOT EXISTS(SELECT 1 FROM reports r WHERE r.visit_id=v.id AND r.status='complete')"),
    }


def _supervisor_dashboard(u):
    """An area manager's or a team leader's home: their own workload, then what
    they answer for.

    Built from _agent_dashboard so the "my work" half can never drift from what
    an engineer sees, with the oversight figures layered on top. The oversight
    half is whatever _sup_visit_clause says this role covers — an area
    manager's patch, a team leader's team — so one function serves both and
    neither can quietly widen. No finance and no company-wide totals: a
    supervisor runs a patch or a crew, not the books."""
    stats = _agent_dashboard(u)
    stats["role"] = u["role"]
    clause, params = _sup_visit_clause(u)
    areas = area_manager_area_ids(u)
    stats["areas"] = db.query(
        "SELECT a.id, a.name_en, a.name_ar FROM area_manager_areas la JOIN areas a ON a.id=la.area_id "
        "WHERE la.manager_id=? ORDER BY a.sort_order, a.id", (u["id"],))
    team = team_member_ids(u)
    stats["team_today"] = len(team)
    one = lambda sql, p: db.query(sql, tuple(p), one=True)["c"]
    # Everything below is the WHOLE patch's (or the whole team's) work, not
    # just this person's.
    stats["sup_visits_today"] = one(
        f"SELECT COUNT(*) c FROM visits v WHERE {clause} AND date(v.scheduled_start)=date('now','localtime')",
        params)
    stats["sup_open"] = one(
        f"SELECT COUNT(*) c FROM visits v WHERE {clause} AND v.status IN('scheduled','in_progress')",
        params)
    # Paperwork still owed — the supervisor's main chasing job.
    stats["sup_reports_due"] = one(
        f"SELECT COUNT(*) c FROM visits v WHERE {clause} AND v.status='completed' "
        "AND NOT EXISTS(SELECT 1 FROM reports r WHERE r.visit_id=v.id AND r.status='complete')",
        params)
    # Traps overdue for a scan are a question about PLACES, so only the role
    # that answers for places is asked it.
    if areas:
        marks = ",".join("?" for _ in areas)
        stats["sup_devices_stale"] = _stale_count(
            f" AND COALESCE((SELECT area_id FROM sites WHERE id=d.site_id),"
            f"(SELECT area_id FROM clients WHERE id=d.client_id)) IN ({marks})", areas)
    else:
        stats["sup_devices_stale"] = 0
    return stats


# A device is "stale" (overdue for a scan) when it's active + assigned and its
# last inspection is older than this many days — or it was never scanned.
STALE_SCAN_DAYS = 30
_STALE_PRED = ("d.active=1 AND d.client_id IS NOT NULL AND COALESCE("
               "(SELECT MAX(recorded_at) FROM device_inspections di WHERE di.device_id=d.id),'0')"
               " < datetime('now','localtime','-%d days')" % STALE_SCAN_DAYS)


def _stale_count(scope="", params=()):
    return db.query("SELECT COUNT(*) c FROM devices d WHERE " + _STALE_PRED + scope,
                    tuple(params), one=True)["c"]


def _stale_devices(limit=None, scope="", params=()):
    """Assigned devices overdue for a scan, oldest (incl. never-scanned) first."""
    sql = ("SELECT d.id, d.code, d.type, d.label loc, c.name_en client_en, "
           "c.name_ar client_ar, s.name site_name, "
           "(SELECT MAX(recorded_at) FROM device_inspections di WHERE di.device_id=d.id) last_seen "
           "FROM devices d LEFT JOIN clients c ON c.id=d.client_id "
           "LEFT JOIN sites s ON s.id=d.site_id WHERE " + _STALE_PRED + scope +
           " ORDER BY last_seen IS NOT NULL, last_seen ASC")
    if limit:
        sql += " LIMIT %d" % int(limit)
    return db.query(sql, tuple(params))


def _device_overview():
    """QR device fleet health for the staff dashboard: how many devices exist,
    how many need service, pest-activity detections this month, what share of
    the fleet was scanned this month (coverage), and how many are overdue."""
    one = lambda q: db.query(q, one=True)["c"]
    total = one("SELECT COUNT(*) c FROM devices WHERE active=1 AND client_id IS NOT NULL")
    scanned = one("SELECT COUNT(DISTINCT device_id) c FROM device_inspections "
                  "WHERE strftime('%Y-%m',recorded_at)=strftime('%Y-%m','now','localtime')")
    return {
        "total": total,
        "needs_service": one("SELECT COUNT(*) c FROM devices WHERE active=1 AND status='needs_service'"),
        "activity_month": one("SELECT COUNT(*) c FROM device_inspections "
                              "WHERE status='activity' AND strftime('%Y-%m',recorded_at)=strftime('%Y-%m','now','localtime')"),
        "coverage": round(100.0 * scanned / total) if total else None,
        "stale": _stale_count(),
        "stale_days": STALE_SCAN_DAYS,
    }


def _owner_cockpit():
    """Aggregate owner KPIs: revenue (this vs last month), overdue receivables,
    SLA health, and per-technician utilization for the current month."""
    rev_month = db.query(
        "SELECT COALESCE(SUM(amount),0) v FROM payments "
        "WHERE strftime('%Y-%m', paid_at)=strftime('%Y-%m','now','localtime')", one=True)["v"]
    rev_prev = db.query(
        "SELECT COALESCE(SUM(amount),0) v FROM payments "
        "WHERE strftime('%Y-%m', paid_at)=strftime('%Y-%m','now','localtime','start of month','-1 month')",
        one=True)["v"]
    overdue = db.query(
        "SELECT COUNT(*) c, COALESCE(SUM(total - COALESCE("
        "(SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0)),0) amt "
        "FROM invoices i WHERE doc_type='invoice' AND status IN('sent','overdue') "
        "AND due_date IS NOT NULL AND date(due_date) < date('now','localtime')", one=True)
    sla_counts = {"ok": 0, "due_soon": 0, "overdue": 0}
    for r in _sla_rows():
        sla_counts[r["status"]] += 1
    # Technician utilization for the current calendar month: assigned vs completed.
    util = []
    for a in db.query(
            "SELECT u.id, u.full_name, COUNT(v.id) total, "
            "SUM(CASE WHEN v.status='completed' THEN 1 ELSE 0 END) completed, "
            "(SELECT ROUND(AVG(vr.stars),1) FROM visit_ratings vr "
            " JOIN visits v2 ON v2.id=vr.visit_id WHERE v2.agent_id=u.id) rating "
            "FROM users u LEFT JOIN visits v ON v.agent_id=u.id "
            "AND strftime('%Y-%m', v.scheduled_start)=strftime('%Y-%m','now','localtime') "
            "WHERE u.role IN ('agent','area_manager','team_leader') AND u.active=1 GROUP BY u.id "
            "ORDER BY total DESC, completed DESC"):
        total = a["total"] or 0
        completed = a["completed"] or 0
        util.append({
            "agent_id": a["id"], "name": a["full_name"], "total": total,
            "completed": completed, "rating": a["rating"],
            "rate": round(completed * 100.0 / total) if total else 0,
        })
    return {
        "revenue_month": rev_month, "revenue_prev": rev_prev,
        "overdue_invoices": overdue["c"], "overdue_amount": overdue["amt"],
        "sla": sla_counts, "utilization": util,
    }


# --------------------------------------------------------------------------
# USERS / AGENTS
# --------------------------------------------------------------------------
@route("GET", r"/api/users")
def list_users(ctx):
    require_perm(ctx.user, "users.view")
    role = ctx.query.get("role")
    sql = ("SELECT u.*, s.name site_name FROM users u LEFT JOIN sites s ON s.id=u.site_id")
    if role:
        rows = db.query(sql + " WHERE u.role=? ORDER BY u.full_name", (role,))
    else:
        rows = db.query(sql + " ORDER BY u.role, u.full_name")
    return [_public_user(r) | {"active": r["active"], "hire_date": r["hire_date"],
                               "site_name": r["site_name"]} for r in rows]


@route("GET", r"/api/agents")
def list_agents(ctx):
    # Whoever hands out work has to know who they can hand it to. This is a
    # names-and-trade projection of the field staff, not the account list, so
    # dispatching or scheduling is enough — a team leader plans their patch's
    # day without also being given the user admin screen.
    # `clients.edit` is here because a branch can now name the engineer it
    # belongs to, and whoever edits the branch has to be able to pick him.
    if not (has_perm(ctx.user, "dispatch.view") or has_perm(ctx.user, "visits.edit")
            or has_perm(ctx.user, "clients.edit")):
        require_perm(ctx.user, "users.view")
    rows = db.query("SELECT * FROM users WHERE role IN ('agent','area_manager','team_leader') AND active=1 "
                    "ORDER BY full_name")
    return [_public_user(r) | {"hire_date": r["hire_date"]} for r in rows]


@route("GET", r"/api/my-team")
def my_team(ctx):
    """Who a supervisor answers for on one day.

    For an AREA MANAGER this is derived, never stored: whoever the roster puts
    on one of their areas that date. Ask for another date and you get that
    day's crew, which is the whole point — an engineer is under whoever holds
    the patch they are serving today, and tomorrow that can be someone else.

    For a TEAM LEADER it is their standing team (users.team_leader_id), so the
    same faces come back on every date; only the day's shifts and visit counts
    beside them move.

    The office can look at anybody's team with ?leader_id=, which is how a
    manager checks a patch or a crew has someone on it."""
    u = ctx.user
    date = _shift_date(ctx.query["date"], "date") if ctx.query.get("date") else _today()
    target = u
    if ctx.query.get("leader_id"):
        if not has_perm(u, "users.view"):
            raise ApiError(403, "You do not have permission for this action")
        marks = ",".join("?" for _ in SUPERVISOR_ROLES)
        target = db.query(f"SELECT * FROM users WHERE id=? AND role IN ({marks})",
                          (int(ctx.query["leader_id"]), *SUPERVISOR_ROLES), one=True)
        if not target:
            raise ApiError(404, "Supervisor not found")
    elif u["role"] not in SUPERVISOR_ROLES:
        raise ApiError(400, "Only an area manager or a team leader has a team of their own")
    areas = db.query(
        "SELECT a.id, a.name_en, a.name_ar FROM area_manager_areas la JOIN areas a ON a.id=la.area_id "
        "WHERE la.manager_id=? ORDER BY a.sort_order, a.id", (target["id"],))
    ids = team_member_ids(target, date)
    members = []
    for uid in ids:
        person = db.query("SELECT id, full_name, phone, role FROM users WHERE id=? AND active=1",
                          (uid,), one=True)
        if not person:
            continue                       # rostered then deactivated
        row = dict(person)
        row["shifts"] = db.query(
            "SELECT s.id, s.area_id, a.name_en area_en, a.name_ar area_ar, "
            "COALESCE(s.start_time, t.start_time) from_time, "
            "COALESCE(s.end_time, t.end_time) to_time, t.name_en shift_en, t.name_ar shift_ar "
            "FROM agent_shifts s JOIN shift_types t ON t.id=s.shift_type_id "
            "LEFT JOIN areas a ON a.id=s.area_id "
            "WHERE s.agent_id=? AND s.shift_date=? ORDER BY from_time", (uid, date))
        counts = db.query(
            "SELECT COUNT(*) total, "
            "SUM(CASE WHEN status='completed' THEN 1 ELSE 0 END) done, "
            "SUM(CASE WHEN status='in_progress' THEN 1 ELSE 0 END) doing "
            "FROM visits WHERE agent_id=? AND date(scheduled_start)=date(?)", (uid, date), one=True)
        row["visits"] = {"total": counts["total"] or 0, "completed": counts["done"] or 0,
                         "in_progress": counts["doing"] or 0}
        # Paperwork this person still owes, on any day — the supervisor's chasing list.
        row["reports_due"] = db.query(
            "SELECT COUNT(*) c FROM visits v WHERE v.agent_id=? AND v.status='completed' "
            "AND NOT EXISTS(SELECT 1 FROM reports r WHERE r.visit_id=v.id AND r.status='complete')",
            (uid,), one=True)["c"]
        members.append(row)
    members.sort(key=lambda m: m["full_name"] or "")
    return {"date": date,
            "leader": {"id": target["id"], "full_name": target["full_name"],
                       "role": target["role"]},
            "areas": areas, "members": members}


def _portal_site_id(role, client_id, raw):
    """Validate the location a client-portal login is pinned to.

    Only a role='client' account can be pinned, and only to a location of its
    own company — anything else stores NULL rather than a dangling link."""
    if role != "client" or not client_id or raw in (None, "", 0, "0"):
        return None
    if not db.query("SELECT 1 FROM sites WHERE id=? AND client_id=?",
                    (raw, client_id), one=True):
        raise ApiError(400, "Invalid branch for this client")
    return int(raw)


@route("POST", r"/api/users")
def create_user(ctx):
    require_perm(ctx.user, "users.create")
    b = ctx.body
    if not b.get("email") or not b.get("password") or not b.get("full_name"):
        raise ApiError(400, "Name, email and password are required")
    if b.get("role") not in ROLES:
        raise ApiError(400, "Invalid role")
    # Only an admin may mint another admin (prevents privilege escalation by a
    # manager who merely holds users.create).
    if b["role"] == "admin" and ctx.user["role"] != "admin":
        raise ApiError(403, "Only an admin can create an admin user")
    if db.query("SELECT id FROM users WHERE lower(email)=?", (b["email"].lower(),), one=True):
        raise ApiError(409, "Email already in use")
    site_id = _portal_site_id(b.get("role"), b.get("client_id"), b.get("site_id"))
    uid = db.execute(
        "INSERT INTO users(full_name,email,password_hash,role,phone,client_id,site_id,specialization,"
        "hire_date,license_no,license_expiry,lang) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (b["full_name"], b["email"], auth.hash_password(b["password"]), b["role"],
         b.get("phone"), b.get("client_id"), site_id,
         b.get("specialization"), b.get("hire_date"),
         b.get("license_no"), b.get("license_expiry"), b.get("lang", "en")))
    if b["role"] == "area_manager":
        set_area_manager_areas(uid, b.get("area_ids"))
    if b["role"] == "team_leader":
        set_team_members(uid, b.get("member_ids"))
    # A new engineer can be put on a team as they are created.
    if b.get("team_leader_id") and b["role"] in FIELD_ROLES:
        boss = db.query("SELECT id FROM users WHERE id=? AND role='team_leader'",
                        (int(b["team_leader_id"]),), one=True)
        if not boss:
            raise ApiError(400, "That user is not a team leader")
        db.execute("UPDATE users SET team_leader_id=? WHERE id=?", (boss["id"], uid))
    audit(ctx, "user.create", "user", uid, f"{b['role']} {b['email']}")
    return _public_user(db.query("SELECT * FROM users WHERE id=?", (uid,), one=True))


@route("PUT", r"/api/users/(\d+)")
def update_user(ctx):
    require_perm(ctx.user, "users.edit")
    uid = int(ctx.params[0])
    b = ctx.body
    target = db.query("SELECT role, client_id, site_id FROM users WHERE id=?", (uid,), one=True)
    if not target:
        raise ApiError(404, "User not found")
    # Guard the admin role: only an admin may edit an admin account or grant the
    # admin role — otherwise a manager could elevate themselves / reset the admin.
    if ctx.user["role"] != "admin":
        if target["role"] == "admin":
            raise ApiError(403, "Only an admin can modify an admin account")
        if b.get("role") == "admin":
            raise ApiError(403, "Only an admin can grant the admin role")
    fields, vals = [], []
    for col in ("full_name", "phone", "role", "client_id", "specialization", "hire_date",
                "license_no", "license_expiry", "lang", "active"):
        if col in b:
            fields.append(f"{col}=?")
            vals.append(b[col])
    # The email is the login, so it can be corrected — a typo on the way in
    # should not mean a new account — but it stays unique and stays an address.
    if "email" in b:
        email = str(b["email"] or "").strip()
        if not email or "@" not in email:
            raise ApiError(400, "A valid email is required")
        clash = db.query("SELECT id FROM users WHERE lower(email)=? AND id!=?",
                         (email.lower(), uid), one=True)
        if clash:
            raise ApiError(409, "Email already in use")
        fields.append("email=?"); vals.append(email)
    # The location pin has to be re-checked whenever the role or the company
    # moves, or a demoted/reassigned account would keep a pin to a company it
    # no longer belongs to.
    if {"site_id", "role", "client_id"} & set(b):
        role = b.get("role", target["role"])
        cid = b.get("client_id", target["client_id"])
        raw = b.get("site_id", target["site_id"])
        fields.append("site_id=?")
        vals.append(_portal_site_id(role, cid, raw))
    if b.get("password"):
        fields.append("password_hash=?")
        vals.append(auth.hash_password(b["password"]))
        # Changing the password revokes the user's existing session tokens.
        fields.append("token_version=token_version+1")
    # The patch an area manager covers and the team a team leader holds, both
    # re-picked in full each time. Moving somebody off either role drops what
    # they held — a patch belongs to whoever currently manages it, a crew to
    # whoever currently leads it, and a stale row would quietly widen someone's
    # access if they were ever put back.
    role_now = b.get("role", target["role"])
    areas_set = None
    if role_now == "area_manager" and "area_ids" in b:
        areas_set = set_area_manager_areas(uid, b["area_ids"])
    elif role_now != "area_manager" and target["role"] == "area_manager":
        db.execute("DELETE FROM area_manager_areas WHERE manager_id=?", (uid,))
    team_set = None
    if role_now == "team_leader" and "member_ids" in b:
        team_set = set_team_members(uid, b["member_ids"])
    elif role_now != "team_leader" and target["role"] == "team_leader":
        db.execute("UPDATE users SET team_leader_id=NULL WHERE team_leader_id=?", (uid,))
    # An engineer's own line of report, set from their side of the form.
    if "team_leader_id" in b and role_now in FIELD_ROLES:
        tl = b["team_leader_id"] or None
        if tl:
            tl = int(tl)
            if tl == uid:
                raise ApiError(400, "Somebody cannot lead themselves")
            boss = db.query("SELECT id FROM users WHERE id=? AND role='team_leader'",
                            (tl,), one=True)
            if not boss:
                raise ApiError(400, "That user is not a team leader")
        fields.append("team_leader_id=?"); vals.append(tl)
    if not fields and areas_set is None and team_set is None:
        raise ApiError(400, "Nothing to update")
    if fields:
        vals.append(uid)
        db.execute(f"UPDATE users SET {','.join(fields)} WHERE id=?", vals)
    # Switching someone off here is the same event as deactivating them, so it
    # has to stop their salary too — otherwise the rule depends on which button
    # the office happened to use.
    paused = 0
    if "active" in b and str(b["active"]) in ("0", "false", "False"):
        paused = _pause_salaries_for(uid)
    audit(ctx, "user.update", "user", uid,
          ("password reset; " if b.get("password") else "") + ", ".join(f for f in b if f != "password")
          + (f"; {paused} salary line(s) paused" if paused else ""))
    out = _public_user(db.query("SELECT * FROM users WHERE id=?", (uid,), one=True))
    if paused:
        out["salaries_paused"] = paused
    return out


@route("DELETE", r"/api/users/(\d+)")
def deactivate_user(ctx):
    require_perm(ctx.user, "users.delete")
    uid = int(ctx.params[0])
    target = db.query("SELECT role FROM users WHERE id=?", (uid,), one=True)
    if target and target["role"] == "admin" and ctx.user["role"] != "admin":
        raise ApiError(403, "Only an admin can deactivate an admin account")
    db.execute("UPDATE users SET active=0 WHERE id=?", (uid,))
    # Somebody who has left is not on the payroll. Their salary is a standing
    # order that would otherwise keep posting itself every month, quietly
    # inflating payroll and every labour figure derived from it.
    paused = _pause_salaries_for(uid)
    audit(ctx, "user.delete", "user", uid,
          "deactivated" + (f", {paused} salary line(s) paused" if paused else ""))
    return {"ok": True, "salaries_paused": paused}


@route("DELETE", r"/api/users/(\d+)/permanent")
def delete_user(ctx):
    """Remove the account outright, rather than switching it off.

    Their roster, notifications and permission overrides go with them. Their
    work does NOT: visits, reports and the audit trail keep what they recorded
    (those columns null out, and the audit log stored the name at the time).

    Materials are the exception that blocks it. An engineer's issues explain
    stock that left the warehouse, and the rows cascade — deleting the person
    would erase the explanation while the inventory ledger still shows the
    movement. That account gets deactivated instead."""
    require_perm(ctx.user, "users.delete")
    uid = int(ctx.params[0])
    target = db.query("SELECT id, role, full_name, email FROM users WHERE id=?", (uid,), one=True)
    if not target:
        raise ApiError(404, "User not found")
    if uid == ctx.user["id"]:
        raise ApiError(400, "You cannot delete your own account")
    if target["role"] == "admin":
        if ctx.user["role"] != "admin":
            raise ApiError(403, "Only an admin can delete an admin account")
        others = db.query("SELECT COUNT(*) n FROM users WHERE role='admin' AND active=1 AND id!=?",
                          (uid,), one=True)["n"]
        if not others:
            raise ApiError(400, "This is the last admin — the CRM would lock everyone out")
    issues = db.query("SELECT COUNT(*) n FROM engineer_issues WHERE agent_id=?", (uid,), one=True)["n"]
    if issues:
        raise ApiError(400, f"{target['full_name']} has {issues} material issue(s) on record. "
                            "Deleting the account would erase the record of stock that left "
                            "the warehouse — deactivate them instead.")
    paused = _pause_salaries_for(uid)
    db.execute("DELETE FROM users WHERE id=?", (uid,))
    audit(ctx, "user.purge", "user", uid,
          f"{target['role']} {target['email']}" + (f", {paused} salary line(s) paused" if paused else ""))
    return {"deleted": True, "salaries_paused": paused}


def _pause_salaries_for(uid):
    """Switch off this person's salary standing orders. What they were already
    paid stays in the ledger — history does not change because someone left."""
    rows = db.query("SELECT id FROM cost_recurring WHERE user_id=? AND category='salary' "
                    "AND active=1", (uid,))
    for r in rows:
        db.execute("UPDATE cost_recurring SET active=0, updated_at=datetime('now','localtime') WHERE id=?",
                   (r["id"],))
    return len(rows)


# --------------------------------------------------------------------------
# AGENT SHIFTS — weekly roster (which shift each agent works on each day)
# --------------------------------------------------------------------------
_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_TIME_RE = re.compile(r"^([01]\d|2[0-3]):[0-5]\d$")


def _shift_date(value, field="date"):
    import datetime as _dt
    if not value or not _DATE_RE.match(str(value)):
        raise ApiError(400, f"Invalid {field} — expected YYYY-MM-DD")
    try:
        _dt.date.fromisoformat(str(value))   # rejects 2026-02-31 and friends
    except ValueError:
        raise ApiError(400, f"Invalid {field} — expected YYYY-MM-DD")
    return str(value)


def _shift_time(value, field):
    """Optional 'HH:MM' override. Empty string / None clears it."""
    if value in (None, ""):
        return None
    if not _TIME_RE.match(str(value)):
        raise ApiError(400, f"Invalid {field} — expected HH:MM")
    return str(value)


@route("GET", r"/api/shift-types")
def list_shift_types(ctx):
    require_perm(ctx.user, "shifts.view")
    where = "" if ctx.query.get("all") else " WHERE active=1"
    return db.query(f"SELECT * FROM shift_types{where} ORDER BY sort_order, id")


@route("POST", r"/api/shift-types")
def create_shift_type(ctx):
    require_perm(ctx.user, "shifts.create")
    b = ctx.body
    name = (b.get("name_en") or "").strip()
    if not name:
        raise ApiError(400, "Shift name is required")
    # The code is only an internal handle; derive one that can't collide.
    code = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-") or "shift"
    if db.query("SELECT 1 FROM shift_types WHERE code=?", (code,), one=True):
        code = f"{code}-{int(time.time())}"
    nxt = db.query("SELECT COALESCE(MAX(sort_order),0)+1 n FROM shift_types", one=True)["n"]
    sid = db.execute(
        "INSERT INTO shift_types(code,name_en,name_ar,start_time,end_time,color,is_off,"
        "open_ended,sort_order) VALUES(?,?,?,?,?,?,?,?,?)",
        (code, name, (b.get("name_ar") or "").strip() or None,
         _shift_time(b.get("start_time"), "start_time"), _shift_time(b.get("end_time"), "end_time"),
         (b.get("color") or "#1f74d6"), 1 if b.get("is_off") else 0,
         1 if b.get("open_ended") else 0, nxt))
    audit(ctx, "shift_type.create", "shift_type", sid, name)
    return db.query("SELECT * FROM shift_types WHERE id=?", (sid,), one=True)


@route("PUT", r"/api/shift-types/(\d+)")
def update_shift_type(ctx):
    require_perm(ctx.user, "shifts.edit")
    sid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM shift_types WHERE id=?", (sid,), one=True):
        raise ApiError(404, "Shift not found")
    b = ctx.body
    if "name_en" in b and not (b["name_en"] or "").strip():
        raise ApiError(400, "Shift name is required")
    fields, vals = [], []
    for col in ("name_en", "name_ar"):
        if col in b:
            fields.append(f"{col}=?")
            vals.append((b[col] or "").strip() or None)
    if b.get("color"):
        fields.append("color=?")
        vals.append(b["color"])
    for col in ("start_time", "end_time"):
        if col in b:
            fields.append(f"{col}=?")
            vals.append(_shift_time(b[col], col))
    for col in ("is_off", "active", "open_ended"):
        if col in b:
            fields.append(f"{col}=?")
            vals.append(1 if b[col] else 0)
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(sid)
    db.execute(f"UPDATE shift_types SET {','.join(fields)} WHERE id=?", vals)
    audit(ctx, "shift_type.update", "shift_type", sid)
    return db.query("SELECT * FROM shift_types WHERE id=?", (sid,), one=True)


@route("DELETE", r"/api/shift-types/(\d+)")
def delete_shift_type(ctx):
    """Retire a shift. Deactivated rather than deleted when it is already on the
    roster, so historical weeks keep showing what people actually worked."""
    require_perm(ctx.user, "shifts.delete")
    sid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM shift_types WHERE id=?", (sid,), one=True):
        raise ApiError(404, "Shift not found")
    used = db.query("SELECT 1 FROM agent_shifts WHERE shift_type_id=? LIMIT 1", (sid,), one=True)
    if used:
        db.execute("UPDATE shift_types SET active=0 WHERE id=?", (sid,))
    else:
        db.execute("DELETE FROM shift_types WHERE id=?", (sid,))
    audit(ctx, "shift_type.delete", "shift_type", sid, "deactivated" if used else "deleted")
    return {"ok": True, "deactivated": bool(used)}


_SHIFT_SELECT = """
SELECT s.*, u.full_name AS agent_name,
       st.code AS shift_code, st.name_en AS shift_name_en, st.name_ar AS shift_name_ar,
       st.color AS shift_color, st.is_off AS is_off,
       ar.name_en AS area_en, ar.name_ar AS area_ar,
       COALESCE(s.start_time, st.start_time) AS from_time,
       COALESCE(s.end_time,   st.end_time)   AS to_time
FROM agent_shifts s
JOIN users u ON u.id = s.agent_id
JOIN shift_types st ON st.id = s.shift_type_id
LEFT JOIN areas ar ON ar.id = s.area_id
"""


@route("GET", r"/api/shifts")
def list_shifts(ctx):
    """The roster for a date range (defaults to the current week)."""
    require_perm(ctx.user, "shifts.view")
    q = ctx.query
    frm = _shift_date(q["from"], "from") if q.get("from") else None
    to = _shift_date(q["to"], "to") if q.get("to") else None
    where, params = ["1=1"], []
    if frm:
        where.append("s.shift_date >= ?")
        params.append(frm)
    if to:
        where.append("s.shift_date <= ?")
        params.append(to)
    if q.get("agent_id"):
        where.append("s.agent_id = ?")
        params.append(int(q["agent_id"]))
    # An agent without edit rights only sees their own roster line.
    if not has_perm(ctx.user, "shifts.edit") and ctx.user["role"] == "agent":
        where.append("s.agent_id = ?")
        params.append(ctx.user["id"])
    # An area manager rosters their own patch: the shifts that sit on one of
    # their areas, plus their own line wherever it is. A team leader rosters
    # people instead: their own team's lines, wherever those send them.
    if ctx.user["role"] == "area_manager":
        areas = area_manager_area_ids(ctx.user)
        if areas:
            marks = ",".join("?" for _ in areas)
            where.append(f"(s.area_id IN ({marks}) OR s.agent_id = ?)")
            params += [*areas, ctx.user["id"]]
        else:
            where.append("s.agent_id = ?")
            params.append(ctx.user["id"])
    elif ctx.user["role"] == "team_leader":
        ids = [*team_member_ids(ctx.user), ctx.user["id"]]
        marks = ",".join("?" for _ in ids)
        where.append(f"s.agent_id IN ({marks})")
        params += ids
    return db.query(f"{_SHIFT_SELECT} WHERE {' AND '.join(where)} "
                    "ORDER BY s.shift_date, u.full_name, from_time", params)


@route("GET", r"/api/shifts/week")
def shift_week(ctx):
    """Everything the weekly roster grid needs in one call: the seven days, the
    agents to roster, the shift catalog, the assignments already made, and each
    agent's visit count per day (so a manager rosters against the real load)."""
    import datetime as _dt
    require_perm(ctx.user, "shifts.view")
    start = ctx.query.get("start")
    day = _dt.date.fromisoformat(_shift_date(start, "start")) if start else _dt.date.today()
    # The roster week runs Saturday–Friday. date.weekday() is Mon=0 … Sat=5, so
    # this steps back to the Saturday on or before the requested day.
    first = day - _dt.timedelta(days=(day.weekday() - 5) % 7)
    days = [(first + _dt.timedelta(days=i)).isoformat() for i in range(7)]
    frm, to = days[0], days[6]

    editable = has_perm(ctx.user, "shifts.edit")
    if ctx.user["role"] == "team_leader":
        # A team leader's roster is their team's roster and their own line —
        # the whole point of the role is that it follows the people.
        ids = [*team_member_ids(ctx.user), ctx.user["id"]]
        marks = ",".join("?" for _ in ids)
        agents = db.query(
            f"SELECT id, full_name, role, specialization FROM users "
            f"WHERE id IN ({marks}) AND active=1 ORDER BY role='team_leader' DESC, full_name", ids)
    elif editable or ctx.user["role"] != "agent":
        agents = db.query(
            "SELECT id, full_name, role, specialization FROM users "
            "WHERE role IN ('agent','manager','area_manager','team_leader') AND active=1 "
            "ORDER BY role='manager', full_name")
    else:
        # A rostered agent sees only their own line.
        agents = db.query(
            "SELECT id, full_name, role, specialization FROM users WHERE id=?",
            (ctx.user["id"],))
    agent_ids = {a["id"] for a in agents}

    shifts = [s for s in db.query(
        f"{_SHIFT_SELECT} WHERE s.shift_date BETWEEN ? AND ? "
        "ORDER BY s.shift_date, from_time", (frm, to))
        if s["agent_id"] in agent_ids]

    load = {}
    if has_perm(ctx.user, "visits.view"):
        for r in db.query(
                "SELECT agent_id, substr(scheduled_start,1,10) d, COUNT(*) c FROM visits "
                "WHERE agent_id IS NOT NULL AND status<>'cancelled' "
                "AND substr(scheduled_start,1,10) BETWEEN ? AND ? GROUP BY agent_id, d", (frm, to)):
            if r["agent_id"] in agent_ids:
                load[f"{r['agent_id']}|{r['d']}"] = r["c"]

    return {
        "start": frm, "end": to, "days": days,
        "agents": agents,
        "types": db.query("SELECT * FROM shift_types WHERE active=1 ORDER BY sort_order, id"),
        "areas": db.query("SELECT * FROM areas WHERE active=1 ORDER BY sort_order, name_en"),
        "shifts": shifts,
        "visit_load": load,
        "editable": editable,
    }


def _hhmm_min(value):
    """'HH:MM' -> minutes past midnight, or None."""
    if not value:
        return None
    h, m = str(value).split(":")
    return int(h) * 60 + int(m)


DAY_END = 24 * 60


def _window_bounds(w_from, w_to):
    """A branch's opening window as minutes past midnight, with a closing time
    that lands on the NEXT day carried PAST 1440 instead of coming out negative.

    A restaurant serviced after it shuts is entered as 22:00 -> 02:00, and that
    is a real four-hour window, not minus twenty hours. Plain subtraction made
    it negative, which read as "opens for only -1200 minutes" on the roster
    preview and — far worse — meant the visit could never be fitted, so the
    branch quietly fell off the schedule week after week.

    Either end may be None, meaning open-ended that side."""
    a = _hhmm_min(w_from) if w_from else None
    b = _hhmm_min(w_to) if w_to else None
    if a is not None and b is not None and b <= a:
        b += DAY_END
    return a, b


def _bookable_minutes(w_from, w_to):
    """How long the branch's door is open, midnight or no midnight. A branch
    open 22:00-02:00 is open for four hours, and all four are bookable: the
    visit that starts at 23:45 simply ends at 00:15 the next morning, which is
    what a night round actually looks like. None when either end is open-ended
    — there is no length to speak of."""
    a, b = _window_bounds(w_from, w_to)
    if a is None or b is None:
        return None
    return b - a


def _job_sort_key(job):
    """Hardest to fit first (see the allocator, which is where this is used):
    the earliest DEADLINE, then the earliest opening. A job with no window
    sorts as if it closed at midnight; a night window sorts on the midnight it
    must be finished by, not on the small hours printed on its sign.

    THE DEADLINE, NOT THE CLOSING TIME, and the difference is not academic. An
    area offers the allocator ONE candidate — its first fit in this order — so
    a job that sorts second never competes at all. The owner's Exception
    Factory is an eight-hour visit at a branch open 07:00-15:00: it must begin
    at seven or not at all, and on closing time alone it sorted BEHIND a
    half-hour coffee shop shutting at 08:30. His engineer did the coffee shop
    at eight, and the factory that is his whole day was reported as work his
    own man had no room for."""
    a, b = _job_window(job)
    return (job["visit_id"] is None, -job.get("overdue", 0),
            b - (job.get("mins") or 0) if b is not None else DAY_END * 2, a or 0)


def _job_window(job):
    """The bounds the planner may place a job inside, on a timeline that starts
    at midnight of the day the round BEGINS and simply keeps counting: a window
    of 22:00-02:00 is 1320..1560, not 1320..1440. Everything past 1440 is the
    next morning, and _stamp turns it back into a clock and a date."""
    return _window_bounds(job.get("from"), job.get("to"))


def _stamp(minutes):
    """A minute on that timeline -> ('HH:MM', how many days past the start).

    THE ONE PLACE the planner's flat timeline becomes a real clock. A round
    that begins at 22:00 on the 1st and ends at 03:00 on the 2nd is one shift
    to the engineer and two dates to the database, and every visit written out
    of that round has to carry the date its own clock actually falls on."""
    minutes = int(minutes)
    return _mins_to_hhmm(minutes % DAY_END), minutes // DAY_END


def _segments(start, end):
    """The minute ranges a shift covers. A shift that runs past midnight (22:00
    to 06:00) becomes two ranges, so overlap can be compared on a flat timeline.
    Equal start and end means a full 24 hours."""
    a, b = _hhmm_min(start), _hhmm_min(end)
    if a is None or b is None:
        return []
    if a == b:
        return [(0, 1440)]
    return [(a, b)] if b > a else [(a, 1440), (0, b)]


def _shift_minutes(start, end):
    return sum(e - s for s, e in _segments(start, end))


def _clean_day_shifts(raw):
    """Validate the set of shifts an agent holds on one day.

    Several are allowed — a short morning plus a short evening, say — so long as
    their hours don't collide. Returns the rows ready to insert.
    """
    if not isinstance(raw, list):
        raise ApiError(400, "shifts must be a list")
    if len(raw) > 6:
        raise ApiError(400, "Too many shifts in one day")
    out = []
    for item in raw:
        type_id = item.get("shift_type_id")
        if type_id in (None, "", 0, "0"):
            continue                      # a blank row in the day editor
        type_id = int(type_id)
        ty = db.query("SELECT * FROM shift_types WHERE id=?", (type_id,), one=True)
        if not ty:
            raise ApiError(404, "Shift not found")
        start = _shift_time(item.get("start_time"), "start_time")
        end = _shift_time(item.get("end_time"), "end_time")
        # Fall back to the shift's standard hours; an explicit time on the entry
        # is what makes a 2-hour or 4-hour block possible.
        eff_start = start or ty["start_time"]
        eff_end = end or ty["end_time"]
        # An open-ended shift is worked but not clocked: the engineer covers an
        # area and finishes when the work is done. Hours are not required, and
        # any that arrive are ignored rather than half-recorded — with no hours
        # it has no segments, so it never collides and a second area can share
        # the day. Set hours on it and it stops being open-ended, which is why
        # this drops them outright.
        if ty["open_ended"]:
            eff_start = eff_end = None
        elif not ty["is_off"] and (not eff_start or not eff_end):
            raise ApiError(400, f"{ty['name_en']} needs a start and end time on this day")
        if eff_start and eff_end and _shift_minutes(eff_start, eff_end) == 0:
            raise ApiError(400, "A shift must be longer than zero minutes")
        out.append({
            "shift_type_id": type_id, "area_id": _coerce_area_id(item.get("area_id")),
            "start_time": start, "end_time": end,
            "note": (item.get("note") or "").strip() or None,
            "is_off": ty["is_off"], "name": ty["name_en"],
            "segments": _segments(eff_start, eff_end),
        })
    # A day off is a statement about the whole day, so it can't share it.
    if any(r["is_off"] for r in out) and len(out) > 1:
        raise ApiError(400, "A day off cannot be combined with other shifts")
    for i, r in enumerate(out):
        for other in out[i + 1:]:
            if any(s1 < e2 and s2 < e1 for s1, e1 in r["segments"]
                   for s2, e2 in other["segments"]):
                raise ApiError(409, f"{r['name']} and {other['name']} overlap on this day")
    return out


def _replace_day(ctx, agent_id, date, shifts, cx):
    """Make an agent's shifts for one day exactly `shifts`. An empty list clears
    the day. Runs inside a transaction so a day is never half-written."""
    if not agent_id:
        raise ApiError(400, "Engineer is required")
    agent_id = int(agent_id)
    date = _shift_date(date)
    agent = db.query("SELECT role FROM users WHERE id=?", (agent_id,), one=True)
    if not agent:
        raise ApiError(404, "Engineer not found")
    if agent["role"] == "client":
        raise ApiError(400, "Client users cannot be rostered")
    rows = _clean_day_shifts(shifts)
    _assert_sup_may_roster(ctx.user, agent_id, date, rows)
    cx.execute("DELETE FROM agent_shifts WHERE agent_id=? AND shift_date=?", (agent_id, date))
    for r in rows:
        cx.execute(
            "INSERT INTO agent_shifts(agent_id,shift_date,shift_type_id,area_id,start_time,"
            "end_time,note,assigned_by) VALUES(?,?,?,?,?,?,?,?)",
            (agent_id, date, r["shift_type_id"], r["area_id"], r["start_time"], r["end_time"],
             r["note"], ctx.user["id"]))
    return len(rows)


def _assert_sup_may_roster(user, agent_id, date, rows):
    """An area manager rosters their own patch and nobody else's; a team leader
    rosters their own team and nobody else.

    For the area manager both ends are checked: every shift being WRITTEN must
    sit on one of their areas, and so must every shift already on that day —
    _replace_day clears the day before rewriting it, so without this a manager
    could wipe another manager's morning block by editing the evening one.

    For the team leader the question is the person, not the place: their own
    engineers' days are theirs to write, wherever those days send them.
    Everybody's own line is always theirs to edit."""
    role = user.get("role")
    if role not in SUPERVISOR_ROLES:
        return
    if int(agent_id) == user["id"]:
        return
    if role == "team_leader":
        if int(agent_id) not in team_member_ids(user):
            raise ApiError(403, "You can only roster your own team")
        return
    areas = area_manager_area_ids(user)
    for r in rows:
        if r["area_id"] not in areas:
            raise ApiError(403, "You can only roster your own areas")
    for ex in db.query("SELECT area_id FROM agent_shifts WHERE agent_id=? AND shift_date=?",
                       (int(agent_id), date)):
        if ex["area_id"] not in areas:
            raise ApiError(403, "That day holds a shift outside your areas")


def _day_shifts_of(body):
    """Accept either {shifts:[…]} or a single flat {shift_type_id, …} entry."""
    if isinstance(body.get("shifts"), list):
        return body["shifts"]
    if body.get("shift_type_id") in (None, "", 0, "0"):
        return []
    return [body]


@route("POST", r"/api/shifts/day")
def set_day_shifts(ctx):
    """Set everything an agent works on one day. This is the roster's main write:
    the day editor sends the whole list, so adding a second block, trimming hours
    and removing one are all the same call."""
    require_perm(ctx.user, "shifts.create")
    b = ctx.body
    agent_id, date = b.get("agent_id"), b.get("date") or b.get("shift_date")
    with db.transaction() as cx:
        n = _replace_day(ctx, agent_id, date, _day_shifts_of(b), cx)
    audit(ctx, "shift.day", "agent_shift", agent_id, f"{date}: {n} shift(s)")
    return db.query(f"{_SHIFT_SELECT} WHERE s.agent_id=? AND s.shift_date=? "
                    "ORDER BY from_time", (int(agent_id), _shift_date(date)))


@route("POST", r"/api/shifts")
def assign_shift(ctx):
    """Add one shift to an agent's day, keeping any already there."""
    require_perm(ctx.user, "shifts.create")
    b = ctx.body
    agent_id, date = b.get("agent_id"), b.get("date") or b.get("shift_date")
    existing = []
    if agent_id and date:
        existing = db.query(
            "SELECT shift_type_id, area_id, start_time, end_time, note FROM agent_shifts "
            "WHERE agent_id=? AND shift_date=?", (int(agent_id), _shift_date(date)))
    with db.transaction() as cx:
        _replace_day(ctx, agent_id, date, existing + _day_shifts_of(b), cx)
    audit(ctx, "shift.assign", "agent_shift", agent_id, str(date))
    return db.query(f"{_SHIFT_SELECT} WHERE s.agent_id=? AND s.shift_date=? "
                    "ORDER BY from_time", (int(agent_id), _shift_date(date)))


@route("POST", r"/api/shifts/bulk")
def assign_shifts_bulk(ctx):
    """Roster several days at once — used by "fill the week" and "copy last
    week". Each item is one agent-day and replaces that day outright. All or
    nothing, so a bad row can't half-apply a week."""
    require_perm(ctx.user, "shifts.create")
    items = ctx.body.get("items")
    if not isinstance(items, list) or not items:
        raise ApiError(400, "No shifts to save")
    if len(items) > 500:
        raise ApiError(400, "Too many shifts in one request")
    with db.transaction() as cx:
        for it in items:
            _replace_day(ctx, it.get("agent_id"), it.get("date") or it.get("shift_date"),
                         _day_shifts_of(it), cx)
    audit(ctx, "shift.bulk", "agent_shift", None, f"{len(items)} day(s)")
    return {"ok": True, "saved": len(items)}


@route("POST", r"/api/shifts/area")
def roster_area(ctx):
    """Put engineers on an AREA across a set of days.

    This is the roster for an office whose day is defined by WHERE someone
    works, not by when: pick the area, pick the people, pick the days. Hours are
    optional and default to the open-ended "Area cover" shift, which has none.

    It APPENDS rather than replacing the day — /shifts/day and /shifts/bulk both
    rewrite a day outright, which would mean rostering a second area silently
    wiped the first. An engineer who covers two areas in one day is the normal
    case here, so the same person/day/area twice is skipped, not duplicated."""
    require_perm(ctx.user, "shifts.create")
    b = ctx.body
    area_id = _coerce_area_id(b.get("area_id"))
    if not area_id:
        raise ApiError(400, "An area is required")
    agent_ids = [int(a) for a in (b.get("agent_ids") or []) if str(a).isdigit()]
    if not agent_ids:
        raise ApiError(400, "Choose at least one engineer")
    dates = [_shift_date(d, "date") for d in (b.get("dates") or [])]
    if not dates:
        raise ApiError(400, "Choose at least one day")
    if len(agent_ids) * len(dates) > 500:
        raise ApiError(400, "Too many shifts in one request")
    ty = _cover_shift_type(b.get("shift_type_id"))
    start = _shift_time(b.get("start_time"), "start_time") if not ty["open_ended"] else None
    end = _shift_time(b.get("end_time"), "end_time") if not ty["open_ended"] else None
    saved = skipped = 0
    with db.transaction() as cx:
        for aid in agent_ids:
            person = db.query("SELECT role FROM users WHERE id=?", (aid,), one=True)
            if not person:
                raise ApiError(404, "Engineer not found")
            if person["role"] == "client":
                raise ApiError(400, "Client users cannot be rostered")
            for date in dates:
                # The supervisor guard reads the day as it WILL be, so it is handed
                # the new entry plus whatever is already there.
                existing = db.query(
                    "SELECT shift_type_id, area_id, start_time, end_time, note "
                    "FROM agent_shifts WHERE agent_id=? AND shift_date=?", (aid, date))
                if any(e["area_id"] == area_id and e["shift_type_id"] == ty["id"]
                       for e in existing):
                    skipped += 1
                    continue
                rows = _clean_day_shifts(
                    [dict(e) for e in existing]
                    + [{"shift_type_id": ty["id"], "area_id": area_id,
                        "start_time": start, "end_time": end}])
                _assert_sup_may_roster(ctx.user, aid, date, rows)
                cx.execute(
                    "INSERT INTO agent_shifts(agent_id,shift_date,shift_type_id,area_id,"
                    "start_time,end_time,assigned_by) VALUES(?,?,?,?,?,?,?)",
                    (aid, date, ty["id"], area_id, start, end, ctx.user["id"]))
                saved += 1
    audit(ctx, "shift.area", "agent_shift", area_id,
          f"{len(agent_ids)} engineer(s) x {len(dates)} day(s): {saved} added, {skipped} already set")
    return {"saved": saved, "skipped": skipped}


def _cover_shift_type(requested=None):
    """The shift an area roster writes. An explicit choice wins; otherwise the
    open-ended "Area cover" type, creating it if this database predates it."""
    if requested not in (None, "", 0, "0"):
        ty = db.query("SELECT * FROM shift_types WHERE id=?", (int(requested),), one=True)
        if not ty:
            raise ApiError(404, "Shift not found")
        return ty
    ty = db.query("SELECT * FROM shift_types WHERE open_ended=1 AND active=1 "
                  "ORDER BY sort_order, id", one=True)
    if not ty:
        # No hours-free shift left — this office has renamed the built-in one
        # into their own lineup. Make a fresh one rather than rostering with
        # whatever now sits under the old code: a cover row that carries hours
        # collides with the engineer's real shifts and takes the run down.
        with db.transaction() as cx:
            db.ensure_cover_shift(cx)
        ty = db.query("SELECT * FROM shift_types WHERE open_ended=1 AND active=1 "
                      "ORDER BY sort_order, id", one=True)
    return ty


# --------------------------------------------------------------------------
# AUTOMATIC SCHEDULING
#
# One button fills the roster AND the diary. The office supplies three facts
# per branch — its area, when it will accept a visit, how many visits a week it
# needs — and two per engineer: which areas they may work and their hours per
# weekday. Everything below is derived from those; nothing is hand-placed.
#
# The planner is a PURE function. The endpoint previews it or applies it, both
# from the same call, so what is shown can never differ from what is written.
# --------------------------------------------------------------------------
AUTO_SLOT_MIN = 60          # minutes a visit occupies, travel included
_WEEK_MINUTES = 24 * 60


def _mins_to_hhmm(m):
    return f"{int(m) // 60:02d}:{int(m) % 60:02d}"


def _clock_min(stamp):
    """Minutes past midnight from a stored timestamp ('YYYY-MM-DD HH:MM…' or
    the 'T' form), or None when there is no usable time in it. Tolerant on
    purpose: a timestamp the scheduler cannot read must not take the whole
    plan down, it must simply not reserve anything."""
    if not stamp or len(str(stamp)) < 16:
        return None
    try:
        return _hhmm_min(str(stamp)[11:16])
    except (ValueError, IndexError):
        return None


def _avail_bounds(start, end):
    """An engineer's hours for one day, in minutes, as the board means them.

    A BLANK BOX MEANS NO LIMIT ON THAT SIDE — blank to blank is the whole
    twenty-four hours, and that is the office's own reading: "when I leave the
    time in engineer availability blank it doesn't go to 24 hour availability,
    it goes from 9 to 17:00 — make it fit 24 hours, at any time." Nine to five
    was a guess this code had no business making, and it quietly shut a man out
    of every branch that opens in the evening.

    A shift entered the other way round (22:00 -> 06:00) is the night, and the
    end is carried past midnight rather than coming out negative — the same
    reading as a branch's window."""
    s_min = _hhmm_min(start) if start else 0
    e_min = _hhmm_min(end) if end else DAY_END
    if e_min <= s_min:
        e_min += DAY_END
    return s_min, e_min


def _weekday_set(raw):
    """'1,3' -> {1, 3}; anything empty -> None, which means "no restriction".
    None and the empty set are deliberately different answers: no rule at all
    versus a rule that allows nothing."""
    if raw in (None, ""):
        return None
    out = {int(p) for p in str(raw).split(",") if p.strip().isdigit() and 0 <= int(p) <= 6}
    return out or None


def _weekday_text(raw):
    """The other direction, for storing: a list of weekdays -> '1,3', or None
    when every day is allowed. Refuses anything that is not a weekday."""
    if raw in (None, "", []):
        return None
    if not isinstance(raw, (list, tuple, set)):
        raise ApiError(400, "Weekdays must be a list")
    out = set()
    for v in raw:
        try:
            n = int(v)
        except (TypeError, ValueError):
            raise ApiError(400, "Weekday must be 0-6")
        if not 0 <= n <= 6:
            raise ApiError(400, "Weekday must be 0-6")
        out.add(n)
    return ",".join(str(n) for n in sorted(out)) or None


def _rest_days():
    """The weekdays the roster treats as rest — planned on only when a branch
    would otherwise miss its visit altogether.

    Stored as a comma-separated list of PYTHON weekdays (Mon=0 … Sun=6), the
    same numbering as `agent_availability` and `site_service_days`, so nothing
    has to be converted at compare time. Default 4 = Friday. Empty means the
    week has no rest day and every day is dealt on as before."""
    row = db.query("SELECT value FROM settings WHERE key='auto_rest_days'", one=True)
    raw = (row or {}).get("value")
    if raw is None:
        raw = "4"
    out = set()
    for part in str(raw).split(","):
        part = part.strip()
        if part.isdigit() and 0 <= int(part) <= 6:
            out.add(int(part))
    return out


def _auto_slot_minutes():
    """How long one visit occupies, travel included. A setting because an hour
    per call is a guess about THIS company's work, not a fact about scheduling."""
    row = db.query("SELECT value FROM settings WHERE key='auto_slot_minutes'", one=True)
    try:
        return max(15, int(float((row or {}).get("value") or AUTO_SLOT_MIN)))
    except (TypeError, ValueError):
        return AUTO_SLOT_MIN


def _setting_num(key, fallback, low, high):
    """A numeric setting, guarded. Garbage or a wild value must never take the
    whole planner down — it falls back to something workable."""
    row = db.query("SELECT value FROM settings WHERE key=?", (key,), one=True)
    try:
        return max(low, min(high, float((row or {}).get("value"))))
    except (TypeError, ValueError):
        return fallback


def _travel_config():
    """Read once per plan, not once per placement.

    ONE NUMBER, AND IT IS A MAXIMUM. The owner: "delete the 15 min to get to
    the location, make it maximum 45min to travel — of course he can travel in
    less minutes." Fifteen minutes between two calls is not a Cairo journey,
    and it was not a ceiling either, it was a fixed charge.

    So `max` is the longest journey the plan will ever ask of anybody, and it
    does two jobs:
      · when the drive CANNOT be measured — which is every drive on a book
        where no branch has coordinates — it is what the day reserves. He may
        well arrive in twenty minutes; the diary simply does not promise a
        customer a slot that assumes he did.
      · when it CAN be measured, the real drive is used, and a hop longer than
        this is not offered at all: the branch waits for somebody nearer
        instead of being handed a round trip that eats the afternoon.

    `auto_travel_minutes` is still read for a book that set the old key — and
    read for its PRESENCE, not its truth: a company that deliberately set it to
    zero means zero, and must not be handed the new default instead."""
    cap = _setting_num("auto_travel_max_minutes", None, 0, 300)
    if cap is None:
        cap = _setting_num("auto_travel_minutes", 45, 0, 300)
    cap = int(cap)
    # AND A SECOND MAXIMUM, FOR THE DRIVE THAT NEVER LEAVES THE PATCH. Crossing
    # Cairo and crossing the Fifth Settlement are not the same journey, and
    # until this the plan reserved the same three quarters of an hour for both.
    # That is what made a round of four calls in one area cost the same as four
    # calls in four areas — so the diary had no reason to keep a man where he
    # was, and no room for the extra call that staying would have bought him.
    # Still a MAXIMUM, and still only used where the drive cannot be measured:
    # two geocoded branches are timed on the real distance whatever patch they
    # are in.
    # Defaulted here as well as in the settings table, because a CRM that has
    # been running since before this setting existed has no row for it — and
    # falling back to the full allowance would leave every book already in use
    # planning exactly as it did before, which is the bug.
    near = min(int(_setting_num("auto_travel_area_minutes", 20, 0, 300)), cap)
    return {"flat": cap, "max": cap, "area": near,
            "kmh": _setting_num("auto_travel_kmh", 25, 0, 200)}


def _travel_minutes(frm, to, cfg, same_place=False, same_area=False):
    """How long it takes to get from one stop to the next.

    Coordinates on BOTH ends buys a real distance; anything else falls back to
    an allowance — the shorter one when the next call is in the SAME AREA, the
    full one when it is not. Two calls at the same place cost nothing; that is
    the one case we can be sure about."""
    if same_place:
        return 0
    if not frm or not to or not cfg["kmh"]:
        return cfg.get("area", cfg["flat"]) if same_area else cfg["flat"]
    if frm == to:
        return 0
    return int(round(_haversine(frm, to) / cfg["kmh"] * 60))


def _one_address(prev, job):
    """Whether the next call is at the SAME PLACE as the last one, so there is
    no journey to charge between them.

    The obvious case is the same branch twice. The one that matters to the
    office is the other: three branches of one customer inside one area — MMK's
    kitchen, bakery and club; R.W's five units in Dabaa City — are one compound
    with three doors, and charging a full cross-town allowance to walk between
    them would make a round the day cannot hold.

    Only ever assumed where nobody has said otherwise: if EITHER branch carries
    coordinates the measured distance decides, so an office that really does
    have two addresses for one customer in one area fixes it by geocoding them.

    `prev` is (site_id, client_id, area_id, geo) — where the engineer is now."""
    p_site, p_client, p_area, p_geo = prev
    if p_site is not None and p_site == job["site_id"]:
        return True
    if p_geo or job.get("geo"):
        return False
    return (p_client is not None and p_client == job["client_id"]
            and p_area is not None and p_area == job.get("area_id"))


def _too_far_to_drive(frm, to, cfg, same_place=False):
    """Whether this hop is longer than the office allows anybody to drive
    between two calls. Only ever true for a journey we can actually MEASURE —
    an unmeasured drive falls back to the allowance, which is the ceiling
    itself, and refusing it would take every branch off the map."""
    if same_place or not frm or not to or not cfg.get("max"):
        return False
    return _travel_minutes(frm, to, cfg) > cfg["max"]


def _week_index(d):
    """A stable week number on the roster's OWN week, which runs SATURDAY to
    FRIDAY. Rotation and the visit cycle are both keyed on it, so the SAME week
    always replans identically (re-running is safe) while consecutive weeks
    shift.

    IT USED TO BE THE ISO WEEK, AND THAT WAS A REAL BUG, not a detail. ISO weeks
    start on MONDAY; every other part of this app — `shift_week`, the frontend's
    `weekStartOf`, the availability board, the auto-roster modal — starts the
    week on SATURDAY. So the office's ordinary Sat-to-Fri range straddled two
    ISO weeks, and a branch asking for one visit a week was due once in each:
    it got TWO visits two days apart and then a twelve-day gap, while the branch
    whose turn fell in the half of each ISO week that lay outside the range got
    NONE. Measured on a copy of the live book: 13-16 branches double-booked and
    ~13 more starved, every single week.

    Saturdays are the days whose proleptic ordinal is 6 mod 7, so +1 puts a
    week boundary exactly there."""
    return (d.toordinal() + 1) // 7


# How many roster weeks the office calls a month. Four Saturday-to-Friday
# weeks, not a calendar month: the roster only ever plans in whole weeks, and a
# calendar month that starts on a Wednesday has no honest number of them.
WEEKS_PER_MONTH = roster.WEEKS_PER_MONTH


def _month_days_now():
    """How many days this calendar month actually has. A month is 28, 29, 30 or
    31 days — never a nominal four weeks — and every conversion between a
    monthly figure and a weekly one goes through the real number."""
    today = _dt_mod.date.today()
    return roster.days_in_month(today.year, today.month)


def _job_minutes(site, default_slot):
    """How long this branch's visit takes: its own length, else the company
    default. Read by the capacity screen and the branch board as well as the
    planner, so it lives here rather than inside the roster module."""
    try:
        n = int(site.get("visit_minutes") or 0)
    except (TypeError, ValueError):
        n = 0
    return n if n > 0 else default_slot


def _roster_settings():
    """The dials, read once per plan. Every one has a code default, so a book
    with no settings rows plans exactly the same as one with them."""
    return {
        "slot_minutes": _auto_slot_minutes(),
        "travel_area": int(_setting_num("auto_travel_area_minutes", 20, 0, 240)),
        "travel_max": int(_setting_num("auto_travel_max_minutes", 45, 0, 240)),
        "travel_kmh": _setting_num("auto_travel_kmh", 25, 5, 120),
        "areas_per_day": int(_setting_num("auto_areas_per_day", 2, 1, 28)),
        "rest_day": int(_setting_num("auto_rest_days", 4, 0, 6)),
        # Phase 4A: how far a visit may be nudged from its due date to join a
        # round already going to its patch. 0 switches the preference off.
        "cluster_days": int(_setting_num("auto_cluster_days", 3, 0, 14)),
        # Phase 4B: the largest day the move-only compaction will try to
        # dissolve onto other rounds. 0 switches the pass off.
        "compact": int(_setting_num("auto_compact", 2, 0, 8)),
    }


def _plan_auto_roster(frm, to, user=None):
    """THE ROSTER, from six rules — see roster.py, which owns every one of them.

    This is the seam between the office's screen and the planner: the dials
    come from Settings, the plan comes back in the shape the preview and the
    apply path have always read, and nothing is written here."""
    # An area manager plans and is warned about their own patch; everybody else
    # who may press the button sees the whole book.
    scope = area_manager_area_ids(user) if user else None
    try:
        return roster.plan(db, frm, to, _roster_settings(),
                           scope_areas=scope if scope else None)
    except roster.RosterError as e:
        raise ApiError(400, str(e))


@route("POST", r"/api/shifts/auto")
def auto_roster(ctx):
    """Preview or apply the automatic schedule for a range.

    Preview by default; `apply: true` writes it. Applying does three things per
    assignment: books the visits it invented, gives an engineer to visits that
    were already booked without one, and rosters the engineer onto the areas
    the day actually sent them to — through the APPEND path, so a day that
    already holds other work keeps it."""
    require_perm(ctx.user, "shifts.create")
    b = ctx.body
    frm = _shift_date(b.get("from"), "from")
    to = _shift_date(b.get("to") or b.get("from"), "to")
    plan = _plan_auto_roster(frm, to, ctx.user)
    if not b.get("apply"):
        return plan | {"applied": False}
    require_perm(ctx.user, "visits.create")
    import datetime as _dt                  # a night round writes onto two dates
    ty = _cover_shift_type()
    made = booked = assigned = 0
    # Cover rows the day would not accept. THE VISITS ARE THE POINT OF THE RUN;
    # a shift row that clashes with something already on that engineer's day is
    # a note about who covers which patch, and losing it must never cost the
    # office the week's diary. Before this, one 409 out of a hundred days threw
    # the whole transaction away and the office saw "nothing happened".
    shift_clashes = []
    with db.transaction() as cx:
        run_id = cx.execute(
            "INSERT INTO roster_runs(from_date,to_date,created_by) VALUES(?,?,?)",
            (frm, to, ctx.user["id"])).lastrowid
        # Only what this press ACTUALLY wrote goes in the list — see the note on
        # the table. A shift that already existed and a visit somebody else had
        # already claimed belong to whoever wrote them, not to this run.
        def _wrote(kind, ref_id, agent_id=None):
            cx.execute("INSERT INTO roster_run_items(run_id,kind,ref_id,agent_id) "
                       "VALUES(?,?,?,?)", (run_id, kind, ref_id, agent_id))
        for day in plan["days"]:
            date = day["date"]
            for row in day["assignments"]:
                aid = row["agent_id"]
                for area in row["areas"]:
                    existing_rows = db.query(
                        "SELECT shift_type_id, area_id, start_time, end_time, note "
                        "FROM agent_shifts WHERE agent_id=? AND shift_date=?", (aid, date))
                    if any(e["area_id"] == area["id"] and e["shift_type_id"] == ty["id"]
                           for e in existing_rows):
                        continue
                    try:
                        _assert_sup_may_roster(
                            ctx.user, aid, date,
                            _clean_day_shifts([dict(e) for e in existing_rows]
                                              + [{"shift_type_id": ty["id"],
                                                  "area_id": area["id"]}]))
                    except ApiError as e:
                        # 403 is "you may not roster this person" and stands.
                        # Anything else is this ONE day refusing this ONE row —
                        # skip it, say so at the end, and book the work.
                        if e.status == 403:
                            raise
                        shift_clashes.append({"agent_id": aid, "agent_name": row["agent_name"],
                                              "date": date, "reason": e.message})
                        continue
                    sid_new = cx.execute(
                        "INSERT INTO agent_shifts(agent_id,shift_date,shift_type_id,area_id,"
                        "assigned_by) VALUES(?,?,?,?,?)", (aid, date, ty["id"], area["id"],
                                                           ctx.user["id"])).lastrowid
                    _wrote("shift_created", sid_new, aid)
                    made += 1
                for v in row["visits"]:
                    # A round that begins at 22:00 ends after midnight, so the
                    # visit's two ends can sit on two dates. Writing both on the
                    # round's date would give a visit that finishes before it
                    # starts — 23:45 to 00:15 read as minus 23 and a half hours.
                    d0 = _dt.date.fromisoformat(date)
                    when = f"{(d0 + _dt.timedelta(days=v.get('start_day') or 0)).isoformat()}T{v['start']}"
                    ends = f"{(d0 + _dt.timedelta(days=v.get('end_day') or 0)).isoformat()}T{v['end']}"
                    if v["visit_id"]:
                        # Already booked, just nobody on it — give it an engineer
                        # and leave the customer's time exactly as promised.
                        # Only claim it if it was still free: another run (or the
                        # office) may have staffed it since the plan was drawn.
                        cur = cx.execute(
                            "UPDATE visits SET agent_id=? WHERE id=? AND agent_id IS NULL",
                            (aid, v["visit_id"]))
                        if cur.rowcount:
                            _wrote("visit_assigned", v["visit_id"], aid)
                            assigned += 1
                    else:
                        vid_new = cx.execute(
                            "INSERT INTO visits(client_id,site_id,agent_id,scheduled_start,"
                            "scheduled_end,status) VALUES(?,?,?,?,?,'scheduled')",
                            (v["client_id"], v["site_id"], aid, when, ends)).lastrowid
                        _wrote("visit_created", vid_new, aid)
                        booked += 1
        # THE LEFTOVERS ARE THE POINT OF THE RUN AS MUCH AS THE BOOKINGS.
        # What the planner could not fit used to live only in the preview on
        # screen: press Apply and it was gone, so nobody could act on it. Keep
        # it against the run, and the bell can hand the office a worklist.
        for u in plan.get("unplaced", []):
            cx.execute("INSERT INTO roster_run_unplaced(run_id,visit_date,site_id,"
                       "area_id,minutes,reason) VALUES(?,?,?,?,?,?)",
                       (run_id, u["date"], u.get("site_id"), u.get("area_id"),
                        u.get("minutes"), u["reason"]))
        # RULE 2: THE BRANCH KEEPS ITS ENGINEER. The plan worked out an owner
        # for every branch that had none; applying is where that stops being a
        # proposal and becomes the book. Only branches the office has NOT
        # already named somebody on are written — his choice always stands —
        # and from here on the branch board shows who it belongs to.
        owned = 0
        for site_id, agent_id in (plan.get("owners_assigned") or {}).items():
            cur = cx.execute("UPDATE sites SET preferred_agent_id=? "
                             "WHERE id=? AND preferred_agent_id IS NULL",
                             (agent_id, site_id))
            owned += cur.rowcount
        cx.execute("UPDATE roster_runs SET visits=?, assigned=?, shifts=? WHERE id=?",
                   (booked, assigned, made, run_id))
    # TELL THE FIELD. Applying writes somebody's whole week and, until now, said
    # nothing to the person who has to drive it. Counted per engineer so the
    # message is about their own days, and keyed on the run so re-reading the
    # bell does not re-send it.
    per_agent = {}
    area_ids = set()
    for day in plan["days"]:
        for row in day["assignments"]:
            per_agent[row["agent_id"]] = per_agent.get(row["agent_id"], 0) + len(row["visits"])
            area_ids.update(a["id"] for a in row["areas"])
    for aid, n in per_agent.items():
        if aid == ctx.user["id"]:
            continue                       # the person who pressed it knows
        _notify(aid, "roster_ready", "Your schedule is ready",
                f"{n} visit(s) booked for you between {frm} and {to}.",
                "myday", None, f"roster:{run_id}:{aid}")
    # AND THE CUSTOMER. "When are you coming?" is a phone call the office
    # should not have to take once the week is actually booked. One message per
    # company with its earliest date, not one per visit — a customer with
    # fourteen branches does not want fourteen bells. Portal users only; a
    # company with no login is simply not told.
    per_client = {}
    for day in plan["days"]:
        for row in day["assignments"]:
            for v in row["visits"]:
                c = per_client.setdefault(v["client_id"], {"n": 0, "first": day["date"]})
                c["n"] += 1
                if day["date"] < c["first"]:
                    c["first"] = day["date"]
    for cid, info in per_client.items():
        _notify_client_users(
            cid, "visits_scheduled", "Your next service visits are booked",
            f"{info['n']} visit(s) scheduled, starting {info['first']}.",
            "visits", None, f"rostercli:{run_id}:{cid}")
    # And the manager of every patch the plan sent somebody into.
    for area in area_ids:
        for ld in db.query("SELECT manager_id FROM area_manager_areas WHERE area_id=?", (area,)):
            if ld["manager_id"] == ctx.user["id"] or ld["manager_id"] in per_agent:
                continue
            _notify(ld["manager_id"], "roster_ready", "Your area has been rostered",
                    f"A plan for {frm} to {to} was applied covering your area.",
                    "myteam", None, f"rosterlead:{run_id}:{ld['manager_id']}")
    # AND THE OFFICE, about the work that did NOT get booked. This is the one
    # notification the person who pressed the button DOES want: they are the
    # one who has to place those visits by hand, and a count that scrolled off
    # the preview is a count nobody acts on. It carries the run, so opening it
    # goes straight to the list.
    left = plan.get("unplaced", [])
    if left:
        _notify(ctx.user["id"], "roster_unplaced",
                f"{len(left)} visit(s) still need a place",
                f"The plan for {frm} to {to} is applied. Open this to see which "
                f"branches were left out and why.",
                "shifts", run_id, f"rosterun:{run_id}")
        # A manager hears only about their own patches, or the list they open
        # would name branches they may not otherwise read.
        by_mgr = {}
        for u in left:
            if not u.get("area_id"):
                continue
            for ld in db.query("SELECT manager_id FROM area_manager_areas WHERE area_id=?",
                               (u["area_id"],)):
                if ld["manager_id"] != ctx.user["id"]:
                    by_mgr[ld["manager_id"]] = by_mgr.get(ld["manager_id"], 0) + 1
        for mid, n in by_mgr.items():
            _notify(mid, "roster_unplaced", f"{n} visit(s) in your areas need a place",
                    f"The plan for {frm} to {to} is applied. Open this to see which "
                    f"branches were left out and why.",
                    "shifts", run_id, f"rosterun:{run_id}:{mid}")
    audit(ctx, "shifts.auto", "agent_shift", None,
          f"{frm}..{to}: {made} shift(s), {booked} visit(s) booked, {assigned} assigned, "
          f"{len(left)} unplaced" + (f", {len(shift_clashes)} cover shift(s) clashed"
                                     if shift_clashes else ""))
    return plan | {"applied": True, "owners_written": owned, "shifts": made, "booked": booked, "assigned": assigned,
                   "run_id": run_id, "shift_clashes": shift_clashes}


# --------------------------------------------------------------------------
# BACKUP AND RESTORE — a copy of the whole business, in the office's own hands
#
# The server already backs itself up nightly (backup.py + pestcrm-backup.timer,
# 14 kept, proven weekly by restore_drill.py). What it could not do was hand
# the OWNER a copy: everything here is about a file he can download, keep off
# this machine, and send back if the worst happens.
#
# Three sizes, because 94 MB of photos over a phone is not the same errand as
# 1 MB of records: the database alone, the database plus the files still in
# use, or the database plus every uploaded file ever.
# --------------------------------------------------------------------------
BACKUP_MANIFEST = "manifest.json"
BACKUP_APP = "pestcrm"
DATA_DIR = db.DATA_DIR
DB_FILE = db.DB_PATH


def _require_owner(user):
    """A full backup is the whole business in one file — every customer, every
    engineer, their numbers and their credentials — and a restore replaces all
    of it. That is the owner's decision and nobody else's, so this is checked
    on the ROLE, not on a permission somebody could be granted by mistake."""
    if not user or user.get("role") != "admin":
        raise ApiError(403, "Only an admin can back up or restore the system")


# THE CRM IN PARTS. A full backup is one database file and is the only thing
# that can be RESTORED; these are copies of one piece of the business at a time
# — the customer book, the reports, the people — written as spreadsheets the
# office can open, read, send to an accountant or keep for a year.
#
# Every table lands in exactly one part, so "everything ticked" really is
# everything. Credentials never travel in a parts copy: those columns are for
# the database file, which is admin-only and warns about what it holds.
BACKUP_PARTS = [
    ("customers", ["clients", "sites", "site_service_days", "contract_sites", "contracts",
                   "price_book", "service_types"]),
    ("visits", ["visits", "reports", "photos", "chemical_usage", "visit_ratings",
                "visit_requests", "report_options", "transport_entries"]),
    ("people", ["users", "user_permissions", "role_permissions", "agent_areas",
                "agent_availability", "marketing_targets"]),
    ("shifts", ["agent_shifts", "shift_types", "roster_runs", "roster_run_items",
                "roster_run_unplaced"]),
    ("devices", ["devices", "device_inspections", "maps", "map_markers", "marker_events"]),
    ("stock", ["chemicals", "inventory_transactions", "engineer_issues",
               "engineer_issue_items", "material_returns", "material_return_items",
               "purchase_orders", "purchase_order_items"]),
    ("money", ["invoices", "invoice_items", "payments", "payment_intents", "expenses",
               "petty_cash", "cost_budgets", "cost_recurring", "vat_returns"]),
    ("leads", ["leads"]),
    ("places", ["areas", "zones", "area_manager_areas"]),
    ("documents", ["company_files"]),
    ("settings", ["settings", "translations", "notification_prefs"]),
    ("audit", ["audit_log", "notifications"]),
]
# Columns that must never leave in a spreadsheet: password hashes and anything
# else that would let somebody in.
BACKUP_SECRET_COLS = {"password_hash", "token", "reset_token", "secret", "api_key"}


def _part_tables(key):
    for k, tables in BACKUP_PARTS:
        if k == key:
            return [t for t in tables
                    if db.query("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                                (t,), one=True)]
    raise ApiError(400, f"Unknown part: {key}")


def _part_counts():
    """Row counts per part, so the office picks with the numbers in front of
    them rather than after the download."""
    out = []
    for key, _ in BACKUP_PARTS:
        rows = 0
        for t in _part_tables(key):
            rows += db.query(f"SELECT COUNT(*) n FROM {t}", one=True)["n"]
        out.append({"key": key, "rows": rows, "tables": len(_part_tables(key))})
    return out


def _write_parts_db(path, parts):
    """A real SQLite file holding ONLY the chosen parts' tables — schema, rows,
    ids and all.

    The CSVs beside it are for reading; this is the one that can be put back.
    A spreadsheet loses what a restore needs (types, nulls, the exact ids other
    rows point at), so the two travel together: the office reads the CSV and
    the CRM restores from this."""
    out = sqlite3.connect(path)
    src = db.query
    tables = []
    for key in parts:
        for t in _part_tables(key):
            if t not in tables:
                tables.append(t)
    with out:
        for t in tables:
            ddl = src("SELECT sql FROM sqlite_master WHERE type='table' AND name=?",
                      (t,), one=True)
            if not ddl or not ddl["sql"]:
                continue
            out.execute(ddl["sql"])
            cols = [c["name"] for c in src(f"PRAGMA table_info({t})")]
            rows = [tuple(r[c] for c in cols) for r in src(f"SELECT * FROM {t}")]
            if rows:
                out.executemany(
                    f"INSERT INTO {t}({','.join(cols)}) VALUES({','.join('?' * len(cols))})",
                    rows)
    out.close()
    return tables


def _restore_parts(work, manifest):
    """Put chosen parts back: for each table, the live rows go and the backup's
    rows take their place — inside ONE transaction, so the CRM is never left
    half-way between two versions of the customer book.

    Foreign keys are switched off for the swap (a part is restored parent-first
    but its children may live in a part that is not being restored) and then
    CHECKED. If that check finds an orphan the whole thing rolls back and the
    office is told which table — a restore that leaves visits pointing at
    customers who no longer exist is worse than one that refuses."""
    src_path = os.path.join(work, "parts.db")
    if not os.path.isfile(src_path):
        raise ApiError(400, "That backup has no restorable parts inside")
    tables = []
    for key in manifest.get("parts") or []:
        for t in _part_tables(key):
            if t not in tables:
                tables.append(t)
    done, rows_in = [], 0
    con = sqlite3.connect(DB_FILE)
    try:
        con.execute("PRAGMA foreign_keys=OFF")
        con.execute(f"ATTACH DATABASE '{src_path}' AS backup")
        cur = con.cursor()
        cur.execute("BEGIN")
        try:
            have = {r[0] for r in cur.execute(
                "SELECT name FROM backup.sqlite_master WHERE type='table'")}
            for t in reversed(tables):            # children first
                if t in have:
                    cur.execute(f"DELETE FROM main.{t}")
            for t in tables:                      # parents first
                if t not in have:
                    continue
                # The schema goes BEFORE the pragma name, not inside its
                # argument: PRAGMA main.table_info(x), never table_info(main.x).
                cols = [c[1] for c in cur.execute(f"PRAGMA main.table_info({t})")]
                backup_cols = {c[1] for c in cur.execute(f"PRAGMA backup.table_info({t})")}
                shared = [c for c in cols if c in backup_cols]
                if not shared:
                    continue
                cur.execute(f"INSERT INTO main.{t}({','.join(shared)}) "
                            f"SELECT {','.join(shared)} FROM backup.{t}")
                rows_in += cur.rowcount if cur.rowcount and cur.rowcount > 0 else 0
                # A BACKUP TAKEN BEFORE THE CYCLE WAS COUNTED IN MONTHS still
                # says `visits_per_week`, which is not a column here any more —
                # the shared-column rule would drop it and hand every branch
                # back with a cycle of ZERO, silently off the roster. Carry it
                # across at four weeks to the month, reading in weeks, exactly
                # as the upgrade itself did.
                if (t == "sites" and "visits_per_month" in cols
                        and "visits_per_month" not in backup_cols
                        and "visits_per_week" in backup_cols):
                    cur.execute(
                        "UPDATE main.sites SET visits_per_month = ROUND(COALESCE("
                        "(SELECT b.visits_per_week FROM backup.sites b "
                        " WHERE b.id = main.sites.id), 0) * 4, 2), freq_unit='week'")
                done.append(t)
            bad = cur.execute("PRAGMA main.foreign_key_check").fetchall()
            if bad:
                cur.execute("ROLLBACK")
                where = ", ".join(sorted({str(b[0]) for b in bad})[:4])
                raise ApiError(409, "Putting those parts back would leave rows pointing at "
                                    f"records that are not there ({where}) — nothing was changed. "
                                    "Restore the whole backup instead.")
            cur.execute("COMMIT")
        except ApiError:
            raise
        except Exception:
            cur.execute("ROLLBACK")
            raise
    finally:
        try:
            con.execute("DETACH DATABASE backup")
        except Exception:
            pass
        con.close()
    return {"tables": done, "rows": rows_in}


def _write_part_csvs(tar, key, tmpdir):
    """One CSV per table in the part, added straight to the archive."""
    import csv as _csv
    written = []
    for table in _part_tables(key):
        cols = [c["name"] for c in db.query(f"PRAGMA table_info({table})")
                if c["name"].lower() not in BACKUP_SECRET_COLS]
        if not cols:
            continue
        path = os.path.join(tmpdir, f"{key}-{table}.csv")
        with open(path, "w", newline="", encoding="utf-8-sig") as f:
            w = _csv.writer(f)
            w.writerow(cols)
            for r in db.query(f"SELECT {','.join(cols)} FROM {table}"):
                w.writerow(["" if r[c] is None else r[c] for c in cols])
        tar.add(path, arcname=f"parts/{key}/{table}.csv")
        written.append(table)
    return written


def _linked_upload_files():
    """The uploaded files the database still points at — site maps, company
    documents, report signatures, photos. An upload folder collects orphans
    over years (a photo replaced, a client deleted); this is the set that would
    actually be missed."""
    names = set()
    for table, col in (("sites", "map_image"), ("maps", "filename"),
                       ("company_files", "filename"), ("photos", "filename"),
                       ("reports", "customer_signature"),
                       ("reports", "technician_signature")):
        if not db.query("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                        (table,), one=True):
            continue
        cols = {c["name"] for c in db.query(f"PRAGMA table_info({table})")}
        if col not in cols:
            continue
        for r in db.query(f"SELECT DISTINCT {col} v FROM {table} WHERE {col} IS NOT NULL"):
            v = str(r["v"]).strip()
            if v:
                names.add(os.path.basename(v))
    return {n for n in names if os.path.isfile(os.path.join(UPLOAD_DIR, n))}


def _dir_size(names):
    total = 0
    for n in names:
        try:
            total += os.path.getsize(os.path.join(UPLOAD_DIR, n))
        except OSError:
            pass
    return total


@route("GET", r"/api/backup/options")
def backup_options(ctx):
    """What a backup would contain and what it would cost to download, so the
    choice is made with the sizes on screen rather than after a 94 MB wait."""
    _require_owner(ctx.user)
    try:
        db_bytes = os.path.getsize(DB_FILE)
    except OSError:
        db_bytes = 0
    all_files = [f for f in os.listdir(UPLOAD_DIR)] if os.path.isdir(UPLOAD_DIR) else []
    all_files = [f for f in all_files if os.path.isfile(os.path.join(UPLOAD_DIR, f))]
    linked = _linked_upload_files()
    tables = db.query("SELECT COUNT(*) n FROM sqlite_master WHERE type='table' "
                      "AND name NOT LIKE 'sqlite_%'", one=True)["n"]
    counts = {}
    for t in ("users", "clients", "sites", "visits", "devices", "agent_shifts",
              "reports", "invoices", "contracts"):
        row = db.query("SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
                       (t,), one=True)
        if row:
            counts[t] = db.query(f"SELECT COUNT(*) n FROM {t}", one=True)["n"]
    return {"database": {"bytes": db_bytes, "tables": tables, "counts": counts},
            "linked_files": {"count": len(linked), "bytes": _dir_size(linked)},
            "all_files": {"count": len(all_files), "bytes": _dir_size(all_files)},
            "parts": _part_counts(),
            "auto": _auto_backups()[:1]}


def _auto_backups():
    """The nightly snapshots this server keeps on its own disk, newest first.
    Shown so the office can see the automatic safety net exists — and take one
    of those away with them instead of making a fresh copy."""
    dest = os.path.join(DATA_DIR, "backups")
    out = []
    if not os.path.isdir(dest):
        return out
    for name in os.listdir(dest):
        full = os.path.join(dest, name)
        if not os.path.isfile(full):
            continue
        try:
            st = os.stat(full)
        except OSError:
            continue
        out.append({"name": name, "bytes": st.st_size,
                    "at": _dt_mod.datetime.fromtimestamp(st.st_mtime).strftime("%Y-%m-%d %H:%M"),
                    "kind": "uploads" if name.startswith("uploads-") else "database"})
    out.sort(key=lambda r: r["at"], reverse=True)
    return out


@route("GET", r"/api/backup/list")
def backup_list(ctx):
    """The server's own automatic backups."""
    _require_owner(ctx.user)
    return {"backups": _auto_backups(), "dir": os.path.join(DATA_DIR, "backups")}


@route("GET", r"/api/backup/download")
def backup_download(ctx):
    """Build the archive the office asked for and hand it back as one file.

    `files` picks how much comes with the records: none / linked / all. The
    database itself is written through SQLite's ONLINE BACKUP API, so it is a
    consistent snapshot even though the CRM is serving requests while it runs —
    copying the file by hand under WAL is how people end up with a backup that
    will not open."""
    _require_owner(ctx.user)
    want_db = (ctx.query.get("db") or "1") not in ("0", "false", "no")
    files_mode = (ctx.query.get("files") or "linked").lower()
    if files_mode not in ("none", "linked", "all"):
        raise ApiError(400, "files must be none, linked or all")
    parts = [p for p in (ctx.query.get("parts") or "").split(",") if p]
    known = {k for k, _ in BACKUP_PARTS}
    for p in parts:
        if p not in known:
            raise ApiError(400, f"Unknown part: {p}")
    if not want_db and files_mode == "none" and not parts:
        raise ApiError(400, "Choose at least one thing to back up")
    stamp = _dt_mod.datetime.now().strftime("%Y%m%d-%H%M%S")
    tmp = tempfile.mkdtemp(prefix="pestcrm-backup-")
    archive = os.path.join(tmp, f"pestcrm-backup-{stamp}.tar.gz")
    manifest = {"app": BACKUP_APP, "created_at": _dt_mod.datetime.now().isoformat(timespec="seconds"),
                "created_by": ctx.user["email"], "includes_database": want_db,
                "files_mode": files_mode, "parts": parts, "public_url": _public_url}
    try:
        with tarfile.open(archive, "w:gz") as tar:
            if want_db:
                snap = os.path.join(tmp, "crm.db")
                src = sqlite3.connect(DB_FILE)
                dst = sqlite3.connect(snap)
                with dst:
                    src.backup(dst)          # consistent even mid-write
                dst.close()
                src.close()
                manifest["database_bytes"] = os.path.getsize(snap)
                tar.add(snap, arcname="crm.db")
            # Chosen pieces of the business, as spreadsheets. These ride
            # ALONGSIDE the database file when both are asked for — they are for
            # reading, and it is the database that gets restored.
            if parts:
                manifest["part_tables"] = {k: _write_part_csvs(tar, k, tmp) for k in parts}
                # …and the same rows as a database, which is what a restore
                # reads. CSV is for the office; this is for the CRM.
                pdb = os.path.join(tmp, "parts.db")
                _write_parts_db(pdb, parts)
                tar.add(pdb, arcname="parts.db")
                manifest["restorable_parts"] = True
            names = []
            if files_mode == "linked":
                names = sorted(_linked_upload_files())
            elif files_mode == "all" and os.path.isdir(UPLOAD_DIR):
                names = sorted(f for f in os.listdir(UPLOAD_DIR)
                               if os.path.isfile(os.path.join(UPLOAD_DIR, f)))
            for n in names:
                tar.add(os.path.join(UPLOAD_DIR, n), arcname=f"uploads/{n}")
            manifest["file_count"] = len(names)
            mpath = os.path.join(tmp, BACKUP_MANIFEST)
            with open(mpath, "w") as f:
                json.dump(manifest, f, indent=2)
            tar.add(mpath, arcname=BACKUP_MANIFEST)
    except Exception:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    audit(ctx, "backup.download", "backup", None,
          f"db={want_db}, files={files_mode} ({manifest['file_count']}), "
          f"parts={','.join(parts) or 'none'}, {os.path.getsize(archive) // 1024} KB")
    # The handler streams it and deletes the working directory afterwards.
    return {"_file": archive, "_filename": os.path.basename(archive),
            "_mime": "application/gzip", "_cleanup": tmp}


# A prepared archive waiting to be collected. The browser cannot put an
# Authorization header on a plain download, and pulling 95 MB through fetch()
# into a Blob would hold the whole backup in the phone's memory — so the office
# asks for the file first, is told how big it is, and then collects it on a
# single-use link that streams straight to their disk.
_BACKUP_READY = {}
_BACKUP_TTL = 15 * 60


def _sweep_backup_tokens():
    now = time.time()
    for tok, row in list(_BACKUP_READY.items()):
        if row["expires"] < now:
            shutil.rmtree(row["dir"], ignore_errors=True)
            _BACKUP_READY.pop(tok, None)


@route("POST", r"/api/backup/prepare")
def backup_prepare(ctx):
    """Build the archive now and hand back a one-time link to collect it."""
    _require_owner(ctx.user)
    _sweep_backup_tokens()
    built = backup_download(Ctx(ctx.user, [], {
        "db": "0" if ctx.body.get("database") is False else "1",
        "files": ctx.body.get("files") or "linked",
        "parts": ",".join(ctx.body.get("parts") or [])}, {}, b"", "",
        ip=getattr(ctx, "ip", None)))
    token = uuid.uuid4().hex
    _BACKUP_READY[token] = {"path": built["_file"], "dir": built["_cleanup"],
                            "name": built["_filename"], "user_id": ctx.user["id"],
                            "expires": time.time() + _BACKUP_TTL}
    return {"token": token, "filename": built["_filename"],
            "bytes": os.path.getsize(built["_file"]), "expires_in": _BACKUP_TTL}


@route("GET", r"/api/backup/file/([0-9a-f]{32})", auth_required=False)
def backup_collect(ctx):
    """Collect a prepared backup. The token IS the authorisation — it is random,
    single-use and short-lived, and it only ever exists because an admin asked
    for this file a moment ago."""
    _sweep_backup_tokens()
    row = _BACKUP_READY.pop(ctx.params[0], None)
    if not row:
        raise ApiError(404, "That download has expired — take a new backup")
    return {"_file": row["path"], "_filename": row["name"],
            "_mime": "application/gzip", "_cleanup": row["dir"]}


def _safety_snapshot(tag="PRE-RESTORE"):
    """Copy the CURRENT data somewhere safe before it is replaced.

    A restore is the one operation in the CRM that destroys everything at once.
    The office asked for it anyway, and they are right to — but a mistaken
    restore must itself be undoable, so the state being thrown away is written
    to data/backups first, in the same shape backup.py writes and
    restore_drill.py knows how to check."""
    dest = os.path.join(DATA_DIR, "backups")
    os.makedirs(dest, exist_ok=True)
    stamp = _dt_mod.datetime.now().strftime("%Y%m%d-%H%M%S")
    out = {}
    dbfile = os.path.join(dest, f"crm-{tag}-{stamp}.db")
    src = sqlite3.connect(DB_FILE)
    snap = sqlite3.connect(dbfile)
    with snap:
        src.backup(snap)
    snap.close()
    src.close()
    out["database"] = os.path.basename(dbfile)
    if os.path.isdir(UPLOAD_DIR) and os.listdir(UPLOAD_DIR):
        tgz = os.path.join(dest, f"uploads-{tag}-{stamp}.tar.gz")
        with tarfile.open(tgz, "w:gz") as tar:
            tar.add(UPLOAD_DIR, arcname="uploads")
        out["uploads"] = os.path.basename(tgz)
    return out


def _read_backup_archive(path):
    """Open an uploaded archive and satisfy ourselves it IS one of ours before
    a single live file is touched: our manifest, a database that opens and
    passes an integrity check and carries the tables a CRM has. Everything
    here happens in a scratch directory; the live system is untouched until
    this function has returned without complaint."""
    work = tempfile.mkdtemp(prefix="pestcrm-restore-")
    try:
        with tarfile.open(path, "r:gz") as tar:
            names = tar.getnames()
            if BACKUP_MANIFEST not in names:
                raise ApiError(400, "That file is not a Fox CRM backup — no manifest inside")
            for member in tar.getmembers():
                target = os.path.normpath(os.path.join(work, member.name))
                if not target.startswith(work) or member.issym() or member.islnk():
                    raise ApiError(400, "That archive contains unsafe paths")
            tar.extractall(work)
    except tarfile.TarError:
        shutil.rmtree(work, ignore_errors=True)
        raise ApiError(400, "That file is not a readable .tar.gz archive")
    except ApiError:
        shutil.rmtree(work, ignore_errors=True)
        raise
    try:
        with open(os.path.join(work, BACKUP_MANIFEST)) as f:
            manifest = json.load(f)
        if manifest.get("app") != BACKUP_APP:
            raise ApiError(400, "That backup was made by a different system")
        if not manifest.get("includes_database") and not manifest.get("restorable_parts"):
            raise ApiError(400, "That file holds nothing that can be restored")
        dbfile = os.path.join(work, "crm.db")
        if manifest.get("includes_database"):
            if not os.path.isfile(dbfile):
                raise ApiError(400, "The backup says it holds the database, but it is missing")
            con = sqlite3.connect(dbfile)
            try:
                ok = con.execute("PRAGMA integrity_check").fetchone()[0]
                if ok != "ok":
                    raise ApiError(400, "The database inside that backup is damaged")
                have = {r[0] for r in con.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'")}
                missing = {"users", "clients", "sites", "visits"} - have
                if missing:
                    raise ApiError(400, "That database is not a Fox CRM database")
                manifest["users"] = con.execute("SELECT COUNT(*) FROM users").fetchone()[0]
                manifest["clients"] = con.execute("SELECT COUNT(*) FROM clients").fetchone()[0]
                manifest["visits"] = con.execute("SELECT COUNT(*) FROM visits").fetchone()[0]
            finally:
                con.close()
        upl = os.path.join(work, "uploads")
        manifest["found_files"] = len(os.listdir(upl)) if os.path.isdir(upl) else 0
        return work, manifest
    except (json.JSONDecodeError, KeyError, sqlite3.DatabaseError):
        shutil.rmtree(work, ignore_errors=True)
        raise ApiError(400, "That backup could not be read")
    except ApiError:
        shutil.rmtree(work, ignore_errors=True)
        raise


def _apply_restore(work, manifest):
    """Swap the checked copy in. Files first, database last — the database is
    the one that forces the restart, and a half-restored system that is still
    serving the OLD database is a worse place to be interrupted than one whose
    photos have already moved."""
    moved = {"files": 0}
    upl = os.path.join(work, "uploads")
    if manifest.get("files_mode") in ("linked", "all") and os.path.isdir(upl):
        os.makedirs(UPLOAD_DIR, exist_ok=True)
        for name in os.listdir(upl):
            src = os.path.join(upl, name)
            if os.path.isfile(src):
                shutil.copy2(src, os.path.join(UPLOAD_DIR, os.path.basename(name)))
                moved["files"] += 1
    if manifest.get("includes_database"):
        incoming = os.path.join(work, "crm.db")
        staged = DB_FILE + ".incoming"
        shutil.copy2(incoming, staged)
        os.replace(staged, DB_FILE)
        # The old write-ahead log belongs to the database that just left. Left
        # in place, SQLite would replay it over the restored file.
        for tail in ("-wal", "-shm"):
            try:
                os.remove(DB_FILE + tail)
            except OSError:
                pass
        moved["database"] = True
    return moved


def _restart_soon(delay=1.0):
    """Come back with the restored data. The reply goes out first — a restart
    that beats its own response leaves the office staring at a dead browser tab
    wondering whether the restore happened."""
    def _go():
        time.sleep(delay)
        try:
            os.execv(sys.executable, [sys.executable] + sys.argv)
        except Exception:
            os._exit(0)          # systemd (Restart=always) brings us back
    threading.Thread(target=_go, daemon=True).start()


def do_backup_restore(user, upload_path, confirm):
    """Replace everything with the contents of an uploaded backup.

    Called from the request handler rather than through @route, because the
    archive is streamed to disk instead of being read into memory like every
    other body."""
    _require_owner(user)
    if (confirm or "").strip().upper() != "RESTORE":
        raise ApiError(400, "Type RESTORE to confirm")
    work, manifest = _read_backup_archive(upload_path)
    partial = not manifest.get("includes_database")
    try:
        safety = _safety_snapshot()
        # Same job, two sizes: a whole-system backup replaces everything and
        # needs a restart; a backup of chosen parts puts those parts back and
        # leaves the rest of the business exactly where it was.
        moved = ({"files": 0} | _restore_parts(work, manifest)) if partial \
            else _apply_restore(work, manifest)
    finally:
        shutil.rmtree(work, ignore_errors=True)
    # WRITE THE ENTRY INTO THE DATABASE THAT IS NOW LIVE, on its own connection.
    # The pooled one still points at the file that was just replaced — an audit
    # row sent through it lands in a deleted inode, so the single most drastic
    # action in the CRM would leave no trace anywhere. The restored database
    # should carry the record of its own restoring.
    detail = (f"restored from {manifest.get('created_at')}: "
              f"database={bool(manifest.get('includes_database'))}, "
              f"parts={','.join(manifest.get('parts') or []) or 'none'}, "
              f"{moved['files']} file(s); safety copy {safety.get('database')}")
    try:
        con = sqlite3.connect(DB_FILE)
        with con:
            con.execute("INSERT INTO audit_log(user_id,user_name,action,entity,detail) "
                        "VALUES(?,?,?,?,?)",
                        (user.get("id"), user.get("full_name") or user.get("email"),
                         "backup.restore", "backup", detail))
        con.close()
    except Exception:
        traceback.print_exc()
    # Written AFTER the swap on purpose: whichever audit_log is now live — the
    # restored one, or the one that was never touched — is the one that should
    # carry the record of this restore.
    # Only a whole-system restore needs the process to come back on the new
    # file. Parts went in through the live database and are already in effect.
    if not partial:
        _restart_soon()
    return {"restored": True, "from": manifest.get("created_at"),
            "database": bool(manifest.get("includes_database")),
            "partial": partial, "parts": manifest.get("parts") or [],
            "tables": moved.get("tables") or [], "rows": moved.get("rows", 0),
            "files": moved["files"], "safety_copy": safety,
            "users": manifest.get("users"), "clients": manifest.get("clients"),
            "visits": manifest.get("visits")}


@route("GET", r"/api/shifts/auto/runs")
def list_roster_runs(ctx):
    """The last few presses of the button, newest first, so one can be taken
    back. A supervisor only ever sees their own — undo is scoped by who pressed it,
    not by area, because a single run can span several patches."""
    require_perm(ctx.user, "shifts.create")
    where, params = "", []
    if ctx.user["role"] in SUPERVISOR_ROLES:
        where = " WHERE r.created_by=?"
        params.append(ctx.user["id"])
    # `unplaced` counts only what is STILL waiting: a branch somebody has since
    # booked by hand is done, whether or not anyone came back to say so.
    return db.query(
        "SELECT r.*, u.full_name created_name, ("
        "  SELECT COUNT(*) FROM roster_run_unplaced p"
        "  WHERE p.run_id=r.id AND p.dismissed_at IS NULL AND NOT EXISTS ("
        "    SELECT 1 FROM visits v WHERE v.site_id=p.site_id"
        "      AND substr(v.scheduled_start,1,10)=p.visit_date"
        "      AND v.status <> 'cancelled')) unplaced "
        "FROM roster_runs r "
        "LEFT JOIN users u ON u.id=r.created_by" + where +
        " ORDER BY r.id DESC LIMIT 20", params)


@route("GET", r"/api/shifts/auto/runs/(\d+)/unplaced")
def roster_run_unplaced(ctx):
    """The visits one press of the button could NOT book, as a worklist.

    The office asked for this shape directly: apply everything that fits, and
    keep the rest where it can be opened, read and cleared by hand. So each row
    carries what it takes to act — the branch, the customer, the date it was
    due, how long the visit takes and WHY it did not fit — plus `booked`, which
    is true once a visit exists for that branch on that date. Booking one by
    hand is therefore all it takes to clear a line; there is nothing to tick.

    An area manager sees only rows in their own patches — the same fail-closed
    rule the preview follows, or the list would name customers they may not
    otherwise read."""
    require_perm(ctx.user, "shifts.create")
    rid = int(ctx.params[0])
    run = db.query("SELECT * FROM roster_runs WHERE id=?", (rid,), one=True)
    if not run:
        raise ApiError(404, "No such plan")
    if ctx.user["role"] in SUPERVISOR_ROLES and run["created_by"] != ctx.user["id"]:
        raise ApiError(403, "That plan was run by somebody else")
    scope = (set(area_manager_area_ids(ctx.user)) if ctx.user["role"] == "area_manager"
             else set() if ctx.user["role"] in SUPERVISOR_ROLES else None)
    rows = db.query(
        "SELECT p.id, p.visit_date, p.site_id, p.area_id, p.minutes, p.reason, "
        "p.dismissed_at, s.name site_name, s.client_id, "
        "c.name_en client_en, c.name_ar client_ar, "
        "a.name_en area_en, a.name_ar area_ar, EXISTS("
        "  SELECT 1 FROM visits v WHERE v.site_id=p.site_id"
        "    AND substr(v.scheduled_start,1,10)=p.visit_date"
        "    AND v.status <> 'cancelled') booked "
        "FROM roster_run_unplaced p "
        "LEFT JOIN sites s ON s.id=p.site_id "
        "LEFT JOIN clients c ON c.id=s.client_id "
        "LEFT JOIN areas a ON a.id=p.area_id "
        "WHERE p.run_id=? ORDER BY p.visit_date, s.name", (rid,))
    if scope is not None:
        rows = [r for r in rows if r["area_id"] in scope]
    return {"run": {"id": run["id"], "from_date": run["from_date"],
                    "to_date": run["to_date"], "undone_at": run["undone_at"]},
            "items": rows,
            "open": sum(1 for r in rows if not r["booked"] and not r["dismissed_at"])}


@route("POST", r"/api/shifts/auto/unplaced/(\d+)/dismiss")
def dismiss_roster_unplaced(ctx):
    """Take one line off the worklist without booking it — the visit was not
    needed, or the branch's own details were fixed so the next run will catch
    it. Booking it by hand needs no button at all; this is for everything else.
    `undo: true` puts it back, because a list you cannot restore is one nobody
    dares tidy."""
    require_perm(ctx.user, "shifts.create")
    pid = int(ctx.params[0])
    row = db.query("SELECT p.*, r.created_by FROM roster_run_unplaced p "
                   "JOIN roster_runs r ON r.id=p.run_id WHERE p.id=?", (pid,), one=True)
    if not row:
        raise ApiError(404, "No such row")
    if ctx.user["role"] in SUPERVISOR_ROLES:
        if row["created_by"] != ctx.user["id"]:
            raise ApiError(403, "That plan was run by somebody else")
        if row["area_id"] not in set(area_manager_area_ids(ctx.user)):
            raise ApiError(403, "That branch is not in your areas")
    if ctx.body.get("undo"):
        db.execute("UPDATE roster_run_unplaced SET dismissed_at=NULL, dismissed_by=NULL "
                   "WHERE id=?", (pid,))
    else:
        db.execute("UPDATE roster_run_unplaced SET dismissed_at=datetime('now','localtime'), "
                   "dismissed_by=? WHERE id=?", (ctx.user["id"], pid))
    return {"ok": True}


# ---------------------------------------------------------------------------
# WHO CAN TAKE THIS VISIT
# ---------------------------------------------------------------------------
# The office's own request (2026-09-06): "it tells me the numbers of ... the
# branches that not assigned in schedule but i want to click it and see it and
# write what the issue and recommend the nearst engineer free can have that
# visit and if he had a visit before and after and where."
#
# So a branch the planner could not book answers three questions here: what
# stopped it, who could go instead, and — for every one of those men — what he
# is doing either side of the gap and where that is.
#
# IT IS ADVICE AND IT WRITES NOTHING. The office still books the visit. That is
# deliberate: the planner refused this visit for a reason, and a screen that
# quietly booked it anyway would be arguing with the plan behind their back.
#
# It reads THE PLANNER'S OWN BOOK (roster.load_book) rather than asking the
# database its own questions, so "may he work that patch on a Tuesday", "is he
# on a day off", "is this a night branch" and "what are his working windows"
# are answered by the same code that made the plan. An answer here that
# disagreed with the planner would be worse than no answer at all.
def _hhmm_of(minutes):
    """Minutes past midnight as 09:30 — and past midnight itself for a night
    round, which the planner counts as 24:30 rather than starting a new day."""
    m = int(minutes) % (24 * 60)
    return "%02d:%02d" % (m // 60, m % 60)


def _wct_stops(book, agent_id, date_s):
    """What that man already has on that date, in order: (start, end, branch).

    Read from the SAME booked list the planner uses, so a visit somebody added
    by hand five minutes ago counts exactly as much as one the button made."""
    out = []
    for v in book["booked"]:
        if v["agent_id"] != agent_id or not v["scheduled_start"]:
            continue
        if str(v["scheduled_start"])[:10] != date_s:
            continue
        st = roster.hhmm_min(str(v["scheduled_start"])[11:16])
        raw_end = str(v["scheduled_end"] or "")[11:16]
        en = roster.hhmm_min(raw_end) if raw_end else (st or 0) + 60
        if st is None:
            continue
        if en <= st:                      # a night visit ending after midnight
            en += 24 * 60
        out.append((st, en, book["branches"].get(v["site_id"]), v["site_id"]))
    out.sort()
    return out


def _wct_place(stop, branch, site_names):
    """One neighbouring call, said the way the office reads it: when, where,
    and how far that is from the branch nobody could book."""
    if not stop:
        return None
    st, en, b, sid = stop
    km = None
    if b is not None and b.geo and branch.geo:
        km = round(roster.haversine_km(b.geo, branch.geo), 1)
    return {"start": _hhmm_of(st), "end": _hhmm_of(en),
            "site_id": sid,
            "site_name": (b.name if b is not None else site_names.get(sid)) or "",
            "client_en": b.client_en if b is not None else None,
            "client_ar": b.client_ar if b is not None else None,
            "area_id": b.area_id if b is not None else None,
            "km": km}


# ---------------------------------------------------------------------------
# THE BRANCHES THE BOOK ASKS TOO MUCH OF
# ---------------------------------------------------------------------------
# His words (2026-09-06): "the error of some branches wants more visits than the
# days is available to it i want to make me view that branches ... and ofcourse
# to see the branches that wants more visits to fix it manual."
#
# The planner has always worked this out BEFORE it plans — rule 6 in roster.py,
# `_capped` — and the preview printed it as a sentence. A sentence is not a
# worklist: he cannot open the branch from it, and it disappears the moment the
# dialog closes. This is the same arithmetic, offered as rows he can read the
# numbers on and act on, at any time, without pressing Preview first.
#
# NOTHING IS FIXED HERE, and deliberately so: every one of these is the office's
# own data — how often the branch is owed, which days it opens, how long its
# door is open, how long its visit takes. The screen names the number to type
# and opens the branch; the office types it.
@route("GET", r"/api/shifts/auto/over-asked")
def roster_over_asked(ctx):
    """Branches the arithmetic cannot serve, whoever is free — for one month."""
    require_perm(ctx.user, "shifts.create")
    q = ctx.query
    today = _dt_mod.date.today()
    def _d(key, dflt):
        raw = str(q.get(key) or "")[:10]
        try:
            return _dt_mod.date.fromisoformat(raw)
        except ValueError:
            return dflt
    frm = _d("from", today.replace(day=1))
    to = _d("to", frm + _dt_mod.timedelta(days=roster.days_in_month(frm.year, frm.month) - 1))
    if to < frm:
        to = frm
    s = _roster_settings()
    book = roster.load_book(db, frm.isoformat(), to.isoformat())
    # The same weekday set rule 6 is given inside plan() — the days the company
    # works at all, with a rest day that is only nominally 24h left out.
    worked = {wd for p in book["people"].values() for wd in p.days
              if not (wd == s["rest_day"] and p.days[wd] == [(0, roster.DAY)])}
    rows = roster._capped(book, worked, s, frm, to)
    # An area manager sees their own patches and nobody else's — the same
    # fail-closed rule the plan preview and the unplaced worklist follow.
    scope = (set(area_manager_area_ids(ctx.user))
             if ctx.user["role"] == "area_manager" else None)
    out = []
    for r in rows:
        b = book["branches"].get(r["site_id"])
        if b is None:
            continue
        if scope is not None and b.area_id not in scope:
            continue
        site = db.query("SELECT service_from, service_to, visits_per_month, freq_unit, "
                        "visit_minutes FROM sites WHERE id=?", (r["site_id"],), one=True)
        area = book["areas"].get(b.area_id) or {}
        # WHO IS EVEN ALLOWED THERE. For the "not enough days" shape this is the
        # other lever — a patch one man works one day a week cannot take eight
        # visits a month however the frequency is typed.
        allowed = [p.name for p in book["people"].values()
                   if b.area_id in p.areas and p.works_shift(b.shift)]
        served_on = sorted({wd for p in book["people"].values()
                            if b.area_id in p.areas and p.works_shift(b.shift)
                            for wd in p.days if p.may_work(b.area_id, wd)})
        out.append({
            "site_id": b.id, "site_name": b.name, "client_id": b.client_id,
            "client_en": b.client_en, "client_ar": b.client_ar,
            "area_id": b.area_id, "area_en": area.get("name_en"),
            "area_ar": area.get("name_ar"),
            # WHICH OF THE TWO PROBLEMS IT IS. The old preview printed one
            # heading over both shapes — "asks for more visits than there are
            # days" — above rows that were often about a door open for less time
            # than the visit takes. Named here so the screen can say the right
            # sentence over the right row.
            # The planner already NAMES the shape (`reason`), and both shapes
            # carry `needs_minutes` — reading that instead labelled every
            # over-asked branch as a short door and sent the office to change
            # opening hours that were never the problem.
            "kind": ("window" if r["reason"] == "window"
                     else "no_day" if not r.get("possible") else "days"),
            "asked": r["asked"], "possible": r["possible"],
            "needs_days": r.get("needs_days"), "month_days": r.get("month_days"),
            "window_minutes": r.get("window_minutes"),
            "needs_minutes": r.get("needs_minutes"),
            "overnight": r.get("overnight"),
            # THE NUMBER TO TYPE, so the office does not have to work it out.
            "fits": r["possible"],
            "service_from": site["service_from"] if site else None,
            "service_to": site["service_to"] if site else None,
            "visits_per_month": site["visits_per_month"] if site else None,
            "freq_unit": site["freq_unit"] if site else None,
            "visit_minutes": site["visit_minutes"] if site else None,
            "open_days": sorted(b.open_days) if b.open_days else None,
            "served_on": served_on,
            "engineers": allowed,
        })
    out.sort(key=lambda r: (r["kind"] != "no_day", r["site_name"] or ""))
    return {"from": frm.isoformat(), "to": to.isoformat(), "rows": out}


@route("POST", r"/api/shifts/auto/who-can-take")
def who_can_take(ctx):
    """Who could take ONE visit at ONE branch on ONE day, and what is in his
    way. Never writes; see the note above."""
    require_perm(ctx.user, "shifts.create")
    try:
        site_id = int(ctx.body.get("site_id") or 0)
    except (TypeError, ValueError):
        raise ApiError(400, "site_id must be a number")
    date_s = str(ctx.body.get("date") or "").strip()[:10]
    try:
        day = _dt_mod.date.fromisoformat(date_s)
    except ValueError:
        raise ApiError(400, "date must be YYYY-MM-DD")
    site = db.query(
        "SELECT s.*, c.name_en client_en, c.name_ar client_ar, a.zone_id, "
        "a.name_en area_en, a.name_ar area_ar "
        "FROM sites s JOIN clients c ON c.id=s.client_id "
        "LEFT JOIN areas a ON a.id=s.area_id WHERE s.id=?", (site_id,), one=True)
    if not site:
        raise ApiError(404, "Branch not found")
    # The same fail-closed rule the unplaced worklist follows: a supervisor is
    # never shown a patch that is not theirs, and this answer names customers.
    if ctx.user["role"] == "area_manager":
        if site["area_id"] not in set(area_manager_area_ids(ctx.user)):
            raise ApiError(403, "That branch is not in your areas")

    s = _roster_settings()
    book = roster.load_book(db, date_s, date_s)
    branch = book["branches"].get(site_id)
    if branch is None:
        # A switched-off branch, or one with no area, is not in the planner's
        # book at all — but the office may still be looking at it, so answer
        # about the branch as it stands rather than refusing.
        branch = roster.Branch(site)
        for d in db.query("SELECT weekday, start_time, end_time FROM site_service_days "
                          "WHERE site_id=?", (site_id,)):
            branch.open_days[d["weekday"]] = (
                roster.window_bounds(d["start_time"], d["end_time"])
                if (d["start_time"] or d["end_time"]) else branch.win)
    wd = day.weekday()
    minutes = branch.job_minutes(s["slot_minutes"])
    win = branch.window_on(wd)
    site_names = {r["id"]: r["name"] for r in db.query("SELECT id, name FROM sites")}

    head = {"id": site_id, "name": site["name"], "date": date_s, "weekday": wd,
            "minutes": minutes, "area_id": site["area_id"],
            "area_en": site["area_en"], "area_ar": site["area_ar"],
            "client_en": site["client_en"], "client_ar": site["client_ar"],
            "window": "%s-%s" % (_hhmm_of(win[0]), _hhmm_of(win[1])),
            "shift": branch.shift, "pinned": bool(branch.geo)}
    # THE BRANCH'S OWN DOOR IS SHUT THAT DAY. Nothing about the men matters
    # until that is fixed, so it is said on its own rather than as eleven
    # identical "no gap" lines.
    if not branch.opens_on(wd):
        return {"site": head, "fits": [], "blocked": [], "shut": True}

    fits, blocked = [], []
    for p in sorted(book["people"].values(), key=lambda q: q.name):
        row = {"agent_id": p.id, "agent_name": p.name}
        if (p.id, date_s) in book["off"]:
            blocked.append({**row, "why": "day_off"})
            continue
        wins = p.windows(wd)
        if not wins:
            blocked.append({**row, "why": "not_working"})
            continue
        if not p.works_shift(branch.shift):
            blocked.append({**row, "why": "wrong_shift"})
            continue
        if branch.area_id not in p.areas:
            blocked.append({**row, "why": "not_this_area"})
            continue
        if not p.may_work(branch.area_id, wd):
            blocked.append({**row, "why": "not_this_day_here"})
            continue
        # HIS DAY, AND THE ROOM LEFT IN IT. Working windows, clipped to the
        # hours the branch is open, minus what he is already committed to — AND
        # minus the driving at either end. A gap of exactly the visit's length
        # between two other calls is not a gap: somebody has to get there. The
        # drive is the planner's own (roster.travel_minutes), measured where
        # both ends carry a pin and the office's allowance where they do not, so
        # this screen can never offer a slot the planner would have refused.
        stops = _wct_stops(book, p.id, date_s)
        best = None
        for w0, w1 in wins:
            lo, hi = max(w0, win[0]), min(w1, win[1])
            if hi - lo < minutes:
                continue
            gaps, prev, free = [], None, lo
            for stop in stops:
                st, en, _b, _sid = stop
                if en <= lo:
                    prev, free = stop, max(free, en)
                    continue
                if st >= hi:
                    break
                if st > free:
                    gaps.append((free, st, prev, stop))
                prev, free = stop, max(free, en)
            nxt = next((x for x in stops if x[0] >= hi), None)
            if free < hi:
                gaps.append((free, hi, prev, nxt))
            for g0, g1, pstop, nstop in gaps:
                drive_in = roster.travel_minutes(
                    pstop[2] if pstop else None, branch, s) if pstop else 0
                drive_out = roster.travel_minutes(
                    branch, nstop[2], s) if (nstop and nstop[2] is not None) else 0
                # A hop the planner calls too long is a hop this screen does not
                # offer either — let somebody nearer have it.
                if drive_in is None or drive_out is None:
                    continue
                a, b = g0 + drive_in, g1 - drive_out
                if b - a < minutes:
                    continue
                if best is None or (b - a) > (best[1] - best[0]):
                    best = (a, b, pstop, nstop, drive_in, drive_out)
        if best is None:
            worked = sum(en - st for st, en, _b, _s in stops)
            blocked.append({**row, "why": "no_gap", "visits_that_day": len(stops),
                            "busy_minutes": worked})
            continue
        start, end = best[0], best[0] + minutes
        before = _wct_place(best[2], branch, site_names)
        after = _wct_place(best[3], branch, site_names)
        if before is not None:
            before["drive"] = best[4]
        if after is not None:
            after["drive"] = best[5]
        # HOW GOOD AN IDEA IS IT? Three things, in the order the office weighs
        # them: is he already in that patch that day (no new journey at all),
        # how far the branch is from the call either side of it (only where BOTH
        # ends carry a pin — four branches in five have none, and a guess
        # dressed up as a distance is worse than an honest blank), and how much
        # of his day is already spoken for.
        same_area = any(b is not None and b.area_id == branch.area_id
                        for _a, _b2, b, _s in stops)
        busy = [(st, en) for st, en, _b, _s in stops]
        near = [x["km"] for x in (before, after) if x and x["km"] is not None]
        fits.append({**row,
                     "suggested_start": _hhmm_of(start), "suggested_end": _hhmm_of(end),
                     "gap_from": _hhmm_of(best[0]), "gap_to": _hhmm_of(best[1]),
                     "free_minutes": best[1] - best[0],
                     "before": before, "after": after,
                     "visits_that_day": len(stops),
                     "busy_minutes": sum(b - a for a, b in busy),
                     "same_area": same_area,
                     "km": min(near) if near else None,
                     "why": ("same_area" if same_area
                             else "free_day" if not stops else "elsewhere_that_day")})
    fits.sort(key=lambda f: (0 if f["same_area"] else 1,
                             f["km"] if f["km"] is not None else 9999,
                             -f["free_minutes"], f["agent_name"]))
    return {"site": head, "fits": fits, "blocked": blocked, "shut": False}


@route("POST", r"/api/shifts/auto/runs/(\d+)/undo")
def undo_roster_run(ctx):
    """Take back one press of the auto-roster button.

    What it will NOT touch is the point: a visit the field has already started,
    completed or cancelled, one that has picked up a report or a device scan,
    and one whose engineer has since been changed by hand. Those are counted as
    `kept` and reported — an undo that quietly deleted a morning's work would be
    worse than no undo at all."""
    require_perm(ctx.user, "shifts.create")
    require_perm(ctx.user, "visits.create")
    rid = int(ctx.params[0])
    undone = {"visits": 0, "assigned": 0, "shifts": 0}
    kept = 0
    with db.transaction() as cx:
        # Re-read INSIDE the transaction: two clicks must not undo twice, and
        # the second would revert visits the office had legitimately re-staffed.
        run = cx.execute("SELECT * FROM roster_runs WHERE id=? AND undone_at IS NULL",
                         (rid,)).fetchone()
        if not run:
            raise ApiError(404, "That plan has already been taken back, or never existed")
        if ctx.user["role"] in SUPERVISOR_ROLES and run["created_by"] != ctx.user["id"]:
            raise ApiError(403, "You can only take back a plan you made yourself")
        items = cx.execute("SELECT kind, ref_id, agent_id FROM roster_run_items "
                           "WHERE run_id=?", (rid,)).fetchall()
        # Visits first, so the shift pass below can see which ones survived.
        survivors = set()
        for it in items:
            if it["kind"] == "visit_created":
                cur = cx.execute(
                    "DELETE FROM visits WHERE id=? AND status='scheduled' AND agent_id=? "
                    "AND NOT EXISTS (SELECT 1 FROM reports WHERE visit_id=visits.id) "
                    "AND NOT EXISTS (SELECT 1 FROM device_inspections WHERE visit_id=visits.id)",
                    (it["ref_id"], it["agent_id"]))
                if cur.rowcount:
                    undone["visits"] += 1
                else:
                    kept += 1
                    survivors.add((it["agent_id"], it["ref_id"]))
            elif it["kind"] == "visit_assigned":
                # Hand it back to nobody — never delete it, it was not ours.
                cur = cx.execute(
                    "UPDATE visits SET agent_id=NULL WHERE id=? AND agent_id=? "
                    "AND status='scheduled'", (it["ref_id"], it["agent_id"]))
                if cur.rowcount:
                    undone["assigned"] += 1
                else:
                    kept += 1
                    survivors.add((it["agent_id"], it["ref_id"]))
        # A cover shift is only removed when nothing of this run's work is left
        # standing on that engineer's day. Otherwise a visit somebody has
        # already started would be left with no area rostered under it.
        busy_days = set()
        for aid, vid in survivors:
            row = cx.execute("SELECT date(scheduled_start) d FROM visits WHERE id=?",
                             (vid,)).fetchone()
            if row and row["d"]:
                busy_days.add((aid, row["d"]))
        for it in items:
            if it["kind"] != "shift_created":
                continue
            row = cx.execute("SELECT agent_id, shift_date FROM agent_shifts WHERE id=?",
                             (it["ref_id"],)).fetchone()
            if row and (row["agent_id"], row["shift_date"]) in busy_days:
                kept += 1
                continue
            cur = cx.execute("DELETE FROM agent_shifts WHERE id=?", (it["ref_id"],))
            if cur.rowcount:
                undone["shifts"] += 1
        cx.execute("UPDATE roster_runs SET undone_at=datetime('now','localtime'), undone_by=?, kept=? "
                   "WHERE id=?", (ctx.user["id"], kept, rid))
    audit(ctx, "shifts.auto.undo", "agent_shift", None,
          f"run {rid}: {undone['visits']} deleted, {undone['assigned']} unassigned, "
          f"{undone['shifts']} shift(s) removed, {kept} kept")
    return {"ok": True, "run_id": rid, "kept": kept, **undone}


# --------------------------------------------------------------------------
# CLEARING THE BOARD — wipe a slice of the roster and start again
# --------------------------------------------------------------------------
def _round_date_shifts(frm, to):
    """(agent_id, date) pairs that carry a shift row anywhere near the range."""
    return {(r["agent_id"], r["shift_date"]) for r in db.query(
        "SELECT agent_id, shift_date FROM agent_shifts WHERE shift_date BETWEEN ? AND ?",
        (frm, to))}


def _engineer_hours():
    """agent_id -> {weekday: (start_min, end_min)} using the PLANNER's own
    reading of an availability row, so the two never drift apart."""
    out = {}
    for r in db.query("SELECT agent_id, weekday, start_time, end_time FROM agent_availability"):
        out.setdefault(r["agent_id"], {})[r["weekday"]] = roster.avail_bounds(
            r["start_time"], r["end_time"])
    return out


def _service_date(agent_id, start, dur, shift_days, hours):
    """The DATE OF THE ROUND a stop belongs to, which is not always the date
    its timestamp falls on.

    A round that begins at 22:00 ends after midnight, so its last calls are
    written onto the next day. Those calls are part of the night before's work
    and must be cleared with it — otherwise "clear September" leaves the tail of
    the 30th behind, orphaned from the round that made it.

    Two things decide it, both taken from the planner's own model, exactly as
    `rounds.py` does when it reads the diary back:
      * the run wrote a shift row for every (engineer, round date) it used, so a
        date carrying no shift row of his was never a round of his;
      * a round is timed inside the man's hours for its OWN date, so a stop that
        would fall outside them on one reading belongs to the other.
    Where both readings survive, the stop keeps its own date — a clear must
    never reach further than it can justify.
    """
    own = start.date()
    prev = own - _dt_mod.timedelta(days=1)
    tod = start.hour * 60 + start.minute
    fits = []
    for rd, at in ((own, tod), (prev, tod + 1440)):
        if (agent_id, rd.isoformat()) not in shift_days:
            continue
        window = hours.get(agent_id, {}).get(rd.weekday())
        if window is None:
            continue
        lo, hi = window
        if at >= lo and at + dur <= hi:
            fits.append(rd)
    return fits[0] if len(fits) == 1 else own


def _night_tail_ids(frm, to):
    """(extra, excluded) visit ids the plain date bound gets wrong.

    Only two days can ever disagree: a stop written onto the day AFTER the range
    may belong to the last round inside it, and a stop written onto the FIRST
    day of the range may belong to the round before it. Everything else lands
    the same either way, so this stays two small queries however wide the range.
    """
    day_before = (_dt_mod.date.fromisoformat(frm) - _dt_mod.timedelta(days=1)).isoformat()
    day_after = (_dt_mod.date.fromisoformat(to) + _dt_mod.timedelta(days=1)).isoformat()
    rows = db.query(
        "SELECT id, agent_id, scheduled_start, scheduled_end FROM visits "
        "WHERE agent_id IS NOT NULL AND date(scheduled_start) IN (?,?)",
        (day_after, frm))
    if not rows:
        return set(), set()
    shift_days = _round_date_shifts(day_before, day_after)
    hours = _engineer_hours()
    extra, excluded = set(), set()
    for r in rows:
        try:
            start = _dt_mod.datetime.fromisoformat(r["scheduled_start"])
            end = _dt_mod.datetime.fromisoformat(r["scheduled_end"]) if r["scheduled_end"] else start
        except (TypeError, ValueError):
            continue
        dur = max(0, int((end - start).total_seconds() // 60))
        rd = _service_date(r["agent_id"], start, dur, shift_days, hours).isoformat()
        own = start.date().isoformat()
        if own == day_after and frm <= rd <= to:
            extra.add(r["id"])
        elif own == frm and rd < frm:
            excluded.add(r["id"])
    return extra, excluded


def _clear_filters(ctx):
    """Read and validate the filters both halves of the clear share.

    An area manager may only ever clear inside their own patch, and a team
    leader — who answers for people, not places — clears nothing at all. Same
    fail-closed rule the planner follows."""
    b = ctx.body
    frm = _shift_date(b["from"], "from") if b.get("from") else None
    to = _shift_date(b["to"], "to") if b.get("to") else None
    if frm and to and to < frm:
        raise ApiError(400, "The end date is before the start date")

    def _id(key):
        v = b.get(key)
        if v in (None, "", 0, "0"):
            return None
        try:
            return int(v)
        except (TypeError, ValueError):
            raise ApiError(400, f"{key} must be a number")

    f = {"from": frm, "to": to, "agent_id": _id("agent_id"),
         "client_id": _id("client_id"), "site_id": _id("site_id"),
         "area_id": _id("area_id")}
    role = ctx.user.get("role")
    if role == "team_leader":
        raise ApiError(403, "A team leader cannot clear the schedule")
    if role == "area_manager":
        scope = area_manager_area_ids(ctx.user)
        if not scope:
            raise ApiError(403, "You hold no area to clear")
        if f["area_id"] and f["area_id"] not in scope:
            raise ApiError(403, "That area is not yours")
        f["_scope"] = scope
    else:
        f["_scope"] = None
    # WIPING THE WHOLE BOOK IS A DIFFERENT ACTION, not this one with the boxes
    # left empty. It used to ride on a flag called `all` — but the browser set
    # that flag for you the moment the date boxes happened to be blank, so the
    # "say it out loud" gate could never be reached as a decision, and one press
    # of a button labelled "Every date" took an applied month off the book.
    # Now it needs a word only a person would send, and a permission the office
    # does not hold.
    scope = b.get("scope") or "range"
    if scope not in ("range", "everything"):
        raise ApiError(400, "scope must be range or everything")
    if scope == "everything":
        require_perm(ctx.user, "schedule.clear_all")
        f["_everything"] = True
    else:
        f["_everything"] = False
        # A NORMAL CLEAR IS ALWAYS BOUNDED. Naming a customer or an engineer is
        # not a boundary — that customer has visits in every month there is.
        if not (frm and to):
            raise ApiError(400, "Choose the dates to clear — a clear needs both "
                                "a start and an end")
    what = b.get("what") or "both"
    if what not in ("both", "visits", "shifts"):
        raise ApiError(400, "what must be visits, shifts or both")
    return f, what, bool(b.get("include_off"))


def _clear_visit_sql(f):
    """WHERE for the visits a clear may touch, and its parameters.

    THE SAFETY IS IN THIS ONE CLAUSE and it is the whole reason this endpoint
    exists rather than a loop of DELETEs: a visit that has been started, done,
    cancelled, reported on, scanned or checked into is WORK THAT HAPPENED. It
    is never deleted, however wide the filter — it is counted and reported
    back, so the office can see the difference between "the plan is gone" and
    "the history is gone", which are not the same thing at all."""
    where = ["v.status='scheduled'",
             "v.checkin_at IS NULL",
             "NOT EXISTS (SELECT 1 FROM reports r WHERE r.visit_id=v.id)",
             "NOT EXISTS (SELECT 1 FROM device_inspections di WHERE di.visit_id=v.id)"]
    scope, params = _clear_scope_sql(f)
    return where + scope, params


def _clear_scope_sql(f):
    """The filter half — the same for the visits that go and the ones kept."""
    where, params = [], []
    if f["from"] and f["to"]:
        # THE RANGE IS A RANGE OF ROUNDS, NOT OF TIMESTAMPS. A stop the night
        # of the 30th wrote onto the 1st is part of the 30th's work and goes
        # with it; a stop on the 1st that belongs to the round before the range
        # stays. See _night_tail_ids — only the two boundary days can differ.
        extra, excluded = _night_tail_ids(f["from"], f["to"])
        inside = "(date(v.scheduled_start) >= ? AND date(v.scheduled_start) <= ?"
        params += [f["from"], f["to"]]
        if excluded:
            inside += " AND v.id NOT IN (%s)" % ",".join("?" * len(excluded))
            params += sorted(excluded)
        inside += ")"
        if extra:
            inside += " OR v.id IN (%s)" % ",".join("?" * len(extra))
            params += sorted(extra)
        where.append("(" + inside + ")")
    elif f["from"]:
        where.append("date(v.scheduled_start) >= ?")
        params.append(f["from"])
    elif f["to"]:
        where.append("date(v.scheduled_start) <= ?")
        params.append(f["to"])
    if f["agent_id"]:
        where.append("v.agent_id=?")
        params.append(f["agent_id"])
    if f["client_id"]:
        where.append("v.client_id=?")
        params.append(f["client_id"])
    if f["site_id"]:
        where.append("v.site_id=?")
        params.append(f["site_id"])
    if f["area_id"]:
        where.append("v.site_id IN (SELECT id FROM sites WHERE area_id=?)")
        params.append(f["area_id"])
    if f["_scope"]:
        marks = ",".join("?" for _ in f["_scope"])
        where.append(f"v.site_id IN (SELECT id FROM sites WHERE area_id IN ({marks}))")
        params.extend(f["_scope"])
    return where, params


def _clear_shift_sql(f, include_off):
    """WHERE for the shift rows a clear may touch.

    A shift belongs to a PERSON and a DAY; it has no customer and no branch. So
    filtering by client or branch narrows the visits and leaves the shift board
    alone — which is right, and the screen says so, because silently wiping an
    engineer's whole week because you picked one restaurant would be a nasty
    surprise."""
    where, params = [], []
    if f["from"]:
        where.append("s.shift_date >= ?")
        params.append(f["from"])
    if f["to"]:
        where.append("s.shift_date <= ?")
        params.append(f["to"])
    if f["agent_id"]:
        where.append("s.agent_id=?")
        params.append(f["agent_id"])
    if f["area_id"]:
        where.append("s.area_id=?")
        params.append(f["area_id"])
    if f["_scope"]:
        marks = ",".join("?" for _ in f["_scope"])
        where.append(f"s.area_id IN ({marks})")
        params.extend(f["_scope"])
    if not include_off:
        # Leave and days off are HR facts, not roster output. Clearing the plan
        # must not quietly cancel somebody's holiday.
        where.append("NOT EXISTS (SELECT 1 FROM shift_types t "
                     "WHERE t.id=s.shift_type_id AND t.is_off=1)")
    return where, params


def _runs_touched_by(visit_ids):
    """run_id -> how many of ITS OWN visits this clear is about to delete.

    Only runs still standing count. A run already taken back has no claim on
    anything left on the book."""
    if not visit_ids:
        return {}
    ids = sorted(visit_ids)
    out = {}
    for chunk in (ids[i:i + 400] for i in range(0, len(ids), 400)):
        marks = ",".join("?" * len(chunk))
        for r in db.query(
            f"SELECT ri.run_id, COUNT(*) n FROM roster_run_items ri "
            f"JOIN roster_runs r ON r.id = ri.run_id "
            f"WHERE ri.kind='visit_created' AND r.undone_at IS NULL "
            f"AND ri.ref_id IN ({marks}) GROUP BY ri.run_id", tuple(chunk)):
            out[r["run_id"]] = out.get(r["run_id"], 0) + r["n"]
    return out


def _reconcile_runs(cx, runs, user_id):
    """Make the run history tell the truth after a clear.

    A CLEAR IS NOT AN UNDO. If it happened to take everything a run wrote, the
    run really is gone and Undo must stop offering it — so it is marked taken
    back, by this clear. If it took only part, the run still has work standing
    and Undo must keep working on the rest; the run is marked as CUT INTO, and
    nothing claims it was undone.

    Before this, a clear left a run standing with its rows already deleted, and
    the next Undo answered "0 deleted, 848 kept" — true of the rows, and
    useless to the person reading it."""
    done = []
    for rid, taken in sorted(runs.items()):
        left = cx.execute(
            "SELECT COUNT(*) FROM roster_run_items ri JOIN visits v ON v.id = ri.ref_id "
            "WHERE ri.run_id=? AND ri.kind='visit_created'", (rid,)).fetchone()[0]
        shifts_gone = cx.execute(
            "SELECT COUNT(*) FROM roster_run_items ri LEFT JOIN agent_shifts s "
            "ON s.id = ri.ref_id WHERE ri.run_id=? AND ri.kind='shift_created' "
            "AND s.id IS NULL", (rid,)).fetchone()[0]
        cx.execute("UPDATE roster_runs SET cleared_at=datetime('now','localtime'), cleared_by=?, "
                   "cleared_visits=cleared_visits+?, cleared_shifts=? WHERE id=?",
                   (user_id, taken, shifts_gone, rid))
        if left == 0:
            cx.execute("UPDATE roster_runs SET undone_at=datetime('now','localtime'), undone_by=? "
                       "WHERE id=? AND undone_at IS NULL", (user_id, rid))
        done.append({"run_id": rid, "visits_cleared": taken,
                     "fully_cleared": left == 0, "visits_left": left})
    return done


@route("POST", r"/api/schedule/clear")
def clear_schedule(ctx):
    """Wipe a slice of the diary and the shift board so it can be planned again.

    The office's own words: "a button with a filter to delete all shifts and
    schedules — by client and location, or engineer, or a specific day — or
    delete all the shifts and schedules we did, to re-design it again."

    ALWAYS PREVIEW FIRST. Without `apply` this writes nothing and answers with
    the counts and a sample, because the one thing a bulk delete must never do
    is surprise the person who pressed it. `apply: true` then does exactly what
    the preview described.

    A visit that has been started, completed, cancelled, reported on, scanned or
    checked into is never deleted — it is counted as `kept` and named.

    APPLYING TAKES THREE THINGS BEYOND THE FILTER, and all three exist because
    of 2026-08-24, when one press took an applied month off the book:
      * a bounded range, unless this is the separate whole-book action;
      * `expect_visits` / `expect_shifts` echoed back from the preview, checked
        again INSIDE the transaction — so a plan that grew between the preview
        and the press is refused rather than silently over-deleted;
      * for the whole book, the word said out loud in `confirm`.
    """
    require_perm(ctx.user, "shifts.edit")
    f, what, include_off = _clear_filters(ctx)
    do_visits = what in ("both", "visits")
    do_shifts = what in ("both", "shifts")
    # A SHIFT HAS NO CUSTOMER. Picking one restaurant and finding every
    # engineer's whole week wiped off the board would be the nastiest surprise
    # this screen could spring, so naming a client or a branch narrows the
    # DIARY and leaves the shift board alone. Said out loud in the answer, or
    # "0 shifts" reads as a broken button.
    skipped = bool(do_shifts and (f["client_id"] or f["site_id"]))
    if skipped:
        do_shifts = False
    if do_visits:
        require_perm(ctx.user, "visits.delete")
    out = {"visits": 0, "shifts": 0, "kept": 0, "sample": [], "kept_sample": [],
           "shifts_skipped": skipped, "applied": False,
           # What the confirmation has to be able to say out loud: how many, and
           # over exactly which dates. "Delete 848 visit(s)?" read the same for
           # one month as for the whole book, which is how a month was lost.
           "scope": "everything" if f["_everything"] else "range",
           "range": {"from": f["from"], "to": f["to"]},
           "sample_ids": [], "runs_affected": []}
    if do_visits:
        gone_w, gone_p = _clear_visit_sql(f)
        scope_w, scope_p = _clear_scope_sql(f)
        out["visits"] = db.query(
            f"SELECT COUNT(*) c FROM visits v WHERE {' AND '.join(gone_w)}",
            tuple(gone_p), one=True)["c"]
        # What the filter caught but the safety clause holds back — the office
        # has to be told, or "0 deleted" reads as a broken button.
        kept_w = scope_w + ["NOT (" + " AND ".join([
            "v.status='scheduled'", "v.checkin_at IS NULL",
            "NOT EXISTS (SELECT 1 FROM reports r WHERE r.visit_id=v.id)",
            "NOT EXISTS (SELECT 1 FROM device_inspections di WHERE di.visit_id=v.id)"]) + ")"]
        out["kept"] = db.query(
            f"SELECT COUNT(*) c FROM visits v WHERE {' AND '.join(kept_w)}",
            tuple(scope_p), one=True)["c"]
        out["sample"] = [dict(r) for r in db.query(
            "SELECT date(v.scheduled_start) d, s.name site_name, c.name_en client_en, "
            "c.name_ar client_ar, u.full_name agent_name FROM visits v "
            "LEFT JOIN sites s ON s.id=v.site_id LEFT JOIN clients c ON c.id=v.client_id "
            "LEFT JOIN users u ON u.id=v.agent_id "
            f"WHERE {' AND '.join(gone_w)} ORDER BY v.scheduled_start LIMIT 8",
            tuple(gone_p))]
        out["kept_sample"] = [dict(r) for r in db.query(
            "SELECT date(v.scheduled_start) d, v.status, s.name site_name FROM visits v "
            "LEFT JOIN sites s ON s.id=v.site_id "
            f"WHERE {' AND '.join(kept_w)} ORDER BY v.scheduled_start LIMIT 5",
            tuple(scope_p))]
        # The ids themselves, so the screen can say WHICH stops go — including
        # the overnight tail, which is the whole point of the round-date rule.
        out["sample_ids"] = [r["id"] for r in db.query(
            f"SELECT v.id FROM visits v WHERE {' AND '.join(gone_w)}", tuple(gone_p))]
    if do_shifts:
        sh_w, sh_p = _clear_shift_sql(f, include_off)
        out["shifts"] = db.query(
            f"SELECT COUNT(*) c FROM agent_shifts s"
            f"{' WHERE ' + ' AND '.join(sh_w) if sh_w else ''}",
            tuple(sh_p), one=True)["c"]
    # WHICH APPLIED RUNS THIS EATS INTO. Named in the preview so the office can
    # see it is about to cut into a plan somebody pressed, and used after the
    # delete to keep the run history honest.
    doomed_ids = set(out["sample_ids"])
    runs = _runs_touched_by(doomed_ids) if doomed_ids else {}
    out["runs_affected"] = sorted(runs)
    if not ctx.body.get("apply"):
        return out

    # THE PREVIEW'S COUNTS, ECHOED BACK. Without this the screen shows one
    # number and the delete uses another — the gap between reading and pressing
    # is exactly where a surprise lives.
    want_v, want_s = ctx.body.get("expect_visits"), ctx.body.get("expect_shifts")
    if want_v is None or want_s is None:
        raise ApiError(400, "Preview it first — the apply must echo back the "
                            "counts that were shown")
    if f["_everything"] and str(ctx.body.get("confirm") or "").strip().upper() != "EVERYTHING":
        raise ApiError(400, "Clearing every date needs the word EVERYTHING")

    with db.transaction() as cx:
        # Counted AGAIN, inside the transaction, against the same WHERE the
        # delete is about to run. If the book moved under the preview, nothing
        # happens and the office previews again.
        if do_visits:
            gone_w, gone_p = _clear_visit_sql(f)
            now_v = cx.execute(f"SELECT COUNT(*) FROM visits v WHERE {' AND '.join(gone_w)}",
                               tuple(gone_p)).fetchone()[0]
        else:
            now_v = 0
        if do_shifts:
            sh_w, sh_p = _clear_shift_sql(f, include_off)
            now_s = cx.execute(
                f"SELECT COUNT(*) FROM agent_shifts s"
                f"{' WHERE ' + ' AND '.join(sh_w) if sh_w else ''}", tuple(sh_p)).fetchone()[0]
        else:
            now_s = 0
        if (now_v, now_s) != (int(want_v), int(want_s)):
            raise ApiError(409, f"The schedule changed since you looked — it now holds "
                                f"{now_v} visit(s) and {now_s} shift(s), not "
                                f"{int(want_v)} and {int(want_s)}. Preview it again.")
        if do_visits:
            cur = cx.execute(f"DELETE FROM visits WHERE id IN "
                             f"(SELECT v.id FROM visits v WHERE {' AND '.join(gone_w)})",
                             tuple(gone_p))
            out["visits"] = cur.rowcount
        if do_shifts:
            cur = cx.execute(
                f"DELETE FROM agent_shifts WHERE id IN (SELECT s.id FROM agent_shifts s"
                f"{' WHERE ' + ' AND '.join(sh_w) if sh_w else ''})", tuple(sh_p))
            out["shifts"] = cur.rowcount
        out["runs_reconciled"] = _reconcile_runs(cx, runs, ctx.user["id"])
    out["applied"] = True
    audit(ctx, "schedule.clear", "schedule", None,
          f"{out['visits']} visit(s), {out['shifts']} shift(s) cleared; "
          f"scope:{out['scope']} range:{f['from'] or '-'}..{f['to'] or '-'}; "
          f"runs:{','.join(str(r) for r in out['runs_affected']) or '-'}; "
          f"filters={{from:{f['from']}, to:{f['to']}, agent:{f['agent_id']}, "
          f"client:{f['client_id']}, site:{f['site_id']}, area:{f['area_id']}, "
          f"what:{what}, days_off:{include_off}}}")
    return out


@route("DELETE", r"/api/shifts/(\d+)")
def delete_shift(ctx):
    require_perm(ctx.user, "shifts.delete")
    sid = int(ctx.params[0])
    row = db.query("SELECT agent_id, shift_date, area_id FROM agent_shifts WHERE id=?",
                   (sid,), one=True)
    if not row:
        raise ApiError(404, "Shift assignment not found")
    if ctx.user["role"] == "area_manager" and row["agent_id"] != ctx.user["id"] \
            and row["area_id"] not in area_manager_area_ids(ctx.user):
        raise ApiError(403, "You can only roster your own areas")
    if ctx.user["role"] == "team_leader" and row["agent_id"] != ctx.user["id"] \
            and row["agent_id"] not in team_member_ids(ctx.user):
        raise ApiError(403, "You can only roster your own team")
    db.execute("DELETE FROM agent_shifts WHERE id=?", (sid,))
    audit(ctx, "shift.delete", "agent_shift", row["agent_id"], row["shift_date"])
    return {"ok": True}


# --------------------------------------------------------------------------
# RBAC — roles & per-user permission management (admin only)
# --------------------------------------------------------------------------
@route("GET", r"/api/permissions/catalog")
def permissions_catalog(ctx):
    require_perm(ctx.user, "permissions.view")
    return {
        "catalog": PERMISSION_CATALOG,
        "roles": ROLES,
        "defaults": ROLE_DEFAULTS,
        # Effective (defaults + saved overrides) matrix for every role.
        "roles_effective": {r: effective_role_perms(r) for r in ROLES},
        "role_overrides": {r: _role_overrides(r) for r in ROLES},
    }


@route("PUT", r"/api/permissions/roles/(\w+)")
def update_role_permissions(ctx):
    require_perm(ctx.user, "permissions.edit")
    role = ctx.params[0]
    if role not in ROLES:
        raise ApiError(400, "Invalid role")
    if role == "admin":
        raise ApiError(400, "The admin role always has full access and cannot be edited")
    valid = set(all_perms())
    perms = ctx.body.get("perms") or {}
    defaults = ROLE_DEFAULTS.get(role, {})
    for perm, val in perms.items():
        if perm not in valid:
            continue
        allowed = 1 if val else 0
        # Store only true overrides; if it matches the built-in default, drop it.
        if (perm in defaults) and (bool(allowed) == defaults[perm]):
            db.execute("DELETE FROM role_permissions WHERE role=? AND perm=?", (role, perm))
        else:
            db.execute(
                "INSERT INTO role_permissions(role,perm,allowed) VALUES(?,?,?) "
                "ON CONFLICT(role,perm) DO UPDATE SET allowed=excluded.allowed",
                (role, perm, allowed))
    audit(ctx, "permissions.role.update", "role", role,
          f"set {len(perms)} permission(s) for role '{role}'")
    return {"role": role, "effective": effective_role_perms(role),
            "overrides": _role_overrides(role)}


@route("GET", r"/api/permissions/users/(\d+)")
def get_user_permissions(ctx):
    require_perm(ctx.user, "permissions.view")
    uid = int(ctx.params[0])
    u = db.query("SELECT id, full_name, role FROM users WHERE id=?", (uid,), one=True)
    if not u:
        raise ApiError(404, "User not found")
    return {
        "user": u,
        "role_effective": effective_role_perms(u["role"]),  # what they inherit
        "effective": effective_user_perms(u),               # final resolved
        "overrides": _user_overrides(uid),                  # per-user only
    }


@route("PUT", r"/api/permissions/users/(\d+)")
def update_user_permissions(ctx):
    require_perm(ctx.user, "permissions.edit")
    uid = int(ctx.params[0])
    u = db.query("SELECT id, role FROM users WHERE id=?", (uid,), one=True)
    if not u:
        raise ApiError(404, "User not found")
    if u["role"] == "admin":
        raise ApiError(400, "Admin users always have full access and cannot be edited")
    valid = set(all_perms())
    # perms maps perm -> true | false | null. null clears the override (inherit).
    perms = ctx.body.get("perms") or {}
    for perm, val in perms.items():
        if perm not in valid:
            continue
        if val is None:
            db.execute("DELETE FROM user_permissions WHERE user_id=? AND perm=?", (uid, perm))
        else:
            db.execute(
                "INSERT INTO user_permissions(user_id,perm,allowed) VALUES(?,?,?) "
                "ON CONFLICT(user_id,perm) DO UPDATE SET allowed=excluded.allowed",
                (uid, perm, 1 if val else 0))
    full = db.query("SELECT * FROM users WHERE id=?", (uid,), one=True)
    audit(ctx, "permissions.user.update", "user", uid,
          f"set {len(perms)} per-user override(s)")
    return {"user_id": uid, "effective": effective_user_perms(full),
            "overrides": _user_overrides(uid)}


@route("GET", r"/api/audit")
def list_audit(ctx):
    require_perm(ctx.user, "permissions.view")
    limit = min(int(ctx.query.get("limit", 100) or 100), 500)
    return db.query("SELECT * FROM audit_log ORDER BY id DESC LIMIT ?", (limit,))


# --------------------------------------------------------------------------
# CLIENTS (company folders)
# --------------------------------------------------------------------------
@route("GET", r"/api/clients")
def list_clients(ctx):
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "clients.view")
    cid = client_scope_id(ctx.user)
    q = ctx.query.get("q", "").strip()
    sql = "SELECT * FROM clients"
    params = []
    where = []
    if cid:
        where.append("id=?")
        params.append(cid)
    lc, lp = _sup_client_clause(ctx.user)
    if lc:
        where.append(lc)
        params += lp
    if q:
        where.append("(name_en LIKE ? OR name_ar LIKE ? OR city LIKE ? OR contact_person LIKE ?)")
        params += [f"%{q}%"] * 4
    # Switched-off customers stay in the list by default — the office has to be
    # able to find one to switch it back on — but can be filtered to either side.
    st = (ctx.query.get("status") or "").strip().lower()
    if st in ("active", "inactive"):
        where.append("status=?"); params.append(st)
    if where:
        sql += " WHERE " + " AND ".join(where)
    return _paginate(ctx, sql, params, "ORDER BY name_en")


@route("GET", r"/api/clients/(\d+)")
def get_client(ctx):
    cid = int(ctx.params[0])
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "clients.view")
    _assert_client_access(ctx.user, cid)
    client = db.query("SELECT * FROM clients WHERE id=?", (cid,), one=True)
    if not client:
        raise ApiError(404, "Client not found")
    # A portal login pinned to one location only ever sees that location.
    site_c, site_p = _client_site_clause(ctx.user, "v.site_id")
    pin = client_site_scope_id(ctx.user)
    client["sites"] = _attach_service_days(db.query(
        "SELECT s.*, ar.name_en area_en, ar.name_ar area_ar, "
        # What is still in the diary for this branch, so switching it off can
        # say how many visits that would leave booked rather than asking the
        # office to go and count them.
        "(SELECT COUNT(*) FROM visits v WHERE v.site_id=s.id AND v.status='scheduled' "
        "AND date(v.scheduled_start) >= date('now','localtime')) upcoming_visits "
        "FROM sites s "
        "LEFT JOIN areas ar ON ar.id=s.area_id "
        "WHERE s.client_id=?" + (" AND s.id=?" if pin else "") + " ORDER BY s.name",
        (cid, *([pin] if pin else []))))
    client["upcoming_visits"] = _upcoming_scheduled("client_id", cid)
    client["photos"] = db.query(
        "SELECT * FROM photos WHERE entity_type='client' AND entity_id=? ORDER BY uploaded_at DESC", (cid,))
    client["recent_visits"] = db.query(
        "SELECT v.*, s.name_en service_en, s.name_ar service_ar, u.full_name agent_name "
        "FROM visits v LEFT JOIN service_types s ON s.id=v.service_type_id "
        "LEFT JOIN users u ON u.id=v.agent_id WHERE v.client_id=?" + site_c +
        " ORDER BY v.scheduled_start DESC LIMIT 10", (cid, *site_p))
    # Finance is money data: clients see their own; staff need invoices.view
    # (so an agent with only clients.view doesn't see the company's finances).
    if ctx.user["role"] == "client" or has_perm(ctx.user, "invoices.view"):
        client["finance"] = _finance_summary(cid, pin)
    else:
        client["finance"] = None
    if ctx.user["role"] == "client":
        client["users"] = []
    else:
        client["users"] = [_public_user(r) for r in
                           db.query("SELECT * FROM users WHERE client_id=?", (cid,))]
    return client


# ---------------------------------------------------------------- switched off
# A CUSTOMER OR A BRANCH THAT IS NO LONGER SERVICED. Deleting one is not the
# answer — its visits, reports and invoices are the company's own history, and
# they go with it. Switching it off takes it out of everything FORWARD-looking
# (the automatic roster, the capacity sums, the SLA nagging) and leaves
# everything already recorded exactly where it is.
def _status_value(raw):
    st = str(raw or "").strip().lower()
    if st not in ("active", "inactive"):
        raise ApiError(400, "Status must be active or inactive")
    return st


# The branches the company actually services — switched on, and belonging to a
# customer who is switched on. Every FORWARD-looking count reads this: what is
# missing an area, what has no cycle, what an area is carrying. History does
# not: a visit that was done was done.
_SERVICED_BRANCH = (" AND status='active' AND client_id IN "
                    "(SELECT id FROM clients WHERE status='active')")


def _truthy(raw):
    return str(raw).strip().lower() in ("1", "true", "on", "yes")


def _upcoming_scheduled(col, oid):
    """Visits still to be driven to — today's included, since a customer who
    stops today has not been serviced today."""
    return db.query(
        f"SELECT COUNT(*) n FROM visits WHERE {col}=? AND status='scheduled' "
        f"AND date(scheduled_start) >= date('now','localtime')", (oid,), one=True)["n"]


def _cancel_upcoming(col, oid, why):
    """Take the booked-but-not-done visits out of the diary. CANCELLED, never
    deleted: the office can see what was called off, and switching the customer
    back on does not have to invent visits that were once real."""
    n = _upcoming_scheduled(col, oid)
    if n:
        db.execute(
            f"UPDATE visits SET status='cancelled', notes=COALESCE(notes || ' | ', '') || ? "
            f"WHERE {col}=? AND status='scheduled' AND date(scheduled_start) >= date('now','localtime')",
            (why, oid))
    return n


@route("POST", r"/api/clients/(\d+)/status")
def set_client_status(ctx):
    """Switch a customer off (or back on). `cancel_visits` also clears what is
    still booked for them — the office's choice, because a place that shuts for
    a month wants its diary kept and a customer who leaves does not."""
    require_perm(ctx.user, "clients.edit")
    cid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM clients WHERE id=?", (cid,), one=True):
        raise ApiError(404, "Client not found")
    st = _status_value(ctx.body.get("status"))
    cancelled = 0
    if st == "inactive" and _truthy(ctx.body.get("cancel_visits")):
        cancelled = _cancel_upcoming("client_id", cid, "Customer switched off")
    db.execute("UPDATE clients SET status=? WHERE id=?", (st, cid))
    audit(ctx, "client.status", "client", cid,
          st + (f", {cancelled} upcoming visit(s) cancelled" if cancelled else ""))
    return {"ok": True, "status": st, "cancelled_visits": cancelled,
            "upcoming_visits": _upcoming_scheduled("client_id", cid)}


@route("POST", r"/api/sites/(\d+)/status")
def set_site_status(ctx):
    """The same for ONE branch. A chain does not close all at once: the office
    switches off the branch that shut and the other nine keep their roster."""
    require_perm(ctx.user, "clients.edit")
    sid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM sites WHERE id=?", (sid,), one=True):
        raise ApiError(404, "Site not found")
    st = _status_value(ctx.body.get("status"))
    cancelled = 0
    if st == "inactive" and _truthy(ctx.body.get("cancel_visits")):
        cancelled = _cancel_upcoming("site_id", sid, "Branch switched off")
    db.execute("UPDATE sites SET status=? WHERE id=?", (st, sid))
    audit(ctx, "site.status", "site", sid,
          st + (f", {cancelled} upcoming visit(s) cancelled" if cancelled else ""))
    return {"ok": True, "status": st, "cancelled_visits": cancelled,
            "upcoming_visits": _upcoming_scheduled("site_id", sid)}


@route("POST", r"/api/clients")
def create_client(ctx):
    require_perm(ctx.user, "clients.create")
    b = ctx.body
    if not b.get("name_en"):
        raise ApiError(400, "Company name (English) is required")
    cid = db.execute(
        "INSERT INTO clients(name_en,name_ar,contact_person,phone,email,address_en,address_ar,"
        "city,area_id,notes,status,dunning) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        (b["name_en"], b.get("name_ar"), b.get("contact_person"), b.get("phone"), b.get("email"),
         b.get("address_en"), b.get("address_ar"), b.get("city"),
         _coerce_area_id(b.get("area_id")), b.get("notes"),
         _status_value(b.get("status") or "active"),
         0 if str(b.get("dunning", 1)) in ("0", "false", "False") else 1))
    return db.query("SELECT * FROM clients WHERE id=?", (cid,), one=True)


@route("PUT", r"/api/clients/(\d+)")
def update_client(ctx):
    require_perm(ctx.user, "clients.edit")
    cid = int(ctx.params[0])
    b = ctx.body
    cols = ("name_en", "name_ar", "contact_person", "phone", "email",
            "address_en", "address_ar", "city", "notes", "status")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [_status_value(b[c]) if c == "status" else b[c] for c in cols if c in b]
    if "dunning" in b:
        fields.append("dunning=?")
        vals.append(0 if str(b["dunning"]) in ("0", "false", "False") else 1)
    if "area_id" in b:
        fields.append("area_id=?"); vals.append(_coerce_area_id(b["area_id"]))
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(cid)
    db.execute(f"UPDATE clients SET {','.join(fields)} WHERE id=?", vals)
    return db.query("SELECT * FROM clients WHERE id=?", (cid,), one=True)


@route("DELETE", r"/api/clients/(\d+)")
def delete_client(ctx):
    require_perm(ctx.user, "clients.delete")
    db.execute("DELETE FROM clients WHERE id=?", (int(ctx.params[0]),))
    return {"ok": True}


@route("GET", r"/api/sites")
def list_all_sites(ctx):
    """Every site/location across all clients (powers the Locations sidebar view)."""
    u = ctx.user
    if u["role"] != "client":
        require_perm(u, "clients.view")
    where, params = [], []
    if u["role"] == "client":
        where.append("s.client_id=?"); params.append(u["client_id"])
        pin = client_site_scope_id(u)
        if pin:
            where.append("s.id=?"); params.append(pin)
    # An area manager's Locations page is their patch's branches. The branch
    # carries the area itself here, so this is a direct match rather than the
    # client-level fallback the visit queries need.
    if u["role"] == "area_manager":
        areas = area_manager_area_ids(u)
        if areas:
            marks = ",".join("?" for _ in areas)
            where.append(f"(s.area_id IN ({marks}) OR EXISTS (SELECT 1 FROM visits v "
                         f"WHERE v.site_id=s.id AND v.agent_id=?))")
            params += [*areas, u["id"]]
        else:
            where.append("EXISTS (SELECT 1 FROM visits v WHERE v.site_id=s.id AND v.agent_id=?)")
            params.append(u["id"])
    # A team leader's is the branches their team is actually sent to.
    if u["role"] == "team_leader":
        ids = [*team_member_ids(u), u["id"]]
        marks = ",".join("?" for _ in ids)
        where.append(f"EXISTS (SELECT 1 FROM visits v WHERE v.site_id=s.id "
                     f"AND v.agent_id IN ({marks}))")
        params += ids
    if ctx.query.get("client"):
        where.append("s.client_id=?"); params.append(ctx.query["client"])
    sql = ("SELECT s.id, s.client_id, s.name, s.address, s.area, s.area_id, s.map_image, "
           "s.lat, s.lng, s.service_from, s.service_to, s.visits_per_month, s.visit_minutes, "
           "s.status, s.map_url, c.status client_status, "
           "(SELECT COUNT(*) FROM visits v WHERE v.site_id=s.id AND v.status='scheduled' "
           "AND date(v.scheduled_start) >= date('now','localtime')) upcoming_visits, "
           "s.created_at, c.name_en client_en, c.name_ar client_ar, "
           "ar.name_en area_en, ar.name_ar area_ar "
           "FROM sites s JOIN clients c ON c.id=s.client_id "
           "LEFT JOIN areas ar ON ar.id=s.area_id")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY c.name_en, s.name"
    return _attach_service_days(db.query(sql, params))


# Twice a day, every day — the same ceiling the weekly field had (14 a week).
MAX_VISITS_PER_MONTH = 56


def _visits_per_week_number(raw):
    """A weekly figure off an older import sheet, as a plain number."""
    try:
        n = float(raw)
    except (TypeError, ValueError):
        raise ApiError(400, "Visits per week must be a number")
    if n < 0:
        raise ApiError(400, "Visits per week must be a number")
    return n


def _freq_unit(raw):
    """Which unit a branch's frequency is READ in — 'week' or 'month'.

    The office is moving to months, but a place serviced twice a week is
    naturally said in weeks, so both are offered and the choice is per branch.
    It is a lens on the stored monthly figure and nothing else: the roster
    never reads it, and switching a branch from one to the other moves no
    visit."""
    if raw in (None, "", False):
        return None
    unit = str(raw).strip().lower()
    if unit not in ("week", "month"):
        raise ApiError(400, "Frequency must be counted per week or per month")
    return unit


def _body_visits_per_month(d):
    """The branch's cycle out of a request body, as visits a MONTH.

    Everything current sends `visits_per_month`. A body still saying
    `visits_per_week` came from a page loaded before the field changed unit —
    or from an edit that sat in the offline queue across the deploy — and is
    read at four weeks to the month rather than silently ignored, which would
    put a branch on a quarter of the visits its owner thought they had asked
    for. Returns None when the body says nothing about the cycle at all."""
    if "visits_per_week" in d:
        return _visits_per_month(
            _visits_per_week_number(d["visits_per_week"] or 0) * WEEKS_PER_MONTH)
    if "visits_per_month" in d:
        return _visits_per_month(d["visits_per_month"])
    return None


def _visits_per_month(raw):
    """How many visits a branch needs each MONTH. 0 (the default) means it is
    not on a routine cycle at all, so the scheduler leaves it alone.

    The office asks in months because that is how the work is sold: "four
    visits a month", "one a month". Fractions are still accepted — 0.5 is a
    visit every two months — and the roster turns whatever is entered into
    whole visits on whole days, four roster weeks to the month."""
    if raw in (None, "", False):
        return 0
    try:
        n = float(raw)
    except (TypeError, ValueError):
        raise ApiError(400, "Visits per month must be a number")
    if n < 0 or n > MAX_VISITS_PER_MONTH:
        raise ApiError(400,
                       f"Visits per month must be between 0 and {MAX_VISITS_PER_MONTH}")
    return n


def _visit_minutes(raw):
    """How long a visit at this branch takes. Empty / 0 means "the company
    default", which is what every branch says until somebody knows better."""
    if raw in (None, "", 0, "0", False):
        return None
    try:
        n = int(float(raw))
    except (TypeError, ValueError):
        raise ApiError(400, "Visit length must be a number of minutes")
    if n < 10 or n > 480:
        raise ApiError(400, "Visit length must be between 10 and 480 minutes")
    return n


def _service_days(raw):
    """Which weekdays a branch will accept a visit, and the hours on each.

    Takes either {"5": {start_time, end_time}, ...} or a list of
    {weekday, start_time, end_time} (a bare list of numbers works too).
    Returns a sorted, deduped [(weekday, start, end)].

    An EMPTY list is meaningful and is not the same as omitting the key: it
    clears the branch's days, putting it back to "any day anyone works"."""
    if raw in (None, ""):
        return []
    items = []
    if isinstance(raw, dict):
        items = [dict(v or {}, weekday=k) for k, v in raw.items()]
    elif isinstance(raw, list):
        items = [it if isinstance(it, dict) else {"weekday": it} for it in raw]
    else:
        raise ApiError(400, "Service days must be a list")
    out = {}
    for it in items:
        try:
            wd = int(it.get("weekday"))
        except (TypeError, ValueError):
            raise ApiError(400, "Invalid service day")
        if not 0 <= wd <= 6:
            raise ApiError(400, "Invalid service day")
        start = _shift_time(it.get("start_time"), "start_time")
        end = _shift_time(it.get("end_time"), "end_time")
        # A closing time EARLIER than the opening one means the night shift —
        # 22:00 to 02:00, the way a restaurant is serviced after it shuts — and
        # the planner reads it that way (_window_bounds). The same two times is
        # the one thing it cannot read: a window of no length, or a whole day,
        # with nothing to say which. Refuse only that.
        if start and end and _hhmm_min(end) == _hhmm_min(start):
            raise ApiError(400, "A branch's closing time must not be the same as its opening time")
        out[wd] = (start, end, _preferred_agent(it.get("agent_id")))
    return sorted((wd, s, e, a) for wd, (s, e, a) in out.items())


def _preferred_agent(raw):
    """The engineer a branch belongs to, checked. "" / 0 / None = nobody, which
    means the roster decides — the state every branch is in until the office
    names somebody.

    Only an ACTIVE engineer may be named. Team leaders, managers and area
    managers are never auto-scheduled (the owner's standing rule), so naming
    one here would create a branch the planner could give to nobody and then
    report as unplaced every week without saying why."""
    if raw in (None, "", 0, "0"):
        return None
    try:
        uid = int(raw)
    except (TypeError, ValueError):
        raise ApiError(400, "Invalid engineer")
    row = db.query("SELECT id, role, active FROM users WHERE id=?", (uid,), one=True)
    if not row or not row["active"] or row["role"] != "agent":
        raise ApiError(400, "That engineer cannot be given a branch of their own")
    return uid


def _attach_service_days(sites):
    """Hang each branch's accepted days onto the rows a list endpoint returns,
    in ONE query rather than one per branch."""
    rows = sites if isinstance(sites, list) else [sites]
    rows = [r for r in rows if r]
    if not rows:
        return sites
    ids = [r["id"] for r in rows]
    marks = ",".join("?" for _ in ids)
    got = {}
    for r in db.query(
            f"SELECT site_id, weekday, start_time, end_time, agent_id FROM site_service_days "
            f"WHERE site_id IN ({marks}) ORDER BY weekday", ids):
        got.setdefault(r["site_id"], []).append(
            {"weekday": r["weekday"], "start_time": r["start_time"],
             "end_time": r["end_time"], "agent_id": r["agent_id"]})
    # WHOSE BRANCH IT IS, BY NAME. The id alone is no use to a page that only
    # renders a summary line, and every such page would otherwise fetch the
    # staff list to turn one number into one name. One more batched query.
    want = {r.get("preferred_agent_id") for r in rows if r.get("preferred_agent_id")}
    want |= {d["agent_id"] for v in got.values() for d in v if d.get("agent_id")}
    names = {}
    if want:
        ids = sorted(want)
        names = {u["id"]: u["full_name"] for u in db.query(
            f"SELECT id, full_name FROM users WHERE id IN ({','.join('?' for _ in ids)})", ids)}
    for r in rows:
        days = got.get(r["id"], [])
        for d in days:
            d["agent_name"] = names.get(d.get("agent_id"))
        r["service_days"] = days
        r["preferred_agent_name"] = names.get(r.get("preferred_agent_id"))
    return sites


def _set_service_days(cx, site_id, days):
    """Replace a branch's accepted days. The whole set is sent at once, so the
    old rows go and the new ones land — there is no partial edit to merge."""
    cx.execute("DELETE FROM site_service_days WHERE site_id=?", (site_id,))
    for wd, start, end, agent in days:
        cx.execute("INSERT INTO site_service_days"
                   "(site_id,weekday,start_time,end_time,agent_id) "
                   "VALUES(?,?,?,?,?)", (site_id, wd, start, end, agent))


def _branch_window(days, branch, wd):
    """The hours this branch takes visits on THIS weekday: the day's own
    override when it carries one, else the branch's usual window."""
    row = (days or {}).get(wd)
    if row and (row[0] or row[1]):
        return (row[0] or branch.get("service_from"), row[1] or branch.get("service_to"))
    return (branch.get("service_from"), branch.get("service_to"))


def _branch_agent(days, branch, wd):
    """WHO does this branch on this weekday, or None for "the roster decides".

    Same shape as the window above and for the same reason: a usual answer on
    the branch, overridden on the odd day. The owner's case, in his words: "the
    Exception Factory, it's a shift for one of my engineers, Alaa Abdelsamad,
    all week except Friday, for Ahmed Ashraf."
    """
    row = (days or {}).get(wd)
    if row and len(row) > 2 and row[2]:
        return row[2]
    return branch.get("preferred_agent_id")


def _contracted_vpm():
    """What each branch's ACTIVE contract says it should get, as visits a week.

    Two books of record grew up side by side: a contract's `frequency` drives
    the SLA and the overdue alerts, while a branch's `visits_per_month` drives
    the roster. Nothing compared them, so the office could satisfy the schedule
    and still show as breaching. This is the bridge — the most specific
    contract wins (one naming the branch, else one covering it through
    contract_sites, else the client's own).

    Returns {site_id: (visits_per_month, frequency, unit)} — the UNIT matters:
    a weekly deal is a weekly rhythm and a monthly one is a count in the
    calendar month, and comparing one against the other is how a branch that is
    serviced exactly as sold shows up as a mismatch."""
    out, byclient = {}, {}
    rows = db.query(
        "SELECT c.id, c.client_id, c.site_id, c.frequency FROM contracts c "
        "WHERE c.status='active'")
    linked = {}
    for r in db.query("SELECT contract_id, site_id FROM contract_sites "
                      "WHERE site_id IS NOT NULL"):
        linked.setdefault(r["contract_id"], []).append(r["site_id"])
    for c in rows:
        vpm = FREQ_PER_MONTH.get(c["frequency"])
        if not vpm:
            continue
        unit = FREQ_UNIT.get(c["frequency"], "month")
        if c["site_id"]:
            out[c["site_id"]] = (vpm, c["frequency"], unit)
        for sid in linked.get(c["id"], []):
            out.setdefault(sid, (vpm, c["frequency"], unit))
        byclient.setdefault(c["client_id"], (vpm, c["frequency"], unit))
    return out, byclient


MEASURE_MIN_SAMPLE = 3          # below this it is an anecdote, not a measurement


def _measured_minutes():
    """How long visits at each branch ACTUALLY take, from the field's own
    check-in and check-out stamps.

    The whole schedule is driven by an estimate somebody typed once. These are
    the real numbers, and they are already being collected as proof of
    presence. Uses the MEDIAN, so one visit that ran into the evening (or a
    check-out tapped in the car park) does not drag the figure; and refuses to
    say anything at all below a handful of visits.

    Returns {site_id: (median_minutes, sample_size)}."""
    import datetime as _dt
    seen = {}
    for r in db.query(
            "SELECT site_id, checkin_at, checkout_at FROM visits "
            "WHERE site_id IS NOT NULL AND status='completed' "
            "AND checkin_at IS NOT NULL AND checkout_at IS NOT NULL"):
        try:
            a = _dt.datetime.fromisoformat(str(r["checkin_at"]).replace(" ", "T"))
            b = _dt.datetime.fromisoformat(str(r["checkout_at"]).replace(" ", "T"))
        except (TypeError, ValueError):
            continue
        mins = (b - a).total_seconds() / 60.0
        # A negative or absurd span is a mis-tap, not a long job.
        if mins <= 0 or mins > 12 * 60:
            continue
        seen.setdefault(r["site_id"], []).append(mins)
    out = {}
    for sid, vals in seen.items():
        if len(vals) < MEASURE_MIN_SAMPLE:
            continue
        vals.sort()
        n = len(vals)
        med = vals[n // 2] if n % 2 else (vals[n // 2 - 1] + vals[n // 2]) / 2.0
        out[sid] = (int(round(med / 5.0) * 5), n)     # to the nearest 5 minutes
    return out


def _board_site_ids(user):
    """Which branches this user may set a schedule for, or None for "all".

    Only a supervisor is ever narrowed, and only if somebody has granted them
    clients.edit — the board would otherwise let them bulk-edit 146 branches
    when their own Locations list shows twelve. A team leader answers for
    people, not for places, so a service window is not theirs to set at all."""
    if user["role"] == "team_leader":
        return set()
    if user["role"] != "area_manager":
        return None
    areas = area_manager_area_ids(user)
    if not areas:
        return set()
    marks = ",".join("?" for _ in areas)
    return {r["id"] for r in db.query(
        f"SELECT id FROM sites WHERE area_id IN ({marks})", list(areas))}


IMPORT_DAY_NAMES = {"mon": 0, "tue": 1, "wed": 2, "thu": 3, "fri": 4, "sat": 5, "sun": 6}
# `visits_per_week` is accepted as well and is not listed: it is what the
# office's older sheets say, read at four weeks to the month.
IMPORT_COLUMNS = ("client", "branch", "area", "from", "to", "days",
                  "visits_per_month", "visit_minutes", "lat", "lng")


def _import_days(raw):
    """'Sat,Mon,Wed' / 'saturday monday' / '5 0 2' -> the stored weekday list.

    Day NAMES are accepted because that is what a person types into a
    spreadsheet; the numbers are Python's Mon=0, the same as everywhere else."""
    if not str(raw or "").strip():
        return None
    out = []
    for bit in str(raw).replace(";", ",").replace("/", ",").replace(" ", ",").split(","):
        bit = bit.strip().lower()
        if not bit:
            continue
        if bit.isdigit():
            n = int(bit)
            if not 0 <= n <= 6:
                raise ValueError(f"'{bit}' is not a day")
            out.append(n)
            continue
        key = bit[:3]
        if key not in IMPORT_DAY_NAMES:
            raise ValueError(f"'{bit}' is not a day")
        out.append(IMPORT_DAY_NAMES[key])
    return sorted(set(out))


@route("POST", r"/api/branches/import")
def import_branches(ctx):
    """Take the office's branch list from a spreadsheet instead of 200 dialogs.

    Two passes over the same parse: without `apply` it reports what WOULD
    happen row by row, and with it writes the lot in one transaction. A single
    bad row refuses the whole import — a half-applied spreadsheet is worse than
    a rejected one, because nobody can tell which half took.

    Matching is by name: the company must already exist (this does not invent
    customers), and a branch of that company with the same name is UPDATED
    rather than duplicated, so the same sheet can be sent twice."""
    require_perm(ctx.user, "clients.edit")
    import csv as _csv
    import io as _io
    text = ctx.body.get("csv") or ""
    if not str(text).strip():
        raise ApiError(400, "Nothing to import")
    try:
        reader = _csv.DictReader(_io.StringIO(str(text).lstrip("﻿")))
        raw_rows = list(reader)
    except Exception:
        raise ApiError(400, "That does not read as a CSV file")
    if not raw_rows:
        raise ApiError(400, "The file has a header but no rows")

    def col(row, name):
        for k, v in row.items():
            if k and k.strip().lower().replace(" ", "_") == name:
                return (v or "").strip()
        return ""

    clients = {}
    for c in db.query("SELECT id, name_en, name_ar FROM clients WHERE status='active'"):
        for nm in (c["name_en"], c["name_ar"]):
            if nm:
                clients.setdefault(nm.strip().lower(), c["id"])
    areas = {}
    for a in db.query("SELECT id, name_en, name_ar FROM areas WHERE active=1"):
        for nm in (a["name_en"], a["name_ar"]):
            if nm:
                areas.setdefault(nm.strip().lower(), a["id"])
    existing = {}
    for s in db.query("SELECT id, client_id, name FROM sites"):
        existing[(s["client_id"], (s["name"] or "").strip().lower())] = s["id"]

    plan, errors = [], 0
    for i, row in enumerate(raw_rows, start=2):        # row 1 is the header
        out = {"row": i, "client": col(row, "client"), "branch": col(row, "branch"),
               "action": "skip", "problems": []}
        if not out["client"] and not out["branch"]:
            continue                                    # blank line in the sheet
        cid = clients.get(out["client"].lower())
        if not cid:
            out["problems"].append("no such customer")
        if not out["branch"]:
            out["problems"].append("branch name is missing")
        fields = {}
        area_txt = col(row, "area")
        if area_txt:
            aid = areas.get(area_txt.lower())
            if not aid:
                out["problems"].append(f"no area called '{area_txt}'")
            else:
                fields["area_id"] = aid
        try:
            for key, name in (("from", "service_from"), ("to", "service_to")):
                val = col(row, key) or col(row, name)
                if val:
                    fields[name] = _shift_time(val, name)
            # A sheet written before the field became monthly still says
            # `visits_per_week`, and the office keeps those files. Read it, and
            # multiply — four weeks to the month — rather than importing a
            # branch on one a week as one a month and starving it.
            if col(row, "visits_per_month"):
                fields["visits_per_month"] = _visits_per_month(col(row, "visits_per_month"))
                fields["freq_unit"] = "month"
            elif col(row, "visits_per_week"):
                fields["visits_per_month"] = _visits_per_month(
                    _visits_per_week_number(col(row, "visits_per_week")) * WEEKS_PER_MONTH)
                fields["freq_unit"] = "week"     # read it back in the unit it was written in
            if col(row, "visit_minutes"):
                fields["visit_minutes"] = _visit_minutes(col(row, "visit_minutes"))
            if col(row, "lat") or col(row, "lng"):
                fields["lat"], fields["lng"] = _coerce_latlng(
                    {"lat": col(row, "lat"), "lng": col(row, "lng")})
        except ApiError as e:
            out["problems"].append(e.message if hasattr(e, "message") else str(e))
        try:
            days = _import_days(col(row, "days"))
        except ValueError as e:
            out["problems"].append(str(e))
            days = None
        if out["problems"]:
            errors += 1
        else:
            sid = existing.get((cid, out["branch"].lower()))
            out["action"] = "update" if sid else "create"
            out["site_id"] = sid
        out["_cid"], out["_fields"], out["_days"] = cid, fields, days
        plan.append(out)

    summary = {"rows": len(plan), "create": sum(1 for p in plan if p["action"] == "create"),
               "update": sum(1 for p in plan if p["action"] == "update"), "problems": errors}
    public = [{k: v for k, v in p.items() if not k.startswith("_")} for p in plan]
    if not ctx.body.get("apply"):
        return {"applied": False, "summary": summary, "rows": public,
                "columns": list(IMPORT_COLUMNS)}
    if errors:
        raise ApiError(400, f"{errors} row(s) have problems — nothing was imported")
    made = touched = 0
    with db.transaction() as cx:
        for p in plan:
            f = p["_fields"]
            if p["action"] == "create":
                cur = cx.execute(
                    "INSERT INTO sites(client_id,name,area_id,service_from,service_to,"
                    "visits_per_month,freq_unit,visit_minutes,lat,lng) "
                    "VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (p["_cid"], p["branch"], f.get("area_id"), f.get("service_from"),
                     f.get("service_to"), f.get("visits_per_month", 0),
                     f.get("freq_unit", "week"),
                     f.get("visit_minutes"), f.get("lat"), f.get("lng")))
                sid = cur.lastrowid
                made += 1
            else:
                sid = p["site_id"]
                if f:
                    sets = ",".join(f"{k}=?" for k in f)
                    cx.execute(f"UPDATE sites SET {sets} WHERE id=?", [*f.values(), sid])
                touched += 1
            if p["_days"] is not None:
                _set_service_days(cx, sid, [(w, None, None, None) for w in p["_days"]])
    audit(ctx, "branches.import", "site", None, f"{made} created, {touched} updated")
    return {"applied": True, "summary": summary, "created": made, "updated": touched}


@route("GET", r"/api/cost-to-serve")
def cost_to_serve(ctx):
    """What each customer and branch actually costs to service, against what
    they pay.

    Every piece of this was already being collected and none of it was ever put
    beside the money: hours from the field's own check-in stamps, materials from
    the visit's chemical usage at their real unit cost, transport from the
    entries the engineer files, pocket money from the approved claims. The one
    number that has to be supplied is what an engineer-hour costs the company.

    Deliberately NOT a profit figure for the accounts — overheads are not
    allocated here. It answers a narrower and more useful question: which
    customers take more to serve than they pay for."""
    require_perm(ctx.user, "analytics.view")
    require_perm(ctx.user, "invoices.view")          # it is a money screen
    default_from = (db.query("SELECT date('now','localtime','-12 month') d", one=True) or {}).get("d")
    rng = (_shift_date(ctx.query.get("from") or default_from, "from"),
           _shift_date(ctx.query.get("to") or _today(), "to"))
    rate = _setting_num("labour_hourly_cost", 0, 0, 100000)

    rows = {}
    def bucket(site_id, client_id, name_en, name_ar, site_name):
        key = site_id or f"c{client_id}"
        if key not in rows:
            rows[key] = {"site_id": site_id, "client_id": client_id,
                         "client_en": name_en, "client_ar": name_ar,
                         "site_name": site_name, "visits": 0, "hours": 0.0,
                         "labour": 0.0, "materials": 0.0, "transport": 0.0,
                         "cash": 0.0, "revenue": 0.0}
        return rows[key]

    for r in db.query(
            f"SELECT v.site_id, v.client_id, c.name_en, c.name_ar, s.name site_name, "
            f"COUNT(*) n, SUM({_VISIT_HOURS}) hrs FROM visits v "
            f"JOIN clients c ON c.id=v.client_id LEFT JOIN sites s ON s.id=v.site_id "
            f"WHERE v.status='completed' AND date(v.scheduled_start) BETWEEN date(?) AND date(?) "
            f"GROUP BY v.site_id, v.client_id", rng):
        row = bucket(r["site_id"], r["client_id"], r["name_en"], r["name_ar"], r["site_name"])
        row["visits"] += r["n"]
        row["hours"] += round(r["hrs"] or 0, 2)
        row["labour"] += round((r["hrs"] or 0) * rate, 2)
    # Materials at what they actually cost to buy, not what they were sold for.
    for r in db.query(
            "SELECT v.site_id, v.client_id, c.name_en, c.name_ar, s.name site_name, "
            "SUM(cu.quantity * COALESCE(ch.cost_per_unit,0)) v FROM chemical_usage cu "
            "JOIN visits v ON v.id=cu.visit_id JOIN clients c ON c.id=v.client_id "
            "LEFT JOIN sites s ON s.id=v.site_id LEFT JOIN chemicals ch ON ch.id=cu.chemical_id "
            "WHERE date(v.scheduled_start) BETWEEN date(?) AND date(?) "
            "GROUP BY v.site_id, v.client_id", rng):
        bucket(r["site_id"], r["client_id"], r["name_en"], r["name_ar"],
               r["site_name"])["materials"] += round(r["v"] or 0, 2)
    for r in db.query(
            "SELECT v.site_id, v.client_id, c.name_en, c.name_ar, s.name site_name, "
            "SUM(te.cost) v FROM transport_entries te JOIN visits v ON v.id=te.visit_id "
            "JOIN clients c ON c.id=v.client_id LEFT JOIN sites s ON s.id=v.site_id "
            "WHERE date(v.scheduled_start) BETWEEN date(?) AND date(?) "
            "GROUP BY v.site_id, v.client_id", rng):
        bucket(r["site_id"], r["client_id"], r["name_en"], r["name_ar"],
               r["site_name"])["transport"] += round(r["v"] or 0, 2)
    for r in db.query(
            "SELECT v.site_id, v.client_id, c.name_en, c.name_ar, s.name site_name, "
            "SUM(p.amount) v FROM petty_cash p JOIN visits v ON v.id=p.visit_id "
            "JOIN clients c ON c.id=v.client_id LEFT JOIN sites s ON s.id=v.site_id "
            "WHERE p.kind='expense' AND p.status='approved' "
            "AND date(v.scheduled_start) BETWEEN date(?) AND date(?) "
            "GROUP BY v.site_id, v.client_id", rng):
        bucket(r["site_id"], r["client_id"], r["name_en"], r["name_ar"],
               r["site_name"])["cash"] += round(r["v"] or 0, 2)
    # What they paid: invoices raised in the window, cancelled ones excluded.
    for r in db.query(
            "SELECT i.site_id, i.client_id, c.name_en, c.name_ar, s.name site_name, "
            "SUM(i.total) v FROM invoices i JOIN clients c ON c.id=i.client_id "
            "LEFT JOIN sites s ON s.id=i.site_id "
            "WHERE i.doc_type='invoice' AND i.status<>'cancelled' "
            "AND date(i.issue_date) BETWEEN date(?) AND date(?) "
            "GROUP BY i.site_id, i.client_id", rng):
        bucket(r["site_id"], r["client_id"], r["name_en"], r["name_ar"],
               r["site_name"])["revenue"] += round(r["v"] or 0, 2)

    out = []
    for row in rows.values():
        row["cost"] = round(row["labour"] + row["materials"] + row["transport"] + row["cash"], 2)
        row["margin"] = round(row["revenue"] - row["cost"], 2)
        row["cost_per_visit"] = round(row["cost"] / row["visits"], 2) if row["visits"] else 0
        out.append(row)
    out.sort(key=lambda r: r["margin"])
    losing = [r for r in out if r["revenue"] > 0 and r["margin"] < 0]
    return {"from": rng[0], "to": rng[1], "hourly_rate": rate, "rows": out,
            "totals": {"cost": round(sum(r["cost"] for r in out), 2),
                       "revenue": round(sum(r["revenue"] for r in out), 2),
                       "losing": len(losing),
                       # Without a rate the labour column is zero and the whole
                       # answer is misleading, so the screen is told to say so.
                       "rate_set": rate > 0}}


# --------------------------------------------------------------------------
# MISSING OWED VISITS — a branch that has quietly dropped below its cycle
# --------------------------------------------------------------------------
# The office's own scenario: Auto Roster applies the month, somebody deletes
# one future visit from the diary by hand, and nobody presses the button again.
# Before this, NOTHING changed anywhere — the Workflow board, the SLA strip,
# the branch board and the run strip all read exactly the same, and the delete
# left no audit row either. The branch was simply a visit short and no screen
# said so.
#
# So this COUNTS, and does nothing else. It never runs the planner, never
# creates a replacement visit and never touches a frequency. The line clears
# itself the moment the count comes back up — by a manual booking or by the
# next Auto Roster — the same way the unplaced worklist already clears itself.


def _months_in_play():
    """The calendar months it is fair to check, newest last.

    A month NOBODY HAS PLANNED is not a month full of gaps. Until the roster
    has covered it, every branch in the book is "short" — 179 lines of noise on
    the day this shipped. So a month counts only once standing roster runs
    (an undone one has no claim on anything) cover EVERY DAY of it, and only
    from the current month forward: a month that has ended is history, and the
    visit cannot be put back into it.
    """
    today = _dt_mod.date.today()
    spans = []
    for r in db.query("SELECT from_date, to_date FROM roster_runs "
                      "WHERE undone_at IS NULL AND from_date IS NOT NULL "
                      "AND to_date IS NOT NULL"):
        spans.append((str(r["from_date"])[:10], str(r["to_date"])[:10]))
    if not spans:
        return []
    # Merge them first: the office plans 1-15 and then 16-30, and between them
    # they have covered the month even though neither did alone.
    spans.sort()
    merged = [list(spans[0])]
    for lo, hi in spans[1:]:
        prev = merged[-1]
        # Touching counts as joined — the 15th and the 16th leave no hole.
        if lo <= (_dt_mod.date.fromisoformat(prev[1])
                  + _dt_mod.timedelta(days=1)).isoformat():
            prev[1] = max(prev[1], hi)
        else:
            merged.append([lo, hi])
    out = []
    y, m = today.year, today.month
    horizon = max(hi for _, hi in merged)
    while _dt_mod.date(y, m, 1).isoformat() <= horizon:
        first = _dt_mod.date(y, m, 1).isoformat()
        last = _dt_mod.date(y, m, roster.days_in_month(y, m)).isoformat()
        if any(lo <= first and hi >= last for lo, hi in merged):
            out.append(f"{y:04d}-{m:02d}")
        y, m = (y + 1, 1) if m == 12 else (y, m + 1)
    return out


# What counts as a visit the branch has been given. A CANCELLED visit is a gap
# and belongs in the warning; a COMPLETED one is the work itself and must never
# read as missing — see the same list in roster.load_book.
_DELIVERED = ("scheduled", "in_progress", "completed")


def _month_visit_counts(year, month):
    """{site_id: visits} for one calendar month, counted by the date of the
    ROUND rather than the date on the timestamp.

    A branch open 00:00-07:00 is night work and its last round of the month is
    written onto the FIRST of the next one. On the real book two branches look
    a visit short by exactly this — Al Beiruti Arkan Plaza and 1980 Central
    kitchen — and counting raw dates would put a permanent, untrue warning on
    both, and call October over-serviced into the bargain. `_night_tail_ids` is
    the Clear-Schedule guard's own answer to the same question, so the warning
    and the clear cannot disagree about which month a stop belongs to.
    """
    first = _dt_mod.date(year, month, 1).isoformat()
    last = _dt_mod.date(year, month, roster.days_in_month(year, month)).isoformat()
    extra, excluded = _night_tail_ids(first, last)
    marks = ",".join("?" * len(_DELIVERED))
    counts = {}
    for r in db.query(
            f"SELECT id, site_id FROM visits WHERE site_id IS NOT NULL "
            f"AND status IN ({marks}) AND date(scheduled_start) BETWEEN ? AND ?",
            (*_DELIVERED, first, last)):
        if r["id"] in excluded:
            continue                    # the 1st's stop that belongs to last month
        counts[r["site_id"]] = counts.get(r["site_id"], 0) + 1
    if extra:
        ids = ",".join("?" * len(extra))
        for r in db.query(
                f"SELECT site_id FROM visits WHERE site_id IS NOT NULL "
                f"AND status IN ({marks}) AND id IN ({ids})",
                (*_DELIVERED, *sorted(extra))):
            counts[r["site_id"]] = counts.get(r["site_id"], 0) + 1
    return counts


def _gap_branches():
    """The branches the planner itself would plan — the SAME filter as
    roster.load_book, so nothing is warned about that the cycle never owed."""
    return db.query(
        "SELECT s.id, s.name, s.client_id, s.area_id, s.visits_per_month, s.freq_unit, "
        "c.name_en client_en, c.name_ar client_ar, "
        "a.name_en area_en, a.name_ar area_ar "
        "FROM sites s JOIN clients c ON c.id=s.client_id "
        "LEFT JOIN areas a ON a.id=s.area_id "
        "WHERE s.visits_per_month > 0 AND s.area_id IS NOT NULL "
        "AND s.status='active' AND c.status='active' ORDER BY c.name_en, s.name")


def _service_gaps(month=None, user=None):
    """Every branch below its owed number, in every month worth checking.

    The owed number comes from `roster.owed_in_month` — the planner's own
    function, reading the branch's own unit — so the warning and the button can
    never disagree about what a contract is worth.
    """
    months = _months_in_play()
    if month:
        months = [m for m in months if m == month]
    # A MANAGER IS WARNED ABOUT THEIR OWN PATCH AND NOBODY ELSE'S — the same
    # fail-closed rule the unplaced worklist follows, because a line here names
    # a customer.
    scope = (set(area_manager_area_ids(user)) if user and user["role"] == "area_manager"
             else set() if user and user["role"] in SUPERVISOR_ROLES else None)
    branches = _gap_branches()
    items = []
    for key in months:
        y, m = int(key[:4]), int(key[5:7])
        counts = _month_visit_counts(y, m)
        for b in branches:
            if scope is not None and b["area_id"] not in scope:
                continue
            owed = roster.owed_in_month(
                b["visits_per_month"], b["freq_unit"] or "month", y, m,
                offset=b["id"] % roster.WEEKS_PER_MONTH)
            got = counts.get(b["id"], 0)
            if got >= owed:
                continue
            items.append({
                "site_id": b["id"], "site_name": b["name"],
                "client_id": b["client_id"], "client_en": b["client_en"],
                "client_ar": b["client_ar"], "area_id": b["area_id"],
                "area_en": b["area_en"], "area_ar": b["area_ar"],
                "month": key, "owed": owed, "scheduled": got,
                "missing": owed - got})
    items.sort(key=lambda r: (r["month"], -r["missing"], r["site_name"] or ""))
    return {"months": months, "month": month, "items": items,
            "branches": len({r["site_id"] for r in items}),
            "missing_visits": sum(r["missing"] for r in items)}


@route("GET", r"/api/service-gaps")
def service_gaps(ctx):
    """Branches that have dropped below their owed count for a month, as a
    worklist. `?month=YYYY-MM` narrows it to one.

    Detection only: nothing here plans, books or changes a frequency. Each row
    carries what it takes to act — the branch, the customer, the patch, the
    month, and "3 of 4" in the planner's own numbers — and disappears of its own
    accord once the visit is back on the book."""
    # A customer holds visits.view for their own portal; this is the company's
    # own workboard, the same gate the Workflow board uses.
    if ctx.user["role"] == "client":
        raise ApiError(403, "You do not have permission for this action")
    require_perm(ctx.user, "visits.view")
    month = (ctx.query.get("month") or "").strip() or None
    if month and not re.fullmatch(r"\d{4}-\d{2}", month):
        raise ApiError(400, "Month must be YYYY-MM")
    return _service_gaps(month, ctx.user)


@route("GET", r"/api/pipeline")
def pipeline_board(ctx):
    """Where work is stuck, across the whole CRM, on one screen.

    Every module can already answer its own question; nobody could ask them all
    at once, so a quote nobody chased and a completed visit nobody billed both
    sit there indefinitely. These are the joins between modules — the places
    work stops moving — counted in the order the work actually flows.

    Money counts are withheld from anyone without invoices.view (a team leader
    sees the operational stalls on their patch and none of the finance)."""
    # A customer holds visits.view for their own portal, so the permission
    # alone is not the gate here — this is the company's own workboard.
    if ctx.user["role"] == "client":
        raise ApiError(403, "You do not have permission for this action")
    require_perm(ctx.user, "visits.view")
    money = has_perm(ctx.user, "invoices.view")
    one = lambda sql, p=(): (db.query(sql, p, one=True) or {}).get("n") or 0
    # A supervisor's board is their own patch or crew; everyone else sees the company.
    # The clause carries no leading AND, so it is spliced with one here.
    clause, params = _sup_visit_clause(ctx.user, "v")
    lead_c, lead_p = (f" AND {clause}", params) if clause else ("", [])

    out = {
        # --- getting the work ---
        "leads_open": one("SELECT COUNT(*) n FROM leads WHERE status IN "
                          "('new','contacted','quoted')") if money else None,
        "quotes_open": one("SELECT COUNT(*) n FROM invoices WHERE doc_type='quote' "
                           "AND status='sent'") if money else None,
        # --- turning it into something serviceable ---
        "contracts_no_branch": one(
            "SELECT COUNT(*) n FROM contracts c WHERE c.status='active' "
            "AND c.site_id IS NULL AND NOT EXISTS "
            "(SELECT 1 FROM contract_sites cs WHERE cs.contract_id=c.id AND cs.site_id IS NOT NULL)"),
        "branches_no_area": one("SELECT COUNT(*) n FROM sites WHERE area_id IS NULL"
                                + _SERVICED_BRANCH),
        "branches_no_cycle": one("SELECT COUNT(*) n FROM sites WHERE area_id IS NOT NULL "
                                 "AND COALESCE(visits_per_month,0)=0" + _SERVICED_BRANCH),
        # --- doing it ---
        "requests_pending": one("SELECT COUNT(*) n FROM visit_requests WHERE status='pending'"),
        # A branch that has dropped below its owed count for a month the roster
        # has already covered — a visit deleted by hand and never replaced.
        # Counted, never fixed: see _service_gaps.
        "visits_missing_owed": _service_gaps(user=ctx.user)["missing_visits"],
        "visits_unassigned": one(
            f"SELECT COUNT(*) n FROM visits v WHERE v.status='scheduled' "
            f"AND v.agent_id IS NULL{lead_c}", lead_p),
        # --- writing it up ---
        "visits_no_report": one(
            f"SELECT COUNT(*) n FROM visits v WHERE v.status='completed' "
            f"AND NOT EXISTS (SELECT 1 FROM reports r WHERE r.visit_id=v.id){lead_c}", lead_p),
        "reports_draft": one(
            f"SELECT COUNT(*) n FROM visits v JOIN reports r ON r.visit_id=v.id "
            f"WHERE r.status='draft'{lead_c}", lead_p),
        # --- getting paid for it ---
        # A completed visit with no invoice against it and no contract behind it
        # is work given away: the contract cycle bills the rest.
        "visits_unbilled": one(
            "SELECT COUNT(*) n FROM visits v WHERE v.status='completed' "
            "AND NOT EXISTS (SELECT 1 FROM invoices i WHERE i.visit_id=v.id "
            "AND i.doc_type='invoice' AND i.status<>'cancelled') "
            "AND NOT EXISTS (SELECT 1 FROM contracts c WHERE c.client_id=v.client_id "
            "AND c.status='active')") if money else None,
        "invoices_unpaid": one("SELECT COUNT(*) n FROM invoices WHERE doc_type='invoice' "
                               "AND status IN ('sent','overdue')") if money else None,
    }
    out["money"] = money
    return out


@route("GET", r"/api/capacity")
def capacity_check(ctx):
    """Can this book actually be serviced, before anybody presses the button?

    Demand is what the branches ask for: visits a week x how long each takes,
    the week being the month they are entered in divided by four,
    plus the travel allowance per call, because getting there is work. Supply is
    the hours the engineers are available. Both are counted per AREA and per
    ZONE, because a zone is the boundary the planner will not casually cross —
    spare hours in another zone are not much help.

    Deliberately arithmetic, not a plan: it answers "is this possible" while the
    office is still typing, which is the point of asking now rather than after
    205 branches have been entered."""
    require_perm(ctx.user, "shifts.view")
    slot = _auto_slot_minutes()
    travel = _travel_config()
    # Capacity is a question about AREAS, so only the role that answers for
    # areas sees a slice of it — and a team leader, who answers for people,
    # sees none of it rather than all of it.
    scope = (area_manager_area_ids(ctx.user) if ctx.user["role"] == "area_manager"
             else [] if ctx.user["role"] == "team_leader" else None)

    areas = {a["id"]: dict(a, demand_minutes=0.0, visits=0.0, branches=0, engineers=[])
             for a in db.query("SELECT id, name_en, name_ar, zone_id FROM areas WHERE active=1")}
    for s in db.query("SELECT area_id, visits_per_month, visit_minutes FROM sites "
                      "WHERE area_id IS NOT NULL AND COALESCE(visits_per_month,0) > 0"
                      + _SERVICED_BRANCH):
        a = areas.get(s["area_id"])
        if not a:
            continue
        # The board is a WEEK against the engineers' weekly hours; the branch
        # asks in a month, so take a week's share of THIS month — 4.0 weeks in
        # February, 4.43 in a 31-day month. Quartering it always was a tenth of
        # a month of demand the board never showed in a long month.
        n = float(s["visits_per_month"] or 0) * 7.0 / _month_days_now()
        mins = _job_minutes(s, slot) + travel["flat"]
        a["visits"] += n
        a["branches"] += 1
        a["demand_minutes"] += n * mins

    # Who may work where, and how many hours a week each of them has.
    hours = {}
    for r in db.query("SELECT agent_id, start_time, end_time FROM agent_availability"):
        # Same reading as the planner's pool: blank is no limit, and a night
        # shift wraps into the next morning — all of it hours he can work.
        s_min, e_min = _avail_bounds(r["start_time"], r["end_time"])
        if e_min > s_min:
            hours[r["agent_id"]] = hours.get(r["agent_id"], 0) + (e_min - s_min)
    names = {u["id"]: u["full_name"] for u in db.query(
        "SELECT id, full_name FROM users WHERE role='agent' AND active=1")}
    for r in db.query("SELECT agent_id, area_id FROM agent_areas"):
        a = areas.get(r["area_id"])
        if a and r["agent_id"] in names:
            a["engineers"].append({"id": r["agent_id"], "full_name": names[r["agent_id"]],
                                   "minutes": hours.get(r["agent_id"], 0)})

    out_areas = []
    for a in areas.values():
        if scope is not None and a["id"] not in scope:
            continue
        out_areas.append({
            "id": a["id"], "name_en": a["name_en"], "name_ar": a["name_ar"],
            "zone_id": a["zone_id"], "branches": a["branches"],
            "visits": round(a["visits"], 2),
            "demand_hours": round(a["demand_minutes"] / 60.0, 1),
            "engineers": len(a["engineers"]),
            # An area with work and nobody allowed on it can never be served,
            # however many spare hours the company has elsewhere.
            "uncovered": a["branches"] > 0 and not a["engineers"]})
    out_areas.sort(key=lambda x: -x["demand_hours"])

    # Per zone: an engineer counts once, however many of its areas they hold.
    zones = {z["id"]: {"id": z["id"], "name_en": z["name_en"], "name_ar": z["name_ar"],
                       "demand_minutes": 0.0, "crew": {}}
             for z in db.query("SELECT id, name_en, name_ar FROM zones")}
    loose = {"id": None, "name_en": "No zone", "name_ar": "بدون نطاق",
             "demand_minutes": 0.0, "crew": {}}
    for a in areas.values():
        if scope is not None and a["id"] not in scope:
            continue
        z = zones.get(a["zone_id"], loose)
        z["demand_minutes"] += a["demand_minutes"]
        for e in a["engineers"]:
            z["crew"][e["id"]] = e["minutes"]
    out_zones = []
    for z in list(zones.values()) + [loose]:
        supply = sum(z["crew"].values())
        demand = z["demand_minutes"]
        if not demand and not supply:
            continue
        out_zones.append({
            "id": z["id"], "name_en": z["name_en"], "name_ar": z["name_ar"],
            "demand_hours": round(demand / 60.0, 1), "supply_hours": round(supply / 60.0, 1),
            "engineers": len(z["crew"]),
            "status": ("over" if demand > supply else
                       "tight" if supply and demand > supply * 0.85 else "ok")})

    total_demand = sum(a["demand_minutes"] for a in areas.values()
                       if scope is None or a["id"] in scope)
    total_supply = sum(hours.get(i, 0) for i in names
                       if scope is None or any(
                           e["id"] == i for a in areas.values()
                           if a["id"] in scope for e in a["engineers"]))
    return {"areas": out_areas, "zones": out_zones,
            "totals": {"demand_hours": round(total_demand / 60.0, 1),
                       "supply_hours": round(total_supply / 60.0, 1),
                       "slot_minutes": slot, "travel_minutes": travel["flat"]}}


@route("GET", r"/api/branch-schedule")
def branch_schedule(ctx):
    """Every branch's visiting schedule in ONE payload.

    The same shape as the engineer availability board and for the same stated
    reason: the office has 146 branches and will not open 146 dialogs to say
    when each one opens. One screen, one save."""
    require_perm(ctx.user, "clients.edit")
    allowed = _board_site_ids(ctx.user)
    rows = db.query(
        "SELECT s.id, s.name, s.client_id, s.area_id, s.service_from, s.service_to, "
        "s.visits_per_month, s.freq_unit, s.visit_minutes, s.preferred_agent_id, "
        "c.name_en client_en, c.name_ar client_ar, "
        "ar.name_en area_en, ar.name_ar area_ar "
        "FROM sites s JOIN clients c ON c.id=s.client_id "
        "LEFT JOIN areas ar ON ar.id=s.area_id "
        # The board is the roster's own screen, so it shows what the roster
        # plans: switched-off branches are managed from the Branches page.
        "WHERE c.status='active' AND s.status='active' ORDER BY c.name_en, s.name")
    if allowed is not None:
        rows = [r for r in rows if r["id"] in allowed]
    slot_default = _auto_slot_minutes()
    # What the CONTRACT says, beside what the roster is being told. A branch
    # where the two disagree is one the office can service perfectly and still
    # show as an SLA breach.
    bysite, byclient = _contracted_vpm()
    measured = _measured_minutes()
    # A branch that has dropped below its owed number for a month the roster has
    # already covered. The rows come back oldest month first, so a branch short
    # in two months shows the one being worked now.
    short = {}
    for g in _service_gaps(user=ctx.user)["items"]:
        short.setdefault(g["site_id"], g)
    for r in rows:
        got = bysite.get(r["id"]) or byclient.get(r["client_id"])
        r["contract_vpm"] = got[0] if got else None
        r["contract_freq"] = got[1] if got else None
        r["contract_unit"] = got[2] if got else None
        # LIKE FOR LIKE. Both sides are stored as a monthly figure, but they
        # only mean the same thing when they are the same RHYTHM: a branch
        # typed as a weekly one and a contract sold by the month are not in
        # disagreement about the number, they are in different units.
        r["freq_mismatch"] = bool(
            got and (abs(float(r["visits_per_month"] or 0) - got[0]) > 0.01
                     or (r.get("freq_unit") or "month") != got[2]))
        # What the branch actually takes, beside what the schedule assumes.
        m = measured.get(r["id"])
        r["measured_minutes"] = m[0] if m else None
        r["measured_visits"] = m[1] if m else 0
        r["length_mismatch"] = bool(m and abs(m[0] - _job_minutes(r, slot_default)) >= 15)
        # "Missing owed visit — 3 of 4 scheduled", on the branch's own row.
        g = short.get(r["id"])
        r["gap_month"] = g["month"] if g else None
        r["gap_owed"] = g["owed"] if g else None
        r["gap_scheduled"] = g["scheduled"] if g else None
        r["gap_missing"] = g["missing"] if g else 0
    return {"branches": _attach_service_days(rows),
            # So the length column can show what a branch that says nothing
            # will actually get, rather than an empty box.
            "slot_minutes": _auto_slot_minutes(),
            # The engineers a branch may be given to. Engineers only — see
            # `_preferred_agent`; naming anybody else would make a branch the
            # planner could hand to nobody.
            "engineers": db.query("SELECT id, full_name FROM users "
                                  "WHERE role='agent' AND active=1 ORDER BY full_name"),
            "areas": db.query("SELECT * FROM areas WHERE active=1 ORDER BY sort_order, name_en")}


@route("PUT", r"/api/branch-schedule")
def save_branch_schedule(ctx):
    """Save the whole board at once. The page sends only the branches it
    actually changed, so a save of two edits does not rewrite 146 rows."""
    require_perm(ctx.user, "clients.edit")
    allowed = _board_site_ids(ctx.user)
    rows = ctx.body.get("branches")
    if not isinstance(rows, list):
        raise ApiError(400, "Expected a list of branches")
    # Validate EVERYTHING before writing anything: a bulk save that half-applied
    # would leave the office with no idea which branches took.
    plan = []
    for r in rows:
        try:
            sid = int(r.get("id"))
        except (TypeError, ValueError):
            raise ApiError(400, "Invalid branch")
        if allowed is not None and sid not in allowed:
            raise ApiError(403, "That branch is not in your areas")
        fields, vals = [], []
        if "area_id" in r:
            fields.append("area_id=?"); vals.append(_coerce_area_id(r["area_id"]))
        for col in ("service_from", "service_to"):
            if col in r:
                fields.append(f"{col}=?"); vals.append(_shift_time(r[col], col))
        vpm = _body_visits_per_month(r)
        if vpm is not None:
            fields.append("visits_per_month=?"); vals.append(vpm)
        unit = _freq_unit(r.get("freq_unit"))
        if unit:
            fields.append("freq_unit=?"); vals.append(unit)
        if "visit_minutes" in r:
            fields.append("visit_minutes=?"); vals.append(_visit_minutes(r["visit_minutes"]))
        if "preferred_agent_id" in r:
            fields.append("preferred_agent_id=?")
            vals.append(_preferred_agent(r["preferred_agent_id"]))
        days = _service_days(r["service_days"]) if "service_days" in r else None
        plan.append((sid, fields, vals, days))
    saved = 0
    with db.transaction() as cx:
        for sid, fields, vals, days in plan:
            if fields:
                cx.execute(f"UPDATE sites SET {','.join(fields)} WHERE id=?", [*vals, sid])
            if days is not None:
                _set_service_days(cx, sid, days)
            saved += 1
    audit(ctx, "branch.schedule", "site", None, f"{saved} branch(es)")
    return {"ok": True, "saved": saved}


@route("POST", r"/api/clients/(\d+)/sites")
def add_site(ctx):
    require_perm(ctx.user, "clients.edit")
    cid = int(ctx.params[0])
    b = ctx.body
    if not b.get("name"):
        raise ApiError(400, "Site name is required")
    lat, lng = _coerce_latlng(b)
    days = _service_days(b.get("service_days"))
    with db.transaction() as cx:
        cur = cx.execute(
            "INSERT INTO sites(client_id,name,address,area,area_id,lat,lng,map_url,"
            "service_from,service_to,visits_per_month,freq_unit,visit_minutes,"
            "preferred_agent_id) "
            "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (cid, b["name"], b.get("address"), b.get("area"),
             _coerce_area_id(b.get("area_id")), lat, lng, _map_url(b),
             _shift_time(b.get("service_from"), "service_from"),
             _shift_time(b.get("service_to"), "service_to"),
             _body_visits_per_month(b) or 0,
             # The board asks in visits a MONTH now — the office took the week
             # option away — so a branch that says nothing is a monthly one.
             _freq_unit(b.get("freq_unit")) or "month",
             _visit_minutes(b.get("visit_minutes")),
             _preferred_agent(b.get("preferred_agent_id"))))
        sid = cur.lastrowid
        _set_service_days(cx, sid, days)
    return _attach_service_days(db.query("SELECT * FROM sites WHERE id=?", (sid,), one=True))


@route("PUT", r"/api/sites/(\d+)")
def update_site(ctx):
    require_perm(ctx.user, "clients.edit")
    sid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM sites WHERE id=?", (sid,), one=True):
        raise ApiError(404, "Site not found")
    b = ctx.body
    fields, vals = [], []
    for col in ("name", "address", "area"):
        if col in b:
            fields.append(f"{col}=?"); vals.append(b[col])
    if "status" in b:
        fields.append("status=?"); vals.append(_status_value(b["status"]))
    if "area_id" in b:
        fields.append("area_id=?"); vals.append(_coerce_area_id(b["area_id"]))
    if "lat" in b or "lng" in b or "geo" in b:
        lat, lng = _coerce_latlng(b)
        fields += ["lat=?", "lng=?"]; vals += [lat, lng]
    if "map_url" in b or "geo" in b:
        fields.append("map_url=?"); vals.append(_map_url(b))
    # When this branch will take a visit, and how often it needs one — the two
    # facts the automatic scheduler reads besides the area.
    for col in ("service_from", "service_to"):
        if col in b:
            fields.append(f"{col}=?"); vals.append(_shift_time(b[col], col))
    vpm = _body_visits_per_month(b)
    if vpm is not None:
        fields.append("visits_per_month=?"); vals.append(vpm)
    unit = _freq_unit(b.get("freq_unit"))
    if unit:
        fields.append("freq_unit=?"); vals.append(unit)
    if "visit_minutes" in b:
        fields.append("visit_minutes=?"); vals.append(_visit_minutes(b["visit_minutes"]))
    if "preferred_agent_id" in b:
        fields.append("preferred_agent_id=?")
        vals.append(_preferred_agent(b["preferred_agent_id"]))
    # Which days it opens: absent leaves them alone, present replaces the set —
    # and an empty list is a real instruction ("no fixed days"), not a no-op.
    sets_days = "service_days" in b
    days = _service_days(b.get("service_days")) if sets_days else []
    if not fields and not sets_days:
        raise ApiError(400, "Nothing to update")
    with db.transaction() as cx:
        if fields:
            cx.execute(f"UPDATE sites SET {','.join(fields)} WHERE id=?", [*vals, sid])
        if sets_days:
            _set_service_days(cx, sid, days)
    return _attach_service_days(db.query("SELECT * FROM sites WHERE id=?", (sid,), one=True))


@route("DELETE", r"/api/sites/(\d+)")
def delete_site(ctx):
    require_perm(ctx.user, "clients.edit")
    db.execute("DELETE FROM sites WHERE id=?", (int(ctx.params[0]),))
    return {"ok": True}


@route("POST", r"/api/sites/(\d+)/map")
def upload_site_map(ctx):
    """Upload (or replace) the map / floor plan for a site.

    A PDF is as valid here as a picture: site plans arrive from the customer as
    PDFs, and nothing is drawn on top of this file (device markers live on the
    `maps` table), so it can be stored as-is and opened in the CRM's own viewer.
    """
    require_perm(ctx.user, "clients.edit")
    sid = int(ctx.params[0])
    site = db.query("SELECT * FROM sites WHERE id=?", (sid,), one=True)
    if not site:
        raise ApiError(404, "Site not found")
    _fields, files = parse_multipart(ctx.raw_body, ctx.content_type)
    if not files:
        raise ApiError(400, "No file uploaded")
    f = files[0]
    ext = _validate_library_upload(f)
    fname = f"sitemap_{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(f["data"])
    # remove the previous image file, if any
    if site.get("map_image"):
        try:
            os.remove(os.path.join(UPLOAD_DIR, site["map_image"]))
        except OSError:
            pass
    db.execute("UPDATE sites SET map_image=? WHERE id=?", (fname, sid))
    return db.query("SELECT * FROM sites WHERE id=?", (sid,), one=True)


@route("DELETE", r"/api/sites/(\d+)/map")
def delete_site_map(ctx):
    require_perm(ctx.user, "clients.edit")
    sid = int(ctx.params[0])
    site = db.query("SELECT * FROM sites WHERE id=?", (sid,), one=True)
    if site and site.get("map_image"):
        try:
            os.remove(os.path.join(UPLOAD_DIR, site["map_image"]))
        except OSError:
            pass
    db.execute("UPDATE sites SET map_image=NULL WHERE id=?", (sid,))
    return {"ok": True}


# --------------------------------------------------------------------------
# SERVICE TYPES
# --------------------------------------------------------------------------
@route("GET", r"/api/service-types")
def list_service_types(ctx):
    return db.query("SELECT * FROM service_types ORDER BY name_en")


@route("POST", r"/api/service-types")
def create_service_type(ctx):
    require_perm(ctx.user, "settings.edit")
    b = ctx.body
    if not b.get("name_en"):
        raise ApiError(400, "Name is required")
    sid = db.execute("INSERT INTO service_types(name_en,name_ar) VALUES(?,?)",
                     (b["name_en"], b.get("name_ar")))
    return db.query("SELECT * FROM service_types WHERE id=?", (sid,), one=True)


# --------------------------------------------------------------------------
# VISITS & SCHEDULE
# --------------------------------------------------------------------------
@route("GET", r"/api/visits")
def list_visits(ctx):
    u = ctx.user
    require_perm(u, "visits.view")
    where, params = [], []
    if u["role"] == "client":
        where.append("v.client_id=?")
        params.append(u["client_id"])
        sid = client_site_scope_id(u)
        if sid:
            where.append("(v.site_id IS NULL OR v.site_id=?)")
            params.append(sid)
    elif u["role"] == "agent":
        where.append("v.agent_id=?")
        params.append(u["id"])
    elif u["role"] in SUPERVISOR_ROLES:
        lc, lp = _sup_visit_clause(u)
        where.append(lc); params += lp
    for key, col in (("client", "v.client_id"), ("agent", "v.agent_id"),
                     ("status", "v.status")):
        if ctx.query.get(key):
            where.append(f"{col}=?")
            params.append(ctx.query[key])
    if ctx.query.get("from"):
        where.append("date(v.scheduled_start) >= date(?)")
        params.append(ctx.query["from"])
    if ctx.query.get("to"):
        where.append("date(v.scheduled_start) <= date(?)")
        params.append(ctx.query["to"])
    sql = ("SELECT v.*, c.name_en client_en, c.name_ar client_ar, "
           "s.name_en service_en, s.name_ar service_ar, u.full_name agent_name, st.name site_name, "
           "st.lat site_lat, st.lng site_lng, " + VISIT_AREA_SQL + ", " + VISIT_NO_SQL + ", "
           "EXISTS(SELECT 1 FROM reports r WHERE r.visit_id=v.id AND r.status='complete') has_report "
           "FROM visits v JOIN clients c ON c.id=v.client_id "
           "LEFT JOIN service_types s ON s.id=v.service_type_id "
           "LEFT JOIN sites st ON st.id=v.site_id "
           "LEFT JOIN users u ON u.id=v.agent_id" + VISIT_AREA_JOIN)
    if where:
        sql += " WHERE " + " AND ".join(where)
    _sd = _sort_dir(ctx)
    res = _paginate(ctx, sql, params, f"ORDER BY v.scheduled_start {_sd}, v.id {_sd}")
    _apply_visit_no(res["items"] if isinstance(res, dict) else res)
    # GPS check-in data is staff-only.
    if u["role"] == "client":
        for r in (res["items"] if isinstance(res, dict) else res):
            for k in CHECKIN_COLS:
                r.pop(k, None)
    return res


# ---- Visit No. (month) ------------------------------------------------------
# The number a report and a certificate carry: which visit of the calendar month
# this is for that client AND that location. It is DERIVED, never typed and never
# stored — an engineer cannot get it wrong, a reschedule or a cancellation
# re-numbers the month by itself, and the count starts again at 1 on the 1st.
# A cancelled visit and a visit with no date take no number at all.
# The stored visits.visit_number column is legacy and no longer read or written.
VISIT_NO_SQL = (
    "CASE WHEN v.scheduled_start IS NULL OR v.status='cancelled' THEN NULL ELSE ("
    " SELECT COUNT(*) FROM visits x"
    " WHERE x.client_id=v.client_id"
    "   AND IFNULL(x.site_id,-1)=IFNULL(v.site_id,-1)"
    "   AND x.status<>'cancelled' AND x.scheduled_start IS NOT NULL"
    "   AND strftime('%Y-%m',x.scheduled_start)=strftime('%Y-%m',v.scheduled_start)"
    "   AND (x.scheduled_start<v.scheduled_start"
    "        OR (x.scheduled_start=v.scheduled_start AND x.id<=v.id))"
    ") END AS visit_no_auto")


# A visit's area is its branch's; a client with no branches falls back to the
# one set on the client, so dispatch always has something to compare against.
VISIT_AREA_SQL = ("COALESCE(st.area_id, c.area_id) AS area_id, "
                  "COALESCE(va.name_en, ca.name_en) AS area_en, "
                  "COALESCE(va.name_ar, ca.name_ar) AS area_ar")
VISIT_AREA_JOIN = (" LEFT JOIN areas va ON va.id=st.area_id"
                   " LEFT JOIN areas ca ON ca.id=c.area_id")


def _apply_visit_no(rows):
    """Move the derived number onto visit_number, so every caller (visit page,
    certificate, follow-up report, audit pack) reads the same field it always
    did — the value behind it is now computed rather than hand-entered."""
    for r in (rows if isinstance(rows, list) else [rows]):
        if r is not None and "visit_no_auto" in r:
            r["visit_number"] = r.pop("visit_no_auto")
    return rows


@route("GET", r"/api/visits/(\d+)")
def get_visit(ctx):
    vid = int(ctx.params[0])
    v = db.query(
        "SELECT v.*, c.name_en client_en, c.name_ar client_ar, c.id client_id, "
        "s.name_en service_en, s.name_ar service_ar, u.full_name agent_name, "
        "st.name site_name, st.map_image site_map_image, "
        "st.lat site_lat, st.lng site_lng, " + VISIT_AREA_SQL + ", " + VISIT_NO_SQL + " "
        "FROM visits v JOIN clients c ON c.id=v.client_id "
        "LEFT JOIN service_types s ON s.id=v.service_type_id "
        "LEFT JOIN users u ON u.id=v.agent_id "
        "LEFT JOIN sites st ON st.id=v.site_id" + VISIT_AREA_JOIN +
        " WHERE v.id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    require_perm(ctx.user, "visits.view")
    _assert_visit_access(ctx.user, v)
    _apply_visit_no(v)
    v["report"] = db.query("SELECT * FROM reports WHERE visit_id=?", (vid,), one=True)
    # Clients only ever see a finished report — a draft is still being worked on.
    if ctx.user["role"] == "client" and v["report"] and v["report"]["status"] != "complete":
        v["report"] = None
    # Transportation invoice and GPS check-in data are internal: never sent
    # to client accounts.
    if ctx.user["role"] == "client":
        if v["report"]:
            for k in ("transport_vehicle", "transport_cost"):
                v["report"].pop(k, None)
        # The GPS fix stays internal, but the two TIMESTAMPS do not: the printed
        # report says when the engineer started and finished, and the customer
        # prints that same report from the portal, so the times have to survive.
        for k in CHECKIN_GPS_COLS:
            v.pop(k, None)
    else:
        v["transport"] = db.query(
            "SELECT * FROM transport_entries WHERE visit_id=? ORDER BY id", (vid,))
    v["rating"] = db.query("SELECT stars, comment, created_at FROM visit_ratings "
                           "WHERE visit_id=?", (vid,), one=True)
    v["chemicals"] = db.query(
        "SELECT cu.*, ch.name_en, ch.name_ar, ch.unit FROM chemical_usage cu "
        "JOIN chemicals ch ON ch.id=cu.chemical_id WHERE cu.visit_id=?", (vid,))
    v["photos"] = db.query(
        "SELECT * FROM photos WHERE entity_type='visit' AND entity_id=? ORDER BY uploaded_at DESC", (vid,))
    if v["report"]:
        v["report_photos"] = db.query(
            "SELECT * FROM photos WHERE entity_type='report' AND entity_id=? ORDER BY uploaded_at DESC",
            (v["report"]["id"],))
    else:
        v["report_photos"] = []
    # Optional auto-translation of the report text for display/printing.
    if ctx.query.get("lang") in ("en", "ar"):
        _translate_report(v["report"], ctx.query["lang"])
    return v


def _visit_conflict(agent_id, start, end, exclude_vid=None):
    """The agent's overlapping scheduled/in_progress visit, if any. Visits with
    no scheduled_end are assumed to run 60 minutes (back-to-back hourly slots
    therefore do NOT clash)."""
    if not agent_id or not start:
        return None
    q = ("SELECT v.id, v.scheduled_start, c.name_en client FROM visits v "
         "JOIN clients c ON c.id=v.client_id "
         "WHERE v.agent_id=? AND v.status IN ('scheduled','in_progress') "
         "AND datetime(v.scheduled_start) < datetime(?) "
         "AND datetime(COALESCE(v.scheduled_end, datetime(v.scheduled_start,'+60 minutes')))"
         " > datetime(?)")
    params = [agent_id, end or start, start]
    if not end:   # compare against the new visit's assumed 60-minute window
        q = q.replace("datetime(?) ", "datetime(?,'+60 minutes') ", 1)
    if exclude_vid:
        q += " AND v.id!=?"
        params.append(exclude_vid)
    return db.query(q, params, one=True)


def _check_visit_conflict(b, merged, exclude_vid=None):
    """Raise 409 when the (merged) visit double-books its agent, unless the
    caller confirmed with ignore_conflict."""
    if b.get("ignore_conflict"):
        return
    cf = _visit_conflict(merged.get("agent_id"), merged.get("scheduled_start"),
                         merged.get("scheduled_end"), exclude_vid)
    if cf:
        raise ApiError(409, f"agent_busy|{cf['client']}|{cf['scheduled_start']}")


def _contract_for_client(raw, client_id):
    """Validate a contract_id supplied for one of that client's visits or
    invoices. Blank means ad-hoc work, which is charged to the customer but to
    no deal — that is a legitimate answer, not a missing field."""
    if raw in (None, "", "0", 0):
        return None
    try:
        cid = int(raw)
    except (TypeError, ValueError):
        raise ApiError(400, "Invalid contract")
    row = db.query("SELECT client_id FROM contracts WHERE id=?", (cid,), one=True)
    if not row:
        raise ApiError(404, "Contract not found")
    if int(row["client_id"]) != int(client_id):
        raise ApiError(400, "That contract belongs to another client")
    return cid


@route("POST", r"/api/visits")
def create_visit(ctx):
    require_perm(ctx.user, "visits.create")
    b = ctx.body
    if not b.get("client_id") or not b.get("scheduled_start"):
        raise ApiError(400, "Client and scheduled date are required")
    _check_visit_conflict(b, b)
    # If the client has locations defined, a visit must be assigned to one so its
    # report rolls up to the right location.
    if not b.get("site_id"):
        has_sites = db.query("SELECT 1 FROM sites WHERE client_id=? LIMIT 1", (b["client_id"],), one=True)
        if has_sites:
            raise ApiError(400, "Please choose a branch for this visit")
    # visit_number is not stored: it is the visit's position in its month and is
    # derived on read (see VISIT_NO_SQL), so any value sent here is ignored.
    vid = db.execute(
        "INSERT INTO visits(client_id,site_id,agent_id,service_type_id,contract_id,scheduled_start,"
        "scheduled_end,status,location,notes) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (b["client_id"], b.get("site_id"), b.get("agent_id"), b.get("service_type_id"),
         _contract_for_client(b.get("contract_id"), b["client_id"]),
         b["scheduled_start"], b.get("scheduled_end"), b.get("status", "scheduled"),
         b.get("location"), b.get("notes")))
    return db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)


# A year of weekly visits is 52 rows; the cap is generous but stops a typo'd
# schedule from filling the calendar.
MAX_BATCH_VISITS = 200
_DT_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?$")


def _visit_end(start, minutes):
    """start + duration as 'YYYY-MM-DDTHH:MM'; None when no duration given."""
    import datetime
    if not minutes:
        return None
    try:
        dt = datetime.datetime.strptime(start.replace("T", " ")[:16], "%Y-%m-%d %H:%M")
    except ValueError:
        return None
    return (dt + datetime.timedelta(minutes=minutes)).strftime("%Y-%m-%dT%H:%M")


@route("POST", r"/api/visits/batch")
def create_visits_batch(ctx):
    """Book the same visit on several dates at once — the office schedules a
    whole month/quarter/year of a recurring slot in one go. The caller sends the
    exact list of start times (the SPA expands the "every Sunday until…" choice
    into them), so this stays a plain "create these visits" call.

    Overlaps with the agent's existing work are NOT refused: they are created
    and listed back in `conflicts`, so a year's schedule never comes back with
    silent holes in it."""
    require_perm(ctx.user, "visits.create")
    b = ctx.body
    dates = b.get("dates")
    if not b.get("client_id"):
        raise ApiError(400, "Client and scheduled date are required")
    if not isinstance(dates, list) or not dates:
        raise ApiError(400, "Pick at least one date")
    # De-duplicate: the same slot picked twice (or reached by two repeats) is
    # one visit, not two.
    starts = []
    for raw in dates:
        s = str(raw or "").strip()
        if not _DT_RE.match(s):
            raise ApiError(400, f"Invalid date: {s or '(empty)'}")
        s = s.replace(" ", "T")[:16]
        if s not in starts:
            starts.append(s)
    if len(starts) > MAX_BATCH_VISITS:
        raise ApiError(400, f"That repeats to {len(starts)} visits — "
                            f"the most that can be booked at once is {MAX_BATCH_VISITS}")
    if not b.get("site_id"):
        has_sites = db.query("SELECT 1 FROM sites WHERE client_id=? LIMIT 1",
                             (b["client_id"],), one=True)
        if has_sites:
            raise ApiError(400, "Please choose a branch for this visit")
    try:
        duration = int(float(b.get("duration") or 0))
    except (TypeError, ValueError):
        duration = 0
    contract_id = _contract_for_client(b.get("contract_id"), b["client_id"])
    ids, conflicts = [], []
    with db.transaction() as cx:
        for start in sorted(starts):
            end = _visit_end(start, duration)
            cf = _visit_conflict(b.get("agent_id"), start, end)
            if cf:
                conflicts.append({"scheduled_start": start, "client": cf["client"]})
            cur = cx.execute(
                "INSERT INTO visits(client_id,site_id,agent_id,service_type_id,contract_id,"
                "scheduled_start,scheduled_end,status,location,notes) "
                "VALUES(?,?,?,?,?,?,?,?,?,?)",
                (b["client_id"], b.get("site_id"), b.get("agent_id"), b.get("service_type_id"),
                 contract_id, start, end, b.get("status", "scheduled"),
                 b.get("location"), b.get("notes")))
            ids.append(cur.lastrowid)
    audit(ctx, "visit.batch", "visit", ids[0] if ids else None,
          f"{len(ids)} visits for client {b['client_id']}")
    return {"created": len(ids), "ids": ids, "conflicts": conflicts}


@route("PUT", r"/api/visits/(\d+)")
def update_visit(ctx):
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    b = ctx.body
    require_perm(u, "visits.edit")
    # An agent never sets the status by hand — it follows the work itself:
    # scheduled until they check in (-> in_progress), completed when they save
    # the report as complete. Only a manager/admin overrides it (e.g. cancel).
    # They may still annotate their own visit.
    if u["role"] == "agent":
        if v["agent_id"] != u["id"]:
            raise ApiError(403, "Not your visit")
        if b.get("status") and b["status"] != v["status"]:
            raise ApiError(403, "Visit status updates automatically — "
                                "ask a manager to change it")
        allowed = {"notes"}
        b = {k: val for k, val in b.items() if k in allowed}
    # A supervisor manages the work they answer for — including reassigning it — but
    # only there. Their own job elsewhere stays editable, as everywhere else.
    _assert_sup_visit(u, v)
    if "site_id" in b and not b["site_id"]:
        b["site_id"] = None     # blank -> unassigned location (NULL), not ""
    # The month's visit number is counted, not typed. Silently drop any attempt
    # to set it (an offline queue may still be holding an old payload).
    b.pop("visit_number", None)
    if "contract_id" in b:
        b["contract_id"] = _contract_for_client(b["contract_id"], b.get("client_id", v["client_id"]))
    # Re-check agent availability when the assignment or the time slot changes.
    if any(k in b for k in ("agent_id", "scheduled_start", "scheduled_end")):
        merged = {k: b.get(k, v[k]) for k in ("agent_id", "scheduled_start", "scheduled_end")}
        _check_visit_conflict(b, merged, exclude_vid=vid)
    cols = ("client_id", "site_id", "agent_id", "service_type_id", "contract_id",
            "scheduled_start", "scheduled_end", "status", "location", "notes",
            "completed_at")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [b[c] for c in cols if c in b]
    if b.get("status") == "completed" and "completed_at" not in b:
        fields.append("completed_at=datetime('now','localtime')")
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(vid)
    db.execute(f"UPDATE visits SET {','.join(fields)} WHERE id=?", vals)
    # Notify managers/admins when a visit is started or ended.
    new_status = b.get("status")
    if new_status and new_status != v["status"]:
        info = db.query("SELECT c.name_en client, u2.full_name agent FROM visits vv "
                        "JOIN clients c ON c.id=vv.client_id LEFT JOIN users u2 ON u2.id=vv.agent_id "
                        "WHERE vv.id=?", (vid,), one=True)
        who = (info["agent"] or "Engineer")
        if new_status == "in_progress":
            _notify_roles(("admin", "manager"), "visit_started", "Visit started",
                          f"{who} started the visit at {info['client']}", "visit", vid,
                          f"vstart:{vid}", exclude=u["id"])
            _notify_supervisors(v["client_id"], v["site_id"], "visit_started",
                                 "Visit started in your area",
                                 f"{who} started the visit at {info['client']}", "visit", vid,
                                 f"vstart:{vid}", exclude=u["id"], agent_id=v["agent_id"])
        elif new_status == "completed":
            _notify_roles(("admin", "manager"), "visit_completed", "Visit completed",
                          f"{who} completed the visit at {info['client']}", "visit", vid,
                          f"vdone:{vid}", exclude=u["id"])
            _notify_supervisors(v["client_id"], v["site_id"], "visit_completed",
                                 "Visit completed in your area",
                                 f"{who} completed the visit at {info['client']}", "visit", vid,
                                 f"vdone:{vid}", exclude=u["id"], agent_id=v["agent_id"])
        # The agent can no longer move the status themselves, so when a manager
        # overrides it — cancelling above all — the agent has to be told.
        _notify_visit_agent_of_override(v, new_status, info["client"], u["id"])
    return db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)


def _notify_visit_agent_of_override(v, new_status, client_name, actor_id):
    """Tell the assigned agent that someone else moved their visit's status."""
    aid = v["agent_id"]
    if not aid or aid == actor_id:
        return
    if new_status == "cancelled":
        title, body = "Visit cancelled", f"Your visit at {client_name} was cancelled."
    else:
        title = "Visit status changed"
        body = f"Your visit at {client_name} was set to {new_status.replace('_', ' ')}."
    _notify(aid, "visit_status", title, body, "visit", v["id"],
            f"vstatus:{v['id']}:{new_status}")


@route("DELETE", r"/api/visits/(\d+)")
def delete_visit(ctx):
    """Take one visit off the diary.

    IT IS WRITTEN DOWN. A visit removed by hand used to vanish without trace —
    no audit row, no soft delete, nothing — so when a branch turned up a visit
    short (which the Workflow board now says out loud) there was no way to
    answer who took it out or off which day. The row is read BEFORE the delete,
    because afterwards there is nothing left to name."""
    require_perm(ctx.user, "visits.delete")
    vid = int(ctx.params[0])
    was = db.query(
        "SELECT v.id, v.scheduled_start, v.status, v.site_id, s.name site_name, "
        "c.name_en client_en, u.full_name agent_name FROM visits v "
        "LEFT JOIN sites s ON s.id=v.site_id "
        "LEFT JOIN clients c ON c.id=v.client_id "
        "LEFT JOIN users u ON u.id=v.agent_id WHERE v.id=?", (vid,), one=True)
    db.execute("DELETE FROM visits WHERE id=?", (vid,))
    if was:
        audit(ctx, "visit.delete", "visit", vid,
              " · ".join(x for x in (
                  str(was["scheduled_start"] or "")[:16].replace("T", " "),
                  was["site_name"] or was["client_en"] or "",
                  f"engineer {was['agent_name']}" if was["agent_name"] else "",
                  f"was {was['status']}" if was["status"] else "") if x))
    return {"ok": True}


# --------------------------------------------------------------------------
# VISIT GPS CHECK-IN / CHECK-OUT (proof of presence; staff-only data)
# --------------------------------------------------------------------------
# Fields never sent to client accounts.
CHECKIN_COLS = ("checkin_at", "checkin_lat", "checkin_lng", "checkin_acc",
                "checkout_at", "checkout_lat", "checkout_lng", "checkout_acc")
# Where the visit was stood — never leaves the staff side. The times (the two
# columns left out here) DO reach the customer on one visit's report.
CHECKIN_GPS_COLS = tuple(c for c in CHECKIN_COLS if not c.endswith("_at"))


def _gps_from_body(b):
    """Validated (lat, lng, accuracy) from a check-in body; None when absent or
    out of range — a check-in without GPS is allowed (indoors/denied), the
    timestamp still counts."""
    def f(key, lo, hi):
        v = b.get(key)
        if v is None or str(v).strip() == "":
            return None
        try:
            x = float(v)
        except (TypeError, ValueError):
            return None
        return x if math.isfinite(x) and lo <= x <= hi else None
    lat, lng = f("lat", -90, 90), f("lng", -180, 180)
    if lat is None or lng is None:      # a lone coordinate is meaningless
        return None, None, None
    return lat, lng, f("accuracy", 0, 10_000_000)


def _client_stamp_or_none(b):
    """The tap time the PHONE recorded — used only for a check-in that was made
    with no signal and replayed afterwards, where the moment of the tap and the
    moment the server hears about it are genuinely different.

    THE PHONE'S CLOCK IS NOT THE COMPANY'S CLOCK (2026-09-06). Every check-in
    used to be stamped with whatever the device said, and the audit log shows
    one engineer's phone running an hour fast: the server logged the check-in at
    13:23:24 and the visit recorded 14:23:09, so his reports read an hour out
    all day. A phone that is set wrong, or on the wrong timezone, must not be
    able to write the wrong time into a customer's report. So an ONLINE check-in
    is stamped by the server, which runs on Africa/Cairo — the office clock —
    and the phone's own reading is kept only for a replay, which the offline
    queue marks with __offline (see replay() in offline.js).

    Even then it is bounded to within 3 days of the server's own clock; further
    out than that is a broken clock, not a late replay, and the server's time is
    used instead."""
    if not b.get("__offline"):
        return None                      # online: the server clock decides
    at = str(b.get("at") or "").strip()
    if not at:
        return None
    row = db.query("SELECT CASE WHEN abs(julianday(?) - julianday('now','localtime')) <= 3 "
                   "THEN datetime(?) END ts", (at, at), one=True)
    return row["ts"] if row else None


def _checkin_visit_or_403(ctx):
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    require_perm(u, "visits.edit")
    if u["role"] == "client":
        raise ApiError(403, "Not available to client accounts")
    if u["role"] == "agent" and v["agent_id"] != u["id"]:
        raise ApiError(403, "Not your visit")
    _assert_sup_visit(u, v)
    return vid, v


@route("POST", r"/api/visits/(\d+)/checkin")
def visit_checkin(ctx):
    vid, v = _checkin_visit_or_403(ctx)
    if v["checkin_at"]:
        raise ApiError(400, "Already checked in")
    if v["status"] in ("completed", "cancelled"):
        raise ApiError(400, "Visit is closed")
    lat, lng, acc = _gps_from_body(ctx.body)
    ts = _client_stamp_or_none(ctx.body)
    # Checking in also starts the visit.
    db.execute("UPDATE visits SET checkin_at=COALESCE(?, datetime('now','localtime')), "
               "checkin_lat=?, checkin_lng=?, checkin_acc=?, "
               "status=CASE WHEN status='scheduled' THEN 'in_progress' ELSE status END "
               "WHERE id=?", (ts, lat, lng, acc, vid))
    audit(ctx, "visit.checkin", "visit", vid,
          f"{lat:.5f},{lng:.5f}" if lat is not None else "no GPS")
    # Check-in is now the only way an agent starts a visit, so the "visit
    # started" alert that used to ride on the manual status change hangs here.
    if v["status"] == "scheduled":
        info = db.query("SELECT c.name_en client, u2.full_name agent FROM visits vv "
                        "JOIN clients c ON c.id=vv.client_id "
                        "LEFT JOIN users u2 ON u2.id=vv.agent_id WHERE vv.id=?", (vid,), one=True)
        _notify_roles(("admin", "manager"), "visit_started", "Visit started",
                      f"{info['agent'] or 'Engineer'} started the visit at {info['client']}",
                      "visit", vid, f"vstart:{vid}", exclude=ctx.user["id"])
        _notify_supervisors(v["client_id"], v["site_id"], "visit_started",
                             "Visit started in your area",
                             f"{info['agent'] or 'Engineer'} started the visit at {info['client']}",
                             "visit", vid, f"vstart:{vid}", exclude=ctx.user["id"],
                             agent_id=v["agent_id"])
    return db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)


@route("POST", r"/api/visits/(\d+)/checkout")
def visit_checkout(ctx):
    vid, v = _checkin_visit_or_403(ctx)
    if not v["checkin_at"]:
        raise ApiError(400, "Check in first")
    if v["checkout_at"]:
        raise ApiError(400, "Already checked out")
    lat, lng, acc = _gps_from_body(ctx.body)
    ts = _client_stamp_or_none(ctx.body)
    db.execute("UPDATE visits SET checkout_at=COALESCE(?, datetime('now','localtime')), "
               "checkout_lat=?, checkout_lng=?, checkout_acc=? WHERE id=?",
               (ts, lat, lng, acc, vid))
    audit(ctx, "visit.checkout", "visit", vid,
          f"{lat:.5f},{lng:.5f}" if lat is not None else "no GPS")
    return db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)


# --------------------------------------------------------------------------
# REPORTS
# --------------------------------------------------------------------------
@route("DELETE", r"/api/visits/(\d+)/report")
def delete_report(ctx):
    """TAKE ONE FILLED-IN REPORT BACK OFF THE BOOK, leaving the visit alone.

    The office asked for this because a report can be written against the wrong
    visit, or finished twice over, and until now the only way to be rid of one
    was to delete the visit it belongs to — which takes a job out of the diary
    to fix a piece of paperwork.

    OWNER AND MANAGER ONLY. It rides on visits.delete, which by default only
    admin and manager hold: an engineer, a team leader and an area manager all
    have visits.edit and none of them has this. If visits.delete is ever handed
    to someone else in the permission matrix, they get this with it.

    The visit itself is untouched — its date, its engineer and its status stay
    exactly as they were; it simply has no report again. The pictures filed
    against the report DO go with it: a fresh report on the same visit is a new
    row with a new id, so nothing could ever reach them again.

    It is written down. The row is read before the delete, because afterwards
    there is nothing left to name."""
    require_perm(ctx.user, "visits.delete")
    vid = int(ctx.params[0])
    was = db.query(
        "SELECT r.id, r.status, r.severity, v.scheduled_start, "
        "c.name_en client_en, s.name site_name, u.full_name agent_name "
        "FROM reports r JOIN visits v ON v.id=r.visit_id "
        "JOIN clients c ON c.id=v.client_id "
        "LEFT JOIN sites s ON s.id=v.site_id "
        "LEFT JOIN users u ON u.id=v.agent_id WHERE r.visit_id=?", (vid,), one=True)
    if not was:
        raise ApiError(404, "Report not found")
    db.execute("DELETE FROM photos WHERE entity_type='report' AND entity_id=?", (was["id"],))
    db.execute("DELETE FROM reports WHERE id=?", (was["id"],))
    audit(ctx, "report.delete", "visit", vid,
          " · ".join(x for x in (
              str(was["scheduled_start"] or "")[:16].replace("T", " "),
              was["site_name"] or was["client_en"] or "",
              f"engineer {was['agent_name']}" if was["agent_name"] else "",
              f"was {was['status']}" if was["status"] else "") if x))
    return {"ok": True}


@route("POST", r"/api/visits/(\d+)/report")
def upsert_report(ctx):
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    require_perm(u, "visits.edit")
    if u["role"] == "agent" and v["agent_id"] != u["id"]:
        raise ApiError(403, "Not your visit")
    _assert_sup_visit(u, v)
    b = ctx.body
    existing = db.query("SELECT * FROM reports WHERE visit_id=?", (vid,), one=True)
    text_cols = ("summary", "pests_found", "findings", "recommendations", "severity",
                 "next_visit_due", "spare_parts_changed", "branch_issue", "condition")
    # Engineer service log — quantities of parts/materials used during the visit.
    num_cols = ("lamps_used", "cables_used", "transformers_used", "light_sheets_used",
                "fipronil_ml", "imidacloprid_gm", "baits_count", "glo_pieces", "flybase_bags")

    def num(v):
        try:
            return float(v) if str(v).strip() != "" else 0
        except (TypeError, ValueError):
            return 0

    # The agent finalising the report sends status=complete; everything else
    # (auto-save while typing) is stored as a draft and can't be finalised until
    # the required fields + both signatures are present.
    want_complete = (b.get("status") or "").lower() == "complete"

    # Legacy shim: clients running a cached pre-multi-trip app.js still send a
    # single transport_vehicle/transport_cost pair on the report body. Fold it
    # into ONE transport_entries row (never back into the report columns, which
    # the migration would re-copy on restart and duplicate).
    if (str(b.get("transport_vehicle") or "").strip() or num(b.get("transport_cost")) > 0):
        veh = str(b.get("transport_vehicle") or "").strip() or None
        cost = num(b.get("transport_cost"))
        first = db.query("SELECT id FROM transport_entries WHERE visit_id=? "
                         "ORDER BY id LIMIT 1", (vid,), one=True)
        if first:
            db.execute("UPDATE transport_entries SET vehicle=?, cost=? WHERE id=?",
                       (veh, cost, first["id"]))
        else:
            db.execute("INSERT INTO transport_entries(visit_id,vehicle,cost,created_by) "
                       "VALUES(?,?,?,?)", (vid, veh, cost, u["id"]))

    if existing:
        fields, vals = [], []
        for c in text_cols:
            if c in b:
                fields.append(f"{c}=?"); vals.append(b[c])
        for c in num_cols:
            if c in b:
                fields.append(f"{c}=?"); vals.append(num(b[c]))
        if fields:
            vals.append(vid)
            db.execute(f"UPDATE reports SET {','.join(fields)} WHERE visit_id=?", vals)
    else:
        cols = ("visit_id",) + text_cols + num_cols
        vals = [vid] + [b.get(c) for c in text_cols] + [num(b.get(c)) for c in num_cols]
        # severity must not be NULL (CHECK constraint) — default it.
        vals[list(cols).index("severity")] = b.get("severity") or "low"
        placeholders = ",".join("?" * len(cols))
        db.execute(f"INSERT INTO reports({','.join(cols)}) VALUES({placeholders})", vals)

    # Re-read the merged row to validate / set the status against final values.
    rep = db.query("SELECT * FROM reports WHERE visit_id=?", (vid,), one=True)
    if want_complete:
        missing = _report_incomplete_fields(rep)
        if missing:
            raise ApiError(400, "report_incomplete:" + ",".join(missing))
        db.execute("UPDATE reports SET status='complete', completed_at=datetime('now','localtime') "
                   "WHERE visit_id=? AND status!='complete'", (vid,))
        # Finishing the report is what closes the visit — the agent has no
        # status control of their own. A cancelled visit stays cancelled;
        # only a manager can bring it back.
        # AND IT IS WHAT ENDS THE VISIT ON THE CLOCK. Finishing the report used
        # to leave checkout_at empty unless the engineer also remembered the 🏁
        # button — 24 of the 32 check-ins in the live book have no check-out —
        # and the printed report then fell back to the BOOKED end: a visit
        # worked 01:58 to 02:42 printed "Scheduled end 03:00". Submitting the
        # report is the engineer saying he has finished, so it stamps the finish
        # too, from the server's Cairo clock. COALESCE, so a real 🏁 check-out
        # already recorded is never overwritten.
        if v["status"] not in ("completed", "cancelled"):
            db.execute("UPDATE visits SET status='completed', "
                       "completed_at=COALESCE(completed_at, datetime('now','localtime')), "
                       "checkout_at=CASE WHEN checkin_at IS NULL THEN checkout_at "
                       "  ELSE COALESCE(checkout_at, datetime('now','localtime')) END "
                       "WHERE id=?", (vid,))
            info = db.query("SELECT c.name_en client, u2.full_name agent FROM visits vv "
                            "JOIN clients c ON c.id=vv.client_id "
                            "LEFT JOIN users u2 ON u2.id=vv.agent_id WHERE vv.id=?", (vid,), one=True)
            _notify_roles(("admin", "manager"), "visit_completed", "Visit completed",
                          f"{info['agent'] or 'Engineer'} completed the visit at {info['client']}",
                          "visit", vid, f"vdone:{vid}", exclude=u["id"])
            _notify_supervisors(v["client_id"], v["site_id"], "visit_completed",
                                 "Visit completed in your area",
                                 f"{info['agent'] or 'Engineer'} completed the visit at {info['client']}",
                                 "visit", vid, f"vdone:{vid}", exclude=u["id"],
                                 agent_id=v["agent_id"])
            audit(ctx, "visit.autocomplete", "visit", vid, "report completed")
        # First completion -> invite the client to rate the visit.
        if rep["status"] != "complete":
            _notify_client_users(v["client_id"], "rate_visit", "How was your service?",
                                 "Your service report is ready — tap to view it and rate the visit.",
                                 "visit", vid, f"rate:{vid}")
    elif rep["status"] != "complete":
        # keep it a draft (clear any stale completed_at)
        db.execute("UPDATE reports SET status='draft', completed_at=NULL WHERE visit_id=?", (vid,))
    return db.query("SELECT * FROM reports WHERE visit_id=?", (vid,), one=True)


@route("POST", r"/api/visits/(\d+)/rating")
def rate_visit(ctx):
    """Client rates a completed visit (1-5 stars + optional comment), once."""
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    if u["role"] != "client" or v["client_id"] != u["client_id"]:
        raise ApiError(403, "Only the client can rate their visit")
    if v["status"] != "completed":
        raise ApiError(400, "Only a completed visit can be rated")
    if db.query("SELECT 1 FROM visit_ratings WHERE visit_id=?", (vid,), one=True):
        raise ApiError(400, "This visit is already rated")
    try:
        stars = int(ctx.body.get("stars"))
    except (TypeError, ValueError):
        raise ApiError(400, "Stars must be 1-5")
    if not 1 <= stars <= 5:
        raise ApiError(400, "Stars must be 1-5")
    comment = str(ctx.body.get("comment") or "").strip()[:1000] or None
    db.execute("INSERT INTO visit_ratings(visit_id,client_id,stars,comment,created_by) "
               "VALUES(?,?,?,?,?)", (vid, v["client_id"], stars, comment, u["id"]))
    info = db.query("SELECT c.name_en client, u2.full_name agent FROM visits vv "
                    "JOIN clients c ON c.id=vv.client_id LEFT JOIN users u2 ON u2.id=vv.agent_id "
                    "WHERE vv.id=?", (vid,), one=True)
    _notify_roles(("admin", "manager"), "visit_rated", "Visit rated",
                  f"{info['client']} rated {info['agent'] or 'the visit'}: {'⭐' * stars}"
                  + (f" — {comment}" if comment else ""),
                  "visit", vid, f"rated:{vid}")
    _notify_supervisors(v["client_id"], v["site_id"], "visit_rated", "Visit rated in your area",
                         f"{info['client']} rated {info['agent'] or 'the visit'}: {'⭐' * stars}"
                         + (f" — {comment}" if comment else ""),
                         "visit", vid, f"rated:{vid}", agent_id=v["agent_id"])
    audit(ctx, "visit.rate", "visit", vid, f"{stars} stars")
    return db.query("SELECT stars, comment, created_at FROM visit_ratings WHERE visit_id=?",
                    (vid,), one=True)


# Fields (and signatures) required before a report can be marked complete.
# What must be filled in before a report can be marked complete. Findings and
# pests-found left the report form when condition and recommendations became
# office-maintained pick lists; requiring a field nobody can fill would block
# every report. Condition is deliberately NOT required: an office that has not
# built its list yet must not lock its engineers out of finishing a visit.
REPORT_REQUIRED_FIELDS = ("summary",)


def _report_incomplete_fields(rep):
    """Return the list of required-but-missing field keys for a report row.

    One signature, not two: the report now has a single signature tab. A report
    filed when there were two still counts as signed, whichever of the columns
    holds the photograph."""
    missing = [f for f in REPORT_REQUIRED_FIELDS if not (rep.get(f) or "").strip()]
    if not (rep.get("customer_signature") or rep.get("technician_signature")):
        missing.append("signature")
    return missing


# Report free-text fields that get auto-translated for display/printing.
REPORT_TRANSLATABLE = ("summary", "pests_found", "findings",
                       "spare_parts_changed", "branch_issue")
# Condition and recommendations are NOT free text: every line was ticked from
# the office's own lists, and the office wrote each of those twice — once in
# English, once in Arabic. So they are shown in the reader's language by looking
# the wording back up in that list, never by machine translation (which left
# every line in the language the engineer had the CRM in whenever the endpoint
# was unreachable — the whole report reading Arabic in an English CRM).
REPORT_WORDING = ("condition", "recommendations")


def _wording_pairs():
    """{wording -> {"en": ..., "ar": ...}} for both spellings of every option."""
    pairs = {}
    for o in db.query("SELECT name_en, name_ar FROM report_options"):
        en = (o["name_en"] or "").strip()
        ar = (o["name_ar"] or "").strip()
        if not (en and ar):
            continue
        both = {"en": en, "ar": ar}
        pairs[en] = both
        pairs[ar] = both
    return pairs


def _localize_wording(text, target, pairs):
    """One picked-wording field, line by line, in `target`.

    A line still on the office's list is swapped for that list's wording in the
    target language. Wording that has since been edited off the list falls back
    to translation, so an older report still reads."""
    out = []
    for line in str(text or "").split("\n"):
        line = line.strip()
        if not line:
            continue
        hit = pairs.get(line)
        out.append(hit[target] if hit else _translate(line, target))
    return "\n".join(out)


def _translate(text, target):
    """Translate text into target ('en'|'ar'), cached in the translations table.

    Uses the free Google endpoint. On any failure (or if the text is already in
    the target language) the original text is returned, so callers degrade
    gracefully and never block on the network."""
    text = (text or "").strip()
    if not text or target not in ("en", "ar"):
        return text
    h = hashlib.sha1((target + "::" + text).encode("utf-8")).hexdigest()
    row = db.query("SELECT text FROM translations WHERE src_hash=? AND target=?",
                   (h, target), one=True)
    if row:
        return row["text"]
    try:
        url = ("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl="
               + target + "&dt=t&q=" + quote(text))
        req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
        with urllib.request.urlopen(req, timeout=8) as r:
            data = json.loads(r.read().decode("utf-8"))
        src_lang = data[2] if len(data) > 2 else None
        out = text if src_lang == target else "".join(
            seg[0] for seg in data[0] if seg and seg[0])
        db.execute("INSERT OR IGNORE INTO translations(src_hash,target,src_lang,text) "
                   "VALUES(?,?,?,?)", (h, target, src_lang, out))
        return out
    except Exception as e:
        print("translate failed:", e)
        return text


def _translate_report(rep, target):
    """Translate a report dict's free-text fields in place (best-effort)."""
    if rep and target in ("en", "ar"):
        for f in REPORT_TRANSLATABLE:
            if rep.get(f):
                rep[f] = _translate(rep[f], target)
        if any(rep.get(f) for f in REPORT_WORDING):
            pairs = _wording_pairs()
            for f in REPORT_WORDING:
                if rep.get(f):
                    rep[f] = _localize_wording(rep[f], target, pairs)
    return rep


def _draft_reports_for(user):
    """Unfinished (draft) reports the user is responsible for.

    Agents see their own; managers/admins see all open drafts so they can chase."""
    sql = ("SELECT r.visit_id, r.created_at, v.agent_id, u.full_name agent_name, "
           "c.name_en, c.name_ar, v.scheduled_start "
           "FROM reports r JOIN visits v ON v.id=r.visit_id "
           "JOIN clients c ON c.id=v.client_id LEFT JOIN users u ON u.id=v.agent_id "
           "WHERE r.status='draft' ")
    params = ()
    if user["role"] == "agent":
        sql += "AND v.agent_id=? "
        params = (user["id"],)
    elif user["role"] in SUPERVISOR_ROLES:
        # A supervisor chases their own paperwork, not the whole company's.
        clause, lp = _sup_visit_clause(user)
        sql += f"AND {clause} "
        params = tuple(lp)
    sql += "ORDER BY r.created_at DESC"
    return db.query(sql, params)


@route("GET", r"/api/reports/drafts")
def list_draft_reports(ctx):
    require_perm(ctx.user, "visits.view")
    return {"items": _draft_reports_for(ctx.user)}


# --------------------------------------------------------------------------
# AREAS — the parts of town the company works. A branch sits in one, a shift
# can cover one, and dispatch compares the two.
# --------------------------------------------------------------------------
@route("GET", r"/api/areas")
def list_areas(ctx):
    """Read by anyone who books or dispatches work; only the office writes it.
    Whoever maintains the list also sees the areas switched off."""
    if ctx.user["role"] == "client":
        raise ApiError(403, "You do not have permission for this action")
    where = "" if has_perm(ctx.user, "settings.edit") else " WHERE active=1"
    rows = db.query("SELECT * FROM areas" + where + " ORDER BY sort_order, name_en")
    # Who manages each area, so the office can see at a glance that a patch has
    # nobody on it. An area can have more than one manager — the list does not
    # pretend otherwise.
    managers = {}
    for r in db.query(
            "SELECT la.area_id, u.id, u.full_name FROM area_manager_areas la "
            "JOIN users u ON u.id=la.manager_id WHERE u.active=1 ORDER BY u.full_name"):
        managers.setdefault(r["area_id"], []).append({"id": r["id"], "full_name": r["full_name"]})
    # Who is ALLOWED to work each patch, and how much work is sitting in it.
    # An area with branches and nobody permitted on it is invisible until
    # somebody runs a plan and reads the "no engineer" line — by which point
    # the week is already being argued about. It belongs on this page instead.
    crew = {}
    for r in db.query(
            "SELECT aa.area_id, u.id, u.full_name FROM agent_areas aa "
            "JOIN users u ON u.id=aa.agent_id WHERE u.active=1 ORDER BY u.full_name"):
        crew.setdefault(r["area_id"], []).append({"id": r["id"], "full_name": r["full_name"]})
    load = {r["area_id"]: r for r in db.query(
        "SELECT area_id, COUNT(*) branches, SUM(COALESCE(visits_per_month,0)) demand "
        "FROM sites WHERE area_id IS NOT NULL" + _SERVICED_BRANCH + " GROUP BY area_id")}
    for r in rows:
        r["managers"] = managers.get(r["id"], [])
        r["engineers"] = crew.get(r["id"], [])
        row = load.get(r["id"]) or {}
        r["branches"] = row.get("branches") or 0
        r["visits_per_month"] = row.get("demand") or 0
    return rows


@route("GET", r"/api/zones")
def list_zones(ctx):
    """The groupings that make one area "near" another. Read by anyone who
    schedules; written by the office."""
    if ctx.user["role"] == "client":
        raise ApiError(403, "You do not have permission for this action")
    rows = db.query("SELECT * FROM zones ORDER BY sort_order, name_en")
    for z in rows:
        z["areas"] = db.query(
            "SELECT id, name_en, name_ar FROM areas WHERE zone_id=? ORDER BY sort_order, name_en",
            (z["id"],))
    return rows


@route("POST", r"/api/zones")
def create_zone(ctx):
    require_perm(ctx.user, "settings.edit")
    name = str(ctx.body.get("name_en") or "").strip()
    if not name:
        raise ApiError(400, "A zone name is required")
    zid = db.execute("INSERT INTO zones(name_en,name_ar,sort_order) VALUES(?,?,?)",
                     (name[:120], (str(ctx.body.get("name_ar")).strip()[:120]
                                   if ctx.body.get("name_ar") else None),
                      int(ctx.body.get("sort_order") or 0)))
    audit(ctx, "zone.create", "zone", zid, name)
    return db.query("SELECT * FROM zones WHERE id=?", (zid,), one=True)


@route("PUT", r"/api/zones/(\d+)")
def update_zone(ctx):
    require_perm(ctx.user, "settings.edit")
    zid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM zones WHERE id=?", (zid,), one=True):
        raise ApiError(404, "Zone not found")
    b = ctx.body
    fields, vals = [], []
    for col in ("name_en", "name_ar"):
        if col in b:
            fields.append(f"{col}=?")
            vals.append((str(b[col]).strip()[:120] or None) if b[col] else None)
    for col in ("sort_order", "active", "own_day"):
        if col in b:
            fields.append(f"{col}=?")
            vals.append(int(b[col] or 0))
    # The whole membership list can be sent at once, which is how the zone
    # editor saves: tick the areas that belong here and press save.
    if "area_ids" in b:
        ids = [int(a) for a in (b["area_ids"] or []) if str(a).isdigit()]
        db.execute("UPDATE areas SET zone_id=NULL WHERE zone_id=?", (zid,))
        for aid in ids:
            db.execute("UPDATE areas SET zone_id=? WHERE id=?", (zid, aid))
    if fields:
        vals.append(zid)
        db.execute(f"UPDATE zones SET {','.join(fields)} WHERE id=?", vals)
    audit(ctx, "zone.update", "zone", zid)
    return db.query("SELECT * FROM zones WHERE id=?", (zid,), one=True)


@route("DELETE", r"/api/zones/(\d+)")
def delete_zone(ctx):
    """Deleting a zone leaves its areas in place with no grouping, rather than
    taking them with it — the areas are real, the grouping is a convenience."""
    require_perm(ctx.user, "settings.edit")
    zid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM zones WHERE id=?", (zid,), one=True):
        raise ApiError(404, "Zone not found")
    db.execute("UPDATE areas SET zone_id=NULL WHERE zone_id=?", (zid,))
    db.execute("DELETE FROM zones WHERE id=?", (zid,))
    audit(ctx, "zone.delete", "zone", zid)
    return {"deleted": True}


# --------------------------------------------------------------------------
# ENGINEER AVAILABILITY — read and written for EVERYONE AT ONCE.
# The office asked for this shape explicitly: "make sure I give you all
# engineers and their available hours, not engineer one by one, to not be any
# mistakes in schedules." So there is deliberately no per-engineer write
# endpoint — one screen, one payload, one save.
# --------------------------------------------------------------------------
@route("GET", r"/api/agent-availability")
def get_agent_availability(ctx):
    require_perm(ctx.user, "shifts.view")
    # ENGINEERS ONLY, because this board is the auto-roster's input and the
    # auto-roster sends engineers. Giving an area manager hours here promised
    # something the planner will never do with them — the owner's rule is that
    # managers and team leaders carry no route unless he assigns one by hand,
    # which is done on the shift board or the visit itself, not here.
    rows = db.query("SELECT id, full_name, role FROM users "
                    "WHERE role='agent' AND active=1 ORDER BY full_name")
    out = []
    for r in rows:
        out.append({
            "id": r["id"], "full_name": r["full_name"], "role": r["role"],
            "area_ids": [x["area_id"] for x in db.query(
                "SELECT area_id FROM agent_areas WHERE agent_id=?", (r["id"],))],
            # Only the patches with days NAMED appear here: an empty map means
            # every patch of his is his on any day he works, which is the
            # ordinary case and the one the board should not clutter.
            "area_days": {str(x["area_id"]): sorted(_weekday_set(x["weekdays"]))
                          for x in db.query(
                              "SELECT area_id, weekdays FROM agent_areas WHERE agent_id=?",
                              (r["id"],)) if _weekday_set(x["weekdays"])},
            # A weekday with no row is a day off, so the client gets exactly the
            # days that ARE worked and nothing to interpret.
            # A weekday now carries a LIST of working windows — a man may work
            # 08:00-12:00 and again 16:00-20:00 with the middle of the day his
            # own. One window is a list of one, so the ordinary case is
            # unchanged in meaning and only the shape moved.
            "days": _availability_days(r["id"]),
        })
    return {"engineers": out,
            "areas": db.query("SELECT id, name_en, name_ar, zone_id FROM areas WHERE active=1 "
                              "ORDER BY sort_order, name_en"),
            "zones": db.query("SELECT id, name_en, name_ar FROM zones WHERE active=1 "
                              "ORDER BY sort_order, name_en")}


DAY_MINUTES = 24 * 60        # one turn of the clock, for overnight windows


def _availability_days(agent_id):
    """{weekday: [ {start_time, end_time}, ... ]} — a day off has no key at all,
    so the client gets exactly the days that ARE worked and nothing to guess."""
    out = {}
    for x in db.query("SELECT weekday, start_time, end_time FROM agent_availability "
                      "WHERE agent_id=? ORDER BY weekday, start_time", (agent_id,)):
        out.setdefault(str(x["weekday"]), []).append(
            {"start_time": x["start_time"], "end_time": x["end_time"]})
    return out


def _windows_of(raw):
    """The windows the client sent for ONE weekday, checked against each other.

    A single object is still accepted, so every caller written before split
    shifts existed keeps working and means exactly what it always meant.

    OVERLAP IS JUDGED ON THE PLANNER'S OWN READING of a window (`avail_bounds`),
    which is what makes the overnight case come out right: 22:00-06:00 is one
    stretch running to 06:00 THE NEXT DAY, so a second window at 02:00-04:00 is
    inside it even though the plain numbers never meet — while 08:00-12:00
    beside it is a perfectly ordinary day-then-night pair.
    """
    if raw is None:
        raw = [{}]
    items = raw if isinstance(raw, list) else [raw]
    if not items:
        items = [{}]
    if len(items) > 6:
        raise ApiError(400, "Too many working windows in one day")
    spans, out = [], []
    for win in items:
        if not isinstance(win, dict):
            raise ApiError(400, "Each working window needs a start and an end")
        f = _shift_time(win.get("start_time"), "start_time")
        t = _shift_time(win.get("end_time"), "end_time")
        lo, hi = roster.avail_bounds(f, t)
        if hi <= lo:
            raise ApiError(400, "A working window must end after it starts")
        # The tail of an overnight window belongs to the small hours of the
        # next day; compare everything on that same continuous clock.
        spans.append((lo, hi))
        out.append((f, t))
    for i, (lo, hi) in enumerate(spans):
        for j, (lo2, hi2) in enumerate(spans):
            if i >= j:
                continue
            a, b = (lo, hi), (lo2, hi2)
            overlap = a[0] < b[1] and b[0] < a[1]
            # ...and the same question asked of the overnight tail, which sits
            # on the next day's clock.
            for shift in (DAY_MINUTES, -DAY_MINUTES):
                if a[0] + shift < b[1] and b[0] < a[1] + shift:
                    overlap = True
            if overlap:
                raise ApiError(400, "Working windows on one day must not overlap")
    return out


@route("PUT", r"/api/agent-availability")
def set_agent_availability(ctx):
    """Save the whole board. The body carries every engineer being changed;
    each one's areas and worked days are replaced outright, because the screen
    always shows and sends the complete picture for that person."""
    require_perm(ctx.user, "shifts.edit")
    people = ctx.body.get("engineers")
    if not isinstance(people, list):
        raise ApiError(400, "engineers must be a list")
    if len(people) > 300:
        raise ApiError(400, "Too many engineers in one request")
    saved = 0
    with db.transaction() as cx:
        for p in people:
            try:
                aid = int(p.get("id"))
            except (TypeError, ValueError):
                raise ApiError(400, "Each engineer needs an id")
            who = db.query("SELECT role FROM users WHERE id=?", (aid,), one=True)
            if not who:
                raise ApiError(404, "Engineer not found")
            if who["role"] not in FIELD_ROLES:
                raise ApiError(400, "Only engineers and team leaders have a roster")
            if "area_ids" in p:
                # Days are validated BEFORE anything is deleted — a bad weekday
                # must not leave an engineer with no patches at all.
                by_area_days = {}
                for k, v in (p.get("area_days") or {}).items():
                    try:
                        by_area_days[int(k)] = _weekday_text(v)
                    except (TypeError, ValueError):
                        raise ApiError(400, "Invalid area")
                cx.execute("DELETE FROM agent_areas WHERE agent_id=?", (aid,))
                for raw in (p["area_ids"] or []):
                    area = _coerce_area_id(raw)
                    if area:
                        cx.execute("INSERT OR IGNORE INTO agent_areas(agent_id,area_id,weekdays) "
                                   "VALUES(?,?,?)", (aid, area, by_area_days.get(area)))
            if "days" in p:
                cx.execute("DELETE FROM agent_availability WHERE agent_id=?", (aid,))
                for wd, win in (p["days"] or {}).items():
                    try:
                        day = int(wd)
                    except (TypeError, ValueError):
                        raise ApiError(400, "Weekday must be 0-6")
                    if not 0 <= day <= 6:
                        raise ApiError(400, "Weekday must be 0-6")
                    for f, t in _windows_of(win):
                        cx.execute(
                            "INSERT INTO agent_availability"
                            "(agent_id,weekday,start_time,end_time) VALUES(?,?,?,?)",
                            (aid, day, f, t))
            saved += 1
    audit(ctx, "availability.save", "user", None, f"{saved} engineer(s)")
    return get_agent_availability(ctx)


def _area_fields(b, existing=None):
    name_en = str(b.get("name_en") if "name_en" in b else (existing or {}).get("name_en") or "").strip()
    if not name_en:
        raise ApiError(400, "An area name is required")
    name_ar = b.get("name_ar") if "name_ar" in b else (existing or {}).get("name_ar")
    order = b.get("sort_order") if "sort_order" in b else (existing or {}).get("sort_order", 0)
    active = b.get("active") if "active" in b else (existing or {}).get("active", 1)
    try:
        order = int(order or 0)
    except (TypeError, ValueError):
        order = 0
    zone = b.get("zone_id") if "zone_id" in b else (existing or {}).get("zone_id")
    if zone in (None, "", 0, "0"):
        zone = None
    else:
        zone = int(zone)
        if not db.query("SELECT id FROM zones WHERE id=?", (zone,), one=True):
            raise ApiError(400, "Unknown zone")
    return (name_en[:120], (str(name_ar).strip()[:120] if name_ar else None), order,
            (1 if active else 0), zone)


@route("POST", r"/api/areas")
def create_area(ctx):
    require_perm(ctx.user, "settings.edit")
    en, ar, order, active, zone = _area_fields(ctx.body)
    aid = db.execute("INSERT INTO areas(name_en,name_ar,sort_order,active,zone_id) "
                     "VALUES(?,?,?,?,?)", (en, ar, order, active, zone))
    audit(ctx, "area.create", "area", aid, en)
    return db.query("SELECT * FROM areas WHERE id=?", (aid,), one=True)


@route("PUT", r"/api/areas/(\d+)")
def update_area(ctx):
    require_perm(ctx.user, "settings.edit")
    aid = int(ctx.params[0])
    existing = db.query("SELECT * FROM areas WHERE id=?", (aid,), one=True)
    if not existing:
        raise ApiError(404, "Area not found")
    en, ar, order, active, zone = _area_fields(ctx.body, existing)
    db.execute("UPDATE areas SET name_en=?,name_ar=?,sort_order=?,active=?,zone_id=? WHERE id=?",
               (en, ar, order, active, zone, aid))
    audit(ctx, "area.update", "area", aid, en)
    return db.query("SELECT * FROM areas WHERE id=?", (aid,), one=True)


def _area_or_404(aid):
    row = db.query("SELECT * FROM areas WHERE id=?", (aid,), one=True)
    if not row:
        raise ApiError(404, "Area not found")
    return row


@route("GET", r"/api/areas/(\d+)/branches")
def area_branches(ctx):
    """The branches on offer to ONE area, so a patch can be filled from its own
    row instead of opening 179 branch dialogs.

    EVERY branch the company services is listed, whichever area it is in now —
    the whole point of the screen is to pull branches ACROSS, so a branch that
    already belongs to Maadi has to be visible from Zayed. One that already
    sits in THIS area is listed even when it, or its customer, has been
    switched off: otherwise it could only be taken out again from a page that
    never shows it."""
    require_perm(ctx.user, "clients.edit")
    aid = int(ctx.params[0])
    area = _area_or_404(aid)
    allowed = _board_site_ids(ctx.user)
    rows = db.query(
        "SELECT s.id, s.name, s.status, s.client_id, s.area_id, s.visits_per_month, "
        "c.name_en client_en, c.name_ar client_ar, c.status client_status, "
        "ar.name_en area_en, ar.name_ar area_ar, "
        # What is already booked into this branch. Moving it does not move the
        # visits: they stay on the engineer they are on, in what is now a
        # different part of town. The office should see that before it ticks.
        "(SELECT COUNT(*) FROM visits v WHERE v.site_id=s.id AND v.status='scheduled' "
        "AND date(v.scheduled_start) >= date('now','localtime')) upcoming_visits "
        "FROM sites s JOIN clients c ON c.id=s.client_id "
        "LEFT JOIN areas ar ON ar.id=s.area_id "
        "WHERE (s.status='active' AND c.status='active') OR s.area_id=? "
        "ORDER BY c.name_en, s.name", (aid,))
    if allowed is not None:
        rows = [r for r in rows if r["id"] in allowed]
    for r in rows:
        r["serviced"] = bool(r["status"] == "active" and r["client_status"] == "active")
    return {"area": {"id": area["id"], "name_en": area["name_en"],
                     "name_ar": area["name_ar"]},
            "branches": rows}


@route("POST", r"/api/areas/(\d+)/branches")
def set_area_branches(ctx):
    """Move a handful of branches into this area, and let a handful go.

    A DELTA — `assign` and `unassign` — never a membership list. The page sends
    only the ticks that were actually changed, for the same reason the branch
    board does: a whole-list save would let a branch nobody looked at (switched
    off, or outside a supervisor's patch) be stripped of its area by a screen
    that never showed it.

    A branch sits in exactly ONE area, so assigning it here takes it out of
    wherever it was; the reply says where from. Un-assigning leaves it with NO
    area, which is a real instruction and not a small one — the roster only
    plans branches that have one, so it drops out of the plan and shows up on
    the Workflow board as a branch with no area."""
    require_perm(ctx.user, "clients.edit")
    aid = int(ctx.params[0])
    area = _area_or_404(aid)
    b = ctx.body or {}

    def id_list(key):
        raw = b.get(key) or []
        if not isinstance(raw, list):
            raise ApiError(400, "Expected a list of branches")
        out = []
        for x in raw:
            try:
                out.append(int(x))
            except (TypeError, ValueError):
                raise ApiError(400, "Invalid branch")
        return out

    # The same branch twice in one list is a page that ticked it twice, not two
    # branches: it must count once and be written once.
    add = list(dict.fromkeys(id_list("assign")))
    drop = list(dict.fromkeys(id_list("unassign")))
    if not add and not drop:
        raise ApiError(400, "No branches were chosen")
    if set(add) & set(drop):
        raise ApiError(400, "A branch cannot be moved in and out of the same area")
    # VALIDATE THE WHOLE REQUEST BEFORE WRITING ANY OF IT. A half-applied move
    # is worse than a refused one: nobody can tell which branches took.
    wanted = sorted(set(add) | set(drop))
    marks = ",".join("?" for _ in wanted)
    known = {r["id"]: r for r in db.query(
        f"SELECT s.id, s.area_id, "
        f"(SELECT COUNT(*) FROM visits v WHERE v.site_id=s.id AND v.status='scheduled' "
        f"AND date(v.scheduled_start) >= date('now','localtime')) upcoming "
        f"FROM sites s WHERE s.id IN ({marks})", wanted)}
    allowed = _board_site_ids(ctx.user)
    for sid in wanted:
        if sid not in known:
            raise ApiError(400, "Unknown branch")
        if allowed is not None and sid not in allowed:
            raise ApiError(403, "That branch is not in your areas")
    # Only what actually CHANGES is written and counted, so the number echoed
    # back is the number of branches that really moved.
    moving = [sid for sid in add if known[sid]["area_id"] != aid]
    leaving = [sid for sid in drop if known[sid]["area_id"] == aid]
    moved_from = {}
    for sid in moving:
        old = known[sid]["area_id"]
        if old is not None:
            moved_from[str(old)] = moved_from.get(str(old), 0) + 1
    with_visits = sum(1 for sid in moving + leaving if known[sid]["upcoming"])
    with db.transaction() as cx:
        for sid in moving:
            cx.execute("UPDATE sites SET area_id=? WHERE id=?", (aid, sid))
        for sid in leaving:
            cx.execute("UPDATE sites SET area_id=NULL WHERE id=?", (sid,))
    audit(ctx, "area.branches", "area", aid,
          f"{area['name_en']}: {len(moving)} in, {len(leaving)} out")
    return {"assigned": len(moving), "unassigned": len(leaving),
            "moved_from": moved_from, "with_visits": with_visits,
            # What the area carries now, so the page can show the same number
            # the Areas list will show when it redraws.
            "branches": (db.query("SELECT COUNT(*) n FROM sites WHERE area_id=?"
                                  + _SERVICED_BRANCH, (aid,), one=True) or {})["n"]}


@route("DELETE", r"/api/areas/(\d+)")
def delete_area(ctx):
    """Deleting an area leaves the branches and shifts that used it without one
    rather than taking them with it (the columns are ON DELETE SET NULL)."""
    require_perm(ctx.user, "settings.edit")
    aid = int(ctx.params[0])
    existing = db.query("SELECT * FROM areas WHERE id=?", (aid,), one=True)
    if not existing:
        raise ApiError(404, "Area not found")
    db.execute("UPDATE sites SET area_id=NULL WHERE area_id=?", (aid,))
    db.execute("UPDATE clients SET area_id=NULL WHERE area_id=?", (aid,))
    db.execute("UPDATE agent_shifts SET area_id=NULL WHERE area_id=?", (aid,))
    # An area manager's patch shrinks with it. The rows would cascade anyway; doing it
    # here keeps the deletion's effect on people's ACCESS explicit.
    db.execute("DELETE FROM area_manager_areas WHERE area_id=?", (aid,))
    db.execute("DELETE FROM areas WHERE id=?", (aid,))
    audit(ctx, "area.delete", "area", aid, existing["name_en"])
    return {"deleted": True}


def _coerce_area_id(value):
    """'' / None clear the area; anything else must be a real one."""
    if value in (None, "", 0, "0"):
        return None
    try:
        aid = int(value)
    except (TypeError, ValueError):
        raise ApiError(400, "Unknown area")
    if not db.query("SELECT id FROM areas WHERE id=?", (aid,), one=True):
        raise ApiError(400, "Unknown area")
    return aid


# --------------------------------------------------------------------------
# REPORT OPTIONS — the conditions and recommendations the office writes once
# and the engineer picks from in the field. Kept as wording, not codes: a
# report stores what was chosen, so editing the list never rewrites a report
# that has already been filed.
# --------------------------------------------------------------------------
REPORT_OPTION_KINDS = ("condition", "recommendation")


@route("GET", r"/api/report-options")
def list_report_options(ctx):
    """The pick lists. Anyone who may write a report needs to read them;
    whoever maintains them also sees the ones switched off."""
    require_perm(ctx.user, "visits.view")
    where, params = [], []
    kind = ctx.query.get("kind")
    if kind:
        if kind not in REPORT_OPTION_KINDS:
            raise ApiError(400, "Unknown option kind")
        where.append("kind=?"); params.append(kind)
    if not has_perm(ctx.user, "settings.edit"):
        where.append("active=1")
    sql = "SELECT * FROM report_options"
    if where:
        sql += " WHERE " + " AND ".join(where)
    return db.query(sql + " ORDER BY kind, sort_order, id", params)


def _report_option_fields(b, existing=None):
    kind = (b.get("kind") or (existing or {}).get("kind") or "").strip()
    if kind not in REPORT_OPTION_KINDS:
        raise ApiError(400, "Unknown option kind")
    name_en = str(b.get("name_en") if "name_en" in b else (existing or {}).get("name_en") or "").strip()
    if not name_en:
        raise ApiError(400, "A wording is required")
    name_ar = b.get("name_ar") if "name_ar" in b else (existing or {}).get("name_ar")
    order = b.get("sort_order") if "sort_order" in b else (existing or {}).get("sort_order", 0)
    active = b.get("active") if "active" in b else (existing or {}).get("active", 1)
    try:
        order = int(order or 0)
    except (TypeError, ValueError):
        order = 0
    return kind, name_en[:300], (str(name_ar).strip()[:300] if name_ar else None), order, (1 if active else 0)


@route("POST", r"/api/report-options")
def create_report_option(ctx):
    require_perm(ctx.user, "settings.edit")
    kind, en, ar, order, active = _report_option_fields(ctx.body)
    rid = db.execute("INSERT INTO report_options(kind,name_en,name_ar,sort_order,active) "
                     "VALUES(?,?,?,?,?)", (kind, en, ar, order, active))
    audit(ctx, "reportoption.create", "report_option", rid, f"{kind}: {en}")
    return db.query("SELECT * FROM report_options WHERE id=?", (rid,), one=True)


@route("PUT", r"/api/report-options/(\d+)")
def update_report_option(ctx):
    require_perm(ctx.user, "settings.edit")
    oid = int(ctx.params[0])
    existing = db.query("SELECT * FROM report_options WHERE id=?", (oid,), one=True)
    if not existing:
        raise ApiError(404, "Option not found")
    kind, en, ar, order, active = _report_option_fields(ctx.body, existing)
    db.execute("UPDATE report_options SET kind=?,name_en=?,name_ar=?,sort_order=?,active=? "
               "WHERE id=?", (kind, en, ar, order, active, oid))
    audit(ctx, "reportoption.update", "report_option", oid, f"{kind}: {en}")
    return db.query("SELECT * FROM report_options WHERE id=?", (oid,), one=True)


@route("DELETE", r"/api/report-options/(\d+)")
def delete_report_option(ctx):
    require_perm(ctx.user, "settings.edit")
    oid = int(ctx.params[0])
    existing = db.query("SELECT * FROM report_options WHERE id=?", (oid,), one=True)
    if not existing:
        raise ApiError(404, "Option not found")
    db.execute("DELETE FROM report_options WHERE id=?", (oid,))
    audit(ctx, "reportoption.delete", "report_option", oid, existing["name_en"])
    return {"deleted": True}


def _report_scope(ctx):
    """Role scoping plus the Reports page filters, as (where, params) over the
    aliases r=reports, v=visits. Shared by the list and the spreadsheet export
    so the two can never disagree about which reports a user may see."""
    u = ctx.user
    where, params = [], []
    if u["role"] == "client":
        where.append("v.client_id=?"); params.append(u["client_id"])
        sid = client_site_scope_id(u)
        if sid:
            where.append("(v.site_id IS NULL OR v.site_id=?)"); params.append(sid)
    elif u["role"] == "agent":
        where.append("v.agent_id=?"); params.append(u["id"])
    elif u["role"] in SUPERVISOR_ROLES:
        lc, lp = _sup_visit_clause(u)
        where.append(lc); params += lp
    for key, col in (("client", "v.client_id"), ("agent", "v.agent_id"),
                     ("severity", "r.severity"), ("status", "r.status")):
        if ctx.query.get(key):
            where.append(f"{col}=?"); params.append(ctx.query[key])
    site = ctx.query.get("site")
    if site:
        if str(site) in ("none", "0"):
            where.append("v.site_id IS NULL")
        else:
            where.append("v.site_id=?"); params.append(site)
    if ctx.query.get("from"):
        where.append("date(v.scheduled_start) >= date(?)"); params.append(ctx.query["from"])
    if ctx.query.get("to"):
        where.append("date(v.scheduled_start) <= date(?)"); params.append(ctx.query["to"])
    return where, params


@route("GET", r"/api/reports")
def list_reports(ctx):
    """Central report list for admin/owner, filterable by agent, client,
    location, severity, status and date range."""
    require_perm(ctx.user, "visits.view")
    where, params = _report_scope(ctx)
    sql = ("SELECT r.id, r.visit_id, r.severity, r.status, r.summary, r.pests_found, "
           "r.recommendations, r.created_at, r.completed_at, "
           "v.scheduled_start, v.agent_id, v.client_id, v.site_id, "
           "c.name_en client_en, c.name_ar client_ar, st.name site_name, "
           "u.full_name agent_name "
           "FROM reports r JOIN visits v ON v.id=r.visit_id "
           "JOIN clients c ON c.id=v.client_id "
           "LEFT JOIN sites st ON st.id=v.site_id "
           "LEFT JOIN users u ON u.id=v.agent_id")
    if where:
        sql += " WHERE " + " AND ".join(where)
    _sd = _sort_dir(ctx)
    res = _paginate(ctx, sql, params, f"ORDER BY v.scheduled_start {_sd}, r.id {_sd}")
    lang = ctx.query.get("lang")
    if lang in ("en", "ar"):
        for r in (res["items"] if isinstance(res, dict) else res):
            if r.get("summary"):
                r["summary"] = _translate(r["summary"], lang)
    return res


# --------------------------------------------------------------------------
# TRANSPORTATION — internal travel-cost log recorded on visit reports.
# Never exposed to client accounts (no transport.view perm, plus a hard block).
# Agents are scoped to their own trips; managers/admins see everyone and get
# cost totals grouped by branch, client and agent.
# --------------------------------------------------------------------------
@route("GET", r"/api/transport")
def list_transport(ctx):
    u = ctx.user
    require_perm(u, "transport.view")
    if u["role"] == "client":
        raise ApiError(403, "Not available to client accounts")
    where, params = ["1=1"], []
    if u["role"] == "agent":
        where.append("v.agent_id=?"); params.append(u["id"])
    for key, col in (("client", "v.client_id"), ("agent", "v.agent_id")):
        if ctx.query.get(key):
            where.append(f"{col}=?"); params.append(ctx.query[key])
    site = ctx.query.get("site")
    if site:
        if str(site) in ("none", "0"):
            where.append("v.site_id IS NULL")
        else:
            where.append("v.site_id=?"); params.append(site)
    if ctx.query.get("from"):
        where.append("date(v.scheduled_start) >= date(?)"); params.append(ctx.query["from"])
    if ctx.query.get("to"):
        where.append("date(v.scheduled_start) <= date(?)"); params.append(ctx.query["to"])
    base = ("FROM transport_entries e JOIN visits v ON v.id=e.visit_id "
            "JOIN clients c ON c.id=v.client_id "
            "LEFT JOIN sites st ON st.id=v.site_id "
            "LEFT JOIN users u2 ON u2.id=v.agent_id "
            "WHERE " + " AND ".join(where))
    res = _paginate(
        ctx,
        "SELECT e.id, e.visit_id, e.vehicle transport_vehicle, e.from_place, e.to_place, "
        "e.cost transport_cost, "
        "v.scheduled_start, v.agent_id, v.client_id, v.site_id, "
        "c.name_en client_en, c.name_ar client_ar, st.name site_name, "
        "u2.full_name agent_name " + base,
        params, "ORDER BY v.scheduled_start DESC, e.id DESC")
    out = res if isinstance(res, dict) else {"items": res}
    tot = db.query("SELECT COUNT(*) trips, COALESCE(SUM(e.cost),0) total "
                   + base, params, one=True)
    out["trips"] = tot["trips"]
    out["total"] = tot["total"]
    # Cost roll-ups for the owner/CEO view (grouped over the same filter scope).
    out["by_branch"] = db.query(
        "SELECT c.name_en client_en, c.name_ar client_ar, st.name site_name, "
        "COUNT(*) trips, COALESCE(SUM(e.cost),0) total "
        + base + " GROUP BY v.client_id, v.site_id ORDER BY total DESC", params)
    out["by_client"] = db.query(
        "SELECT c.name_en client_en, c.name_ar client_ar, "
        "COUNT(*) trips, COALESCE(SUM(e.cost),0) total "
        + base + " GROUP BY v.client_id ORDER BY total DESC", params)
    out["by_agent"] = db.query(
        "SELECT u2.full_name agent_name, "
        "COUNT(*) trips, COALESCE(SUM(e.cost),0) total "
        + base + " GROUP BY v.agent_id ORDER BY total DESC", params)
    return out


@route("POST", r"/api/visits/(\d+)/transport")
def add_transport(ctx):
    """Agent adds one transportation trip (from -> to + cost) to a visit. Any
    number of trips per visit. `vehicle` is still accepted so an app.js cached
    from before the From/To boxes keeps working."""
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    require_perm(u, "visits.edit")
    if u["role"] == "client":
        raise ApiError(403, "Not available to client accounts")
    if u["role"] == "agent" and v["agent_id"] != u["id"]:
        raise ApiError(403, "Not your visit")
    _assert_sup_visit(u, v)
    b = ctx.body
    vehicle = str(b.get("vehicle") or "").strip() or None
    frm = str(b.get("from_place") or "").strip()[:120] or None
    to = str(b.get("to_place") or "").strip()[:120] or None
    try:
        cost = float(b.get("cost")) if str(b.get("cost") or "").strip() != "" else 0.0
    except (TypeError, ValueError):
        raise ApiError(400, "Cost must be a number")
    if not math.isfinite(cost) or cost < 0:
        raise ApiError(400, "Cost must be a positive number")
    if not (frm or to or vehicle) and cost <= 0:
        raise ApiError(400, "Enter where the trip went from and to, or a cost")
    eid = db.execute("INSERT INTO transport_entries"
                     "(visit_id,vehicle,from_place,to_place,cost,created_by) "
                     "VALUES(?,?,?,?,?,?)", (vid, vehicle, frm, to, cost, u["id"]))
    return db.query("SELECT * FROM transport_entries WHERE id=?", (eid,), one=True)


@route("DELETE", r"/api/transport/(\d+)")
def delete_transport(ctx):
    u = ctx.user
    require_perm(u, "visits.edit")
    if u["role"] == "client":
        raise ApiError(403, "Not available to client accounts")
    eid = int(ctx.params[0])
    e = db.query("SELECT e.id, v.agent_id FROM transport_entries e "
                 "JOIN visits v ON v.id=e.visit_id WHERE e.id=?", (eid,), one=True)
    if not e:
        raise ApiError(404, "Entry not found")
    if u["role"] == "agent" and e["agent_id"] != u["id"]:
        raise ApiError(403, "Not your visit")
    if u["role"] in SUPERVISOR_ROLES and e["agent_id"] != u["id"]:
        full = db.query("SELECT v.* FROM transport_entries e JOIN visits v ON v.id=e.visit_id "
                        "WHERE e.id=?", (eid,), one=True)
        _assert_sup_visit(u, full)
    db.execute("DELETE FROM transport_entries WHERE id=?", (eid,))
    return {"ok": True}


# --------------------------------------------------------------------------
# CHEMICALS / INVENTORY
# --------------------------------------------------------------------------
# Stock-book columns: what a product costs, how much of it the company holds
# and when to reorder. Only chemicals.view sees these. expiry_date deliberately
# stays — an engineer must know a product is out of date before applying it.
_INVENTORY_ONLY_COLS = ("quantity_in_stock", "reorder_level", "cost_per_unit")


def _catalog_only(rows):
    """Strip the inventory figures, leaving the pick-list an engineer needs
    (name, unit, active ingredient, expiry) to log usage or request materials."""
    return [{k: v for k, v in r.items() if k not in _INVENTORY_ONLY_COLS} for r in rows]


@route("GET", r"/api/chemicals")
def list_chemicals(ctx):
    # Engineers hold issues.view but not chemicals.view: they must be able to
    # NAME a product on a usage line or an issue request, without the company's
    # stock levels and costs coming with it.
    stock = has_perm(ctx.user, "chemicals.view")
    if not stock:
        require_perm(ctx.user, "issues.view")
    q = ctx.query.get("q", "").strip()
    if q:
        rows = db.query(
            "SELECT * FROM chemicals WHERE name_en LIKE ? OR name_ar LIKE ? OR active_ingredient LIKE ? "
            "ORDER BY name_en", (f"%{q}%", f"%{q}%", f"%{q}%"))
    else:
        rows = db.query("SELECT * FROM chemicals ORDER BY name_en")
    return rows if stock else _catalog_only(rows)


@route("POST", r"/api/chemicals")
def create_chemical(ctx):
    require_perm(ctx.user, "chemicals.create")
    b = ctx.body
    if not b.get("name_en"):
        raise ApiError(400, "Name is required")
    cid = db.execute(
        "INSERT INTO chemicals(name_en,name_ar,active_ingredient,unit,quantity_in_stock,"
        "reorder_level,hazard_class,reg_no,cost_per_unit,expiry_date) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (b["name_en"], b.get("name_ar"), b.get("active_ingredient"), b.get("unit", "L"),
         b.get("quantity_in_stock", 0), b.get("reorder_level", 0), b.get("hazard_class"),
         b.get("reg_no"), b.get("cost_per_unit", 0), b.get("expiry_date") or None))
    return db.query("SELECT * FROM chemicals WHERE id=?", (cid,), one=True)


@route("PUT", r"/api/chemicals/(\d+)")
def update_chemical(ctx):
    require_perm(ctx.user, "chemicals.edit")
    cid = int(ctx.params[0])
    b = ctx.body
    cols = ("name_en", "name_ar", "active_ingredient", "unit", "reorder_level",
            "hazard_class", "reg_no", "cost_per_unit", "expiry_date")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [b[c] for c in cols if c in b]
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(cid)
    db.execute(f"UPDATE chemicals SET {','.join(fields)} WHERE id=?", vals)
    return db.query("SELECT * FROM chemicals WHERE id=?", (cid,), one=True)


@route("DELETE", r"/api/chemicals/(\d+)")
def delete_chemical(ctx):
    require_perm(ctx.user, "chemicals.delete")
    db.execute("DELETE FROM chemicals WHERE id=?", (int(ctx.params[0]),))
    return {"ok": True}


@route("POST", r"/api/chemicals/(\d+)/stock")
def adjust_stock(ctx):
    require_perm(ctx.user, "chemicals.edit")
    cid = int(ctx.params[0])
    b = ctx.body
    change = float(b.get("change", 0))
    reason = b.get("reason", "adjustment")
    if reason not in ("purchase", "adjustment"):
        raise ApiError(400, "Invalid reason")
    with db.transaction() as cx:
        cx.execute("UPDATE chemicals SET quantity_in_stock = quantity_in_stock + ? WHERE id=?", (change, cid))
        cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,note) VALUES(?,?,?,?)",
                   (cid, change, reason, b.get("note")))
    audit(ctx, "stock.adjust", "chemical", cid, f"{reason} {change:+g}")
    return db.query("SELECT * FROM chemicals WHERE id=?", (cid,), one=True)


@route("GET", r"/api/purchase-orders")
def list_purchase_orders(ctx):
    require_perm(ctx.user, "chemicals.view")
    pos = db.query("SELECT po.*, u.full_name created_by_name FROM purchase_orders po "
                   "LEFT JOIN users u ON u.id=po.created_by "
                   "ORDER BY po.created_at DESC LIMIT 100")
    for po in pos:
        po["items"] = db.query(
            "SELECT pi.*, c.name_en, c.name_ar, c.unit FROM purchase_order_items pi "
            "JOIN chemicals c ON c.id=pi.chemical_id WHERE pi.po_id=?", (po["id"],))
    return pos


def _po_lines(b):
    """Validate a purchase order's item lines -> [(chemical_id, qty, unit_cost)]."""
    lines = []
    for it in (b.get("items") or []):
        try:
            chem_id = int(it.get("chemical_id"))
            qty = float(it.get("quantity"))
            cost = float(it.get("unit_cost") or 0)
        except (TypeError, ValueError):
            raise ApiError(400, "Invalid item line")
        if qty <= 0 or cost < 0:
            raise ApiError(400, "Quantity must be positive")
        if not db.query("SELECT 1 FROM chemicals WHERE id=?", (chem_id,), one=True):
            raise ApiError(404, f"Chemical {chem_id} not found")
        lines.append((chem_id, qty, cost))
    if not lines:
        raise ApiError(400, "At least one item is required")
    return lines


def _apply_stock_delta(cx, delta):
    """Move stock by {chemical_id: signed change} inside an open transaction.

    Correcting or removing a purchase takes stock back out. If part of it has
    already been issued or used the correction would drive the count negative,
    which is a real-world discrepancy, not an arithmetic one — so it is refused
    and someone counts the shelf instead of the ledger silently going wrong."""
    for cid, d in delta.items():
        if not d:
            continue
        row = cx.execute("SELECT name_en, quantity_in_stock FROM chemicals WHERE id=?", (cid,)).fetchone()
        if row is None:
            raise ApiError(404, f"Chemical {cid} not found")
        have = row["quantity_in_stock"] or 0
        after = round(have + d, 4)
        if after < 0:
            raise ApiError(400, f"{row['name_en']}: only {have:g} in stock, "
                                f"{-d:g} would have to come back out — it has already been used or issued")
        cx.execute("UPDATE chemicals SET quantity_in_stock=? WHERE id=?", (after, cid))


@route("POST", r"/api/purchase-orders")
def create_purchase_order(ctx):
    """Stock-in: record a purchase and increment inventory in one transaction."""
    require_perm(ctx.user, "chemicals.edit")
    b = ctx.body
    lines = _po_lines(b)
    total = round(sum(q * c for _, q, c in lines), 2)
    with db.transaction() as cx:
        poid = cx.execute(
            "INSERT INTO purchase_orders(supplier,reference,note,total_cost,created_by) "
            "VALUES(?,?,?,?,?)",
            (b.get("supplier"), b.get("reference"), b.get("note"), total,
             ctx.user["id"])).lastrowid
        for chem_id, qty, cost in lines:
            cx.execute("INSERT INTO purchase_order_items(po_id,chemical_id,quantity,unit_cost) "
                       "VALUES(?,?,?,?)", (poid, chem_id, qty, cost))
            cx.execute("UPDATE chemicals SET quantity_in_stock = quantity_in_stock + ? "
                       "WHERE id=?", (qty, chem_id))
            cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,reference,note) "
                       "VALUES(?,?,'purchase',?,?)",
                       (chem_id, qty, f"PO-{poid}", b.get("supplier")))
    audit(ctx, "purchase.create", "purchase_order", poid,
          f"{len(lines)} item(s), total {total:g}" + (f" from {b['supplier']}" if b.get("supplier") else ""))
    return _po_row(poid)


def _po_row(poid):
    po = db.query("SELECT po.*, u.full_name created_by_name FROM purchase_orders po "
                  "LEFT JOIN users u ON u.id=po.created_by WHERE po.id=?", (poid,), one=True)
    if po:
        po["items"] = db.query(
            "SELECT pi.*, c.name_en, c.name_ar, c.unit FROM purchase_order_items pi "
            "JOIN chemicals c ON c.id=pi.chemical_id WHERE pi.po_id=?", (poid,))
    return po


@route("PUT", r"/api/purchase-orders/(\d+)")
def update_purchase_order(ctx):
    """Correct a recorded purchase (wrong quantity, wrong price, wrong product).

    Stock moves by the DIFFERENCE, so a 100 that should have been 10 takes 90
    back out; the PO's 'purchase' ledger rows are rewritten to match, keeping
    the inventory history and the cost record telling the same story."""
    require_perm(ctx.user, "chemicals.edit")
    poid = int(ctx.params[0])
    po = db.query("SELECT * FROM purchase_orders WHERE id=?", (poid,), one=True)
    if not po:
        raise ApiError(404, "Not found")
    b = ctx.body
    lines = _po_lines(b)
    total = round(sum(q * c for _, q, c in lines), 2)
    old = db.query("SELECT chemical_id, quantity FROM purchase_order_items WHERE po_id=?", (poid,))
    delta = {}
    for r in old:
        delta[r["chemical_id"]] = delta.get(r["chemical_id"], 0) - r["quantity"]
    for chem_id, qty, _cost in lines:
        delta[chem_id] = delta.get(chem_id, 0) + qty
    supplier = b.get("supplier", po["supplier"])
    with db.transaction() as cx:
        _apply_stock_delta(cx, delta)
        cx.execute("UPDATE purchase_orders SET supplier=?, reference=?, note=?, total_cost=? WHERE id=?",
                   (supplier, b.get("reference", po["reference"]), b.get("note", po["note"]), total, poid))
        cx.execute("DELETE FROM purchase_order_items WHERE po_id=?", (poid,))
        cx.execute("DELETE FROM inventory_transactions WHERE reason='purchase' AND reference=?",
                   (f"PO-{poid}",))
        for chem_id, qty, cost in lines:
            cx.execute("INSERT INTO purchase_order_items(po_id,chemical_id,quantity,unit_cost) "
                       "VALUES(?,?,?,?)", (poid, chem_id, qty, cost))
            cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,reference,note) "
                       "VALUES(?,?,'purchase',?,?)", (chem_id, qty, f"PO-{poid}", supplier))
    audit(ctx, "purchase.update", "purchase_order", poid,
          f"{len(lines)} item(s), total {total:g}")
    return _po_row(poid)


@route("DELETE", r"/api/purchase-orders/(\d+)")
def delete_purchase_order(ctx):
    """Remove a purchase that never happened — the stock it added comes back out
    with it, along with its ledger rows."""
    require_perm(ctx.user, "chemicals.delete")
    poid = int(ctx.params[0])
    po = db.query("SELECT * FROM purchase_orders WHERE id=?", (poid,), one=True)
    if not po:
        raise ApiError(404, "Not found")
    delta = {}
    for r in db.query("SELECT chemical_id, quantity FROM purchase_order_items WHERE po_id=?", (poid,)):
        delta[r["chemical_id"]] = delta.get(r["chemical_id"], 0) - r["quantity"]
    with db.transaction() as cx:
        _apply_stock_delta(cx, delta)
        cx.execute("DELETE FROM inventory_transactions WHERE reason='purchase' AND reference=?",
                   (f"PO-{poid}",))
        cx.execute("DELETE FROM purchase_order_items WHERE po_id=?", (poid,))
        cx.execute("DELETE FROM purchase_orders WHERE id=?", (poid,))
    audit(ctx, "purchase.delete", "purchase_order", poid,
          f"total {po['total_cost']:g}" + (f" from {po['supplier']}" if po["supplier"] else ""))
    return {"ok": True}


@route("GET", r"/api/chemicals/(\d+)/transactions")
def chemical_transactions(ctx):
    require_perm(ctx.user, "chemicals.view")
    return db.query("SELECT * FROM inventory_transactions WHERE chemical_id=? ORDER BY created_at DESC",
                    (int(ctx.params[0]),))


# How a chemical was applied on a visit, and the kit it was applied with. The
# client renders the same two lists (t("am_"+key) / t("aq_"+key)).
APPLICATION_METHODS = ("by_hand", "spraying", "painting", "gel_application",
                       "ulv_application", "dusting", "fogging")
APPLICATION_EQUIPMENT = ("sprayer", "brush", "duster", "ulv_machine", "hand", "fogger")


@route("POST", r"/api/visits/(\d+)/usage")
def record_usage(ctx):
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    require_perm(u, "visits.edit")
    if u["role"] == "agent" and v["agent_id"] != u["id"]:
        raise ApiError(403, "Not your visit")
    _assert_sup_visit(u, v)
    b = ctx.body
    chem_id = b.get("chemical_id")
    qty = float(b.get("quantity", 0))
    if not chem_id or qty <= 0:
        raise ApiError(400, "Chemical and a positive quantity are required")
    chem = db.query("SELECT material_key FROM chemicals WHERE id=?", (chem_id,), one=True)
    if not chem:
        raise ApiError(400, "Unknown chemical")
    # Consumable materials (UV lamps, glue boards, ...) used to be counted on the
    # report instead of here, and were refused at this door to stop the same lamp
    # being counted twice. Those counters are no longer filled in, so this is now
    # the one place a material is recorded as used — same as any other product.
    # Material consumed on a visit comes out of the engineer's issued on-hand
    # balance (issued − used), NOT central warehouse stock — that was already
    # decremented when the material was issued to the engineer. So we only
    # record the usage; we do not touch chemicals.quantity_in_stock here.
    # How it was applied and with what. Both optional (older rows have neither)
    # and both stored as keys — anything off the list is dropped rather than
    # kept as free text, so the printed report can always name it in either
    # language.
    method = b.get("method") if b.get("method") in APPLICATION_METHODS else None
    equipment = b.get("equipment") if b.get("equipment") in APPLICATION_EQUIPMENT else None
    uid = db.execute(
        "INSERT INTO chemical_usage(visit_id,chemical_id,quantity,area_treated,method,equipment) "
        "VALUES(?,?,?,?,?,?)",
        (vid, chem_id, qty, b.get("area_treated"), method, equipment))
    return db.query(
        "SELECT cu.*, ch.name_en, ch.name_ar, ch.unit FROM chemical_usage cu "
        "JOIN chemicals ch ON ch.id=cu.chemical_id WHERE cu.id=?", (uid,), one=True)


@route("DELETE", r"/api/usage/(\d+)")
def delete_usage(ctx):
    require_perm(ctx.user, "visits.edit")
    uid = int(ctx.params[0])
    row = db.query("SELECT * FROM chemical_usage WHERE id=?", (uid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    # Usage no longer touches central stock (see record_usage), so removing it
    # simply restores the engineer's on-hand balance — nothing to credit back
    # to the warehouse.
    db.execute("DELETE FROM chemical_usage WHERE id=?", (uid,))
    return {"ok": True}


# --------------------------------------------------------------------------
# ENGINEER MATERIAL ISSUES (stock an engineer checks out of inventory)
# --------------------------------------------------------------------------
def _issue_with_items(iid):
    issue = db.query(
        "SELECT ei.*, u.full_name AS agent_name FROM engineer_issues ei "
        "JOIN users u ON u.id=ei.agent_id WHERE ei.id=?", (iid,), one=True)
    if issue:
        issue["items"] = db.query(
            "SELECT it.*, ch.name_en, ch.name_ar, ch.unit FROM engineer_issue_items it "
            "JOIN chemicals ch ON ch.id=it.chemical_id WHERE it.issue_id=? ORDER BY it.id", (iid,))
    return issue


@route("GET", r"/api/issues")
def list_issues(ctx):
    require_perm(ctx.user, "issues.view")
    u = ctx.user
    where, params = [], []
    if u["role"] == "agent":                       # engineers see only their own
        where.append("ei.agent_id=?"); params.append(u["id"])
    elif ctx.query.get("agent_id"):
        where.append("ei.agent_id=?"); params.append(int(ctx.query["agent_id"]))
    if ctx.query.get("status") in ("requested", "approved", "declined"):
        where.append("ei.status=?"); params.append(ctx.query["status"])
    if ctx.query.get("receipt") in ("pending", "received", "disputed"):
        if ctx.query["receipt"] == "pending":
            where.append("ei.status='approved' AND ei.receipt_status IS NULL")
        else:
            where.append("ei.receipt_status=?"); params.append(ctx.query["receipt"])
    sql = ("SELECT ei.id, ei.agent_id, ei.note, ei.created_at, ei.status, "
           "ei.handled_at, ei.decline_reason, ei.receipt_status, ei.receipt_at, "
           "ei.receipt_note, u.full_name AS agent_name, "
           "h.full_name AS handled_by_name, "
           "(SELECT COUNT(*) FROM engineer_issue_items it WHERE it.issue_id=ei.id) AS item_count "
           "FROM engineer_issues ei JOIN users u ON u.id=ei.agent_id "
           "LEFT JOIN users h ON h.id=ei.handled_by")
    if where:
        sql += " WHERE " + " AND ".join(where)
    # Whatever is waiting on somebody goes first: requests waiting on the office,
    # then handovers waiting on the engineer to say they got them.
    sql += (" ORDER BY (ei.status='requested') DESC, "
            "(ei.status='approved' AND ei.receipt_status IS NULL) DESC, "
            "ei.created_at DESC")
    return db.query(sql, tuple(params))


def _engineer_materials(agent_filter=None):
    """agent_id -> chemical_id -> {issued, used, returned}. The one place the
    field stock is worked out, so the balance page and the "you cannot hand
    back more than you hold" check can never disagree."""
    # Only APPROVED rows are real issues — a request that is still waiting (or was
    # declined) has moved no stock and must not show as materials on hand.
    iss_where, iss_params = " WHERE ei.status='approved'", []
    use_where, use_params = "", []
    if agent_filter is not None:
        iss_where += " AND ei.agent_id=?"; iss_params = [agent_filter]
        use_where = " AND v.agent_id=?"; use_params = [agent_filter]
    issued = db.query(
        "SELECT ei.agent_id, it.chemical_id, "
        "SUM(COALESCE(it.approved_quantity, it.quantity)) qty "
        "FROM engineer_issues ei JOIN engineer_issue_items it ON it.issue_id=ei.id"
        + iss_where + " AND COALESCE(it.line_status,'approved')='approved'"
        + " GROUP BY ei.agent_id, it.chemical_id", iss_params)
    used = db.query(
        "SELECT v.agent_id, cu.chemical_id, SUM(cu.quantity) qty "
        "FROM chemical_usage cu JOIN visits v ON v.id=cu.visit_id "
        "WHERE v.agent_id IS NOT NULL" + use_where
        + " GROUP BY v.agent_id, cu.chemical_id", use_params)
    chems = {c["id"]: c for c in db.query("SELECT id,name_en,name_ar,unit FROM chemicals")}
    names = {a["id"]: a["full_name"] for a in db.query("SELECT id,full_name FROM users")}
    # Material handed back and signed for by the warehouse has left the
    # engineer exactly as surely as material used on a visit.
    ret_where, ret_params = (" AND mr.agent_id=?", [agent_filter]) if agent_filter is not None else ("", [])
    returned = db.query(
        "SELECT mr.agent_id, ri.chemical_id, "
        "SUM(COALESCE(ri.approved_quantity, ri.quantity)) qty "
        "FROM material_returns mr JOIN material_return_items ri ON ri.return_id=mr.id "
        "WHERE mr.status='approved' AND mr.receipt_status='received' "
        "AND COALESCE(ri.line_status,'approved')='approved'" + ret_where +
        " GROUP BY mr.agent_id, ri.chemical_id", ret_params)
    blank = lambda: {"issued": 0.0, "used": 0.0, "returned": 0.0}
    eng = {}  # agent_id -> {chemical_id -> {issued, used, returned}}
    for r in issued:
        eng.setdefault(r["agent_id"], {}).setdefault(r["chemical_id"], blank())["issued"] = r["qty"] or 0
    for r in used:
        eng.setdefault(r["agent_id"], {}).setdefault(r["chemical_id"], blank())["used"] = r["qty"] or 0
    for r in returned:
        eng.setdefault(r["agent_id"], {}).setdefault(r["chemical_id"], blank())["returned"] = r["qty"] or 0
    # Consumable materials (lamps, glue boards, ...) are recorded as report
    # counters rather than chemical_usage rows, so fold those into "used" too.
    # material_key values are server-defined (see _migrate), never user input,
    # so building the column list from them is safe.
    mat_items = db.query("SELECT id, material_key FROM chemicals WHERE material_key IS NOT NULL")
    if mat_items:
        cols_sql = ",".join(f"COALESCE(SUM(r.{m['material_key']}),0) {m['material_key']}"
                            for m in mat_items)
        mat_rows = db.query(
            "SELECT v.agent_id, " + cols_sql +
            " FROM reports r JOIN visits v ON v.id=r.visit_id "
            "WHERE v.agent_id IS NOT NULL" + use_where + " GROUP BY v.agent_id", use_params)
        for r in mat_rows:
            for m in mat_items:
                q = r[m["material_key"]] or 0
                if q:
                    eng.setdefault(r["agent_id"], {}).setdefault(m["id"], blank())["used"] += q
    return eng, chems, names


@route("GET", r"/api/issues/balance")
def issues_balance(ctx):
    """Per-engineer materials balance: ISSUED minus what was USED on their own
    visits minus what they HANDED BACK = what is still on hand. Derived live,
    so it drops as visits log usage and as returns are signed for.
    Agents see only their own; managers/admins can filter with ?agent_id=."""
    u = ctx.user
    require_perm(u, "issues.view")
    agent_filter = u["id"] if u["role"] == "agent" else (
        int(ctx.query["agent_id"]) if ctx.query.get("agent_id") else None)
    eng, chems, names = _engineer_materials(agent_filter)
    out = []
    for aid, mats in eng.items():
        materials = []
        for cid, bal in mats.items():
            ch = chems.get(cid, {})
            issued_q, used_q = round(bal["issued"], 3), round(bal["used"], 3)
            ret_q = round(bal.get("returned", 0), 3)
            materials.append({
                "chemical_id": cid, "name_en": ch.get("name_en"),
                "name_ar": ch.get("name_ar"), "unit": ch.get("unit"),
                "issued": issued_q, "used": used_q, "returned": ret_q,
                "remaining": round(issued_q - used_q - ret_q, 3)})
        materials.sort(key=lambda m: (m["name_en"] or "").lower())
        out.append({"agent_id": aid, "agent_name": names.get(aid, "?"), "materials": materials})
    out.sort(key=lambda e: (e["agent_name"] or "").lower())
    return {"engineers": out}


@route("GET", r"/api/issues/(\d+)")
def get_issue(ctx):
    require_perm(ctx.user, "issues.view")
    issue = _issue_with_items(int(ctx.params[0]))
    if not issue:
        raise ApiError(404, "Issue not found")
    if (ctx.user["role"] in ("agent",) + SUPERVISOR_ROLES and issue["agent_id"] != ctx.user["id"]
            and not has_perm(ctx.user, "issues.approve")):
        raise ApiError(403, "Not your issue")
    return issue


@route("POST", r"/api/issues")
def create_issue(ctx):
    require_perm(ctx.user, "issues.create")
    u = ctx.user
    b = ctx.body
    # who the materials are issued to (agents may only issue to themselves)
    agent_id = u["id"]
    if u["role"] in ("admin", "manager") and b.get("agent_id"):
        agent_id = int(b["agent_id"])
    target = db.query("SELECT id FROM users WHERE id=? AND active=1", (agent_id,), one=True)
    if not target:
        raise ApiError(400, "Engineer not found")
    # normalise + validate line items
    clean = []
    for it in (b.get("items") or []):
        cid = it.get("chemical_id")
        qty = float(it.get("quantity", 0) or 0)
        if cid and qty > 0:
            clean.append((int(cid), qty))
    if not clean:
        raise ApiError(400, "Add at least one material with a positive quantity")
    # An engineer does not help themselves to the store: what they submit is a
    # REQUEST, and no stock moves until someone with issues.approve releases it.
    # Anyone who can approve (the office/owner) still issues in a single step.
    if not has_perm(u, "issues.approve"):
        with db.transaction() as cx:
            iid = cx.execute("INSERT INTO engineer_issues(agent_id,note,created_by,status) "
                             "VALUES(?,?,?,'requested')",
                             (agent_id, b.get("note"), u["id"])).lastrowid
            for cid, qty in clean:
                cx.execute("INSERT INTO engineer_issue_items(issue_id,chemical_id,quantity) "
                           "VALUES(?,?,?)", (iid, cid, qty))
        audit(ctx, "issue.request", "engineer_issue", iid,
              f"agent:{agent_id} items:{len(clean)}")
        _notify_roles(("admin", "manager"), "issue_request", "Materials requested",
                      f"{u['full_name']} requested {len(clean)} material(s).",
                      link_view="issues", link_id=iid,
                      dedup_key=f"issuereq:{iid}", exclude=u["id"])
        return _issue_with_items(iid)
    _assert_stock_for(clean)
    with db.transaction() as cx:
        iid = cx.execute("INSERT INTO engineer_issues(agent_id,note,created_by,status,"
                         "handled_by,handled_at) VALUES(?,?,?,'approved',?,datetime('now','localtime'))",
                         (agent_id, b.get("note"), u["id"], u["id"])).lastrowid
        for cid, qty in clean:
            cx.execute("INSERT INTO engineer_issue_items(issue_id,chemical_id,quantity) VALUES(?,?,?)",
                       (iid, cid, qty))
        _release_stock(cx, iid, clean)
    audit(ctx, "issue.create", "engineer_issue", iid, f"agent:{agent_id} items:{len(clean)}")
    if agent_id != u["id"]:
        _notify(agent_id, "issue_approved", "Materials issued to you",
                f"{len(clean)} material(s) were issued to you. Confirm when you have them.",
                link_view="issues", link_id=iid, dedup_key=f"issueok:{iid}")
    return _issue_with_items(iid)


def _assert_stock_for(items):
    """Refuse before anything moves if the warehouse cannot cover the list.
    items = [(chemical_id, qty)]; a material listed twice is summed."""
    needed = {}
    for cid, qty in items:
        needed[cid] = needed.get(cid, 0) + qty
    for cid, qty in needed.items():
        chem = db.query("SELECT name_en, unit, quantity_in_stock FROM chemicals WHERE id=?",
                        (cid,), one=True)
        if not chem:
            raise ApiError(400, "Unknown material")
        if qty > chem["quantity_in_stock"]:
            raise ApiError(400, f"Not enough {chem['name_en']} in stock "
                                f"({chem['quantity_in_stock']:g} {chem['unit']} available, {qty:g} requested)")


def _release_stock(cx, iid, items):
    """The single point where materials leave central stock (a visit's usage draws
    down the engineer's on-hand balance instead — see record_usage). Runs inside
    the caller's transaction."""
    for cid, qty in items:
        cx.execute("UPDATE chemicals SET quantity_in_stock = quantity_in_stock - ? WHERE id=?",
                   (qty, cid))
        cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,reference) "
                   "VALUES(?,?,?,?)", (cid, -qty, "issue", f"issue:{iid}"))


def _approval_decisions(body, rows):
    """Read the office's line-by-line answer into (decisions, approved) where
    decisions is [(item_id, line_status, approved_qty)] and approved is the
    [(chemical_id, qty)] that will actually leave stock.

    A line nobody mentions is approved exactly as asked, so a client that knows
    nothing about per-line approval (an old app, the offline queue) still
    approves the whole request the way it always did."""
    asked = {}
    for d in (body.get("items") or []):
        try:
            asked[int(d.get("id"))] = d
        except (TypeError, ValueError):
            raise ApiError(400, "Each line needs its id")
    decisions, approved = [], []
    for it in rows:
        d = asked.get(it["id"])
        if d is not None and not d.get("approved", True):
            decisions.append((it["id"], "declined", None))
            continue
        qty = it["quantity"]
        if d is not None and d.get("quantity") not in (None, ""):
            try:
                qty = float(d["quantity"])
            except (TypeError, ValueError):
                raise ApiError(400, "A quantity must be a number")
            if not math.isfinite(qty) or qty <= 0:
                raise ApiError(400, "An approved quantity must be more than zero")
            if qty > it["quantity"]:
                raise ApiError(400, "An approved quantity cannot exceed what was requested")
        decisions.append((it["id"], "approved", qty))
        approved.append((it["chemical_id"], qty))
    return decisions, approved


@route("POST", r"/api/issues/(\d+)/approve")
def approve_issue(ctx):
    """Approving IS the issuing: stock is checked and deducted here, and the
    request becomes the engineer's issue.

    The office answers line by line — approve some materials, decline others,
    cut a quantity — and only what was approved leaves stock. Approving nothing
    is a decline of the whole request rather than an issue of nothing."""
    require_perm(ctx.user, "issues.approve")
    iid = int(ctx.params[0])
    issue = db.query("SELECT * FROM engineer_issues WHERE id=?", (iid,), one=True)
    if not issue:
        raise ApiError(404, "Request not found")
    if issue["status"] != "requested":
        raise ApiError(400, "This request has already been handled")
    rows = db.query("SELECT * FROM engineer_issue_items WHERE issue_id=? ORDER BY id", (iid,))
    if not rows:
        raise ApiError(400, "This request has no materials")
    decisions, approved = _approval_decisions(ctx.body, rows)
    if not approved:
        raise ApiError(400, "Nothing was approved — decline the request instead")
    _assert_stock_for(approved)   # stock is checked NOW, not when it was asked for
    with db.transaction() as cx:
        for item_id, line_status, qty in decisions:
            cx.execute("UPDATE engineer_issue_items SET line_status=?, approved_quantity=? "
                       "WHERE id=?", (line_status, qty, item_id))
        cx.execute("UPDATE engineer_issues SET status='approved', handled_by=?, "
                   "handled_at=datetime('now','localtime'), decline_reason=NULL WHERE id=?",
                   (ctx.user["id"], iid))
        _release_stock(cx, iid, approved)
    cut = len(rows) - len(approved)
    audit(ctx, "issue.approve", "engineer_issue", iid,
          f"agent:{issue['agent_id']} approved:{len(approved)}/{len(rows)}")
    _notify(issue["agent_id"], "issue_approved", "Materials approved",
            (f"{len(approved)} of {len(rows)} materials you asked for were approved. "
             if cut else f"Your request for {len(approved)} material(s) was approved. ")
            + "Confirm when you have them.",
            link_view="issues", link_id=iid, dedup_key=f"issueok:{iid}")
    return _issue_with_items(iid)


def _issue_for_receipt(ctx):
    """The engineer's half of the handover. Only the person the materials went to
    can answer for them — that is the whole point of asking both sides, so an
    admin cannot tick it off on their behalf."""
    iid = int(ctx.params[0])
    issue = db.query("SELECT * FROM engineer_issues WHERE id=?", (iid,), one=True)
    if not issue:
        raise ApiError(404, "Issue not found")
    if issue["agent_id"] != ctx.user["id"]:
        raise ApiError(403, "Only the engineer these materials went to can answer for them")
    if issue["status"] != "approved":
        raise ApiError(400, "These materials have not been issued yet")
    return issue


@route("POST", r"/api/issues/(\d+)/receive")
def receive_issue(ctx):
    """Engineer confirms the materials are in their hands. Stock already moved at
    approval, so this records the handover rather than changing any number."""
    require_perm(ctx.user, "issues.view")
    issue = _issue_for_receipt(ctx)
    if issue["receipt_status"] == "received":
        raise ApiError(400, "You have already confirmed these materials")
    iid = issue["id"]
    note = (ctx.body.get("note") or "").strip() or None
    db.execute("UPDATE engineer_issues SET receipt_status='received', "
               "receipt_at=datetime('now','localtime'), receipt_note=? WHERE id=?", (note, iid))
    audit(ctx, "issue.receive", "engineer_issue", iid, note or "")
    _notify_roles(("admin", "manager"), "issue_received", "Materials confirmed",
                  f"{ctx.user['full_name']} confirmed receiving the materials.",
                  link_view="issues", link_id=iid,
                  dedup_key=f"issuercvd:{iid}", exclude=ctx.user["id"])
    return _issue_with_items(iid)


@route("POST", r"/api/issues/(\d+)/dispute")
def dispute_issue(ctx):
    """Engineer says the materials never reached them. Nothing is moved back
    automatically — an engineer must not be able to unwind a warehouse movement
    on their own — so this flags it for the office to settle."""
    require_perm(ctx.user, "issues.view")
    issue = _issue_for_receipt(ctx)
    if issue["receipt_status"] == "received":
        raise ApiError(400, "You have already confirmed these materials")
    iid = issue["id"]
    reason = (ctx.body.get("reason") or ctx.body.get("note") or "").strip() or None
    db.execute("UPDATE engineer_issues SET receipt_status='disputed', "
               "receipt_at=datetime('now','localtime'), receipt_note=? WHERE id=?", (reason, iid))
    audit(ctx, "issue.dispute", "engineer_issue", iid, reason or "")
    _notify_roles(("admin", "manager"), "issue_disputed", "Materials not received",
                  f"{ctx.user['full_name']} reports not receiving the materials"
                  + (f": {reason}" if reason else "."),
                  link_view="issues", link_id=iid,
                  dedup_key=f"issuedisp:{iid}", exclude=ctx.user["id"])
    return _issue_with_items(iid)


@route("POST", r"/api/issues/(\d+)/decline")
def decline_issue(ctx):
    require_perm(ctx.user, "issues.approve")
    iid = int(ctx.params[0])
    issue = db.query("SELECT * FROM engineer_issues WHERE id=?", (iid,), one=True)
    if not issue:
        raise ApiError(404, "Request not found")
    if issue["status"] != "requested":
        raise ApiError(400, "This request has already been handled")
    reason = (ctx.body.get("reason") or "").strip() or None
    db.execute("UPDATE engineer_issues SET status='declined', handled_by=?, "
               "handled_at=datetime('now','localtime'), decline_reason=? WHERE id=?",
               (ctx.user["id"], reason, iid))
    audit(ctx, "issue.decline", "engineer_issue", iid, reason or "")
    _notify(issue["agent_id"], "issue_declined", "Materials request declined",
            reason or "Your materials request was declined.",
            link_view="issues", link_id=iid, dedup_key=f"issueno:{iid}")
    return _issue_with_items(iid)


@route("DELETE", r"/api/issues/(\d+)")
def delete_issue(ctx):
    require_perm(ctx.user, "issues.delete")
    iid = int(ctx.params[0])
    issue = db.query("SELECT * FROM engineer_issues WHERE id=?", (iid,), one=True)
    if not issue:
        raise ApiError(404, "Issue not found")
    items = db.query("SELECT * FROM engineer_issue_items WHERE issue_id=?", (iid,))
    # Only an APPROVED issue took stock out, so only that one gives it back.
    # Deleting a pending or declined request must not invent inventory.
    give_back = issue["status"] == "approved"
    with db.transaction() as cx:
        if give_back:
            for it in items:
                # Give back what actually left the warehouse: the approved
                # quantity, and nothing at all for a line that was declined.
                if (it["line_status"] or "approved") != "approved":
                    continue
                qty = it["approved_quantity"] if it["approved_quantity"] is not None else it["quantity"]
                cx.execute("UPDATE chemicals SET quantity_in_stock = quantity_in_stock + ? WHERE id=?",
                           (qty, it["chemical_id"]))
                cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,reference) VALUES(?,?,?,?)",
                           (it["chemical_id"], qty, "adjustment", f"issue-reversal:{iid}"))
        cx.execute("DELETE FROM engineer_issues WHERE id=?", (iid,))   # items cascade
    audit(ctx, "issue.delete", "engineer_issue", iid,
          f"{'reversed' if give_back else 'dropped'} {len(items)} items ({issue['status']})")
    return {"ok": True}


# --------------------------------------------------------------------------
# MATERIAL RETURNS — what the engineer brings back.
# The mirror of an issue, and signed for the same twice-over way: the engineer
# declares what is left, the office agrees the quantities (line by line, and it
# may cut them), and the WAREHOUSE confirms the goods are physically back.
# Stock moves on that last step and only then — the office agreeing on paper is
# not the same as the material being on the shelf.
# --------------------------------------------------------------------------
def _return_with_items(rid):
    r = db.query(
        "SELECT mr.*, u.full_name agent_name, h.full_name handled_by_name, "
        "rb.full_name receipt_by_name FROM material_returns mr "
        "JOIN users u ON u.id=mr.agent_id "
        "LEFT JOIN users h ON h.id=mr.handled_by "
        "LEFT JOIN users rb ON rb.id=mr.receipt_by WHERE mr.id=?", (rid,), one=True)
    if not r:
        return None
    r["items"] = db.query(
        "SELECT ri.*, ch.name_en, ch.name_ar, ch.unit FROM material_return_items ri "
        "JOIN chemicals ch ON ch.id=ri.chemical_id WHERE ri.return_id=? ORDER BY ri.id", (rid,))
    return r


def _return_qty(item):
    """What this line is actually worth: the approved quantity if the office set
    one, nothing at all if the line was refused."""
    if (item["line_status"] or "approved") != "approved":
        return 0
    q = item["approved_quantity"]
    return q if q is not None else item["quantity"]


@route("GET", r"/api/returns")
def list_returns(ctx):
    require_perm(ctx.user, "issues.view")
    u = ctx.user
    where, params = ["1=1"], []
    if u["role"] == "agent":
        where.append("mr.agent_id=?"); params.append(u["id"])
    elif (ctx.query.get("agent_id") or "").isdigit():
        where.append("mr.agent_id=?"); params.append(int(ctx.query["agent_id"]))
    if ctx.query.get("status") in ("requested", "approved", "declined"):
        where.append("mr.status=?"); params.append(ctx.query["status"])
    return db.query(
        "SELECT mr.*, u.full_name agent_name, h.full_name handled_by_name, "
        "rb.full_name receipt_by_name, "
        "(SELECT COUNT(*) FROM material_return_items ri WHERE ri.return_id=mr.id) item_count "
        "FROM material_returns mr JOIN users u ON u.id=mr.agent_id "
        "LEFT JOIN users h ON h.id=mr.handled_by LEFT JOIN users rb ON rb.id=mr.receipt_by "
        "WHERE " + " AND ".join(where) +
        " ORDER BY (mr.status='requested') DESC, "
        "(mr.status='approved' AND mr.receipt_status IS NULL) DESC, mr.id DESC LIMIT 300", params)


@route("GET", r"/api/returns/(\d+)")
def get_return(ctx):
    require_perm(ctx.user, "issues.view")
    r = _return_with_items(int(ctx.params[0]))
    if not r:
        raise ApiError(404, "Return not found")
    if (ctx.user["role"] in ("agent",) + SUPERVISOR_ROLES and r["agent_id"] != ctx.user["id"]
            and not has_perm(ctx.user, "issues.approve")):
        raise ApiError(403, "Not your return")
    return r


@route("POST", r"/api/returns")
def create_return(ctx):
    """An engineer hands material back. Nothing moves yet — this is the
    declaration, and it is checked against what they actually hold."""
    require_perm(ctx.user, "issues.create")
    u, b = ctx.user, ctx.body
    agent_id = u["id"]
    if u["role"] != "agent" and str(b.get("agent_id") or "").isdigit():
        agent_id = int(b["agent_id"])
    agent = db.query("SELECT id, role FROM users WHERE id=? AND active=1", (agent_id,), one=True)
    if not agent:
        raise ApiError(404, "Engineer not found")
    raw = b.get("items")
    if not isinstance(raw, list) or not raw:
        raise ApiError(400, "Nothing to return")
    if len(raw) > 50:
        raise ApiError(400, "Too many lines in one return")
    held = _engineer_materials(agent_id)[0].get(agent_id, {})
    # Returns already declared but not yet counted into stock are spoken for:
    # without this, the same leftover drum could be handed back twice and the
    # second signature would mint stock that never existed.
    in_flight = {r["chemical_id"]: (r["qty"] or 0) for r in db.query(
        "SELECT ri.chemical_id, SUM(COALESCE(ri.approved_quantity, ri.quantity)) qty "
        "FROM material_returns mr JOIN material_return_items ri ON ri.return_id=mr.id "
        "WHERE mr.agent_id=? AND mr.status<>'declined' "
        "AND COALESCE(mr.receipt_status,'')<>'received' "
        "AND COALESCE(ri.line_status,'approved')='approved' GROUP BY ri.chemical_id", (agent_id,))}
    lines = []
    for it in raw:
        cid = it.get("chemical_id")
        qty = _finite(it.get("quantity"))
        if not cid or qty is None or qty <= 0:
            raise ApiError(400, "Every line needs a material and a quantity")
        cid = int(cid)
        chem = db.query("SELECT id, name_en FROM chemicals WHERE id=?", (cid,), one=True)
        if not chem:
            raise ApiError(400, "Unknown material")
        bal = held.get(cid, {"issued": 0.0, "used": 0.0, "returned": 0.0})
        remaining = round(bal["issued"] - bal["used"] - bal.get("returned", 0)
                          - in_flight.get(cid, 0), 3)
        # Handing back more than you hold would mint stock out of nothing.
        if qty > remaining + 0.001:
            raise ApiError(400, f"{chem['name_en']}: you are only holding {remaining:g}")
        lines.append((cid, qty))
    with db.transaction() as cx:
        rid = cx.execute(
            "INSERT INTO material_returns(agent_id,note,created_by) VALUES(?,?,?)",
            (agent_id, (b.get("note") or "").strip() or None, u["id"])).lastrowid
        for cid, qty in lines:
            cx.execute("INSERT INTO material_return_items(return_id,chemical_id,quantity) "
                       "VALUES(?,?,?)", (rid, cid, qty))
    audit(ctx, "return.create", "material_return", rid, f"agent:{agent_id} {len(lines)} line(s)")
    _notify_roles(("admin", "manager"), "return_filed", "Materials coming back",
                  f"{u['full_name']} is handing back {len(lines)} material(s).",
                  link_view="issues", link_id=rid, dedup_key=f"ret:{rid}", exclude=u["id"])
    return _return_with_items(rid)


@route("POST", r"/api/returns/(\d+)/approve")
def approve_return(ctx):
    """The office agrees what is coming back — per line, and it may take less
    than was offered. Stock still does not move; the warehouse signs for that."""
    require_perm(ctx.user, "issues.approve")
    rid = int(ctx.params[0])
    r = db.query("SELECT * FROM material_returns WHERE id=?", (rid,), one=True)
    if not r:
        raise ApiError(404, "Return not found")
    if r["status"] != "requested":
        raise ApiError(400, "This return has already been handled")
    rows = db.query("SELECT * FROM material_return_items WHERE return_id=?", (rid,))
    decisions = {}
    for d in (ctx.body.get("items") or []):
        if str(d.get("id") or "").isdigit():
            decisions[int(d["id"])] = d
    approved = []
    with db.transaction() as cx:
        for it in rows:
            d = decisions.get(it["id"], {})
            status = "declined" if d.get("line_status") == "declined" else "approved"
            qty = _finite(d.get("approved_quantity"))
            qty = it["quantity"] if qty is None else qty
            if status == "approved":
                if qty <= 0:
                    status = "declined"
                elif qty > it["quantity"] + 0.001:
                    raise ApiError(400, "Cannot take back more than was offered")
            cx.execute("UPDATE material_return_items SET line_status=?, approved_quantity=? WHERE id=?",
                       (status, qty if status == "approved" else None, it["id"]))
            if status == "approved":
                approved.append(it["id"])
        if not approved:
            raise ApiError(400, "Nothing was approved — decline the return instead")
        cx.execute("UPDATE material_returns SET status='approved', handled_by=?, "
                   "handled_at=datetime('now','localtime') WHERE id=?", (ctx.user["id"], rid))
    audit(ctx, "return.approve", "material_return", rid, f"approved:{len(approved)}/{len(rows)}")
    _notify(r["agent_id"], "return_approved", "Return approved",
            f"{len(approved)} material(s) accepted — hand them to the warehouse.",
            link_view="issues", link_id=rid, dedup_key=f"retok:{rid}")
    _notify_roles(("admin", "manager"), "return_to_receive", "Materials to take in",
                  f"{len(approved)} material(s) approved to come back into stock.",
                  link_view="issues", link_id=rid, dedup_key=f"retrcv:{rid}",
                  exclude=ctx.user["id"])
    return _return_with_items(rid)


@route("POST", r"/api/returns/(\d+)/decline")
def decline_return(ctx):
    require_perm(ctx.user, "issues.approve")
    rid = int(ctx.params[0])
    r = db.query("SELECT * FROM material_returns WHERE id=?", (rid,), one=True)
    if not r:
        raise ApiError(404, "Return not found")
    if r["status"] != "requested":
        raise ApiError(400, "This return has already been handled")
    reason = (ctx.body.get("reason") or "").strip() or None
    db.execute("UPDATE material_returns SET status='declined', handled_by=?, "
               "handled_at=datetime('now','localtime'), decline_reason=? WHERE id=?",
               (ctx.user["id"], reason, rid))
    audit(ctx, "return.decline", "material_return", rid, reason or "")
    _notify(r["agent_id"], "return_declined", "Return declined",
            reason or "Your material return was declined.",
            link_view="issues", link_id=rid, dedup_key=f"retno:{rid}")
    return _return_with_items(rid)


@route("POST", r"/api/returns/(\d+)/receive")
def receive_return(ctx):
    """The second signature: the warehouse has the material in its hands. This
    is the only step that puts anything back on the shelf, and it also takes it
    off the engineer's balance."""
    require_perm(ctx.user, "chemicals.edit")
    rid = int(ctx.params[0])
    r = db.query("SELECT * FROM material_returns WHERE id=?", (rid,), one=True)
    if not r:
        raise ApiError(404, "Return not found")
    if r["status"] != "approved":
        raise ApiError(400, "Only an approved return can be taken into stock")
    if r["receipt_status"] == "received":
        raise ApiError(400, "This return is already in stock")
    items = db.query("SELECT * FROM material_return_items WHERE return_id=?", (rid,))
    note = (ctx.body.get("note") or "").strip() or None
    moved = 0
    with db.transaction() as cx:
        for it in items:
            qty = _return_qty(it)
            if not qty:
                continue
            cx.execute("UPDATE chemicals SET quantity_in_stock = quantity_in_stock + ? WHERE id=?",
                       (qty, it["chemical_id"]))
            cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,reference) "
                       "VALUES(?,?,?,?)", (it["chemical_id"], qty, "adjustment", f"return:{rid}"))
            moved += 1
        cx.execute("UPDATE material_returns SET receipt_status='received', "
                   "receipt_at=datetime('now','localtime'), receipt_by=?, receipt_note=? WHERE id=?",
                   (ctx.user["id"], note, rid))
    audit(ctx, "return.receive", "material_return", rid, f"{moved} line(s) back into stock")
    _notify(r["agent_id"], "return_received", "Materials back in stock",
            "The warehouse has taken your return in — it is off your balance.",
            link_view="issues", link_id=rid, dedup_key=f"retin:{rid}")
    return _return_with_items(rid)


@route("POST", r"/api/returns/(\d+)/dispute")
def dispute_return(ctx):
    """The warehouse says what arrived is not what was agreed. Nothing moves —
    it is flagged for the office and the engineer to settle."""
    require_perm(ctx.user, "chemicals.edit")
    rid = int(ctx.params[0])
    r = db.query("SELECT * FROM material_returns WHERE id=?", (rid,), one=True)
    if not r:
        raise ApiError(404, "Return not found")
    if r["receipt_status"] == "received":
        raise ApiError(400, "This return is already in stock")
    reason = (ctx.body.get("reason") or ctx.body.get("note") or "").strip() or None
    db.execute("UPDATE material_returns SET receipt_status='disputed', "
               "receipt_at=datetime('now','localtime'), receipt_by=?, receipt_note=? WHERE id=?",
               (ctx.user["id"], reason, rid))
    audit(ctx, "return.dispute", "material_return", rid, reason or "")
    _notify(r["agent_id"], "return_disputed", "Return not accepted",
            reason or "The warehouse did not accept your return.",
            link_view="issues", link_id=rid, dedup_key=f"retdisp:{rid}")
    return _return_with_items(rid)


@route("DELETE", r"/api/returns/(\d+)")
def delete_return(ctx):
    require_perm(ctx.user, "issues.delete")
    rid = int(ctx.params[0])
    r = db.query("SELECT * FROM material_returns WHERE id=?", (rid,), one=True)
    if not r:
        raise ApiError(404, "Return not found")
    items = db.query("SELECT * FROM material_return_items WHERE return_id=?", (rid,))
    # Only a return the warehouse actually took in added stock, so only that
    # one takes it away again.
    take_back = r["receipt_status"] == "received"
    with db.transaction() as cx:
        if take_back:
            for it in items:
                qty = _return_qty(it)
                if not qty:
                    continue
                cx.execute("UPDATE chemicals SET quantity_in_stock = quantity_in_stock - ? WHERE id=?",
                           (qty, it["chemical_id"]))
                cx.execute("INSERT INTO inventory_transactions(chemical_id,change,reason,reference) "
                           "VALUES(?,?,?,?)", (it["chemical_id"], -qty, "adjustment", f"return-reversal:{rid}"))
        cx.execute("DELETE FROM material_returns WHERE id=?", (rid,))
    audit(ctx, "return.delete", "material_return", rid,
          f"{'reversed' if take_back else 'dropped'} {len(items)} line(s) ({r['status']})")
    return {"ok": True}


# --------------------------------------------------------------------------
# POCKET MONEY — the float an engineer carries into the field.
# The office hands out an advance; the engineer spends it on a taxi, a part or
# a repair and files what they spent; whatever is left comes back. A claim the
# engineer files waits for the office, and only APPROVED rows move a balance,
# so nobody's float changes because a claim was typed.
# --------------------------------------------------------------------------
# How long a float may sit with an engineer before the ledger says so. Not a
# rule the CRM enforces — money is sometimes meant to stay out — just the point
# at which nobody has looked at it for long enough to be worth a nudge.
CASH_FLOAT_STALE_DAYS = 30
CASH_KINDS = ("advance", "expense", "return")
CASH_CATEGORIES = ("transport", "purchase", "repair", "other")


def _cash_row(cid):
    return db.query(
        "SELECT pc.*, u.full_name agent_name, h.full_name handled_by_name, "
        "cb.full_name created_by_name, "
        "(SELECT COUNT(*) FROM photos p WHERE p.entity_type='cash' AND p.entity_id=pc.id) receipts, "
        "(pc.category='transport' AND pc.visit_id IS NOT NULL AND EXISTS("
        "SELECT 1 FROM transport_entries te WHERE te.visit_id=pc.visit_id)) dup_transport "
        "FROM petty_cash pc "
        "JOIN users u ON u.id=pc.agent_id "
        "LEFT JOIN users h ON h.id=pc.handled_by "
        "LEFT JOIN users cb ON cb.id=pc.created_by WHERE pc.id=?", (cid,), one=True)


def _cash_balance(agent_id=None):
    """Per-engineer float: advances handed out, less spending and returns. Only
    approved rows count; pending claims are reported alongside, never inside."""
    where, params = "", []
    if agent_id:
        where = " AND pc.agent_id=?"
        params.append(agent_id)
    return db.query(
        "SELECT u.id agent_id, u.full_name agent_name, "
        "COALESCE(SUM(CASE WHEN pc.status='approved' AND pc.kind='advance' THEN pc.amount END),0) advanced, "
        "COALESCE(SUM(CASE WHEN pc.status='approved' AND pc.kind='expense' THEN pc.amount END),0) spent, "
        "COALESCE(SUM(CASE WHEN pc.status='approved' AND pc.kind='return' THEN pc.amount END),0) returned, "
        "COALESCE(SUM(CASE WHEN pc.status='pending' AND pc.kind='expense' THEN pc.amount END),0) pending, "
        "COUNT(CASE WHEN pc.status='pending' THEN 1 END) pending_count, "
        # The oldest float still out, and how long a claim has gone unbacked:
        # a ledger nobody audits is a ledger that drifts.
        "MIN(CASE WHEN pc.status='approved' AND pc.kind='advance' THEN date(pc.spent_on) END) oldest_advance, "
        "COUNT(CASE WHEN pc.kind='expense' AND pc.status<>'declined' "
        "AND NOT EXISTS(SELECT 1 FROM photos p WHERE p.entity_type='cash' "
        "AND p.entity_id=pc.id) THEN 1 END) no_receipt "
        "FROM users u LEFT JOIN petty_cash pc ON pc.agent_id=u.id" + where +
        " WHERE u.role IN ('agent','manager') AND u.active=1 GROUP BY u.id "
        "HAVING advanced>0 OR spent>0 OR returned>0 OR pending_count>0 "
        "ORDER BY (advanced - spent - returned) DESC", params)


@route("GET", r"/api/cash")
def list_cash(ctx):
    """The movements. An engineer sees their own; the office sees everyone's."""
    require_perm(ctx.user, "cash.view")
    u = ctx.user
    where, params = ["1=1"], []
    if u["role"] == "agent" or not has_perm(u, "cash.approve"):
        where.append("pc.agent_id=?"); params.append(u["id"])
    elif (ctx.query.get("agent_id") or "").isdigit():
        where.append("pc.agent_id=?"); params.append(int(ctx.query["agent_id"]))
    if ctx.query.get("status") in ("pending", "approved", "declined"):
        where.append("pc.status=?"); params.append(ctx.query["status"])
    if ctx.query.get("kind") in CASH_KINDS:
        where.append("pc.kind=?"); params.append(ctx.query["kind"])
    return db.query(
        "SELECT pc.*, u.full_name agent_name, h.full_name handled_by_name, "
        "cb.full_name created_by_name, "
        "(SELECT COUNT(*) FROM photos p WHERE p.entity_type='cash' AND p.entity_id=pc.id) receipts, "
        "(pc.category='transport' AND pc.visit_id IS NOT NULL AND EXISTS("
        "SELECT 1 FROM transport_entries te WHERE te.visit_id=pc.visit_id)) dup_transport "
        "FROM petty_cash pc "
        "JOIN users u ON u.id=pc.agent_id "
        "LEFT JOIN users h ON h.id=pc.handled_by "
        "LEFT JOIN users cb ON cb.id=pc.created_by WHERE " + " AND ".join(where) +
        " ORDER BY (pc.status='pending') DESC, pc.spent_on DESC, pc.id DESC LIMIT 400", params)


@route("GET", r"/api/cash/summary")
def cash_summary(ctx):
    """Balances — every engineer's for the office, only their own otherwise."""
    require_perm(ctx.user, "cash.view")
    u = ctx.user
    mine = None if has_perm(u, "cash.approve") else u["id"]
    rows = _cash_balance(mine)
    import datetime as _dt
    today = _dt.date.today()
    for r in rows:
        r["balance"] = round((r["advanced"] or 0) - (r["spent"] or 0) - (r["returned"] or 0), 2)
        # Days out is only meaningful while money is actually held; a settled
        # engineer is not carrying a two-month-old float, they are carrying none.
        r["days_out"] = None
        if r["balance"] > 0 and r["oldest_advance"]:
            try:
                r["days_out"] = (today - _dt.date.fromisoformat(r["oldest_advance"])).days
            except ValueError:
                r["days_out"] = None
        r["stale"] = bool(r["days_out"] is not None and r["days_out"] >= CASH_FLOAT_STALE_DAYS)
    return {"stale_days": CASH_FLOAT_STALE_DAYS,
            "balances": rows,
            "totals": {
                "advanced": round(sum(r["advanced"] or 0 for r in rows), 2),
                "spent": round(sum(r["spent"] or 0 for r in rows), 2),
                "returned": round(sum(r["returned"] or 0 for r in rows), 2),
                "balance": round(sum(r["balance"] for r in rows), 2),
                "pending": round(sum(r["pending"] or 0 for r in rows), 2),
                "pending_count": sum(r["pending_count"] or 0 for r in rows),
                "stale_count": sum(1 for r in rows if r["stale"]),
                "no_receipt": sum(r["no_receipt"] or 0 for r in rows),
            }}


@route("POST", r"/api/cash")
def create_cash(ctx):
    require_perm(ctx.user, "cash.create")
    u, b = ctx.user, ctx.body
    kind = b.get("kind")
    if kind not in CASH_KINDS:
        raise ApiError(400, "Unknown kind of movement")
    amount = _finite(b.get("amount"))
    if amount is None or amount <= 0:
        raise ApiError(400, "An amount is required")
    office = has_perm(u, "cash.approve")
    # An engineer files against their own float and only ever spends or returns
    # — handing cash out is the office's act, not theirs.
    agent_id = int(b["agent_id"]) if str(b.get("agent_id") or "").isdigit() else u["id"]
    if not office:
        agent_id = u["id"]
        if kind == "advance":
            raise ApiError(403, "Only the office can hand out pocket money")
    agent = db.query("SELECT id, role FROM users WHERE id=? AND active=1", (agent_id,), one=True)
    if not agent:
        raise ApiError(404, "Engineer not found")
    if agent["role"] == "client":
        raise ApiError(400, "Clients do not carry pocket money")
    category = b.get("category") if b.get("category") in CASH_CATEGORIES else None
    if kind == "expense" and not category:
        category = "other"
    vid = int(b["visit_id"]) if str(b.get("visit_id") or "").isdigit() else None
    import datetime as _dt
    spent_on = _shift_date(b.get("spent_on")) if b.get("spent_on") else _dt.date.today().isoformat()
    # The office writing the row IS the approval; an engineer's claim waits.
    status = "approved" if office else "pending"
    handled_at = "datetime('now','localtime')" if status == "approved" else "NULL"
    cid = db.execute(
        "INSERT INTO petty_cash(agent_id,kind,amount,category,spent_on,note,visit_id,status,"
        "created_by,handled_by,handled_at) VALUES(?,?,?,?,?,?,?,?,?,?," + handled_at + ")",
        (agent_id, kind, round(amount, 2), category, spent_on,
         (b.get("note") or "").strip() or None, vid, status, u["id"],
         u["id"] if status == "approved" else None))
    audit(ctx, "cash.create", "petty_cash", cid, f"{kind} {amount:g} agent:{agent_id} ({status})")
    if status == "pending":
        _notify_roles(("admin", "manager"), "cash_claim", "Pocket money claim",
                      f"{u['full_name']} filed {_money(amount)} — {t_cash_kind(kind)}.",
                      link_view="cash", link_id=cid, dedup_key=f"cash:{cid}",
                      exclude=u["id"])
    elif kind == "advance" and agent_id != u["id"]:
        _notify(agent_id, "cash_advance", "Pocket money",
                f"{_money(amount)} was added to your pocket money.",
                link_view="cash", link_id=cid, dedup_key=f"cashadv:{cid}")
    return _cash_row(cid)


def t_cash_kind(kind):
    return {"advance": "advance", "expense": "expense", "return": "returned cash"}.get(kind, kind)


def _money(v):
    return f"{float(v):,.2f}"


@route("POST", r"/api/cash/(\d+)/approve")
def approve_cash(ctx):
    require_perm(ctx.user, "cash.approve")
    cid = int(ctx.params[0])
    row = db.query("SELECT * FROM petty_cash WHERE id=?", (cid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    if row["status"] != "pending":
        raise ApiError(400, "This has already been handled")
    # The office may settle a claim for less than was asked — a receipt that
    # does not add up is trimmed here rather than declined outright.
    amount = _finite(ctx.body.get("amount"))
    amount = round(amount, 2) if (amount is not None and amount > 0) else row["amount"]
    db.execute("UPDATE petty_cash SET status='approved', amount=?, handled_by=?, "
               "handled_at=datetime('now','localtime') WHERE id=?", (amount, ctx.user["id"], cid))
    audit(ctx, "cash.approve", "petty_cash", cid, f"{row['kind']} {amount:g}")
    _notify(row["agent_id"], "cash_approved", "Pocket money approved",
            f"{_money(amount)} was approved.", link_view="cash", link_id=cid,
            dedup_key=f"cashok:{cid}")
    return _cash_row(cid)


@route("POST", r"/api/cash/(\d+)/decline")
def decline_cash(ctx):
    require_perm(ctx.user, "cash.approve")
    cid = int(ctx.params[0])
    row = db.query("SELECT * FROM petty_cash WHERE id=?", (cid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    if row["status"] != "pending":
        raise ApiError(400, "This has already been handled")
    reason = (ctx.body.get("reason") or "").strip() or None
    db.execute("UPDATE petty_cash SET status='declined', handled_by=?, "
               "handled_at=datetime('now','localtime'), decline_reason=? WHERE id=?",
               (ctx.user["id"], reason, cid))
    audit(ctx, "cash.decline", "petty_cash", cid, reason or "")
    _notify(row["agent_id"], "cash_declined", "Pocket money declined",
            reason or "Your pocket money claim was declined.",
            link_view="cash", link_id=cid, dedup_key=f"cashno:{cid}")
    return _cash_row(cid)


@route("DELETE", r"/api/cash/(\d+)")
def delete_cash(ctx):
    """The office can remove any row; an engineer only a claim of their own that
    nobody has answered yet."""
    require_perm(ctx.user, "cash.view")
    cid = int(ctx.params[0])
    row = db.query("SELECT * FROM petty_cash WHERE id=?", (cid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    mine_pending = row["agent_id"] == ctx.user["id"] and row["status"] == "pending"
    if not (has_perm(ctx.user, "cash.delete") or mine_pending):
        raise ApiError(403, "You do not have permission for this action")
    # The receipt goes with the claim — nothing else points at that file.
    for ph in db.query("SELECT id, filename FROM photos WHERE entity_type='cash' AND entity_id=?",
                       (cid,)):
        try:
            os.remove(os.path.join(UPLOAD_DIR, ph["filename"]))
        except OSError:
            pass
        db.execute("DELETE FROM photos WHERE id=?", (ph["id"],))
    db.execute("DELETE FROM petty_cash WHERE id=?", (cid,))
    audit(ctx, "cash.delete", "petty_cash", cid, f"{row['kind']} {row['amount']:g}")
    return {"ok": True}


# --------------------------------------------------------------------------
# INVOICES / FINANCE
# --------------------------------------------------------------------------
@route("GET", r"/api/invoices")
def list_invoices(ctx):
    u = ctx.user
    if u["role"] != "client":
        require_perm(u, "invoices.view")
    where, params = [], []
    if u["role"] == "client":
        where.append("i.client_id=?")
        params.append(u["client_id"])
        # Drafts are internal working documents — never shown to the client.
        where.append("i.status!='draft'")
        sid = client_site_scope_id(u)
        if sid:
            where.append("(i.site_id IS NULL OR i.site_id=?)"); params.append(sid)
    if ctx.query.get("client"):
        where.append("i.client_id=?")
        params.append(ctx.query["client"])
    if ctx.query.get("status"):
        where.append("i.status=?")
        params.append(ctx.query["status"])
    dt = ctx.query.get("doc_type", "invoice")
    if dt != "all":
        where.append("i.doc_type=?")
        params.append(dt)
    sql = ("SELECT i.*, c.name_en client_en, c.name_ar client_ar, "
           "COALESCE((SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0) paid "
           "FROM invoices i JOIN clients c ON c.id=i.client_id")
    if where:
        sql += " WHERE " + " AND ".join(where)
    return _paginate(ctx, sql, params, "ORDER BY i.issue_date DESC")


@route("GET", r"/api/invoices/(\d+)")
def get_invoice(ctx):
    iid = int(ctx.params[0])
    inv = db.query("SELECT i.*, c.name_en client_en, c.name_ar client_ar, "
                   "c.contact_person client_contact, c.phone client_phone, c.email client_email, "
                   "c.city client_city, c.address_en client_address_en, c.address_ar client_address_ar "
                   "FROM invoices i JOIN clients c ON c.id=i.client_id WHERE i.id=?", (iid,), one=True)
    if not inv:
        raise ApiError(404, "Invoice not found")
    if ctx.user["role"] == "client":
        if inv["status"] == "draft":
            raise ApiError(403, "No permission")
        _assert_invoice_access(ctx.user, inv)
    else:
        require_perm(ctx.user, "invoices.view")
    inv["payments"] = db.query("SELECT * FROM payments WHERE invoice_id=? ORDER BY paid_at DESC", (iid,))
    inv["paid"] = sum(p["amount"] for p in inv["payments"])
    inv["items"] = db.query("SELECT * FROM invoice_items WHERE invoice_id=? ORDER BY id", (iid,))
    return inv


def _save_items(iid, items, cx=None):
    """Replace an invoice's line items; return the amount computed from them.
    Pass cx to run inside an existing transaction; otherwise it self-commits."""
    ex = cx.execute if cx is not None else db.execute
    ex("DELETE FROM invoice_items WHERE invoice_id=?", (iid,))
    total = 0.0
    for it in items or []:
        qty = float(it.get("quantity", 1) or 1)
        price = float(it.get("unit_price", 0) or 0)
        amt = round(qty * price, 2)
        total += amt
        ex("INSERT INTO invoice_items(invoice_id,description,quantity,unit_price,amount) "
           "VALUES(?,?,?,?,?)", (iid, it.get("description", ""), qty, price, amt))
    return round(total, 2)


@route("POST", r"/api/invoices")
def create_invoice(ctx):
    require_perm(ctx.user, "invoices.create")
    b = ctx.body
    if not b.get("client_id") or not b.get("issue_date"):
        raise ApiError(400, "Client and issue date are required")
    doc_type = b.get("doc_type", "invoice")
    items = b.get("items")
    number = b.get("number") or _next_invoice_number(doc_type)
    tax = float(b.get("tax", 0))
    with db.transaction() as cx:
        iid = cx.execute(
            "INSERT INTO invoices(client_id,site_id,visit_id,contract_id,doc_type,number,issue_date,due_date,"
            "valid_until,amount,tax,total,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
            (b["client_id"], b.get("site_id") or None, b.get("visit_id"),
             _contract_for_client(b.get("contract_id"), b["client_id"]),
             doc_type, number, b["issue_date"], b.get("due_date"), b.get("valid_until"), 0, 0, 0,
             b.get("status", "draft"), b.get("notes"))).lastrowid
        # amount: from items if provided, else flat amount
        amount = _save_items(iid, items, cx) if items else float(b.get("amount", 0))
        if b.get("tax_rate"):  # percentage helper
            tax = round(amount * float(b["tax_rate"]) / 100, 2)
        cx.execute("UPDATE invoices SET amount=?, tax=?, total=? WHERE id=?",
                   (amount, tax, amount + tax, iid))
    audit(ctx, "invoice.create", "invoice", iid, f"{doc_type} {number} total {amount + tax:g}")
    if doc_type == "quote" and b.get("status") == "sent":
        _notify_client_users(b["client_id"], "quote_new", "New quotation",
                             f"Quotation {number} is ready for your review",
                             "invoice", iid, f"quotesent:{iid}")
    return db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)


@route("PUT", r"/api/invoices/(\d+)")
def update_invoice(ctx):
    require_perm(ctx.user, "invoices.edit")
    iid = int(ctx.params[0])
    b = ctx.body
    cur = db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)
    if not cur:
        raise ApiError(404, "Not found")
    if "site_id" in b and not b["site_id"]:
        b["site_id"] = None     # blank -> unassigned location (NULL), not ""
    if "contract_id" in b:
        # Which deal this billing belongs to — drives profit per contract.
        b["contract_id"] = _contract_for_client(b["contract_id"], cur["client_id"])
    with db.transaction() as cx:
        if "items" in b:                       # items drive the amount
            b["amount"] = _save_items(iid, b["items"], cx)
        if "amount" in b or "tax" in b:
            amount = float(b.get("amount", cur["amount"]))
            tax = float(b.get("tax", cur["tax"]))
            b["amount"], b["tax"], b["total"] = amount, tax, amount + tax
        cols = ("site_id", "visit_id", "contract_id", "issue_date", "due_date", "valid_until",
                "amount", "tax", "total", "status", "notes", "number", "doc_type")
        fields = [f"{c}=?" for c in cols if c in b]
        vals = [b[c] for c in cols if c in b]
        if fields:
            vals.append(iid)
            cx.execute(f"UPDATE invoices SET {','.join(fields)} WHERE id=?", vals)
    audit(ctx, "invoice.update", "invoice", iid, ", ".join(k for k in b if k != "items"))
    if cur["doc_type"] == "quote" and b.get("status") == "sent" and cur["status"] != "sent":
        _notify_client_users(cur["client_id"], "quote_new", "New quotation",
                             f"Quotation {cur['number']} is ready for your review",
                             "invoice", iid, f"quotesent:{iid}")
    return db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)


@route("DELETE", r"/api/invoices/(\d+)")
def delete_invoice(ctx):
    require_perm(ctx.user, "invoices.delete")
    iid = int(ctx.params[0])
    # An invoice with money recorded against it is an accounting record —
    # deleting it would erase the payment history. Cancel it instead.
    if db.query("SELECT 1 FROM payments WHERE invoice_id=? LIMIT 1", (iid,), one=True):
        raise ApiError(400, "This invoice has recorded payments and cannot be deleted. Cancel it instead.")
    db.execute("DELETE FROM invoices WHERE id=?", (iid,))
    audit(ctx, "invoice.delete", "invoice", iid)
    return {"ok": True}


@route("POST", r"/api/invoices/(\d+)/payments")
def add_payment(ctx):
    require_perm(ctx.user, "payments.create")
    iid = int(ctx.params[0])
    b = ctx.body
    try:
        amount = float(b.get("amount", 0))
    except (TypeError, ValueError):
        raise ApiError(400, "Invalid payment amount")
    if not math.isfinite(amount) or amount <= 0:
        raise ApiError(400, "Payment amount must be positive")
    if not db.query("SELECT id FROM invoices WHERE id=?", (iid,), one=True):
        raise ApiError(404, "Invoice not found")
    with db.transaction() as cx:
        # Guard against typos: a payment may not exceed the outstanding balance.
        row = cx.execute(
            "SELECT total - COALESCE((SELECT SUM(amount) FROM payments p "
            "WHERE p.invoice_id=i.id),0) rem FROM invoices i WHERE i.id=?", (iid,)).fetchone()
        if amount > row["rem"] + 0.01:
            raise ApiError(400, f"Payment exceeds the outstanding balance ({row['rem']:g})")
        cx.execute("INSERT INTO payments(invoice_id,amount,method,note) VALUES(?,?,?,?)",
                   (iid, amount, b.get("method", "cash"), b.get("note")))
        # auto-mark paid if fully covered
        inv = cx.execute("SELECT total, status FROM invoices WHERE id=?", (iid,)).fetchone()
        paid = cx.execute("SELECT COALESCE(SUM(amount),0) p FROM payments WHERE invoice_id=?",
                          (iid,)).fetchone()["p"]
        if inv and paid >= inv["total"] and inv["status"] != "cancelled":
            cx.execute("UPDATE invoices SET status='paid' WHERE id=?", (iid,))
    audit(ctx, "payment.create", "invoice", iid, f"{amount:g} via {b.get('method', 'cash')}")
    return get_invoice(Ctx(ctx.user, [str(iid)], {}, {}, b"", ""))


@route("GET", r"/api/clients/(\d+)/finance")
def client_finance(ctx):
    cid = int(ctx.params[0])
    _assert_client_access(ctx.user, cid)
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "invoices.view")
    return _finance_summary(cid, client_site_scope_id(ctx.user))


@route("GET", r"/api/clients/(\d+)/statement")
def client_statement(ctx):
    """Ledger for one client: invoices (debit) and payments (credit) in date
    order with a running balance, plus the opening balance before `from`."""
    cid = int(ctx.params[0])
    _assert_client_access(ctx.user, cid)
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "invoices.view")
    client = db.query("SELECT * FROM clients WHERE id=?", (cid,), one=True)
    if not client:
        raise ApiError(404, "Client not found")
    dfrom, dto = ctx.query.get("from"), ctx.query.get("to")
    # A portal login pinned to one location gets that location's ledger only.
    site_c, site_p = _client_site_clause(ctx.user, "site_id")
    inv_w = "client_id=? AND doc_type='invoice' AND status!='cancelled'" + site_c
    pay_w = ("invoice_id IN (SELECT id FROM invoices WHERE client_id=? "
             "AND doc_type='invoice' AND status!='cancelled'" + site_c + ")")
    opening = 0.0
    if dfrom:
        opening = (db.query(f"SELECT COALESCE(SUM(total),0) v FROM invoices WHERE {inv_w} "
                            "AND date(issue_date) < date(?)", (cid, *site_p, dfrom), one=True)["v"]
                   - db.query(f"SELECT COALESCE(SUM(amount),0) v FROM payments WHERE {pay_w} "
                              "AND date(paid_at) < date(?)", (cid, *site_p, dfrom), one=True)["v"])
    entries = []
    inv_q, inv_p = f"SELECT id, number, issue_date d, total FROM invoices WHERE {inv_w}", [cid, *site_p]
    if dfrom:
        inv_q += " AND date(issue_date) >= date(?)"; inv_p.append(dfrom)
    if dto:
        inv_q += " AND date(issue_date) <= date(?)"; inv_p.append(dto)
    for r in db.query(inv_q, inv_p):
        entries.append({"date": r["d"], "kind": "invoice", "ref": r["number"],
                        "link_id": r["id"], "debit": r["total"], "credit": 0})
    pay_q = (f"SELECT p.paid_at d, p.amount, p.method, i.number, i.id iid "
             f"FROM payments p JOIN invoices i ON i.id=p.invoice_id WHERE p.{pay_w}")
    pay_p = [cid, *site_p]
    if dfrom:
        pay_q += " AND date(p.paid_at) >= date(?)"; pay_p.append(dfrom)
    if dto:
        pay_q += " AND date(p.paid_at) <= date(?)"; pay_p.append(dto)
    for r in db.query(pay_q, pay_p):
        entries.append({"date": r["d"], "kind": "payment", "ref": r["number"],
                        "link_id": r["iid"], "method": r["method"],
                        "debit": 0, "credit": r["amount"]})
    entries.sort(key=lambda e: (str(e["date"] or ""), e["kind"]))
    bal = opening
    for e in entries:
        bal = round(bal + e["debit"] - e["credit"], 2)
        e["balance"] = bal
    return {"client": {"id": cid, "name_en": client["name_en"], "name_ar": client["name_ar"]},
            "from": dfrom, "to": dto, "opening": round(opening, 2), "closing": bal,
            "total_debit": round(sum(e["debit"] for e in entries), 2),
            "total_credit": round(sum(e["credit"] for e in entries), 2),
            "entries": entries}


def _invoice_from_quote(cx, q, status, due_days):
    """Inside a transaction: copy a quote row + its line items into a new
    invoice and mark the quote accepted. Returns the new invoice id."""
    iid = cx.execute(
        "INSERT INTO invoices(client_id,site_id,visit_id,contract_id,doc_type,number,issue_date,due_date,"
        "amount,tax,total,status,notes) VALUES(?,?,?,?,?,?,date('now','localtime'),date('now','localtime',?),?,?,?,?,?)",
        (q["client_id"], q["site_id"], q["visit_id"], q["contract_id"], "invoice",
         _next_invoice_number("invoice"), f"+{int(due_days)} days",
         q["amount"], q["tax"], q["total"], status, q["notes"])).lastrowid
    for it in cx.execute("SELECT * FROM invoice_items WHERE invoice_id=?", (q["id"],)).fetchall():
        cx.execute("INSERT INTO invoice_items(invoice_id,description,quantity,unit_price,amount) "
                   "VALUES(?,?,?,?,?)", (iid, it["description"], it["quantity"], it["unit_price"], it["amount"]))
    cx.execute("UPDATE invoices SET status='accepted' WHERE id=?", (q["id"],))
    return iid


@route("POST", r"/api/visits/(\d+)/invoice")
def invoice_a_visit(ctx):
    """Bill a visit that was actually done.

    `invoices.visit_id` has existed all along and nothing ever wrote it: the
    contract cycle billed the contracted work and everything else — the extra
    call-out, the emergency, the job done as a favour — was completed, written
    up, and quietly given away. The Workflow board counts them; this is how one
    gets cleared.

    Materials used on the visit can ride along as their own lines, priced at
    what they cost, so an argument about the bill has the detail behind it."""
    require_perm(ctx.user, "invoices.create")
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    if v["status"] != "completed":
        raise ApiError(400, "Only a completed visit can be invoiced")
    dup = db.query("SELECT id, number FROM invoices WHERE visit_id=? AND doc_type='invoice' "
                   "AND status<>'cancelled'", (vid,), one=True)
    if dup:
        raise ApiError(400, f"This visit is already on invoice {dup['number']}")
    b = ctx.body
    items = list(b.get("items") or [])
    if not items:
        amount = float(b.get("amount") or 0)
        label = b.get("description") or f"Service visit {v.get('visit_number') or vid}"
        items.append({"description": label, "quantity": 1, "unit_price": amount})
        if b.get("include_materials"):
            for u in db.query(
                    "SELECT ch.name_en, ch.unit, cu.quantity, "
                    "COALESCE(ch.cost_per_unit,0) cost FROM chemical_usage cu "
                    "LEFT JOIN chemicals ch ON ch.id=cu.chemical_id WHERE cu.visit_id=?", (vid,)):
                if not u["name_en"]:
                    continue
                items.append({"description": f"{u['name_en']} ({u['unit'] or 'unit'})",
                              "quantity": float(u["quantity"] or 0),
                              "unit_price": float(u["cost"] or 0)})
    if not any(float(i.get("unit_price") or 0) for i in items):
        raise ApiError(400, "An invoice needs a price on it")
    s = get_settings()
    try:
        tax_rate = float(s.get("tax_rate") or 0)
    except (TypeError, ValueError):
        tax_rate = 0
    terms = int(float(s.get("payment_terms_days") or 14))
    with db.transaction() as cx:
        iid = cx.execute(
            "INSERT INTO invoices(client_id,site_id,visit_id,doc_type,number,issue_date,"
            "due_date,amount,tax,total,status,notes) "
            "VALUES(?,?,?,'invoice',?,date('now','localtime'),date('now','localtime',?),0,0,0,?,?)",
            (v["client_id"], v["site_id"], vid, _next_invoice_number("invoice"),
             f"+{terms} days", b.get("status") or "sent", b.get("notes"))).lastrowid
        amount = _save_items(iid, items, cx)
        tax = round(amount * tax_rate / 100.0, 2)
        cx.execute("UPDATE invoices SET amount=?, tax=?, total=? WHERE id=?",
                   (amount, tax, round(amount + tax, 2), iid))
    audit(ctx, "visit.invoice", "invoice", iid, f"visit {vid}")
    return db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)


@route("POST", r"/api/contracts/(\d+)/apply-to-branches")
def contract_to_branches(ctx):
    """Write what the contract promises onto the branches that must deliver it.

    A signed contract already states how often each place is serviced; until
    now somebody re-typed that on every branch, and the two drifted apart
    quietly — the branch board can show the disagreement but only a person
    could fix it. This closes that loop from the contract's side.

    Without `apply` it reports what WOULD change, because overwriting a
    frequency the office tuned by hand should be a decision, not a side effect
    of opening a contract."""
    require_perm(ctx.user, "clients.edit")
    cid = int(ctx.params[0])
    ct = db.query("SELECT * FROM contracts WHERE id=?", (cid,), one=True)
    if not ct:
        raise ApiError(404, "Contract not found")
    vpm = FREQ_PER_MONTH.get(ct["frequency"])
    unit = FREQ_UNIT.get(ct["frequency"], "month")
    if not vpm:
        raise ApiError(400, "That contract has no service frequency to apply")
    b = ctx.body
    # The branches it covers: the one it names, plus any it lists.
    ids = [r["site_id"] for r in db.query(
        "SELECT site_id FROM contract_sites WHERE contract_id=? AND site_id IS NOT NULL", (cid,))]
    if ct["site_id"]:
        ids.append(ct["site_id"])
    ids = sorted(set(ids))
    if not ids:
        raise ApiError(400, "This contract has no branches to apply it to")
    window = {}
    for key in ("service_from", "service_to"):
        if b.get(key):
            window[key] = _shift_time(b[key], key)
    mins = _visit_minutes(b["visit_minutes"]) if b.get("visit_minutes") else None
    marks = ",".join("?" for _ in ids)
    rows = db.query(f"SELECT id, name, visits_per_month, service_from, service_to, "
                    f"visit_minutes FROM sites WHERE id IN ({marks})", ids)
    changes = []
    for r in rows:
        was = float(r["visits_per_month"] or 0)
        changes.append({"site_id": r["id"], "name": r["name"], "was": was, "now": vpm,
                        "changed": abs(was - vpm) > 0.01})
    if not b.get("apply"):
        return {"applied": False, "frequency": ct["frequency"], "visits_per_month": vpm,
                "freq_unit": unit, "branches": changes}
    with db.transaction() as cx:
        for sid in ids:
            # The RHYTHM goes with the number. A weekly contract lands on the
            # branch as a weekly rhythm, so a five-week month is five visits; a
            # monthly one lands as a count in the calendar month.
            sets, vals = ["visits_per_month=?", "freq_unit=?"], [vpm, unit]
            for k, v in window.items():
                sets.append(f"{k}=?"); vals.append(v)
            if mins is not None:
                sets.append("visit_minutes=?"); vals.append(mins)
            cx.execute(f"UPDATE sites SET {','.join(sets)} WHERE id=?", [*vals, sid])
    audit(ctx, "contract.to_branches", "contract", cid,
          f"{len(ids)} branch(es) set to {vpm} per {unit}")
    return {"applied": True, "frequency": ct["frequency"], "visits_per_month": vpm,
            "freq_unit": unit, "branches": changes, "updated": len(ids)}


@route("POST", r"/api/invoices/(\d+)/to-contract")
def quote_to_contract(ctx):
    """Turn a won quote into the contract that makes it serviceable work.

    Approving a quote produced an invoice and nothing else: the customer had
    agreed to a recurring service and nobody was scheduled to do any of it.
    This is the missing half — the quote's price and the branches it covers
    become a contract, which is what the roster, the SLA and the billing cycle
    all read from.

    The quote keeps a link to the contract and vice versa, so the sales trail
    and the delivery record stay one story."""
    require_perm(ctx.user, "contracts.create")
    qid = int(ctx.params[0])
    q = db.query("SELECT * FROM invoices WHERE id=? AND doc_type='quote'", (qid,), one=True)
    if not q:
        raise ApiError(404, "Quote not found")
    if q["status"] in ("draft", "cancelled", "declined"):
        raise ApiError(400, "Only a quote the customer has been sent or has accepted "
                            "can become a contract")
    already = db.query("SELECT id FROM contracts WHERE quote_id=?", (qid,), one=True)
    if already:
        raise ApiError(400, "This quote already has a contract")
    b = ctx.body
    freq = b.get("frequency") or "monthly"
    if freq not in FREQ_DAYS:
        raise ApiError(400, "Unknown service frequency")
    start = _shift_date(b.get("start_date") or _today(), "start_date")
    # Which branches it covers: what the office picked, else the one the quote
    # named, else the whole company (a contract with no branch is a stall the
    # Workflow board will report).
    site_ids = [int(s) for s in (b.get("site_ids") or []) if str(s).isdigit()]
    if not site_ids and q["site_id"]:
        site_ids = [q["site_id"]]
    for sid in site_ids:
        if not db.query("SELECT 1 FROM sites WHERE id=? AND client_id=?",
                        (sid, q["client_id"]), one=True):
            raise ApiError(400, "That branch does not belong to this customer")
    total = float(q["total"] or q["amount"] or 0)
    # The credit follows the sales trail: whoever is named on the lead this
    # customer came from brought this work in, unless the office says otherwise.
    sold_by = b.get("sold_by") or _who_brought_in(q["client_id"])
    with db.transaction() as cx:
        cid = cx.execute(
            "INSERT INTO contracts(client_id,site_id,quote_id,frequency,start_date,"
            "end_date,next_run_date,price,status,notes,sold_by) "
            "VALUES(?,?,?,?,?,?,?,?,'active',?,?)",
            (q["client_id"], site_ids[0] if len(site_ids) == 1 else None, qid, freq,
             start, b.get("end_date"), start, total,
             f"From quote {q['number']}", sold_by)).lastrowid
        # Split the price evenly when it covers several branches, so the
        # per-location invoice lines add back up to what was quoted.
        if len(site_ids) > 1:
            share = round(total / len(site_ids), 2)
            for sid in site_ids:
                cx.execute("INSERT INTO contract_sites(contract_id,site_id,price) "
                           "VALUES(?,?,?)", (cid, sid, share))
        if q["status"] != "accepted":
            cx.execute("UPDATE invoices SET status='accepted' WHERE id=?", (qid,))
    _notify_roles(("admin", "manager"), "contract_new", "Contract created from a quote",
                  f"Quote {q['number']} is now a {freq} contract.",
                  "contracts", cid, f"q2c:{qid}", exclude=ctx.user["id"])
    audit(ctx, "quote.to_contract", "contract", cid, f"from quote {qid}")
    if sold_by and int(sold_by) != ctx.user["id"]:
        _notify_commission_started(int(sold_by), cid)
    return db.query("SELECT * FROM contracts WHERE id=?", (cid,), one=True)


@route("POST", r"/api/invoices/(\d+)/convert")
def convert_quote(ctx):
    """Convert an accepted quote into a draft invoice (copies line items)."""
    require_perm(ctx.user, "invoices.edit")
    qid = int(ctx.params[0])
    q = db.query("SELECT * FROM invoices WHERE id=?", (qid,), one=True)
    if not q or q["doc_type"] != "quote":
        raise ApiError(400, "Not a quote")
    if q["status"] not in ("draft", "sent"):
        raise ApiError(400, "Quote already converted or closed")
    with db.transaction() as cx:
        iid = _invoice_from_quote(cx, q, "draft", 15)
    return db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)


def _quote_for_decision(ctx):
    """Load a quote a client (own) or staff (invoices.edit) may act on."""
    q = db.query("SELECT * FROM invoices WHERE id=?", (int(ctx.params[0]),), one=True)
    if not q or q["doc_type"] != "quote":
        raise ApiError(400, "Not a quote")
    if ctx.user["role"] == "client":
        _assert_invoice_access(ctx.user, q)
    else:
        require_perm(ctx.user, "invoices.edit")
    if q["status"] != "sent":
        raise ApiError(400, "Only a sent quote can be approved or declined")
    return q


@route("POST", r"/api/invoices/(\d+)/approve")
def approve_quote(ctx):
    """Client accepts a quote from the portal -> immediately payable invoice."""
    q = _quote_for_decision(ctx)
    terms = int(float(get_settings().get("payment_terms_days") or 14))
    with db.transaction() as cx:
        iid = _invoice_from_quote(cx, q, "sent", terms)
    inv = db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)
    _notify_roles(("admin", "manager"), "quote_approved", "Quote approved",
                  f"Quote {q['number']} was approved — invoice {inv['number']} created",
                  "invoice", iid, f"quoteok:{q['id']}", exclude=ctx.user["id"])
    audit(ctx, "quote.approve", "invoice", q["id"], f"{q['number']} -> {inv['number']}")
    return inv


@route("POST", r"/api/invoices/(\d+)/decline")
def decline_quote(ctx):
    """Client declines a quote from the portal (optional reason)."""
    q = _quote_for_decision(ctx)
    reason = str(ctx.body.get("reason") or "").strip()[:500]
    notes = (q["notes"] or "")
    if reason:
        notes = (notes + "\n" if notes else "") + f"Declined: {reason}"
    db.execute("UPDATE invoices SET status='declined', notes=? WHERE id=?", (notes, q["id"]))
    _notify_roles(("admin", "manager"), "quote_declined", "Quote declined",
                  f"Quote {q['number']} was declined" + (f": {reason}" if reason else ""),
                  "invoice", q["id"], f"quoteno:{q['id']}", exclude=ctx.user["id"])
    audit(ctx, "quote.decline", "invoice", q["id"], q["number"])
    return db.query("SELECT * FROM invoices WHERE id=?", (q["id"],), one=True)


# --------------------------------------------------------------------------
# PRICE BOOK — reusable service catalog for quote/invoice line items
# --------------------------------------------------------------------------
@route("GET", r"/api/price-book")
def list_price_book(ctx):
    if ctx.user["role"] == "client":       # internal catalog — staff only
        raise ApiError(403, "No permission")
    require_perm(ctx.user, "invoices.view")
    if ctx.query.get("all"):        # manage UI shows inactive items too
        return db.query("SELECT * FROM price_book ORDER BY active DESC, name_en")
    return db.query("SELECT * FROM price_book WHERE active=1 ORDER BY name_en")


@route("POST", r"/api/price-book")
def create_price_item(ctx):
    require_perm(ctx.user, "invoices.edit")
    b = ctx.body
    if not (b.get("name_en") or "").strip():
        raise ApiError(400, "Name is required")
    pid = db.execute("INSERT INTO price_book(name_en,name_ar,description,unit_price) VALUES(?,?,?,?)",
                     (b["name_en"].strip(), b.get("name_ar"), b.get("description"),
                      float(b.get("unit_price") or 0)))
    audit(ctx, "pricebook.create", "price_book", pid, b["name_en"].strip())
    return db.query("SELECT * FROM price_book WHERE id=?", (pid,), one=True)


@route("PUT", r"/api/price-book/(\d+)")
def update_price_item(ctx):
    require_perm(ctx.user, "invoices.edit")
    pid = int(ctx.params[0])
    if not db.query("SELECT 1 FROM price_book WHERE id=?", (pid,), one=True):
        raise ApiError(404, "Not found")
    b = ctx.body
    if "unit_price" in b:
        b["unit_price"] = float(b["unit_price"] or 0)
    if "active" in b:
        b["active"] = 1 if b["active"] in (1, "1", True, "true") else 0
    cols = ("name_en", "name_ar", "description", "unit_price", "active")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [b[c] for c in cols if c in b]
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(pid)
    db.execute(f"UPDATE price_book SET {','.join(fields)} WHERE id=?", vals)
    return db.query("SELECT * FROM price_book WHERE id=?", (pid,), one=True)


@route("DELETE", r"/api/price-book/(\d+)")
def delete_price_item(ctx):
    require_perm(ctx.user, "invoices.delete")
    db.execute("DELETE FROM price_book WHERE id=?", (int(ctx.params[0]),))
    return {"ok": True}


# --------------------------------------------------------------------------
# LEADS — sales pipeline (website booking form + manual entry)
# --------------------------------------------------------------------------
LEAD_STATUSES = ("new", "contacted", "quoted", "won", "lost")


@route("GET", r"/api/leads")
def list_leads(ctx):
    require_perm(ctx.user, "leads.view")
    where, params = [], []
    if ctx.query.get("status") and ctx.query["status"] in LEAD_STATUSES:
        where.append("l.status=?")
        params.append(ctx.query["status"])
    sql = ("SELECT l.*, c.name_en client_en, c.name_ar client_ar, u.full_name handled_by_name "
           "FROM leads l LEFT JOIN clients c ON c.id=l.client_id "
           "LEFT JOIN users u ON u.id=l.handled_by")
    if where:
        sql += " WHERE " + " AND ".join(where)
    rows = _paginate(ctx, sql, params, "ORDER BY l.created_at DESC")
    counts = {r["status"]: r["c"] for r in
              db.query("SELECT status, COUNT(*) c FROM leads GROUP BY status")}
    if isinstance(rows, dict):
        rows["counts"] = counts
        return rows
    return {"items": rows, "counts": counts}


@route("POST", r"/api/leads")
def create_lead(ctx):
    require_perm(ctx.user, "leads.create")
    b = ctx.body
    if not (b.get("name") or "").strip():
        raise ApiError(400, "Name is required")
    lid = db.execute(
        "INSERT INTO leads(name,company,phone,email,sector,message,preferred_date,source,status,note) "
        "VALUES(?,?,?,?,?,?,?,?,?,?)",
        (b["name"].strip(), b.get("company"), b.get("phone"), b.get("email"), b.get("sector"),
         b.get("message"), b.get("preferred_date"), "manual",
         b.get("status") if b.get("status") in LEAD_STATUSES else "new", b.get("note")))
    audit(ctx, "lead.create", "lead", lid, b["name"].strip())
    return db.query("SELECT * FROM leads WHERE id=?", (lid,), one=True)


@route("PUT", r"/api/leads/(\d+)")
def update_lead(ctx):
    require_perm(ctx.user, "leads.edit")
    lid = int(ctx.params[0])
    cur = db.query("SELECT * FROM leads WHERE id=?", (lid,), one=True)
    if not cur:
        raise ApiError(404, "Lead not found")
    b = ctx.body
    if "status" in b and b["status"] not in LEAD_STATUSES:
        raise ApiError(400, "Invalid status")
    cols = ("name", "company", "phone", "email", "sector", "message",
            "preferred_date", "status", "note")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [b[c] for c in cols if c in b]
    if not fields and "handled_by" not in b:
        raise ApiError(400, "Nothing to update")
    # Who is on this lead was, until now, always whoever last touched it. That
    # is fine as a default and wrong as a rule: the person who FOUND the
    # customer is the one a contract's commission should follow, and it is
    # rarely whoever typed the last note. It can now be named outright.
    owner = ctx.user["id"]
    if "handled_by" in b:
        if not b["handled_by"]:
            raise ApiError(400, "A lead has to belong to somebody")
        who = db.query("SELECT id FROM users WHERE id=? AND active=1 AND role<>'client'",
                       (b["handled_by"],), one=True)
        if not who:
            raise ApiError(400, "That is not a member of staff")
        owner = who["id"]
    fields += ["handled_by=?", "updated_at=datetime('now','localtime')"]
    vals += [owner, lid]
    db.execute(f"UPDATE leads SET {','.join(fields)} WHERE id=?", vals)
    audit(ctx, "lead.update", "lead", lid, ", ".join(k for k in b))
    return db.query("SELECT * FROM leads WHERE id=?", (lid,), one=True)


@route("DELETE", r"/api/leads/(\d+)")
def delete_lead(ctx):
    require_perm(ctx.user, "leads.delete")
    db.execute("DELETE FROM leads WHERE id=?", (int(ctx.params[0]),))
    audit(ctx, "lead.delete", "lead", int(ctx.params[0]))
    return {"ok": True}


@route("POST", r"/api/leads/(\d+)/convert")
def convert_lead(ctx):
    """Won lead -> real client record (the lead keeps a link to it)."""
    require_perm(ctx.user, "leads.edit")
    require_perm(ctx.user, "clients.create")
    lid = int(ctx.params[0])
    lead = db.query("SELECT * FROM leads WHERE id=?", (lid,), one=True)
    if not lead:
        raise ApiError(404, "Lead not found")
    if lead["client_id"]:
        raise ApiError(400, "Lead already converted")
    with db.transaction() as cx:
        cid = cx.execute(
            "INSERT INTO clients(name_en,name_ar,contact_person,phone,email,notes) VALUES(?,?,?,?,?,?)",
            (lead["company"] or lead["name"], lead["company"] or lead["name"], lead["name"],
             lead["phone"], lead["email"],
             ("Lead from website. " if lead["source"] == "website" else "") + (lead["message"] or ""))).lastrowid
        cx.execute("UPDATE leads SET status='won', client_id=?, handled_by=?, "
                   "updated_at=datetime('now','localtime') WHERE id=?", (cid, ctx.user["id"], lid))
    audit(ctx, "lead.convert", "lead", lid, f"-> client {cid}")
    return db.query("SELECT * FROM clients WHERE id=?", (cid,), one=True)


@route("POST", r"/api/public/lead", auth_required=False)
def public_lead(ctx):
    """Unauthenticated booking/contact form on the marketing website.
    Rate-limited per IP; the hidden 'website' field is a bot honeypot."""
    b = ctx.body
    if b.get("website"):                       # honeypot filled -> bot; pretend success
        return {"ok": True}
    name = str(b.get("name") or "").strip()[:120]
    phone = str(b.get("phone") or "").strip()[:40]
    email = str(b.get("email") or "").strip()[:120]
    if not name or not (phone or email):
        raise ApiError(400, "Name and a phone or email are required")
    if not rate_limit(f"lead:{ctx.ip or '?'}", 5, 3600):
        raise ApiError(429, "Too many requests. Please try again later.")
    lid = db.execute(
        "INSERT INTO leads(name,company,phone,email,sector,message,preferred_date,source) "
        "VALUES(?,?,?,?,?,?,?,'website')",
        (name, str(b.get("company") or "").strip()[:120] or None, phone or None, email or None,
         str(b.get("sector") or "").strip()[:120] or None,
         str(b.get("message") or "").strip()[:2000] or None,
         str(b.get("preferred_date") or "").strip()[:40] or None))
    _notify_roles(("admin", "manager"), "lead_new", "New website lead",
                  f"{name}" + (f" — {phone}" if phone else "") + (f" — {email}" if email else ""),
                  "leads", lid, f"lead:{lid}")
    return {"ok": True}


# --------------------------------------------------------------------------
# ONLINE PAYMENTS — gateway-agnostic adapters + checkout/callback flow
# --------------------------------------------------------------------------
# Each provider implements two steps of the standard hosted-checkout dance:
#   create_intent(intent, invoice, return_url) -> (checkout_url, provider_ref)
#   parse_callback(ctx)                         -> (provider_ref, status, raw)
# Drop a new class in PAYMENT_PROVIDERS and select it via the payment_provider
# setting to support Paymob / Fawry / Stripe / etc. once merchant keys + HTTPS
# are in place. The built-in "manual" provider needs neither and is used to
# exercise the whole loop end-to-end (it confirms via an in-app prompt).
class PaymentProvider:
    name = "base"

    def create_intent(self, intent, invoice, return_url):
        raise ApiError(501, "Payment provider not implemented")

    def parse_callback(self, ctx):
        raise ApiError(501, "Payment provider not implemented")


class ManualProvider(PaymentProvider):
    """Sandbox provider: no external gateway. The client confirms in-app and the
    callback marks the intent paid. Stands in until a real gateway is wired."""
    name = "manual"

    def create_intent(self, intent, invoice, return_url):
        return return_url, intent["token"]

    def parse_callback(self, ctx):
        tok = ctx.body.get("token") or ctx.query.get("token")
        if not tok:
            raise ApiError(400, "token required")
        return tok, "paid", json.dumps(ctx.body)[:2000]


class PaymobProvider(PaymentProvider):
    """Skeleton for Paymob (Egypt). The flow is: auth token -> register order ->
    request a payment key -> redirect to the iframe; success arrives on the
    callback as an HMAC-signed transaction. Wire the TODOs once keys + HTTPS are
    available; until then it fails clearly rather than pretending to work."""
    name = "paymob"

    def create_intent(self, intent, invoice, return_url):
        s = get_settings()
        if not s.get("paymob_api_key") or not s.get("paymob_integration_id"):
            raise ApiError(400, "Paymob keys not configured in Settings")
        # TODO: POST /api/auth/tokens -> POST /api/ecommerce/orders ->
        #       POST /api/acceptance/payment_keys -> build the iframe URL.
        raise ApiError(501, "Paymob integration not finished — keys present, flow pending HTTPS")

    def parse_callback(self, ctx):
        s = get_settings()
        secret = s.get("paymob_hmac")
        if not secret:
            raise ApiError(400, "Paymob HMAC not configured")
        # TODO: recompute the HMAC over the ordered Paymob fields and compare to
        #       ctx.query['hmac']; map obj.success -> 'paid'/'failed'.
        raise ApiError(501, "Paymob callback verification not finished")


PAYMENT_PROVIDERS = {p.name: p for p in (ManualProvider(), PaymobProvider())}


def _active_payment_provider():
    name = (get_settings().get("payment_provider") or "manual").strip()
    return PAYMENT_PROVIDERS.get(name, PAYMENT_PROVIDERS["manual"])


@route("POST", r"/api/invoices/(\d+)/pay")
def start_payment(ctx):
    """Begin an online payment for an invoice. Clients may pay their own
    invoices; staff need payments.create (e.g. to hand a customer a pay link).
    Returns a checkout_url to send the payer to (or, for the manual provider, an
    in-app confirm path) plus the intent token to poll."""
    iid = int(ctx.params[0])
    inv = db.query("SELECT * FROM invoices WHERE id=?", (iid,), one=True)
    if not inv:
        raise ApiError(404, "Invoice not found")
    if ctx.user["role"] == "client":
        _assert_invoice_access(ctx.user, inv)
    else:
        require_perm(ctx.user, "payments.create")
    if inv["doc_type"] != "invoice":
        raise ApiError(400, "Only invoices can be paid")
    if inv["status"] == "cancelled":
        raise ApiError(400, "Invoice is cancelled")
    paid = db.query("SELECT COALESCE(SUM(amount),0) p FROM payments WHERE invoice_id=?",
                    (iid,), one=True)["p"]
    remaining = round(inv["total"] - paid, 2)
    if remaining <= 0:
        raise ApiError(400, "Invoice already paid")
    provider = _active_payment_provider()
    currency = get_settings().get("currency") or "EGP"
    token = uuid.uuid4().hex
    intent_id = db.execute(
        "INSERT INTO payment_intents(invoice_id,client_id,provider,token,amount,currency,status) "
        "VALUES(?,?,?,?,?,?, 'pending')",
        (iid, inv["client_id"], provider.name, token, remaining, currency))
    intent = db.query("SELECT * FROM payment_intents WHERE id=?", (intent_id,), one=True)
    checkout_url, provider_ref = provider.create_intent(intent, inv, f"/pay/{token}")
    db.execute("UPDATE payment_intents SET provider_ref=? WHERE id=?", (provider_ref, intent_id))
    audit(ctx, "payment.intent", "invoice", iid, f"{provider.name} {remaining:g} {currency}")
    return {"token": token, "provider": provider.name, "checkout_url": checkout_url,
            "amount": remaining, "currency": currency}


@route("GET", r"/api/payment-intents/([0-9a-fA-F]+)")
def get_payment_intent(ctx):
    """Poll a payment intent's status (after returning from checkout)."""
    intent = db.query("SELECT * FROM payment_intents WHERE token=?", (ctx.params[0],), one=True)
    if not intent:
        raise ApiError(404, "Not found")
    if ctx.user["role"] == "client":
        _assert_client_access(ctx.user, intent["client_id"])
    else:
        require_perm(ctx.user, "invoices.view")
    return {"token": intent["token"], "status": intent["status"], "amount": intent["amount"],
            "invoice_id": intent["invoice_id"]}


@route("POST", r"/api/payments/callback/(\w+)", auth_required=False)
def payment_callback(ctx):
    """Gateway callback / webhook (unauthenticated — the provider calls it). The
    adapter validates the payload; on success we record the payment, mark the
    invoice paid when fully covered, and flag the intent. Idempotent."""
    # Unauthenticated (the provider calls it) -> cap per-IP to blunt abuse.
    if not rate_limit(f"paycb:{ctx.ip}", 60, 60):
        raise ApiError(429, "Too many requests")
    provider = PAYMENT_PROVIDERS.get(ctx.params[0])
    if not provider:
        raise ApiError(404, "Unknown payment provider")
    ref, status, raw = provider.parse_callback(ctx)
    intent = db.query("SELECT * FROM payment_intents WHERE provider_ref=? OR token=?",
                      (ref, ref), one=True)
    if not intent:
        raise ApiError(404, "Unknown payment reference")
    if intent["status"] == "paid":
        return {"ok": True, "status": "paid"}      # already processed
    if status != "paid":
        db.execute("UPDATE payment_intents SET status=?, updated_at=datetime('now','localtime') WHERE id=?",
                   (status if status in ("failed", "cancelled") else "failed", intent["id"]))
        return {"ok": True, "status": status}
    iid = intent["invoice_id"]
    with db.transaction() as cx:
        pid = cx.execute(
            "INSERT INTO payments(invoice_id,amount,method,note) VALUES(?,?,?,?)",
            (iid, intent["amount"], f"online:{provider.name}",
             f"Online payment {intent['token'][:8]}")).lastrowid
        inv = cx.execute("SELECT number, total, status FROM invoices WHERE id=?", (iid,)).fetchone()
        tot = cx.execute("SELECT COALESCE(SUM(amount),0) p FROM payments WHERE invoice_id=?",
                         (iid,)).fetchone()["p"]
        if inv and tot >= inv["total"] and inv["status"] != "cancelled":
            cx.execute("UPDATE invoices SET status='paid' WHERE id=?", (iid,))
        cx.execute("UPDATE payment_intents SET status='paid', payment_id=?, "
                   "updated_at=datetime('now','localtime') WHERE id=?", (pid, intent["id"]))
    _notify_roles(("admin", "manager"), "payment_received", "Payment received",
                  f"Invoice {inv['number'] if inv else iid} paid online "
                  f"({intent['amount']:g} {intent['currency']})", "invoices", iid,
                  f"paid:{intent['id']}")
    return {"ok": True, "status": "paid"}


# --------------------------------------------------------------------------
# SETTINGS (company profile / branding)
# --------------------------------------------------------------------------
DEFAULT_SETTINGS = {
    "company_name_en": "PestCare Pest Control Co.", "company_name_ar": "شركة بيست كير لمكافحة الآفات",
    "address_en": "Riyadh, Saudi Arabia", "address_ar": "الرياض، المملكة العربية السعودية",
    "phone": "+966 11 000 0000", "email": "billing@pestcare.com", "vat_no": "300000000000003",
    "currency": "EGP", "tax_rate": "14", "payment_terms_days": "14", "logo": "",
    # Cash in the bank today. The only figure the CRM cannot derive — it never
    # sees the bank — and the one that turns the cash-flow forecast from "net
    # movement" into "the week you run short".
    "cash_on_hand": "0",
    # How long the automatic scheduler allows per visit, travel included.
    "auto_slot_minutes": "60",
    # THE LONGEST JOURNEY THE PLAN WILL ASK OF ANYBODY, between one customer
    # and the next. Where both branches carry coordinates the planner works the
    # real distance out and refuses a hop longer than this; where they do not —
    # most of the book — it is what the day reserves, and the engineer is very
    # welcome to arrive sooner. Two doors of one address cost nothing. Set it
    # to 0 to go back to packing visits nose to tail.
    "auto_travel_max_minutes": "45",
    # AND THE LONGEST HOP THAT NEVER LEAVES THE PATCH. Crossing Cairo and
    # crossing one district are not the same journey, and reserving three
    # quarters of an hour for both is what made a round of four calls in one
    # area cost the same as four calls in four areas — so the diary had no
    # reason to keep a man where he was. Also a maximum, also only used where
    # the drive cannot be measured; two geocoded branches are always timed on
    # the real distance. Never more than the figure above.
    "auto_travel_area_minutes": "20",
    "auto_travel_kmh": "25",
    # How far an engineer may be sent OUTSIDE their zone once their own zone's
    # work is done. 0 keeps them strictly inside it.
    "auto_spill_km": "25",
    # HOW MANY ZONES ONE ENGINEER'S DAY MAY TOUCH. A zone is the office's own
    # statement that these areas are near each other, so 1 means "a round stays
    # in one part of the city". Never lifted to mop up leftovers: a branch on
    # the worklist can be given a day of its own, a round nobody can drive
    # cannot. 0 = no limit.
    "auto_zones_per_day": "1",
    # WHICH WEEKDAYS ARE REST. The cycle never deals a visit onto one; a branch
    # only gets it when it would otherwise run out of week. Python weekdays,
    # Mon=0, so 4 is Friday. Empty = no rest day, every day dealt on alike.
    "auto_rest_days": "4",
    # HOW MANY DIFFERENT AREAS ONE ENGINEER'S DAY MAY HOLD. "The engineer
    # priority is the location he is in, before he travels to another
    # location" — so he finishes where he is standing, and 2 lets him move on
    # once when his own patch runs dry. It is lifted at the very end of each
    # day's planning for work nobody else could reach, so tidying a round never
    # costs a branch its visit. 0 = no limit, which is how it planned before.
    "auto_areas_per_day": "2",
    # What an engineer-hour costs the company. Without it the cost-to-serve
    # screen has no labour figure and says so rather than guessing.
    "labour_hourly_cost": "0",
    # What share of a contract the person who brought it in earns, as a
    # percentage, for as long as that contract stays active. A single contract
    # may carry its own rate; this is what every other one is worked out at.
    "commission_rate": "25",
    # VAT filing: how often the return is due, and how many days after the
    # period closes it must be paid. 'none' switches the whole thing off for a
    # company that is not VAT-registered.
    "vat_filing": "monthly",          # monthly | quarterly | none
    "vat_due_days": "30",
    # Chasing money: how many days past due each reminder to the customer goes
    # out. Empty, or dunning_enabled=0, switches the whole ladder off.
    "dunning_enabled": "1",
    "dunning_days": "3,14,30",
    # How far ahead a contract's end date is worth flagging.
    "contract_expiry_days": "60,30",
    # Online payments. payment_provider selects the active gateway adapter
    # ("manual" = built-in sandbox that records a payment on confirm, no keys).
    # Real adapters (paymob/…) read their keys from these slots once supplied.
    "payment_provider": "manual",
    "paymob_api_key": "", "paymob_integration_id": "", "paymob_iframe_id": "", "paymob_hmac": "",
    "google_maps_api_key": "",   # enables Places search on contract site locations
    "company_geo": "",   # depot "lat,lng" — start point for route optimization
    # Canonical https address of this CRM (e.g. https://crm.example.com). Set it
    # and anyone who reaches the box by its bare IP — an old printed QR label, a
    # bookmark, an old app install — is redirected here, so the page always runs
    # in a secure context. Empty = no redirect.
    "public_url": "",
    # Service-certificate template (editable in Settings, used on every certificate).
    "cert_statement_en": "This is to certify that pest control services were carried out at the "
                         "premises detailed below, in accordance with professional standards and applicable regulations.",
    "cert_statement_ar": "نشهد بموجب هذه الوثيقة بأنه تم تنفيذ أعمال مكافحة الآفات في الموقع الموضح أدناه، "
                         "وفقاً للمعايير المهنية واللوائح المعمول بها.",
    "cert_footer_en": "This certificate is issued based on the service performed on the date stated above. "
                      "Continued protection is subject to the recommended next service date.",
    "cert_footer_ar": "تصدر هذه الشهادة بناءً على الخدمة المنفذة في التاريخ المذكور أعلاه. "
                      "تستمر الحماية وفقاً لموعد الخدمة القادم الموصى به.",
    "cert_license_no": "",
}


def get_settings():
    s = dict(DEFAULT_SETTINGS)
    for r in db.query("SELECT key, value FROM settings"):
        s[r["key"]] = r["value"]
    return s


# Settings that must never be exposed to non-admin users (credentials).
_SECRET_SETTING_KEYS = {"smtp_host", "smtp_port", "smtp_user", "smtp_pass",
                        "smtp_from", "smtp_tls", "paymob_api_key", "paymob_hmac"}


@route("GET", r"/api/settings")
def read_settings(ctx):
    s = get_settings()
    # Internal counters (invoice/quote sequences) are not user-facing settings.
    for k in [k for k in s if k.startswith("seq_")]:
        s.pop(k, None)
    # Everyone can read branding/cert/company fields the UI needs, but secrets
    # (SMTP credentials) are only returned to users who can manage settings.
    if not has_perm(ctx.user, "settings.view"):
        for k in _SECRET_SETTING_KEYS:
            s.pop(k, None)
        if ctx.user["role"] == "client":
            s.pop("google_maps_api_key", None)
    return s


@route("PUT", r"/api/settings")
def write_settings(ctx):
    require_perm(ctx.user, "settings.edit")
    for k, v in ctx.body.items():
        if k.startswith("seq_"):
            continue  # internal invoice/quote counters — not editable here
        db.execute("INSERT INTO settings(key,value) VALUES(?,?) "
                   "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (k, str(v)))
    refresh_public_url()   # the redirect target is cached — pick up an edit now
    return get_settings()


@route("POST", r"/api/settings/logo")
def upload_logo(ctx):
    require_perm(ctx.user, "settings.edit")
    _fields, files = parse_multipart(ctx.raw_body, ctx.content_type)
    if not files:
        raise ApiError(400, "No file uploaded")
    f = files[0]
    ext = _validate_image_upload(f)
    fname = f"logo_{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(f["data"])
    db.execute("INSERT INTO settings(key,value) VALUES('logo',?) "
               "ON CONFLICT(key) DO UPDATE SET value=excluded.value", (fname,))
    return get_settings()


# --------------------------------------------------------------------------
# CONTRACTS (recurring schedules)
# --------------------------------------------------------------------------
FREQ_DAYS = {"weekly": 7, "biweekly": 14, "monthly": 30, "quarterly": 91,
             "semiannual": 182, "annual": 365}

# The same contract rhythms as VISITS A MONTH, which is the unit the branch
# schedule now speaks. Read off the calendar rather than divided out of
# FREQ_DAYS: "monthly" is one a month exactly, and 28/30 of a visit is not a
# number to show anybody.
# WHICH RHYTHM EACH CONTRACT WORD MEANS. A weekly deal is a WEEKLY rhythm —
# a month with five of its weeks in it is five visits, and that is what was
# sold. A monthly deal is a COUNT IN THE CALENDAR MONTH: one a month is one in
# February and one in October, never 1.1 because October is longer.
FREQ_UNIT = {"weekly": "week", "biweekly": "week", "monthly": "month",
             "quarterly": "month", "semiannual": "month", "annual": "month"}

FREQ_PER_MONTH = {"weekly": 4.0, "biweekly": 2.0, "monthly": 1.0,
                  "quarterly": round(1 / 3, 3), "semiannual": round(1 / 6, 3),
                  "annual": round(1 / 12, 3)}


@route("GET", r"/api/contracts")
def list_contracts(ctx):
    u = ctx.user
    if u["role"] != "client":
        require_perm(u, "contracts.view")
    where, params = [], []
    if u["role"] == "client":
        where.append("ct.client_id=?")
        params.append(u["client_id"])
        pin = client_site_scope_id(u)
        if pin:
            # A contract with no site is the company-wide agreement; one that
            # names another branch is not this login's business.
            where.append("(ct.site_id IS NULL OR ct.site_id=? OR EXISTS "
                         "(SELECT 1 FROM contract_sites cs WHERE cs.contract_id=ct.id AND cs.site_id=?))")
            params += [pin, pin]
    elif u["role"] == "agent":
        where.append("ct.agent_id=?")
        params.append(u["id"])
    if ctx.query.get("client"):
        where.append("ct.client_id=?")
        params.append(ctx.query["client"])
    sql = ("SELECT ct.*, c.name_en client_en, c.name_ar client_ar, "
           "s.name_en service_en, s.name_ar service_ar, u.full_name agent_name, "
           "sb.full_name sold_by_name "
           "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
           "LEFT JOIN service_types s ON s.id=ct.service_type_id "
           "LEFT JOIN users u ON u.id=ct.agent_id "
           "LEFT JOIN users sb ON sb.id=ct.sold_by")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY ct.next_run_date"
    rows = db.query(sql, params)
    # Attach each contract's per-site lines (location + Google Maps URL + price).
    for ct in rows:
        ct["sites"] = db.query(
            "SELECT cs.id, cs.site_id, cs.map_location, cs.price, s.name site_name "
            "FROM contract_sites cs LEFT JOIN sites s ON s.id=cs.site_id "
            "WHERE cs.contract_id=? ORDER BY cs.id", (ct["id"],))
    return rows


def _who_brought_in(client_id):
    """Who to credit a new contract to when nobody said. The lead this customer
    came from already records who handled it, and that is the person who
    brought them in — so the credit follows the sales trail instead of being
    re-typed (and forgotten) on every contract.

    Only a WON lead counts, and only a member of staff who is still here. When
    there is nothing to go on this returns None: an uncredited contract shows
    up on the marketing page asking to be settled, which is far better than
    quietly paying the wrong person."""
    row = db.query(
        "SELECT l.handled_by FROM leads l JOIN users u ON u.id=l.handled_by "
        "WHERE l.client_id=? AND l.status='won' AND u.active=1 AND u.role<>'client' "
        "ORDER BY l.updated_at DESC, l.id DESC LIMIT 1", (client_id,), one=True)
    return row["handled_by"] if row else None


def _save_contract_sites(cid, sites):
    """Replace a contract's per-site lines. Each entry: {site_id, map_location, price}."""
    db.execute("DELETE FROM contract_sites WHERE contract_id=?", (cid,))
    for s in (sites or []):
        if not s.get("site_id") and not s.get("map_location") and not s.get("price"):
            continue  # skip empty rows
        db.execute(
            "INSERT INTO contract_sites(contract_id,site_id,map_location,price) VALUES(?,?,?,?)",
            (cid, s.get("site_id") or None, s.get("map_location") or None,
             float(s.get("price") or 0)))


@route("POST", r"/api/contracts")
def create_contract(ctx):
    require_perm(ctx.user, "contracts.create")
    b = ctx.body
    if not b.get("client_id") or not b.get("start_date") or not b.get("frequency"):
        raise ApiError(400, "Client, start date and frequency are required")
    sites = b.get("sites") or []
    # The contract's headline site/price are derived from the site rows (first
    # location, summed price) so existing lists and visit-generation still work.
    site_id = (sites[0].get("site_id") or None) if sites else b.get("site_id")
    price = sum(float(s.get("price") or 0) for s in sites) if sites else float(b.get("price", 0))
    auto = 1 if b.get("auto_invoice") in (1, "1", True, "true", "on") else 0
    next_bill = (b.get("next_bill_date") or b["start_date"]) if auto else None
    sold_by = b.get("sold_by") or _who_brought_in(b["client_id"])
    rate = b.get("commission_rate")
    rate = None if rate in ("", None) else _amount(rate, "Commission rate")
    cid = db.execute(
        "INSERT INTO contracts(client_id,site_id,service_type_id,agent_id,frequency,start_date,"
        "end_date,next_run_date,price,status,notes,bill_every,next_bill_date,auto_invoice,"
        "sold_by,commission_rate) "
        "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (b["client_id"], site_id, b.get("service_type_id"), b.get("agent_id"),
         b["frequency"], b["start_date"], b.get("end_date"), b["start_date"],
         price, b.get("status", "active"), b.get("notes"),
         b.get("bill_every") or None, next_bill, auto, sold_by, rate))
    _save_contract_sites(cid, sites)
    cl = db.query("SELECT name_en FROM clients WHERE id=?", (b["client_id"],), one=True)
    _notify_roles(("admin", "manager"), "contract_new", "New contract",
                  f"New {b['frequency']} contract for {cl['name_en'] if cl else ''}",
                  "contracts", cid, f"contract:{cid}", exclude=ctx.user["id"])
    if sold_by and int(sold_by) != ctx.user["id"]:
        _notify_commission_started(int(sold_by), cid)
    return db.query("SELECT * FROM contracts WHERE id=?", (cid,), one=True)


@route("PUT", r"/api/contracts/(\d+)")
def update_contract(ctx):
    require_perm(ctx.user, "contracts.edit")
    cid = int(ctx.params[0])
    b = ctx.body
    sites = b.get("sites")
    if sites is not None:
        # Derive headline site/price from the rows, then persist the rows below.
        b["site_id"] = (sites[0].get("site_id") or None) if sites else None
        b["price"] = sum(float(s.get("price") or 0) for s in sites)
    if "auto_invoice" in b:
        b["auto_invoice"] = 1 if b["auto_invoice"] in (1, "1", True, "true", "on") else 0
        if b["auto_invoice"] and not b.get("next_bill_date"):
            cur = db.query("SELECT next_bill_date, start_date FROM contracts WHERE id=?",
                           (cid,), one=True) or {}
            b["next_bill_date"] = cur.get("next_bill_date") or cur.get("start_date") \
                or db.query("SELECT date('now','localtime') d", one=True)["d"]
    if b.get("bill_every") == "":
        b["bill_every"] = None
    if "sold_by" in b and not b["sold_by"]:
        b["sold_by"] = None                 # "nobody" is a real answer here
    if "commission_rate" in b:
        b["commission_rate"] = (None if b["commission_rate"] in ("", None)
                                else _amount(b["commission_rate"], "Commission rate"))
    # Somebody's pay hangs off this contract's status, so the state it was in
    # before the update has to be read before the update happens.
    was = db.query("SELECT status, sold_by FROM contracts WHERE id=?", (cid,), one=True) or {}
    cols = ("site_id", "service_type_id", "agent_id", "frequency", "start_date",
            "end_date", "next_run_date", "price", "status", "notes",
            "bill_every", "next_bill_date", "auto_invoice", "sold_by", "commission_rate")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [b[c] for c in cols if c in b]
    if not fields and sites is None:
        raise ApiError(400, "Nothing to update")
    if fields:
        vals.append(cid)
        db.execute(f"UPDATE contracts SET {','.join(fields)} WHERE id=?", vals)
    # Suspending or ending a contract takes the uplift off the salary of
    # whoever brought it in. They are told, rather than finding out from a
    # smaller payslip.
    new_status = b.get("status")
    if new_status and new_status != was.get("status") \
            and new_status != COMMISSION_EARNING_STATUS:
        _notify_commission_ended(cid, new_status)
    if b.get("sold_by") and b["sold_by"] != was.get("sold_by") \
            and int(b["sold_by"]) != ctx.user["id"]:
        _notify_commission_started(int(b["sold_by"]), cid)
    if sites is not None:
        _save_contract_sites(cid, sites)
    return db.query("SELECT * FROM contracts WHERE id=?", (cid,), one=True)


@route("DELETE", r"/api/contracts/(\d+)")
def delete_contract(ctx):
    require_perm(ctx.user, "contracts.delete")
    db.execute("DELETE FROM contracts WHERE id=?", (int(ctx.params[0]),))
    return {"ok": True}


@route("POST", r"/api/contracts/run")
def run_contracts(ctx):
    """Generate visits for all active contracts due within the look-ahead window."""
    require_perm(ctx.user, "contracts.edit")
    created = _generate_due_visits()
    return {"created": created}


@route("POST", r"/api/contracts/bill")
def run_billing(ctx):
    """Generate any due recurring invoices for auto-billed contracts."""
    require_perm(ctx.user, "invoices.create")
    return {"created": _generate_due_invoices()}


def _generate_due_visits(lookahead_days=14):
    """Create visits for contracts whose next_run_date falls within the window.
    Advances next_run_date by the frequency. Returns number of visits created."""
    horizon = f"+{lookahead_days} days"
    due = db.query(
        "SELECT * FROM contracts WHERE status='active' AND date(next_run_date) <= date('now','localtime',?) "
        "AND (end_date IS NULL OR date(next_run_date) <= date(end_date))", (horizon,))
    count = 0
    for ct in due:
        days = FREQ_DAYS.get(ct["frequency"], 30)
        run = ct["next_run_date"]
        # generate every occurrence already due up to the horizon (avoids gaps)
        for _ in range(60):  # safety cap
            row = db.query("SELECT date(?) d, date('now','localtime',?) h", (run, horizon), one=True)
            if row["d"] > row["h"]:
                break
            if ct["end_date"]:
                er = db.query("SELECT date(?) d, date(?) e", (run, ct["end_date"]), one=True)
                if er["d"] > er["e"]:
                    break
            # skip if a visit for this contract already exists on that date
            exists = db.query(
                "SELECT id FROM visits WHERE client_id=? AND date(scheduled_start)=date(?) "
                "AND service_type_id IS ?", (ct["client_id"], run, ct["service_type_id"]), one=True)
            if not exists:
                db.execute(
                    "INSERT INTO visits(client_id,site_id,agent_id,service_type_id,contract_id,"
                    "scheduled_start,status,notes) VALUES(?,?,?,?,?,?,?,?)",
                    (ct["client_id"], ct["site_id"], ct["agent_id"], ct["service_type_id"],
                     ct["id"], run + " 09:00:00", "scheduled",
                     f"Auto-generated from contract #{ct['id']}"))
                count += 1
            nxt = db.query("SELECT date(?, ?) n", (run, f"+{days} days"), one=True)["n"]
            run = nxt
        db.execute("UPDATE contracts SET next_run_date=? WHERE id=?", (run, ct["id"]))
    return count


def _contract_invoice_items(ct):
    """Build invoice line items for a contract's billing cycle. One line per
    per-site row when present (so each location is itemized), else a single line
    at the contract's headline price."""
    svc = db.query("SELECT name_en FROM service_types WHERE id=?",
                   (ct["service_type_id"],), one=True) if ct["service_type_id"] else None
    label = (svc["name_en"] if svc else "Pest control") + f" — {ct['frequency']} service"
    sites = db.query(
        "SELECT cs.price, s.name site_name FROM contract_sites cs "
        "LEFT JOIN sites s ON s.id=cs.site_id WHERE cs.contract_id=? AND cs.price > 0 "
        "ORDER BY cs.id", (ct["id"],))
    if sites:
        return [{"description": f"{label}" + (f" — {s['site_name']}" if s["site_name"] else ""),
                 "quantity": 1, "unit_price": s["price"]} for s in sites]
    return [{"description": label, "quantity": 1, "unit_price": ct["price"]}]


def _generate_due_invoices(lookahead_days=0):
    """Auto-generate invoices for contracts opted into recurring billing whose
    next_bill_date has arrived. Advances next_bill_date by the billing cadence
    (bill_every, falling back to the service frequency). Idempotent: skips a
    cycle that already has a non-cancelled invoice for that contract + date."""
    horizon = f"+{lookahead_days} days"
    s = get_settings()
    try:
        tax_rate = float(s.get("tax_rate") or 0)
    except (TypeError, ValueError):
        tax_rate = 0.0
    try:
        terms = int(float(s.get("payment_terms_days") or 14))
    except (TypeError, ValueError):
        terms = 14
    due = db.query(
        "SELECT * FROM contracts WHERE status='active' AND auto_invoice=1 "
        "AND next_bill_date IS NOT NULL AND date(next_bill_date) <= date('now','localtime',?) "
        "AND (end_date IS NULL OR date(next_bill_date) <= date(end_date))", (horizon,))
    count = 0
    for ct in due:
        days = FREQ_DAYS.get(ct["bill_every"] or ct["frequency"], 30)
        bill = ct["next_bill_date"]
        for _ in range(36):  # safety cap on catch-up
            row = db.query("SELECT date(?) d, date('now','localtime',?) h", (bill, horizon), one=True)
            if row["d"] > row["h"]:
                break
            if ct["end_date"]:
                er = db.query("SELECT date(?) d, date(?) e", (bill, ct["end_date"]), one=True)
                if er["d"] > er["e"]:
                    break
            exists = db.query(
                "SELECT id FROM invoices WHERE contract_id=? AND doc_type='invoice' "
                "AND date(issue_date)=date(?) AND status!='cancelled'",
                (ct["id"], bill), one=True)
            if not exists:
                items = _contract_invoice_items(ct)
                number = _next_invoice_number("invoice")
                due_date = db.query("SELECT date(?, ?) n", (bill, f"+{terms} days"), one=True)["n"]
                with db.transaction() as cx:
                    iid = cx.execute(
                        "INSERT INTO invoices(client_id,site_id,contract_id,doc_type,number,issue_date,"
                        "due_date,amount,tax,total,status,notes) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
                        (ct["client_id"], ct["site_id"], ct["id"], "invoice", number, bill,
                         due_date, 0, 0, 0, "sent",
                         f"Auto-generated from contract #{ct['id']}")).lastrowid
                    amount = _save_items(iid, items, cx)
                    tax = round(amount * tax_rate / 100, 2)
                    cx.execute("UPDATE invoices SET amount=?, tax=?, total=? WHERE id=?",
                               (amount, tax, amount + tax, iid))
                count += 1
                # surface the new invoice to the client portal
                cl = db.query("SELECT name_en FROM clients WHERE id=?", (ct["client_id"],), one=True)
                for cu in db.query(
                        "SELECT id FROM users WHERE role='client' AND client_id=? AND active=1",
                        (ct["client_id"],)):
                    _notify(cu["id"], "invoice_new", "New invoice",
                            f"{number} — {amount + tax:g}", "invoices", iid,
                            f"autoinv:{iid}:{cu['id']}")
            bill = db.query("SELECT date(?, ?) n", (bill, f"+{days} days"), one=True)["n"]
        db.execute("UPDATE contracts SET next_bill_date=? WHERE id=?", (bill, ct["id"]))
    return count


# --------------------------------------------------------------------------
# OPERATING COSTS — standing bills, the expense ledger, and the profit picture
# --------------------------------------------------------------------------
# Invoices say what the customers owe. This says what the business keeps: rent,
# every salary, the tax, the licences — posted on their own cycle — set against
# the money actually collected.
EXPENSE_CATEGORIES = [
    "rent", "salary", "tax", "utilities", "vehicle", "fuel", "materials",
    "equipment", "insurance", "licenses", "marketing", "office", "maintenance",
    "bank", "other",
]

# One cycle of each cadence. Month-based cadences advance by CALENDAR months,
# not 30 days, so rent due on the 1st keeps landing on the 1st.
COST_PERIODS = {"weekly": ("d", 7), "biweekly": ("d", 14), "monthly": ("m", 1),
                "quarterly": ("m", 3), "semiannual": ("m", 6), "annual": ("m", 12)}

# Three costs the company already records elsewhere and must not be asked to
# type in twice: stock bought on a purchase order, the travel logged on visits,
# and pocket money an engineer spent in the field. They are folded into the
# totals as derived categories, read-only here.
#
# Pocket money counts at the moment it is SPENT and approved, not when the
# float was handed over: an advance is the company's cash in someone else's
# pocket, and cash that comes back was never a cost at all.
DERIVED_COST_CATEGORIES = ("inventory", "transport", "pocket")


def _add_period(day, freq, times=1, anchor=None):
    """Advance 'YYYY-MM-DD' by `times` cycles of `freq`, keeping the day of the
    month — a bill due on the 31st lands on the 30th in a short month rather
    than skidding into the next one (which is what SQLite's '+1 month' does).

    `anchor` is the standing order's start date: the day of the month comes
    from there, so a February clamp is borrowed for one cycle and not kept —
    31st, 28th, 31st, not 31st, 28th, 28th for the rest of the bill's life."""
    import datetime as _dt
    import calendar as _cal
    unit, n = COST_PERIODS.get(freq, ("m", 1))
    d = _dt.date.fromisoformat(str(day)[:10])
    if unit == "d":
        return (d + _dt.timedelta(days=n * times)).isoformat()
    want = _dt.date.fromisoformat(str(anchor)[:10]).day if anchor else d.day
    total = (d.month - 1) + n * times
    year, month = d.year + total // 12, total % 12 + 1
    return _dt.date(year, month, min(want, _cal.monthrange(year, month)[1])).isoformat()


def _monthly_equiv(amount, freq):
    """What one standing order costs per month, whatever its cadence — the
    number the run-rate is built from."""
    unit, n = COST_PERIODS.get(freq, ("m", 1))
    amount = float(amount or 0)
    return amount * 365.25 / (12 * n) if unit == "d" else amount / n


def _today():
    return db.query("SELECT date('now','localtime') d", one=True)["d"]


def _amount(raw, field="amount"):
    try:
        val = float(raw)
    except (TypeError, ValueError):
        raise ApiError(400, f"{field} must be a number")
    if not math.isfinite(val) or val < 0:
        raise ApiError(400, f"{field} must be a positive number")
    return round(val, 2)


def _category(raw, default="other"):
    cat = (raw or default) or default
    if cat not in EXPENSE_CATEGORIES:
        raise ApiError(400, "Unknown cost category")
    return cat


def _cost_user_id(raw):
    """The person a salary line belongs to. Optional everywhere else."""
    if raw in (None, "", "0"):
        return None
    try:
        uid = int(raw)
    except (TypeError, ValueError):
        raise ApiError(400, "Invalid user")
    if not db.query("SELECT 1 FROM users WHERE id=?", (uid,), one=True):
        raise ApiError(404, "User not found")
    return uid


def _recurring_row(rid):
    r = db.query("SELECT r.*, u.full_name user_name FROM cost_recurring r "
                 "LEFT JOIN users u ON u.id=r.user_id WHERE r.id=?", (rid,), one=True)
    return _decorate_recurring(r) if r else None


def _decorate_recurring(r, today=None):
    today = today or _today()
    r["monthly_equiv"] = round(_monthly_equiv(r["amount"], r["frequency"]), 2)
    r["annual_equiv"] = round(r["monthly_equiv"] * 12, 2)
    r["due_now"] = bool(r["active"] and r["next_due"] and str(r["next_due"])[:10] <= today)
    return r


@route("GET", r"/api/recurring-costs")
def list_recurring_costs(ctx):
    require_perm(ctx.user, "finance.view")
    rows = db.query("SELECT r.*, u.full_name user_name, u.active user_active "
                    "FROM cost_recurring r LEFT JOIN users u ON u.id=r.user_id "
                    "ORDER BY r.active DESC, r.category, r.name")
    today = _today()
    return [_decorate_recurring(r, today) for r in rows]


@route("POST", r"/api/recurring-costs")
def create_recurring_cost(ctx):
    require_perm(ctx.user, "finance.create")
    b = ctx.body
    name = (b.get("name") or "").strip()
    if not name:
        raise ApiError(400, "Name is required")
    freq = b.get("frequency") or "monthly"
    if freq not in COST_PERIODS:
        raise ApiError(400, "Unknown billing cycle")
    start = (b.get("start_date") or "")[:10] or _today()
    rid = db.execute(
        "INSERT INTO cost_recurring(name,category,amount,frequency,start_date,next_due,end_date,"
        "user_id,vendor,note,auto_post,active,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)",
        (name, _category(b.get("category")), _amount(b.get("amount", 0)), freq, start,
         (b.get("next_due") or start)[:10], (b.get("end_date") or None),
         _cost_user_id(b.get("user_id")), b.get("vendor"), b.get("note"),
         0 if str(b.get("auto_post", 1)) in ("0", "false", "False") else 1,
         0 if str(b.get("active", 1)) in ("0", "false", "False") else 1,
         ctx.user["id"]))
    audit(ctx, "cost.recurring.create", "cost_recurring", rid, f"{name} {b.get('amount')} {freq}")
    return _recurring_row(rid)


@route("PUT", r"/api/recurring-costs/(\d+)")
def update_recurring_cost(ctx):
    require_perm(ctx.user, "finance.edit")
    rid = int(ctx.params[0])
    old = db.query("SELECT * FROM cost_recurring WHERE id=?", (rid,), one=True)
    if not old:
        raise ApiError(404, "Not found")
    b = ctx.body
    fields, vals = [], []
    for key in ("name", "vendor", "note"):
        if key in b:
            fields.append(f"{key}=?"); vals.append(b[key])
    if "category" in b:
        fields.append("category=?"); vals.append(_category(b["category"], old["category"]))
    if "amount" in b:
        fields.append("amount=?"); vals.append(_amount(b["amount"]))
    if "frequency" in b:
        if b["frequency"] not in COST_PERIODS:
            raise ApiError(400, "Unknown billing cycle")
        fields.append("frequency=?"); vals.append(b["frequency"])
    for key in ("start_date", "next_due", "end_date"):
        if key in b:
            fields.append(f"{key}=?"); vals.append((b[key] or None) and b[key][:10])
    if "user_id" in b:
        fields.append("user_id=?"); vals.append(_cost_user_id(b["user_id"]))
    for key in ("auto_post", "active"):
        if key in b:
            fields.append(f"{key}=?")
            vals.append(0 if str(b[key]) in ("0", "false", "False") else 1)
    if not fields:
        return _recurring_row(rid)
    fields.append("updated_at=datetime('now','localtime')")
    vals.append(rid)
    db.execute(f"UPDATE cost_recurring SET {','.join(fields)} WHERE id=?", vals)
    audit(ctx, "cost.recurring.update", "cost_recurring", rid, old["name"])
    return _recurring_row(rid)


@route("DELETE", r"/api/recurring-costs/(\d+)")
def delete_recurring_cost(ctx):
    """Stop a standing order. What it already posted stays in the ledger — the
    money was spent, and the year's totals must not change because a bill was
    cancelled today (the expense rows' recurring_id simply goes null)."""
    require_perm(ctx.user, "finance.delete")
    rid = int(ctx.params[0])
    row = db.query("SELECT * FROM cost_recurring WHERE id=?", (rid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    db.execute("DELETE FROM cost_recurring WHERE id=?", (rid,))
    audit(ctx, "cost.recurring.delete", "cost_recurring", rid, row["name"])
    return {"ok": True}


@route("POST", r"/api/recurring-costs/post")
def post_due_costs(ctx):
    """Post every standing order that has come due, now, by hand."""
    require_perm(ctx.user, "finance.create")
    created = _generate_due_costs()
    audit(ctx, "cost.recurring.post", None, None, f"{created} expense(s)")
    return {"created": created}


def _expense_row(eid):
    return db.query(
        "SELECT e.*, u.full_name user_name, cu.full_name created_by_name, r.name recurring_name, "
        "(SELECT COUNT(*) FROM photos p WHERE p.entity_type='expense' AND p.entity_id=e.id) receipts "
        "FROM expenses e LEFT JOIN users u ON u.id=e.user_id "
        "LEFT JOIN users cu ON cu.id=e.created_by "
        "LEFT JOIN cost_recurring r ON r.id=e.recurring_id WHERE e.id=?", (eid,), one=True)


@route("GET", r"/api/expenses")
def list_expenses(ctx):
    require_perm(ctx.user, "finance.view")
    q = ctx.query
    where, params = [], []
    if q.get("from"):
        where.append("date(e.spent_on) >= date(?)"); params.append(q["from"][:10])
    if q.get("to"):
        where.append("date(e.spent_on) <= date(?)"); params.append(q["to"][:10])
    if q.get("category"):
        where.append("e.category=?"); params.append(q["category"])
    if q.get("user_id"):
        where.append("e.user_id=?"); params.append(q["user_id"])
    if q.get("recurring_id"):
        where.append("e.recurring_id=?"); params.append(q["recurring_id"])
    sql = ("SELECT e.*, u.full_name user_name, cu.full_name created_by_name, "
           "r.name recurring_name, "
           "(SELECT COUNT(*) FROM photos p WHERE p.entity_type='expense' "
           " AND p.entity_id=e.id) receipts FROM expenses e "
           "LEFT JOIN users u ON u.id=e.user_id "
           "LEFT JOIN users cu ON cu.id=e.created_by "
           "LEFT JOIN cost_recurring r ON r.id=e.recurring_id")
    if where:
        sql += " WHERE " + " AND ".join(where)
    return _paginate(ctx, sql, params, "ORDER BY date(e.spent_on) DESC, e.id DESC")


@route("POST", r"/api/expenses")
def create_expense(ctx):
    require_perm(ctx.user, "finance.create")
    b = ctx.body
    eid = db.execute(
        "INSERT INTO expenses(spent_on,category,description,amount,vendor,method,reference,"
        "user_id,recurring_id,source,note,created_by) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)",
        ((b.get("spent_on") or _today())[:10], _category(b.get("category")),
         b.get("description"), _amount(b.get("amount", 0)), b.get("vendor"),
         b.get("method"), b.get("reference"), _cost_user_id(b.get("user_id")),
         None, "manual", b.get("note"), ctx.user["id"]))
    audit(ctx, "expense.create", "expense", eid,
          f"{b.get('category')} {b.get('amount')}")
    return _expense_row(eid)


@route("PUT", r"/api/expenses/(\d+)")
def update_expense(ctx):
    require_perm(ctx.user, "finance.edit")
    eid = int(ctx.params[0])
    old = db.query("SELECT * FROM expenses WHERE id=?", (eid,), one=True)
    if not old:
        raise ApiError(404, "Not found")
    b = ctx.body
    fields, vals = [], []
    for key in ("description", "vendor", "method", "reference", "note"):
        if key in b:
            fields.append(f"{key}=?"); vals.append(b[key])
    if "spent_on" in b:
        fields.append("spent_on=?"); vals.append((b["spent_on"] or old["spent_on"])[:10])
    if "category" in b:
        fields.append("category=?"); vals.append(_category(b["category"], old["category"]))
    if "amount" in b:
        fields.append("amount=?"); vals.append(_amount(b["amount"]))
    if "user_id" in b:
        fields.append("user_id=?"); vals.append(_cost_user_id(b["user_id"]))
    if not fields:
        return _expense_row(eid)
    fields.append("updated_at=datetime('now','localtime')")
    vals.append(eid)
    db.execute(f"UPDATE expenses SET {','.join(fields)} WHERE id=?", vals)
    audit(ctx, "expense.update", "expense", eid, f"{old['category']} {old['amount']:g}")
    return _expense_row(eid)


@route("DELETE", r"/api/expenses/(\d+)")
def delete_expense(ctx):
    require_perm(ctx.user, "finance.delete")
    eid = int(ctx.params[0])
    row = db.query("SELECT * FROM expenses WHERE id=?", (eid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    # photos.entity_id is a loose reference, so the receipts have to be cleaned
    # up here or they would be orphaned on disk and unreachable forever.
    for ph in db.query("SELECT id, filename FROM photos WHERE entity_type='expense' AND entity_id=?",
                       (eid,)):
        try:
            os.remove(os.path.join(UPLOAD_DIR, ph["filename"]))
        except OSError:
            pass
        db.execute("DELETE FROM photos WHERE id=?", (ph["id"],))
    db.execute("DELETE FROM expenses WHERE id=?", (eid,))
    audit(ctx, "expense.delete", "expense", eid, f"{row['category']} {row['amount']:g}")
    return {"ok": True}


def _generate_due_costs(lookahead_days=0):
    """Post an expense for every standing order whose next_due has arrived, and
    advance it to the following cycle. Idempotent twice over: a cycle that
    already has an expense row for that (standing order, date) is skipped, and
    next_due only ever moves forward — so running this on every notification
    poll costs nothing and never double-books the rent."""
    horizon = db.query("SELECT date('now','localtime',?) h", (f"+{lookahead_days} days",), one=True)["h"]
    due = db.query(
        "SELECT * FROM cost_recurring WHERE active=1 AND auto_post=1 AND next_due IS NOT NULL "
        "AND date(next_due) <= date(?)", (horizon,))
    created = 0
    for r in due:
        nxt = str(r["next_due"])[:10]
        for _ in range(36):                      # safety cap on catch-up
            if nxt > horizon:
                break
            if r["end_date"] and nxt > str(r["end_date"])[:10]:
                nxt = None
                break
            exists = db.query("SELECT id FROM expenses WHERE recurring_id=? AND date(spent_on)=date(?)",
                              (r["id"], nxt), one=True)
            if not exists:
                db.execute(
                    "INSERT INTO expenses(spent_on,category,description,amount,vendor,"
                    "user_id,recurring_id,source,note,created_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
                    (nxt, r["category"], r["name"], r["amount"], r["vendor"],
                     r["user_id"], r["id"], "recurring", r["note"], r["created_by"]))
                created += 1
            nxt = _add_period(nxt, r["frequency"], anchor=r["start_date"])
        db.execute("UPDATE cost_recurring SET next_due=? WHERE id=?", (nxt, r["id"]))
    return created


# Budgets may be set for the derived categories too — stock and travel are real
# money, and an owner who caps them wants to see the cap.
BUDGET_CATEGORIES = tuple(EXPENSE_CATEGORIES) + DERIVED_COST_CATEGORIES


def _budget_category(raw):
    if raw not in BUDGET_CATEGORIES:
        raise ApiError(400, "Unknown cost category")
    return raw


def _budget_row(bid):
    b = db.query("SELECT * FROM cost_budgets WHERE id=?", (bid,), one=True)
    return _decorate_budget(b) if b else None


def _decorate_budget(b):
    """Both readings of the same figure, so the caller never has to divide."""
    amount = float(b["amount"] or 0)
    b["monthly"] = round(amount if b["period"] == "monthly" else amount / 12, 2)
    b["annual"] = round(amount * 12 if b["period"] == "monthly" else amount, 2)
    return b


@route("GET", r"/api/budgets")
def list_budgets(ctx):
    require_perm(ctx.user, "finance.view")
    year = (ctx.query.get("year") or _today()[:4])[:4]
    rows = db.query("SELECT * FROM cost_budgets WHERE year=? ORDER BY category", (year,))
    return [_decorate_budget(b) for b in rows]


@route("POST", r"/api/budgets")
def set_budget(ctx):
    """Set (or correct) one category's budget for a year. Upsert on purpose: the
    owner thinks 'rent is 5,000 a month', not 'insert a budget row'."""
    require_perm(ctx.user, "finance.create")
    b = ctx.body
    cat = _budget_category(b.get("category"))
    year = (b.get("year") or _today()[:4])[:4]
    period = b.get("period") or "monthly"
    if period not in ("monthly", "annual"):
        raise ApiError(400, "Budget period must be monthly or annual")
    amount = _amount(b.get("amount", 0))
    existing = db.query("SELECT id FROM cost_budgets WHERE category=? AND year=?",
                        (cat, year), one=True)
    if existing:
        db.execute("UPDATE cost_budgets SET period=?, amount=?, note=?, "
                   "updated_at=datetime('now','localtime') WHERE id=?",
                   (period, amount, b.get("note"), existing["id"]))
        bid = existing["id"]
    else:
        bid = db.execute(
            "INSERT INTO cost_budgets(category,year,period,amount,note,created_by) "
            "VALUES(?,?,?,?,?,?)", (cat, year, period, amount, b.get("note"), ctx.user["id"]))
    audit(ctx, "budget.set", "cost_budget", bid, f"{cat} {year} {period} {amount:g}")
    return _budget_row(bid)


@route("DELETE", r"/api/budgets/(\d+)")
def delete_budget(ctx):
    require_perm(ctx.user, "finance.delete")
    bid = int(ctx.params[0])
    row = db.query("SELECT * FROM cost_budgets WHERE id=?", (bid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    db.execute("DELETE FROM cost_budgets WHERE id=?", (bid,))
    audit(ctx, "budget.delete", "cost_budget", bid, f"{row['category']} {row['year']}")
    return {"ok": True}


def _budget_for_window(row, months):
    """A yearly intention, prorated to the window on screen: a monthly budget
    times the months shown, an annual one by the fraction of the year covered."""
    amount = float(row["amount"] or 0)
    if row["period"] == "monthly":
        return round(amount * months, 2)
    return round(amount * months / 12, 2)


def _category_actual_this_month(category):
    """What one category has cost so far this month, counted the same way the
    finance page counts it (the two derived categories read their own logs)."""
    if category == "inventory":
        sql = ("SELECT COALESCE(SUM(total_cost),0) v FROM purchase_orders "
               "WHERE strftime('%Y-%m', created_at)=strftime('%Y-%m','now','localtime')")
    elif category == "transport":
        sql = ("SELECT COALESCE(SUM(cost),0) v FROM transport_entries "
               "WHERE strftime('%Y-%m', created_at)=strftime('%Y-%m','now','localtime')")
    else:
        return round(db.query(
            "SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE category=? "
            "AND strftime('%Y-%m', spent_on)=strftime('%Y-%m','now','localtime')",
            (category,), one=True)["v"], 2)
    return round(db.query(sql, one=True)["v"], 2)


def _budget_compare(frm, to, actual_by_cat):
    """Budget against actual for one window, per category and in total.

    Categories with a budget and no spend are kept (an unused budget is news);
    so are categories spent with no budget, at zero — an owner should see what
    they never planned for."""
    year = frm[:4]
    months = len(_month_keys(frm, to))
    rows = db.query("SELECT * FROM cost_budgets WHERE year=? ORDER BY category", (year,))
    budgets = {r["category"]: r for r in rows}
    out = []
    for cat in sorted(set(budgets) | set(actual_by_cat)):
        row = budgets.get(cat)
        budget = _budget_for_window(row, months) if row else 0
        actual = round(actual_by_cat.get(cat, 0), 2)
        out.append({
            "category": cat,
            "budget_id": row["id"] if row else None,
            "period": row["period"] if row else None,
            "set_amount": round(float(row["amount"]), 2) if row else None,
            "budget": budget,
            "actual": actual,
            # Positive variance = under budget, which is the direction an owner
            # wants to read as good news.
            "variance": round(budget - actual, 2),
            "used_pct": round(actual / budget * 100, 1) if budget else None,
            "over": bool(budget and actual > budget),
        })
    out.sort(key=lambda r: (r["budget"] or 0) + r["actual"], reverse=True)
    total_budget = round(sum(r["budget"] for r in out), 2)
    total_actual = round(sum(r["actual"] for r in out), 2)
    return {
        "year": year, "months": months, "categories": out,
        "totals": {"budget": total_budget, "actual": total_actual,
                   "variance": round(total_budget - total_actual, 2),
                   "used_pct": round(total_actual / total_budget * 100, 1) if total_budget else None,
                   "over": bool(total_budget and total_actual > total_budget)},
        "set_count": len(rows),
    }


def _finance_range(ctx):
    """The reporting window: an explicit from/to, else a whole calendar year."""
    q = ctx.query
    frm, to = (q.get("from") or "")[:10], (q.get("to") or "")[:10]
    if frm and to:
        return (frm, to) if frm <= to else (to, frm)
    year = q.get("year") or _today()[:4]
    try:
        year = int(year)
    except (TypeError, ValueError):
        year = int(_today()[:4])
    return f"{year}-01-01", f"{year}-12-31"


def _month_keys(frm, to, cap=36):
    """['2026-01', '2026-02', …] across the window."""
    y, m = int(frm[:4]), int(frm[5:7])
    end = to[:7]
    out = []
    while len(out) < cap:
        key = f"{y:04d}-{m:02d}"
        out.append(key)
        if key >= end:
            break
        m += 1
        if m > 12:
            y, m = y + 1, 1
    return out


def _sum_by_month(sql, params):
    return {r["m"]: round(r["v"] or 0, 2) for r in db.query(sql, params)}


@route("GET", r"/api/finance/summary")
def finance_summary(ctx):
    """The whole picture for one window: what came in, what went out, what is
    left, and what the standing bills will cost whether or not work comes in."""
    require_perm(ctx.user, "finance.view")
    frm, to = _finance_range(ctx)
    months = _month_keys(frm, to)
    rng = (frm, to)

    collected = _sum_by_month(
        "SELECT strftime('%Y-%m', paid_at) m, SUM(amount) v FROM payments "
        "WHERE date(paid_at) BETWEEN date(?) AND date(?) GROUP BY 1", rng)
    invoiced = _sum_by_month(
        "SELECT strftime('%Y-%m', issue_date) m, SUM(total) v FROM invoices "
        "WHERE doc_type='invoice' AND status!='cancelled' "
        "AND date(issue_date) BETWEEN date(?) AND date(?) GROUP BY 1", rng)
    spent = _sum_by_month(
        "SELECT strftime('%Y-%m', spent_on) m, SUM(amount) v FROM expenses "
        "WHERE date(spent_on) BETWEEN date(?) AND date(?) GROUP BY 1", rng)
    # Stock-in and the travel log are already recorded elsewhere; they are read
    # here so the profit line is the truth, not the part that was typed twice.
    purchases = _sum_by_month(
        "SELECT strftime('%Y-%m', created_at) m, SUM(total_cost) v FROM purchase_orders "
        "WHERE date(created_at) BETWEEN date(?) AND date(?) GROUP BY 1", rng)
    transport = _sum_by_month(
        "SELECT strftime('%Y-%m', created_at) m, SUM(cost) v FROM transport_entries "
        "WHERE date(created_at) BETWEEN date(?) AND date(?) GROUP BY 1", rng)
    pocket = _sum_by_month(
        "SELECT strftime('%Y-%m', spent_on) m, SUM(amount) v FROM petty_cash "
        "WHERE kind='expense' AND status='approved' "
        "AND date(spent_on) BETWEEN date(?) AND date(?) GROUP BY 1", rng)

    series = []
    for key in months:
        rev = collected.get(key, 0)
        cost = round(spent.get(key, 0) + purchases.get(key, 0) + transport.get(key, 0)
                     + pocket.get(key, 0), 2)
        series.append({"m": key, "revenue": rev, "invoiced": invoiced.get(key, 0),
                       "expenses": spent.get(key, 0), "purchases": purchases.get(key, 0),
                       "transport": transport.get(key, 0), "pocket": pocket.get(key, 0),
                       "costs": cost, "profit": round(rev - cost, 2)})

    by_cat = [{"category": r["category"], "amount": round(r["v"] or 0, 2), "derived": False}
              for r in db.query(
                  "SELECT category, SUM(amount) v FROM expenses "
                  "WHERE date(spent_on) BETWEEN date(?) AND date(?) "
                  "GROUP BY category ORDER BY v DESC", rng)]
    for cat, total in (("inventory", sum(purchases.values())),
                       ("transport", sum(transport.values())),
                       ("pocket", sum(pocket.values()))):
        if total:
            by_cat.append({"category": cat, "amount": round(total, 2), "derived": True})
    by_cat.sort(key=lambda c: c["amount"], reverse=True)

    revenue = round(sum(collected.values()), 2)
    costs = round(sum(c["amount"] for c in by_cat), 2)
    profit = round(revenue - costs, 2)
    totals = {
        "revenue": revenue,
        "invoiced": round(sum(invoiced.values()), 2),
        "expenses": round(sum(spent.values()), 2),
        "purchases": round(sum(purchases.values()), 2),
        "transport": round(sum(transport.values()), 2),
        "pocket": round(sum(pocket.values()), 2),
        "costs": costs,
        "profit": profit,
        "margin": round(profit / revenue * 100, 1) if revenue else 0,
        "outstanding": round(db.query(
            "SELECT COALESCE(SUM(total - COALESCE("
            "(SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0)),0) v "
            "FROM invoices i WHERE doc_type='invoice' AND status NOT IN('cancelled','paid')",
            one=True)["v"] or 0, 2),
    }

    # Run rate: what the company owes every month before it sells anything.
    active = db.query("SELECT r.*, u.full_name user_name FROM cost_recurring r "
                      "LEFT JOIN users u ON u.id=r.user_id WHERE r.active=1")
    monthly = round(sum(_monthly_equiv(r["amount"], r["frequency"]) for r in active), 2)
    payroll_monthly = round(sum(_monthly_equiv(r["amount"], r["frequency"])
                                for r in active if r["category"] == "salary"), 2)
    run_rate = {"monthly": monthly, "annual": round(monthly * 12, 2),
                "payroll_monthly": payroll_monthly, "standing_orders": len(active)}

    # Payroll, per person: the standing salary, what was actually paid in the
    # window, and what that bought — completed visits, hence cost per visit.
    paid_by_user = {r["user_id"]: round(r["v"] or 0, 2) for r in db.query(
        "SELECT user_id, SUM(amount) v FROM expenses WHERE category='salary' "
        "AND user_id IS NOT NULL AND date(spent_on) BETWEEN date(?) AND date(?) "
        "GROUP BY user_id", rng)}
    visits_by_user = {r["agent_id"]: r["c"] for r in db.query(
        "SELECT agent_id, COUNT(*) c FROM visits WHERE status='completed' "
        "AND agent_id IS NOT NULL AND date(scheduled_start) BETWEEN date(?) AND date(?) "
        "GROUP BY agent_id", rng)}
    hours_by_user = {k: v for k, v in
                     _visit_hours_by("v.agent_id", rng, "AND v.agent_id IS NOT NULL").items() if k}
    payroll = []
    # Every wage the company pays, which includes the supervising field roles —
    # an area manager or a team leader draws a salary like anybody else.
    staff = db.query("SELECT id, full_name, role, active FROM users "
                     "WHERE role IN ('admin','manager','agent','area_manager','team_leader') "
                     "ORDER BY role, full_name")
    salaries = {r["user_id"]: r for r in active if r["category"] == "salary" and r["user_id"]}
    for s in staff:
        sal = salaries.get(s["id"])
        paid = paid_by_user.get(s["id"], 0)
        if not sal and not paid and not s["active"]:
            continue
        visits = visits_by_user.get(s["id"], 0)
        hrs = hours_by_user.get(s["id"], 0)
        payroll.append({
            "user_id": s["id"], "name": s["full_name"], "role": s["role"],
            "active": s["active"],
            "recurring_id": sal["id"] if sal else None,
            "monthly": round(_monthly_equiv(sal["amount"], sal["frequency"]), 2) if sal else 0,
            "frequency": sal["frequency"] if sal else None,
            "paid": paid, "visits": visits, "hours": hrs,
            "cost_per_visit": round(paid / visits, 2) if visits and paid else 0,
            # What an hour of this person's time costs, which is the figure a
            # quote should be priced against.
            "cost_per_hour": round(paid / hrs, 2) if hrs and paid else 0,
        })
    # Salary lines that belong to nobody in particular (a crew, a subcontractor).
    for r in active:
        if r["category"] == "salary" and not r["user_id"]:
            payroll.append({"user_id": None, "name": r["name"], "role": None, "active": 1,
                            "recurring_id": r["id"],
                            "monthly": round(_monthly_equiv(r["amount"], r["frequency"]), 2),
                            "frequency": r["frequency"],
                            "paid": 0, "visits": 0, "hours": 0,
                            "cost_per_visit": 0, "cost_per_hour": 0})

    today = _today()
    upcoming = [{"id": r["id"], "name": r["name"], "category": r["category"],
                 "amount": round(r["amount"], 2), "next_due": r["next_due"],
                 "overdue": str(r["next_due"])[:10] < today}
                for r in db.query(
                    "SELECT * FROM cost_recurring WHERE active=1 AND next_due IS NOT NULL "
                    "AND date(next_due) <= date('now','localtime','+30 days') ORDER BY date(next_due) LIMIT 20")]
    expiring = [{"contract_id": r["id"], "client_en": r["name_en"], "client_ar": r["name_ar"],
                 "end_date": r["end_date"], "days_left": r["days_left"],
                 "price": round(r["price"] or 0, 2), "frequency": r["frequency"]}
                for r in db.query(
                    "SELECT ct.id, ct.end_date, ct.price, ct.frequency, c.name_en, c.name_ar, "
                    "CAST(julianday(ct.end_date) - julianday('now','localtime') AS INTEGER) days_left "
                    "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
                    "WHERE ct.status='active' AND ct.end_date IS NOT NULL "
                    "AND date(ct.end_date) BETWEEN date('now','localtime') AND date('now','localtime','+90 days') "
                    "ORDER BY date(ct.end_date) LIMIT 20")]
    vendors = [{"vendor": r["vendor"], "amount": round(r["v"] or 0, 2)} for r in db.query(
        "SELECT vendor, SUM(amount) v FROM expenses WHERE vendor IS NOT NULL AND vendor!='' "
        "AND date(spent_on) BETWEEN date(?) AND date(?) GROUP BY vendor "
        "ORDER BY v DESC LIMIT 8", rng)]
    years = sorted({r["y"] for r in db.query(
        "SELECT strftime('%Y', spent_on) y FROM expenses UNION "
        "SELECT strftime('%Y', paid_at) y FROM payments") if r["y"]} | {today[:4]}, reverse=True)

    # Budget against actual, on the same window and the same category totals the
    # breakdown above is built from — so the two panels can never disagree.
    budget = _budget_compare(frm, to, {c["category"]: c["amount"] for c in by_cat})
    for c in by_cat:
        row = next((b for b in budget["categories"] if b["category"] == c["category"]), None)
        c["budget"] = row["budget"] if row else 0

    return {"from": frm, "to": to, "months": series, "by_category": by_cat,
            "totals": totals, "run_rate": run_rate, "payroll": payroll,
            "upcoming": upcoming, "expiring": expiring, "vendors": vendors, "years": years,
            "budget": budget, "budget_categories": list(BUDGET_CATEGORIES),
            "categories": EXPENSE_CATEGORIES, "currency": get_settings().get("currency") or "EGP"}


# A visit's length in hours. Checked-in time is what actually happened, so it
# wins; a scheduled window is the plan; DEFAULT_VISIT_HOURS is the last resort
# for an old visit that recorded neither. Labour is split by these hours rather
# than by visit count, because a 30-minute callout and a 6-hour fumigation are
# not the same cost.
DEFAULT_VISIT_HOURS = 1.0

_VISIT_HOURS_SQL = (
    "COALESCE("
    " CASE WHEN v.checkin_at IS NOT NULL AND v.checkout_at IS NOT NULL"
    "      THEN (julianday(v.checkout_at) - julianday(v.checkin_at)) * 24 END,"
    " CASE WHEN v.scheduled_end IS NOT NULL"
    "      THEN (julianday(v.scheduled_end) - julianday(v.scheduled_start)) * 24 END,"
    " %f)" % DEFAULT_VISIT_HOURS
)
# A stopwatch left running overnight would otherwise swallow the whole payroll.
MAX_VISIT_HOURS = 12.0
_VISIT_HOURS = f"MIN(MAX({_VISIT_HOURS_SQL}, 0.25), {MAX_VISIT_HOURS})"


def _visit_hours_by(column, rng, extra_where=""):
    """Completed hours in the window, grouped by any column of `visits`."""
    return {r["k"]: round(r["v"] or 0, 2) for r in db.query(
        f"SELECT COALESCE({column},0) k, SUM({_VISIT_HOURS}) v FROM visits v "
        f"WHERE v.status='completed' AND date(v.scheduled_start) BETWEEN date(?) AND date(?) "
        f"{extra_where} GROUP BY 1", rng)}


def _cost_pools(rng):
    """The costs that belong to everybody, for one window: wages actually paid,
    the overhead left in the ledger once wages are taken out, and the stock
    bought (which is charged on per customer/contract as materials used, so it
    is reported alongside rather than allocated twice)."""
    salary = round(db.query(
        "SELECT COALESCE(SUM(amount),0) v FROM expenses WHERE category='salary' "
        "AND date(spent_on) BETWEEN date(?) AND date(?)", rng, one=True)["v"], 2)
    ledger = round(db.query(
        "SELECT COALESCE(SUM(amount),0) v FROM expenses "
        "WHERE date(spent_on) BETWEEN date(?) AND date(?)", rng, one=True)["v"], 2)
    stock = round(db.query(
        "SELECT COALESCE(SUM(total_cost),0) v FROM purchase_orders "
        "WHERE date(created_at) BETWEEN date(?) AND date(?)", rng, one=True)["v"], 2)
    return salary, round(ledger - salary, 2), stock


# --------------------------------------------------------------------------
# VAT / SALES TAX — what was charged on invoices and is owed to the authority
# --------------------------------------------------------------------------
# The tax on an invoice is never the company's money. Treating the gross
# receipt as income makes a cash forecast optimistic by exactly the tax rate,
# every single period — so the liability is tracked as its own obligation and
# scheduled like any other bill.


def _vat_config():
    s = get_settings()
    mode = (s.get("vat_filing") or "monthly").lower()
    if mode not in ("monthly", "quarterly", "none"):
        mode = "none"
    try:
        due_days = int(float(s.get("vat_due_days") or 30))
    except (TypeError, ValueError):
        due_days = 30
    return mode, max(0, min(due_days, 180))


def _vat_period_bounds(day, mode):
    """The filing period containing `day`: (key, start, end)."""
    year, month = int(day[:4]), int(day[5:7])
    if mode == "quarterly":
        q = (month - 1) // 3 + 1
        start_m = (q - 1) * 3 + 1
        end_m = start_m + 2
        key = f"{year}-Q{q}"
    else:
        start_m = end_m = month
        key = f"{year}-{month:02d}"
    start = f"{year:04d}-{start_m:02d}-01"
    end = db.query("SELECT date(?, '+1 month', '-1 day') d",
                   (f"{year:04d}-{end_m:02d}-01",), one=True)["d"]
    return key, start, end


def _vat_output_for(start, end):
    """VAT charged on invoices ISSUED in the period — the accrual basis a return
    is normally filed on. Cancelled documents and quotes are not charges."""
    return round(db.query(
        "SELECT COALESCE(SUM(tax),0) v FROM invoices WHERE doc_type='invoice' "
        "AND status!='cancelled' AND date(issue_date) BETWEEN date(?) AND date(?)",
        (start, end), one=True)["v"], 2)


def _vat_row(vid):
    r = db.query("SELECT * FROM vat_returns WHERE id=?", (vid,), one=True)
    if r:
        r["net_due"] = round((r["output_vat"] or 0) - (r["input_vat"] or 0), 2)
    return r


def _generate_vat_returns():
    """Open a return for every closed filing period that has none yet, and keep
    an unpaid one's output figure in step with the invoices behind it (a late
    invoice for last month changes what is owed). Idempotent."""
    mode, due_days = _vat_config()
    if mode == "none":
        return 0
    today = _today()
    # Walk back over the last four periods so a gap (a box switched off for a
    # while, an old database) fills in rather than starting from today.
    created = 0
    cursor = today
    for _ in range(4):
        key, start, end = _vat_period_bounds(cursor, mode)
        if end < today:                     # only closed periods get a return
            due = db.query("SELECT date(?, ?) d", (end, f"+{due_days} days"), one=True)["d"]
            output = _vat_output_for(start, end)
            row = db.query("SELECT * FROM vat_returns WHERE period=?", (key,), one=True)
            if not row:
                if output:                  # nothing charged, nothing to file
                    db.execute(
                        "INSERT INTO vat_returns(period,period_start,period_end,due_date,output_vat) "
                        "VALUES(?,?,?,?,?)", (key, start, end, due, output))
                    created += 1
            elif row["status"] == "pending" and abs((row["output_vat"] or 0) - output) > 0.01:
                db.execute("UPDATE vat_returns SET output_vat=?, updated_at=datetime('now','localtime') "
                           "WHERE id=?", (output, row["id"]))
        cursor = db.query("SELECT date(?, '-1 month') d", (start,), one=True)["d"]
    return created


def _refresh_pending_vat():
    """Re-derive the output figure on every unpaid return before it is shown.

    A return is not a snapshot: an invoice raised or cancelled after the period
    closed changes what is owed, and a stale liability on screen is exactly the
    number that misleads. Cheap — there are only ever a handful of open returns.
    """
    for r in db.query("SELECT * FROM vat_returns WHERE status='pending'"):
        output = _vat_output_for(r["period_start"], r["period_end"])
        if abs((r["output_vat"] or 0) - output) > 0.01:
            db.execute("UPDATE vat_returns SET output_vat=?, updated_at=datetime('now','localtime') "
                       "WHERE id=?", (output, r["id"]))


def _vat_pending_items(start, horizon):
    """Filed-but-unpaid returns, plus the period now running, as cash outflows.

    The running period is computed live rather than stored — it is still moving,
    and pretending otherwise would put a number in the ledger that tomorrow's
    invoice changes."""
    mode, due_days = _vat_config()
    if mode == "none":
        return []
    _refresh_pending_vat()
    items = []
    for r in db.query("SELECT * FROM vat_returns WHERE status='pending' ORDER BY due_date"):
        net = round((r["output_vat"] or 0) - (r["input_vat"] or 0), 2)
        if net <= 0:
            continue
        day = str(r["due_date"])[:10]
        overdue = day < start
        if not overdue and day > horizon:
            continue
        items.append({"date": start if overdue else day, "kind": "out", "source": "vat",
                      "label": f"VAT {r['period']}", "category": "tax", "amount": net,
                      "certainty": "committed", "overdue": overdue,
                      "due_date": day, "vat_id": r["id"]})
    key, p_start, p_end = _vat_period_bounds(start, mode)
    if not db.query("SELECT 1 FROM vat_returns WHERE period=?", (key,), one=True):
        running = _vat_output_for(p_start, p_end)
        due = db.query("SELECT date(?, ?) d", (p_end, f"+{due_days} days"), one=True)["d"]
        if running > 0 and due <= horizon:
            items.append({"date": due, "kind": "out", "source": "vat",
                          "label": f"VAT {key}", "category": "tax", "amount": running,
                          "certainty": "expected", "period_open": True, "due_date": due})
    return items


@route("GET", r"/api/vat-returns")
def list_vat_returns(ctx):
    require_perm(ctx.user, "finance.view")
    mode, due_days = _vat_config()
    if mode != "none":
        _generate_vat_returns()      # a period may have closed since the last poll
        _refresh_pending_vat()
    rows = db.query("SELECT * FROM vat_returns ORDER BY period_end DESC LIMIT 24")
    for r in rows:
        r["net_due"] = round((r["output_vat"] or 0) - (r["input_vat"] or 0), 2)
        r["overdue"] = bool(r["status"] == "pending" and str(r["due_date"])[:10] < _today())
    running = None
    if mode != "none":
        key, start, end = _vat_period_bounds(_today(), mode)
        if not any(r["period"] == key for r in rows):
            running = {"period": key, "period_start": start, "period_end": end,
                       "due_date": db.query("SELECT date(?, ?) d",
                                            (end, f"+{due_days} days"), one=True)["d"],
                       "output_vat": _vat_output_for(start, end), "input_vat": 0,
                       "status": "open"}
            running["net_due"] = running["output_vat"]
    return {"filing": mode, "due_days": due_days, "returns": rows, "running": running}


@route("PUT", r"/api/vat-returns/(\d+)")
def update_vat_return(ctx):
    """Record reclaimable input VAT (or a note) against an open return."""
    require_perm(ctx.user, "finance.edit")
    vid = int(ctx.params[0])
    r = db.query("SELECT * FROM vat_returns WHERE id=?", (vid,), one=True)
    if not r:
        raise ApiError(404, "Not found")
    if r["status"] == "paid":
        raise ApiError(400, "That return is already paid")
    b = ctx.body
    fields, vals = [], []
    if "input_vat" in b:
        fields.append("input_vat=?"); vals.append(_amount(b["input_vat"], "input_vat"))
    if "note" in b:
        fields.append("note=?"); vals.append(b["note"])
    if fields:
        fields.append("updated_at=datetime('now','localtime')")
        vals.append(vid)
        db.execute(f"UPDATE vat_returns SET {','.join(fields)} WHERE id=?", vals)
        audit(ctx, "vat.update", "vat_return", vid, r["period"])
    return _vat_row(vid)


@route("POST", r"/api/vat-returns/(\d+)/pay")
def pay_vat_return(ctx):
    """Mark a return paid, writing the payment into the expense ledger so the
    money shows up as a real cost exactly once — and drops out of the forecast."""
    require_perm(ctx.user, "finance.create")
    vid = int(ctx.params[0])
    r = db.query("SELECT * FROM vat_returns WHERE id=?", (vid,), one=True)
    if not r:
        raise ApiError(404, "Not found")
    if r["status"] == "paid":
        raise ApiError(400, "That return is already paid")
    net = round((r["output_vat"] or 0) - (r["input_vat"] or 0), 2)
    if net <= 0:
        raise ApiError(400, "Nothing is owed on that return")
    day = (ctx.body.get("paid_on") or _today())[:10]
    with db.transaction() as cx:
        eid = cx.execute(
            "INSERT INTO expenses(spent_on,category,description,amount,reference,source,created_by) "
            "VALUES(?,?,?,?,?,?,?)",
            (day, "tax", f"VAT return {r['period']}", net, f"VAT-{r['period']}",
             "vat", ctx.user["id"])).lastrowid
        cx.execute("UPDATE vat_returns SET status='paid', expense_id=?, "
                   "updated_at=datetime('now','localtime') WHERE id=?", (eid, vid))
    audit(ctx, "vat.pay", "vat_return", vid, f"{r['period']} {net:g}")
    return _vat_row(vid)


CASHFLOW_MAX_WEEKS = 52


def _forecast_costs(start, horizon):
    """Every standing cost that falls due between two dates, one item per
    occurrence — the rent in each of the next three months, not once."""
    items = []
    for r in db.query("SELECT * FROM cost_recurring WHERE active=1 AND next_due IS NOT NULL"):
        day = str(r["next_due"])[:10]
        if day < start:
            # Already due and not yet posted: it is still money owed, so it
            # lands at the front of the forecast rather than in the past.
            day = start
        for _ in range(80):                       # safety cap
            if day > horizon:
                break
            if r["end_date"] and day > str(r["end_date"])[:10]:
                break
            items.append({
                "date": day, "kind": "out", "source": "recurring",
                "label": r["name"], "category": r["category"],
                "amount": round(float(r["amount"] or 0), 2),
                "certainty": "committed",
                # auto_post writes itself into the ledger; a manual one needs
                # somebody to actually pay it, which the owner should see.
                "needs_action": not r["auto_post"],
            })
            day = _add_period(day, r["frequency"], anchor=r["start_date"])
    return items


def _forecast_income(start, horizon):
    """Money expected in: balances on invoices already raised, then the invoices
    the auto-billing contracts will raise, each landing when its terms expire."""
    s = get_settings()
    try:
        terms = int(float(s.get("payment_terms_days") or 14))
    except (TypeError, ValueError):
        terms = 14
    try:
        tax_rate = float(s.get("tax_rate") or 0)
    except (TypeError, ValueError):
        tax_rate = 0.0
    items = []
    for i in db.query(
            "SELECT i.id, i.number, i.due_date, i.issue_date, i.total, c.name_en client, "
            "COALESCE((SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0) paid "
            "FROM invoices i JOIN clients c ON c.id=i.client_id "
            "WHERE i.doc_type='invoice' AND i.status IN ('sent','overdue')"):
        balance = round((i["total"] or 0) - (i["paid"] or 0), 2)
        if balance <= 0:
            continue
        due = str(i["due_date"] or i["issue_date"])[:10]
        overdue = due < start
        items.append({
            "date": start if overdue else due, "kind": "in", "source": "invoice",
            "label": f"{i['number']} — {i['client']}", "amount": balance,
            "certainty": "committed", "overdue": overdue, "due_date": due,
            "invoice_id": i["id"],
        })
    # Contracts that bill themselves: project the invoice, then the cash.
    for ct in db.query(
            "SELECT ct.*, c.name_en client FROM contracts ct JOIN clients c ON c.id=ct.client_id "
            "WHERE ct.status='active' AND ct.auto_invoice=1 AND ct.next_bill_date IS NOT NULL"):
        sites = db.query("SELECT COALESCE(SUM(price),0) v FROM contract_sites "
                         "WHERE contract_id=? AND price > 0", (ct["id"],), one=True)["v"]
        net = round(float(sites or ct["price"] or 0), 2)
        if net <= 0:
            continue
        gross = round(net * (1 + tax_rate / 100), 2)
        bill = str(ct["next_bill_date"])[:10]
        for _ in range(80):
            if bill > horizon:
                break
            if ct["end_date"] and bill > str(ct["end_date"])[:10]:
                break
            cash_day = db.query("SELECT date(?, ?) d", (bill, f"+{terms} days"), one=True)["d"]
            if cash_day <= horizon:
                items.append({
                    "date": max(cash_day, start), "kind": "in", "source": "contract",
                    "label": f"{ct['client']} — {t_freq(ct['bill_every'] or ct['frequency'])}",
                    "amount": gross, "certainty": "expected", "contract_id": ct["id"],
                    "bill_date": bill,
                })
            bill = _add_period(bill, ct["bill_every"] or ct["frequency"],
                               anchor=ct["start_date"])
    return items


def t_freq(freq):
    """Plain-English cadence for a forecast label (the SPA localizes its own)."""
    return {"weekly": "weekly", "biweekly": "fortnightly", "monthly": "monthly",
            "quarterly": "quarterly", "semiannual": "half-yearly",
            "annual": "yearly"}.get(freq, freq or "")


@route("GET", r"/api/finance/cashflow")
def finance_cashflow(ctx):
    """Cash in and out, week by week, from the dates already in the system.

    Out: every standing cost, projected from its next_due through the horizon.
    In: what is still owed on invoices already raised, plus the invoices the
    auto-billing contracts will raise, each arriving when its payment terms
    expire. The running balance starts from the cash-on-hand figure in Settings,
    which is the one number the CRM cannot know by itself — without it the line
    still shows the shape of the month, just not the floor.
    """
    require_perm(ctx.user, "finance.view")
    try:
        weeks = int(ctx.query.get("weeks") or 13)
    except (TypeError, ValueError):
        weeks = 13
    weeks = max(1, min(weeks, CASHFLOW_MAX_WEEKS))
    start = _today()
    horizon = db.query("SELECT date(?, ?) d", (start, f"+{weeks * 7 - 1} days"), one=True)["d"]
    s = get_settings()
    opening_raw = ctx.query.get("opening", s.get("cash_on_hand") or 0)
    try:
        opening = round(float(opening_raw or 0), 2)
    except (TypeError, ValueError):
        opening = 0.0

    items = (_forecast_costs(start, horizon) + _forecast_income(start, horizon)
             + _vat_pending_items(start, horizon))
    items.sort(key=lambda i: (i["date"], i["kind"]))

    buckets, balance = [], opening
    for w in range(weeks):
        b_start = db.query("SELECT date(?, ?) d", (start, f"+{w * 7} days"), one=True)["d"]
        b_end = db.query("SELECT date(?, ?) d", (b_start, "+6 days"), one=True)["d"]
        week_items = [i for i in items if b_start <= i["date"] <= b_end]
        cash_in = round(sum(i["amount"] for i in week_items if i["kind"] == "in"), 2)
        cash_out = round(sum(i["amount"] for i in week_items if i["kind"] == "out"), 2)
        balance = round(balance + cash_in - cash_out, 2)
        buckets.append({"start": b_start, "end": b_end, "in": cash_in, "out": cash_out,
                        "net": round(cash_in - cash_out, 2), "balance": balance,
                        "items": len(week_items)})

    total_in = round(sum(b["in"] for b in buckets), 2)
    total_out = round(sum(b["out"] for b in buckets), 2)
    short = next((b for b in buckets if b["balance"] < 0), None)
    overdue = round(sum(i["amount"] for i in items
                        if i["kind"] == "in" and i.get("overdue")), 2)
    return {
        "start": start, "horizon": horizon, "weeks": weeks, "opening": opening,
        "opening_set": bool(float(s.get("cash_on_hand") or 0)),
        "buckets": buckets, "items": items[:200], "item_count": len(items),
        "totals": {"in": total_in, "out": total_out, "net": round(total_in - total_out, 2),
                   "closing": buckets[-1]["balance"] if buckets else opening},
        "overdue_in": overdue,
        "shortfall": {"start": short["start"], "balance": short["balance"]} if short else None,
        "currency": s.get("currency") or "EGP",
        # The tax inside the money coming in is not the company's to spend.
        "vat": {"filing": _vat_config()[0],
                "scheduled": round(sum(i["amount"] for i in items
                                       if i["source"] == "vat"), 2)},
    }


@route("GET", r"/api/finance/clients")
def finance_by_client(ctx):
    """Profit per customer: what each company paid, what serving it cost, and
    what is left.

    Three of the four costs are real and traceable to the client — the chemical
    used on its visits (valued at cost), the travel logged against them, and a
    share of the salaries actually paid, split by the visits each company took.
    The fourth, overhead (rent, tax, licences, the office), belongs to no
    customer in particular, so it is spread across them: by visits, because
    that is where the work went, or by revenue when ?basis=revenue is asked
    for. A company can therefore show a loss simply by being small — that is
    the point of showing the split, not a bug in it."""
    require_perm(ctx.user, "finance.view")
    frm, to = _finance_range(ctx)
    rng = (frm, to)
    basis = "revenue" if ctx.query.get("basis") == "revenue" else "visits"

    def by_client(sql):
        return {r["cid"]: round(r["v"] or 0, 2) for r in db.query(sql, rng) if r["cid"]}

    revenue = by_client(
        "SELECT i.client_id cid, SUM(p.amount) v FROM payments p "
        "JOIN invoices i ON i.id=p.invoice_id "
        "WHERE date(p.paid_at) BETWEEN date(?) AND date(?) GROUP BY 1")
    invoiced = by_client(
        "SELECT client_id cid, SUM(total) v FROM invoices "
        "WHERE doc_type='invoice' AND status!='cancelled' "
        "AND date(issue_date) BETWEEN date(?) AND date(?) GROUP BY 1")
    materials = by_client(
        "SELECT v.client_id cid, SUM(cu.quantity * c.cost_per_unit) v FROM chemical_usage cu "
        "JOIN visits v ON v.id=cu.visit_id JOIN chemicals c ON c.id=cu.chemical_id "
        "WHERE date(v.scheduled_start) BETWEEN date(?) AND date(?) GROUP BY 1")
    travel = by_client(
        "SELECT v.client_id cid, SUM(te.cost) v FROM transport_entries te "
        "JOIN visits v ON v.id=te.visit_id "
        "WHERE date(te.created_at) BETWEEN date(?) AND date(?) GROUP BY 1")
    # Pocket money reaches a customer only through the visit the claim named;
    # a taxi nobody tied to a job stays in the overhead pool with the rent.
    pocket = by_client(
        "SELECT v.client_id cid, SUM(pc.amount) v FROM petty_cash pc "
        "JOIN visits v ON v.id=pc.visit_id "
        "WHERE pc.kind='expense' AND pc.status='approved' "
        "AND date(pc.spent_on) BETWEEN date(?) AND date(?) GROUP BY 1")
    visits = {r["cid"]: r["v"] for r in db.query(
        "SELECT client_id cid, COUNT(*) v FROM visits WHERE status='completed' "
        "AND date(scheduled_start) BETWEEN date(?) AND date(?) GROUP BY 1", rng) if r["cid"]}
    # Labour follows the hours the work actually took.
    hours = {k: v for k, v in _visit_hours_by("v.client_id", rng).items() if k}
    last_visit = {r["cid"]: r["d"] for r in db.query(
        "SELECT client_id cid, MAX(scheduled_start) d FROM visits WHERE status='completed' "
        "GROUP BY 1") if r["cid"]}

    salary_pool, overhead_pool, stock_pool = _cost_pools(rng)

    total_visits = sum(visits.values())
    total_hours = sum(hours.values())
    total_revenue = sum(revenue.values())
    ids = set(revenue) | set(invoiced) | set(visits) | set(materials) | set(travel) | set(pocket)
    rows = []
    for c in db.query("SELECT id, name_en, name_ar, status FROM clients"):
        cid = c["id"]
        if cid not in ids:
            continue
        rev = revenue.get(cid, 0)
        vis = visits.get(cid, 0)
        hrs = hours.get(cid, 0)
        # Hours where they exist, visit count as the fallback — an old database
        # with neither timestamps nor scheduled ends still gets a sane split.
        work_share = (hrs / total_hours) if total_hours else ((vis / total_visits) if total_visits else 0)
        share = work_share if basis == "visits" else ((rev / total_revenue) if total_revenue else 0)
        mat, trv = materials.get(cid, 0), travel.get(cid, 0)
        pkt = pocket.get(cid, 0)
        labour = round(salary_pool * work_share, 2)
        overhead = round(overhead_pool * share, 2)
        cost = round(mat + trv + pkt + labour + overhead, 2)
        rows.append({
            "client_id": cid, "name_en": c["name_en"], "name_ar": c["name_ar"],
            "status": c["status"], "revenue": rev, "invoiced": invoiced.get(cid, 0),
            "visits": vis, "hours": hrs, "materials": mat, "travel": trv, "pocket": pkt,
            "labour": labour,
            "overhead": overhead, "cost": cost, "profit": round(rev - cost, 2),
            "margin": round((rev - cost) / rev * 100, 1) if rev else 0,
            "revenue_per_visit": round(rev / vis, 2) if vis else 0,
            "last_visit": last_visit.get(cid),
        })
    rows.sort(key=lambda r: r["profit"], reverse=True)
    totals = {k: round(sum(r[k] for r in rows), 2)
              for k in ("revenue", "invoiced", "materials", "travel", "pocket", "labour",
                        "overhead", "cost", "profit", "hours")}
    totals["visits"] = sum(r["visits"] for r in rows)
    return {"from": frm, "to": to, "basis": basis, "clients": rows, "totals": totals,
            "labour_basis": "hours" if total_hours else "visits",
            "pools": {"salary": salary_pool, "overhead": overhead_pool,
                      "stock_bought": stock_pool, "materials_used": round(sum(materials.values()), 2)}}


@route("GET", r"/api/finance/contracts")
def finance_by_contract(ctx):
    """Profit per contract: is this deal priced right for the work it takes?

    Same arithmetic as profit per customer, but keyed on the contract a visit
    was worked under and an invoice was raised for. Work that belongs to no
    contract — an ad-hoc callout, a visit booked before the deal existed — is
    reported as one 'unattributed' line rather than being spread over the deals,
    so a contract is never charged for work it did not ask for."""
    require_perm(ctx.user, "finance.view")
    frm, to = _finance_range(ctx)
    rng = (frm, to)
    basis = "revenue" if ctx.query.get("basis") == "revenue" else "visits"

    def by_contract(sql):
        return {r["k"]: round(r["v"] or 0, 2) for r in db.query(sql, rng)}

    revenue = by_contract(
        "SELECT COALESCE(i.contract_id,0) k, SUM(p.amount) v FROM payments p "
        "JOIN invoices i ON i.id=p.invoice_id "
        "WHERE date(p.paid_at) BETWEEN date(?) AND date(?) GROUP BY 1")
    invoiced = by_contract(
        "SELECT COALESCE(contract_id,0) k, SUM(total) v FROM invoices "
        "WHERE doc_type='invoice' AND status!='cancelled' "
        "AND date(issue_date) BETWEEN date(?) AND date(?) GROUP BY 1")
    materials = by_contract(
        "SELECT COALESCE(v.contract_id,0) k, SUM(cu.quantity * c.cost_per_unit) v "
        "FROM chemical_usage cu JOIN visits v ON v.id=cu.visit_id "
        "JOIN chemicals c ON c.id=cu.chemical_id "
        "WHERE date(v.scheduled_start) BETWEEN date(?) AND date(?) GROUP BY 1")
    travel = by_contract(
        "SELECT COALESCE(v.contract_id,0) k, SUM(te.cost) v FROM transport_entries te "
        "JOIN visits v ON v.id=te.visit_id "
        "WHERE date(te.created_at) BETWEEN date(?) AND date(?) GROUP BY 1")
    pocket = by_contract(
        "SELECT COALESCE(v.contract_id,0) k, SUM(pc.amount) v FROM petty_cash pc "
        "JOIN visits v ON v.id=pc.visit_id "
        "WHERE pc.kind='expense' AND pc.status='approved' "
        "AND date(pc.spent_on) BETWEEN date(?) AND date(?) GROUP BY 1")
    visits = {r["k"]: r["v"] for r in db.query(
        "SELECT COALESCE(contract_id,0) k, COUNT(*) v FROM visits WHERE status='completed' "
        "AND date(scheduled_start) BETWEEN date(?) AND date(?) GROUP BY 1", rng)}
    hours = _visit_hours_by("v.contract_id", rng)

    salary_pool, overhead_pool, stock_pool = _cost_pools(rng)
    total_visits = sum(visits.values())
    total_hours = sum(hours.values())
    total_revenue = sum(revenue.values())

    def line(key, name, extra=None):
        rev = revenue.get(key, 0)
        vis = visits.get(key, 0)
        hrs = hours.get(key, 0)
        work_share = (hrs / total_hours) if total_hours else ((vis / total_visits) if total_visits else 0)
        share = work_share if basis == "visits" else ((rev / total_revenue) if total_revenue else 0)
        mat, trv = materials.get(key, 0), travel.get(key, 0)
        pkt = pocket.get(key, 0)
        labour = round(salary_pool * work_share, 2)
        overhead = round(overhead_pool * share, 2)
        cost = round(mat + trv + pkt + labour + overhead, 2)
        row = {"contract_id": key or None, "name": name, "revenue": rev,
               "invoiced": invoiced.get(key, 0), "visits": vis, "hours": hrs, "materials": mat,
               "travel": trv, "pocket": pkt, "labour": labour, "overhead": overhead, "cost": cost,
               "profit": round(rev - cost, 2),
               "margin": round((rev - cost) / rev * 100, 1) if rev else 0}
        row.update(extra or {})
        return row

    # Pocket money counts towards a deal being ACTIVE in the window, exactly as
    # it does on the per-customer screen. Left out, a contract whose only cost
    # here was a taxi fare dropped off this list entirely — and its money with
    # it, since the totals are summed from the rows — while the same spend was
    # still visible against the customer.
    active = (set(revenue) | set(invoiced) | set(visits) | set(materials)
              | set(travel) | set(pocket))
    rows = []
    for ct in db.query(
            "SELECT ct.*, c.name_en client_en, c.name_ar client_ar, "
            "s.name_en service_en, s.name_ar service_ar, u.full_name agent_name "
            "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
            "LEFT JOIN service_types s ON s.id=ct.service_type_id "
            "LEFT JOIN users u ON u.id=ct.agent_id"):
        if ct["id"] not in active:
            continue
        rows.append(line(ct["id"], ct["client_en"], {
            "client_id": ct["client_id"], "client_en": ct["client_en"],
            "client_ar": ct["client_ar"], "service_en": ct["service_en"],
            "service_ar": ct["service_ar"], "agent_name": ct["agent_name"],
            "frequency": ct["frequency"], "price": ct["price"], "status": ct["status"],
            "start_date": ct["start_date"], "end_date": ct["end_date"],
            # What the deal SHOULD bring in over the window, at its own price and
            # cadence — the number the collected revenue is worth comparing to.
            "expected": round(_monthly_equiv(ct["price"], ct["bill_every"] or ct["frequency"])
                              * len(_month_keys(frm, to)), 2),
        }))
    rows.sort(key=lambda r: r["profit"], reverse=True)
    unattributed = line(0, "") if 0 in active else None
    totals = {k: round(sum(r[k] for r in rows) + (unattributed[k] if unattributed else 0), 2)
              for k in ("revenue", "invoiced", "materials", "travel", "pocket", "labour",
                        "overhead", "cost", "profit", "hours")}
    totals["visits"] = sum(r["visits"] for r in rows) + (unattributed["visits"] if unattributed else 0)
    return {"from": frm, "to": to, "basis": basis, "contracts": rows,
            "unattributed": unattributed, "totals": totals,
            "labour_basis": "hours" if total_hours else "visits",
            "pools": {"salary": salary_pool, "overhead": overhead_pool,
                      "stock_bought": stock_pool,
                      "materials_used": round(sum(materials.values()), 2)}}


# --------------------------------------------------------------------------
# MARKETING TARGETS — what an engineer brings in, and what it adds to their pay
# --------------------------------------------------------------------------
# An engineer who brings a customer in earns a share of that customer's
# contract — the company rate is 25% — and it is paid as an uplift on their
# salary for as long as the contract runs. End the contract or pause it and the
# uplift stops, and their pay is what it was before.
#
# That last rule is why NOTHING here is stored as an earned amount. The uplift
# is DERIVED, every time it is asked for, from the contracts the person is
# credited with and the status those contracts are in right now. A stored
# figure would have to be swept and corrected whenever a contract lapsed, and
# the day that sweep failed somebody would be overpaid without anybody knowing.
# The only thing written down is the target — what they were ASKED to bring in
# — because that is a decision, not a consequence.
#
# Every money figure on this screen is PER MONTH, salary included, so the
# target, the commission and the pay are one comparable scale. A contract's
# `price` is what it charges per cycle, so a quarterly contract is divided
# down to its monthly worth rather than counted whole.
CONTRACT_CYCLES_PER_MONTH = {
    "weekly": 52 / 12.0, "biweekly": 26 / 12.0, "monthly": 1.0,
    "quarterly": 1 / 3.0, "semiannual": 1 / 6.0, "annual": 1 / 12.0,
}

# The statuses that keep paying. Everything else — 'paused' (suspended) and
# 'ended' — takes the uplift away.
COMMISSION_EARNING_STATUS = "active"


def _commission_rate_default():
    """The company's share, in percent. Guarded to 0–100: a typo in settings
    must not multiply somebody's salary."""
    return _setting_num("commission_rate", 25.0, 0, 100)


def _contract_month_value(price, frequency):
    """One contract's worth per month, whatever cadence it bills on."""
    return round(float(price or 0) * CONTRACT_CYCLES_PER_MONTH.get(frequency, 1.0), 2)


def _commission_of(ct, default_rate):
    """(rate, value per month, commission per month) for one contract.

    `commission` is 0 for anything not active — the suspension rule lives here
    and nowhere else, so every screen that adds these up agrees about it."""
    raw = ct.get("commission_rate")
    rate = default_rate if raw is None else raw
    try:
        rate = max(0.0, min(100.0, float(rate)))
    except (TypeError, ValueError):
        rate = default_rate
    value = _contract_month_value(ct.get("price"), ct.get("frequency"))
    earning = ct.get("status") == COMMISSION_EARNING_STATUS
    return rate, value, (round(value * rate / 100.0, 2) if earning else 0.0)


def _base_salary(user_id):
    """What this person is paid before any commission: their standing salary
    orders, per month. 0 when the office has not entered one — the screen says
    so rather than implying they are paid nothing."""
    rows = db.query("SELECT amount, frequency FROM cost_recurring "
                    "WHERE user_id=? AND category='salary' AND active=1", (user_id,))
    return round(sum(_monthly_equiv(r["amount"], r["frequency"]) for r in rows), 2)


def _period_or_current(raw):
    """'YYYY-MM' from the query string, or this month. Anything else is this
    month too — a malformed period must not empty the page."""
    p = (raw or "").strip()[:7]
    return p if re.fullmatch(r"\d{4}-\d{2}", p) else \
        db.query("SELECT strftime('%Y-%m','now','localtime') p", one=True)["p"]


def _marketing_people(only_user=None):
    """Who belongs on this page: the field, plus anyone else who has actually
    been credited with a contract or given a target. A manager who sells is
    still selling; an admin who has never sold anything is not shown."""
    if only_user is not None:
        row = db.query("SELECT id, full_name, role, email FROM users WHERE id=? AND role<>'client'",
                       (only_user,), one=True)
        return [row] if row else []
    people = db.query(
        "SELECT id, full_name, role, email FROM users WHERE active=1 AND ("
        f"role IN ({','.join('?' * len(FIELD_ROLES))}) OR "
        "id IN (SELECT sold_by FROM contracts WHERE sold_by IS NOT NULL) OR "
        "id IN (SELECT user_id FROM marketing_targets)) AND role<>'client' "
        "ORDER BY full_name", tuple(FIELD_ROLES))
    return people


def _marketing_rows(period, only_user=None):
    """The whole picture per person: what they are credited with, what it pays
    them this month, what lapsing has cost them, and how the period is going
    against their target."""
    default_rate = _commission_rate_default()
    people = _marketing_people(only_user)
    if not people:
        return []
    ids = [p["id"] for p in people]
    ph = ",".join("?" * len(ids))
    contracts = db.query(
        f"SELECT ct.id, ct.sold_by, ct.status, ct.price, ct.frequency, ct.commission_rate, "
        f"ct.start_date, ct.end_date, ct.client_id, c.name_en client_en, c.name_ar client_ar "
        f"FROM contracts ct JOIN clients c ON c.id=ct.client_id "
        f"WHERE ct.sold_by IN ({ph}) ORDER BY ct.start_date DESC", tuple(ids))
    targets = {r["user_id"]: r for r in db.query(
        f"SELECT * FROM marketing_targets WHERE period=? AND user_id IN ({ph})",
        tuple([period] + ids))}

    by_person = {i: [] for i in ids}
    for ct in contracts:
        by_person[ct["sold_by"]].append(ct)

    rows = []
    for p in people:
        mine = by_person.get(p["id"], [])
        live = lapsed = 0
        live_value = commission = lapsed_value = lapsed_commission = 0.0
        won_n, won_value, won_commission = 0, 0.0, 0.0
        for ct in mine:
            rate, value, earned = _commission_of(ct, default_rate)
            would_earn = round(value * rate / 100.0, 2)
            if ct["status"] == COMMISSION_EARNING_STATUS:
                live += 1
                live_value += value
                commission += earned
            else:
                lapsed += 1
                lapsed_value += value
                # What it WOULD still be paying — the size of what stopping it
                # took off this person's pay.
                lapsed_commission += would_earn
            if (ct["start_date"] or "")[:7] == period:
                won_n += 1
                won_value += value
                won_commission += would_earn
        tgt = targets.get(p["id"]) or {}
        target_amount = float(tgt.get("target_amount") or 0)
        target_contracts = int(tgt.get("target_contracts") or 0)
        base = _base_salary(p["id"])
        commission = round(commission, 2)
        rows.append({
            "user_id": p["id"], "name": p["full_name"], "role": p["role"],
            "base_salary": base,
            "commission": commission,
            "effective_salary": round(base + commission, 2),
            "uplift_pct": round(commission * 100.0 / base, 1) if base else None,
            "active_contracts": live, "active_value": round(live_value, 2),
            "lapsed_contracts": lapsed, "lapsed_value": round(lapsed_value, 2),
            "lapsed_commission": round(lapsed_commission, 2),
            "won_contracts": won_n, "won_value": round(won_value, 2),
            "won_commission": round(won_commission, 2),
            "target_id": tgt.get("id"),
            "target_amount": round(target_amount, 2),
            "target_contracts": target_contracts,
            "target_note": tgt.get("note"),
            # Progress is measured on what was brought in THIS period, not on
            # the standing book — otherwise last year's win keeps hitting the
            # target every month and the number means nothing.
            "progress": round(won_value * 100.0 / target_amount, 1) if target_amount else None,
            "on_target": (won_value >= target_amount and
                          won_n >= target_contracts) if target_amount or target_contracts else None,
        })
    rows.sort(key=lambda r: (-(r["commission"] or 0), r["name"] or ""))
    return rows


def _may_see_pay(user, user_id):
    """A person's salary is their own business and the owner's. Everyone else
    sees the commission and the target without the pay it sits on."""
    return user["id"] == user_id or has_perm(user, "finance.view")


def _marketing_scope(user):
    """Who this login may look at: their own row only, unless they hold the
    edit right (the office) or the company's books."""
    if user["role"] == "client":
        raise ApiError(403, "You do not have permission for this action")
    require_perm(user, "targets.view")
    if has_perm(user, "targets.edit") or has_perm(user, "finance.view"):
        return None
    return user["id"]


@route("GET", r"/api/marketing/targets")
def marketing_targets(ctx):
    """The team's targets and standing commission for a month."""
    u = ctx.user
    only = _marketing_scope(u)
    period = _period_or_current(ctx.query.get("period"))
    rows = _marketing_rows(period, only)
    for r in rows:
        if not _may_see_pay(u, r["user_id"]):
            r["base_salary"] = None
            r["effective_salary"] = None
            r["uplift_pct"] = None
    totals = {
        "people": len(rows),
        "commission": round(sum(r["commission"] for r in rows), 2),
        "active_contracts": sum(r["active_contracts"] for r in rows),
        "active_value": round(sum(r["active_value"] for r in rows), 2),
        "won_value": round(sum(r["won_value"] for r in rows), 2),
        "target_amount": round(sum(r["target_amount"] for r in rows), 2),
        "lapsed_commission": round(sum(r["lapsed_commission"] for r in rows), 2),
        "on_target": sum(1 for r in rows if r["on_target"]),
    }
    out = {"period": period, "rate": _commission_rate_default(),
           "rows": rows, "totals": totals, "self_only": only is not None,
           "can_edit": has_perm(u, "targets.edit")}
    if out["can_edit"]:
        # Work nobody has been credited with is money nobody is being paid for
        # and, more to the point, a decision the office has not made yet.
        out["unattributed"] = db.query(
            "SELECT ct.id, ct.price, ct.frequency, ct.start_date, "
            "c.name_en client_en, c.name_ar client_ar "
            "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
            "WHERE ct.sold_by IS NULL AND ct.status='active' "
            "ORDER BY ct.start_date DESC LIMIT 50")
        for ct in out["unattributed"]:
            ct["value_month"] = _contract_month_value(ct["price"], ct["frequency"])
    return out


@route("GET", r"/api/marketing/person/(\d+)")
def marketing_person(ctx):
    """One person's file: every contract they are credited with, what each one
    pays them, and the targets they have been set."""
    u = ctx.user
    only = _marketing_scope(u)
    uid = int(ctx.params[0])
    if only is not None and uid != only:
        raise ApiError(403, "You do not have permission for this action")
    period = _period_or_current(ctx.query.get("period"))
    rows = _marketing_rows(period, uid)
    if not rows:
        raise ApiError(404, "Not found")
    summary = rows[0]
    if not _may_see_pay(u, uid):
        summary["base_salary"] = summary["effective_salary"] = summary["uplift_pct"] = None
    default_rate = _commission_rate_default()
    contracts = db.query(
        "SELECT ct.id, ct.client_id, ct.status, ct.price, ct.frequency, ct.commission_rate, "
        "ct.start_date, ct.end_date, c.name_en client_en, c.name_ar client_ar "
        "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
        "WHERE ct.sold_by=? ORDER BY (ct.status='active') DESC, ct.start_date DESC", (uid,))
    for ct in contracts:
        rate, value, earned = _commission_of(ct, default_rate)
        ct["rate"] = rate
        ct["value_month"] = value
        ct["commission"] = earned
        # What it would pay if it were running again — the figure that makes a
        # paused contract worth chasing.
        ct["commission_if_active"] = round(value * rate / 100.0, 2)
    return {"period": period, "rate": default_rate, "person": summary,
            "contracts": contracts, "can_edit": has_perm(u, "targets.edit"),
            "targets": db.query("SELECT * FROM marketing_targets WHERE user_id=? "
                                "ORDER BY period DESC LIMIT 12", (uid,))}


@route("POST", r"/api/marketing/targets")
def set_marketing_target(ctx):
    """Set (or change) what one person is asked to bring in for one month.
    One row per person per month — sending it twice edits, never duplicates."""
    require_perm(ctx.user, "targets.edit")
    b = ctx.body
    uid = b.get("user_id")
    if not uid:
        raise ApiError(400, "Choose whose target this is")
    person = db.query("SELECT id, role, full_name FROM users WHERE id=?", (uid,), one=True)
    if not person or person["role"] == "client":
        raise ApiError(400, "That is not a member of staff")
    period = (b.get("period") or "").strip()[:7]
    if not re.fullmatch(r"\d{4}-\d{2}", period):
        raise ApiError(400, "A target needs a month, as YYYY-MM")
    amount = _amount(b.get("target_amount") or 0, "Target amount")
    try:
        count = max(0, int(b.get("target_contracts") or 0))
    except (TypeError, ValueError):
        raise ApiError(400, "Number of contracts must be a whole number")
    existing = db.query("SELECT id FROM marketing_targets WHERE user_id=? AND period=?",
                        (uid, period), one=True)
    if existing:
        db.execute("UPDATE marketing_targets SET target_amount=?, target_contracts=?, note=?, "
                   "updated_at=datetime('now','localtime') WHERE id=?",
                   (amount, count, b.get("note"), existing["id"]))
        tid = existing["id"]
    else:
        tid = db.execute(
            "INSERT INTO marketing_targets(user_id,period,target_amount,target_contracts,note,created_by) "
            "VALUES(?,?,?,?,?,?)", (uid, period, amount, count, b.get("note"), ctx.user["id"]))
    audit(ctx, "target.set", "marketing_target", tid,
          f"{person['full_name']} {period}: {amount}")
    return db.query("SELECT * FROM marketing_targets WHERE id=?", (tid,), one=True)


@route("DELETE", r"/api/marketing/targets/(\d+)")
def delete_marketing_target(ctx):
    require_perm(ctx.user, "targets.edit")
    tid = int(ctx.params[0])
    if not db.query("SELECT id FROM marketing_targets WHERE id=?", (tid,), one=True):
        raise ApiError(404, "Not found")
    db.execute("DELETE FROM marketing_targets WHERE id=?", (tid,))
    audit(ctx, "target.delete", "marketing_target", tid, "")
    return {"ok": True}


@route("POST", r"/api/marketing/attribute")
def attribute_contract(ctx):
    """Credit a contract to the person who brought it in (or take the credit
    away by sending user_id null). Separate from editing the contract itself so
    the office can settle credit from this page without the right to change
    what the customer is being charged."""
    require_perm(ctx.user, "targets.edit")
    b = ctx.body
    cid = b.get("contract_id")
    ct = db.query("SELECT * FROM contracts WHERE id=?", (cid,), one=True) if cid else None
    if not ct:
        raise ApiError(404, "Contract not found")
    uid = b.get("user_id") or None
    if uid:
        person = db.query("SELECT id, role FROM users WHERE id=? AND active=1", (uid,), one=True)
        if not person or person["role"] == "client":
            raise ApiError(400, "That is not a member of staff")
    rate = b.get("commission_rate")
    if rate in ("", None):
        rate = ct.get("commission_rate")
    else:
        rate = _amount(rate, "Commission rate")
        if not 0 <= rate <= 100:
            raise ApiError(400, "A commission rate is a percentage between 0 and 100")
    db.execute("UPDATE contracts SET sold_by=?, commission_rate=? WHERE id=?", (uid, rate, cid))
    audit(ctx, "contract.attribute", "contract", cid, f"sold_by={uid}")
    if uid and uid != ctx.user["id"]:
        _notify_commission_started(int(uid), cid)
    return db.query("SELECT * FROM contracts WHERE id=?", (cid,), one=True)


def _notify_commission_started(user_id, contract_id):
    """Tell somebody a contract is now earning them money. Dedup per contract,
    so re-crediting the same contract to the same person is not a second
    announcement."""
    ct = db.query("SELECT ct.price, ct.frequency, ct.commission_rate, ct.status, "
                  "c.name_en client_en FROM contracts ct JOIN clients c ON c.id=ct.client_id "
                  "WHERE ct.id=?", (contract_id,), one=True)
    if not ct:
        return
    rate, _value, earned = _commission_of(ct, _commission_rate_default())
    _notify(user_id, "commission_started", "Contract credited to you",
            f"{ct['client_en']} — {rate:g}% commission, {earned:g} per month while it runs.",
            "marketing", contract_id, f"comm:{contract_id}:{user_id}")


def _notify_commission_ended(contract_id, new_status):
    """The moment the uplift goes away, said out loud. A salary quietly
    dropping back at the end of the month is how a person finds out the wrong
    way."""
    ct = db.query("SELECT ct.sold_by, ct.price, ct.frequency, ct.commission_rate, "
                  "c.name_en client_en FROM contracts ct JOIN clients c ON c.id=ct.client_id "
                  "WHERE ct.id=?", (contract_id,), one=True)
    if not ct or not ct["sold_by"]:
        return
    rate = ct["commission_rate"]
    rate = _commission_rate_default() if rate is None else float(rate)
    lost = round(_contract_month_value(ct["price"], ct["frequency"]) * rate / 100.0, 2)
    word = "suspended" if new_status == "paused" else "ended"
    _notify(int(ct["sold_by"]), "commission_ended", f"Contract {word}",
            f"{ct['client_en']} has been {word}. Your commission of {lost:g} per month "
            f"stops with it, and your salary returns to its usual figure.",
            "marketing", contract_id, f"commend:{contract_id}:{new_status}")


# --------------------------------------------------------------------------
# SMART DISPATCH — route optimization + SLA tracking
# --------------------------------------------------------------------------
DISPATCH_SLOT_MIN = 90   # minutes between visits when applying an optimized route


def _map_url(b):
    """The link the office pasted, kept as typed. Only a real map link is
    stored — a pair of numbers pasted into the same box is the pin, not a URL."""
    raw = (b.get("map_url") or b.get("geo") or "").strip()
    if not raw or "//" not in raw:
        return None
    parts = urlparse(raw)
    if parts.scheme not in ("http", "https") or (parts.hostname or "").lower() not in _MAP_HOSTS:
        return None
    return raw[:500]


def _coerce_latlng(b):
    """Pull (lat, lng) from a request body: a free-text `geo` field (lat,lng or
    a maps URL) or explicit numeric lat/lng. Returns (None, None) when absent."""
    geo = b.get("geo")
    if geo:
        ll = db._parse_latlng(geo)
        if ll:
            return ll
    lat, lng = b.get("lat"), b.get("lng")
    if lat in (None, "") or lng in (None, ""):
        return (None, None)
    try:
        lat, lng = float(lat), float(lng)
    except (TypeError, ValueError):
        return (None, None)
    if -90 <= lat <= 90 and -180 <= lng <= 180:
        return (lat, lng)
    return (None, None)


# Hosts a "share this place" link can legitimately come from. The server
# fetches whatever is pasted here, so it is an allow-list and not a filter:
# without one, a pasted link is a way to make this machine open any address on
# the internet on the office's behalf.
_MAP_HOSTS = ("maps.app.goo.gl", "goo.gl", "maps.google.com", "www.google.com",
              "google.com", "g.co", "maps.googleapis.com")


@route("POST", r"/api/geo/resolve")
def resolve_map_link(ctx):
    """Turn a pasted Google Maps link into coordinates.

    The office pins a branch on the phone and presses Share. What Google gives
    is `https://maps.app.goo.gl/xxxx` — a short link with NO coordinates in it
    at all, which is why pasting one used to leave the pin empty and look like
    the CRM had thrown it away. Nothing can be parsed out of it; it has to be
    followed, and a browser cannot follow it (Google sends no CORS header), so
    the server does it here.
    """
    require_perm(ctx.user, "clients.edit")
    raw = (ctx.body.get("url") or "").strip()
    if not raw:
        raise ApiError(400, "Paste a Google Maps link")
    # Anything already carrying coordinates never needs the network.
    got = db._parse_latlng(raw)
    if got:
        return {"lat": got[0], "lng": got[1], "url": raw, "followed": False}
    parts = urlparse(raw if "//" in raw else "https://" + raw)
    host = (parts.hostname or "").lower()
    if parts.scheme not in ("http", "https") or host not in _MAP_HOSTS:
        raise ApiError(400, "That is not a Google Maps link")
    try:
        req = urllib.request.Request(
            parts.geturl(),
            # Google hands a bare client a consent page instead of the place.
            headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                     "Accept-Language": "en"})
        with urllib.request.urlopen(req, timeout=12) as r:
            final = r.geturl()
            body = r.read(400000).decode("utf-8", "replace")
    except Exception as e:
        raise ApiError(502, f"Could not open that link ({type(e).__name__}). "
                            f"Open it in the browser and paste the address from the bar.")
    # The place may be in the address we landed on, or in the page itself —
    # Google's own map page carries the pin as !3d<lat>!4d<lng>.
    got = db._parse_latlng(final) or db._parse_latlng(body)
    if not got:
        raise ApiError(400, "That link does not name a place. In Google Maps, tap the "
                            "pin, then Share, and paste the link it gives.")
    return {"lat": got[0], "lng": got[1], "url": final, "followed": True}


def _haversine(a, b):
    """Great-circle distance in km between two (lat, lng) tuples."""
    R = 6371.0
    lat1, lng1, lat2, lng2 = map(math.radians, (a[0], a[1], b[0], b[1]))
    dlat, dlng = lat2 - lat1, lng2 - lng1
    h = math.sin(dlat / 2) ** 2 + math.cos(lat1) * math.cos(lat2) * math.sin(dlng / 2) ** 2
    return 2 * R * math.asin(math.sqrt(h))


def _visit_geo(v):
    """Resolve a visit's coordinates: its site's lat/lng, else parse the visit's
    free-text location. Returns (lat, lng) or None."""
    if v.get("site_lat") is not None and v.get("site_lng") is not None:
        return (v["site_lat"], v["site_lng"])
    return db._parse_latlng(v.get("location"))


def _route_km(points):
    """Total path length (km) visiting `points` (list of (lat,lng)) in order."""
    return sum(_haversine(points[i], points[i + 1]) for i in range(len(points) - 1))


@route("POST", r"/api/dispatch/optimize")
def dispatch_optimize(ctx):
    """Order one agent's visits for a day to minimize driving (nearest-neighbour
    on site coordinates). Preview by default; pass apply=true to rewrite the
    visits' scheduled times into the optimized sequence."""
    require_perm(ctx.user, "dispatch.view")
    require_perm(ctx.user, "visits.edit")
    b = ctx.body
    agent_id, date = b.get("agent_id"), b.get("date")
    if not agent_id or not date:
        raise ApiError(400, "An engineer and a date are required")
    # Applying this rewrites a whole day's scheduled times. A supervisor may do
    # that for their own day and for whoever they answer for — the crew the
    # roster puts on their areas that date, or their standing team — never for
    # an engineer who is neither.
    if ctx.user["role"] in SUPERVISOR_ROLES and int(agent_id) != ctx.user["id"]:
        if int(agent_id) not in team_member_ids(ctx.user, _shift_date(date)):
            raise ApiError(403, "That engineer is not on your team that day")
    rows = db.query(
        "SELECT v.id, v.scheduled_start, v.scheduled_end, v.location, "
        "c.name_en client_en, c.name_ar client_ar, st.name site_name, "
        "st.lat site_lat, st.lng site_lng "
        "FROM visits v JOIN clients c ON c.id=v.client_id "
        "LEFT JOIN sites st ON st.id=v.site_id "
        "WHERE v.agent_id=? AND date(v.scheduled_start)=date(?) "
        "AND v.status IN ('scheduled','in_progress') ORDER BY v.scheduled_start",
        (agent_id, date))
    geo, ungeo = [], []
    for v in rows:
        g = _visit_geo(v)
        if g:
            v["lat"], v["lng"] = g
            geo.append(v)
        else:
            ungeo.append(v)
    # start point: explicit in body, else company HQ coords, else the first stop
    start = _coerce_latlng(b)
    if start == (None, None):
        start = db._parse_latlng(get_settings().get("company_geo"))
    if not start and geo:
        start = (geo[0]["lat"], geo[0]["lng"])
    pre = ([start] if start else [])

    def length(seq):
        return _route_km(pre + [(g["lat"], g["lng"]) for g in seq])

    km_before = length(geo)
    # nearest-neighbour ordering
    remaining, optimized = geo[:], []
    cur = start or (remaining[0]["lat"], remaining[0]["lng"]) if remaining else None
    while remaining:
        nxt = min(remaining, key=lambda g: _haversine(cur, (g["lat"], g["lng"])))
        optimized.append(nxt); cur = (nxt["lat"], nxt["lng"]); remaining.remove(nxt)
    km_after = length(optimized)

    final = optimized + ungeo
    applied = False
    if b.get("apply") and final:
        starts = [v["scheduled_start"] for v in rows if v.get("scheduled_start")]
        first_t = min(starts)[11:16] if starts else "09:00"
        import datetime as _dt
        try:
            base = _dt.datetime.strptime(f"{date} {first_t}", "%Y-%m-%d %H:%M")
        except ValueError:
            base = _dt.datetime.strptime(f"{date} 09:00", "%Y-%m-%d %H:%M")
        with db.transaction() as cx:
            for i, v in enumerate(final):
                ns = (base + _dt.timedelta(minutes=i * DISPATCH_SLOT_MIN)).strftime("%Y-%m-%d %H:%M:00")
                cx.execute("UPDATE visits SET scheduled_start=? WHERE id=?", (ns, v["id"]))
        applied = True
        audit(ctx, "dispatch.optimize", "user", int(agent_id),
              f"{len(final)} visits on {date}, saved {round(km_before - km_after, 1)} km")

    def card(v, i):
        return {"id": v["id"], "seq": i + 1, "client_en": v["client_en"],
                "client_ar": v["client_ar"], "site_name": v["site_name"],
                "scheduled_start": v["scheduled_start"],
                "lat": v.get("lat"), "lng": v.get("lng")}
    return {
        "agent_id": int(agent_id), "date": date, "applied": applied,
        "km_before": round(km_before, 2), "km_after": round(km_after, 2),
        "km_saved": round(max(0, km_before - km_after), 2),
        "stops": len(geo), "ungeocoded": len(ungeo),
        "order": [card(v, i) for i, v in enumerate(final)],
        "has_start": bool(start),
    }


def _sla_rows():
    """Per active-contract SLA status. Tiered: ok / due_soon (period end
    approaching) / overdue (past period end + ~20% grace). Compares the contract
    cadence against the last COMPLETED visit for that client (+ site if set)."""
    out = []
    for ct in db.query(
            "SELECT ct.*, c.name_en client_en, c.name_ar client_ar, s.name site_name "
            "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
            "LEFT JOIN sites s ON s.id=ct.site_id WHERE ct.status='active' "
            # "Service overdue" is a complaint about work not done. Nobody owes
            # work to a customer who has stopped, or to a branch that has shut,
            # so those stop generating breaches the moment they are switched off.
            "AND c.status='active' AND (s.id IS NULL OR s.status='active')"):
        period = FREQ_DAYS.get(ct["frequency"], 30)
        site_clause, sp = "", []
        if ct["site_id"]:
            site_clause = " AND site_id=?"; sp = [ct["site_id"]]
        last = db.query(
            "SELECT MAX(date(COALESCE(completed_at, scheduled_start))) d FROM visits "
            "WHERE client_id=? AND status='completed'" + site_clause,
            (ct["client_id"], *sp), one=True)["d"]
        ref = last or ct["start_date"]
        days_since = db.query("SELECT CAST(julianday('now','localtime') - julianday(?) AS INT) d",
                              (ref,), one=True)["d"] or 0
        if days_since < period * 0.8:
            status = "ok"
        elif days_since <= period * 1.2:
            status = "due_soon"
        else:
            status = "overdue"
        out.append({
            "contract_id": ct["id"], "client_id": ct["client_id"],
            "client_en": ct["client_en"], "client_ar": ct["client_ar"],
            "site_id": ct["site_id"], "site_name": ct["site_name"], "frequency": ct["frequency"],
            "period_days": period, "last_service": last, "days_since": days_since,
            "days_overdue": max(0, days_since - period), "next_run_date": ct["next_run_date"],
            "status": status,
        })
    out.sort(key=lambda r: (-r["days_since"]))
    return out


@route("GET", r"/api/dispatch/sla")
def dispatch_sla(ctx):
    require_perm(ctx.user, "contracts.view")
    rows = _sla_rows()
    if ctx.user["role"] == "client":
        rows = [r for r in rows if r["client_id"] == ctx.user["client_id"]]
        pin = client_site_scope_id(ctx.user)
        if pin:
            rows = [r for r in rows if r["site_id"] in (None, pin)]
    counts = {"ok": 0, "due_soon": 0, "overdue": 0}
    for r in rows:
        counts[r["status"]] += 1
    return {"items": rows, "counts": counts}


# Python's own weekday numbering, for a sentence the office can read.
_WEEKDAYS = ["Monday", "Tuesday", "Wednesday", "Thursday",
             "Friday", "Saturday", "Sunday"]


def _post_days(raw):
    """A post's weekdays, from a list or a comma string, checked."""
    if raw is None:
        return []
    items = raw if isinstance(raw, list) else str(raw).split(",")
    out = set()
    for x in items:
        if str(x).strip() == "":
            continue
        try:
            w = int(x)
        except (TypeError, ValueError):
            raise ApiError(400, "Weekday must be 0-6")
        if not 0 <= w <= 6:
            raise ApiError(400, "Weekday must be 0-6")
        out.add(w)
    return sorted(out)


def _post_row(r):
    return {"id": r["id"], "site_id": r["site_id"], "site_name": r["site_name"],
            "client_en": r["client_en"], "client_ar": r["client_ar"],
            "primary_agent_id": r["primary_agent_id"], "primary_name": r["primary_name"],
            "relief_agent_id": r["relief_agent_id"], "relief_name": r["relief_name"],
            "primary_weekdays": _post_days(r["primary_weekdays"]),
            "relief_weekdays": _post_days(r["relief_weekdays"]),
            "from_time": r["from_time"], "to_time": r["to_time"],
            "start_date": r["start_date"], "end_date": r["end_date"],
            "active": r["active"]}


_POST_SQL = ("SELECT f.*, s.name AS site_name, c.name_en AS client_en, c.name_ar AS client_ar, "
             "p.full_name AS primary_name, r.full_name AS relief_name "
             "FROM fixed_assignments f JOIN sites s ON s.id=f.site_id "
             "JOIN clients c ON c.id=s.client_id "
             "LEFT JOIN users p ON p.id=f.primary_agent_id "
             "LEFT JOIN users r ON r.id=f.relief_agent_id ")


# The sections a menu may hide. The dashboard is deliberately absent: it is the
# way home, and a menu you cannot get back from is not a tidy menu.
NAV_KEYS = {
    "clients", "leads", "locations", "schedule", "dispatch", "requests", "reports",
    "transport", "contracts", "certificates", "chemicals", "issues", "cash",
    "devices", "ipm", "invoices", "finance", "marketing", "analytics", "agents",
    "availability", "fixedposts", "branchsched", "pipeline", "areas",
    "reportopts", "settings", "permissions", "backup", "search", "calendar",
    "shifts", "visits", "myday", "myteam",
}
PREF_KEYS = {"nav_hidden"}


def _read_prefs(user_id):
    out = {}
    for r in db.query("SELECT key, value FROM user_prefs WHERE user_id=?", (user_id,)):
        try:
            out[r["key"]] = json.loads(r["value"])
        except Exception:
            out[r["key"]] = r["value"]
    return out


@route("GET", r"/api/me/prefs")
def get_my_prefs(ctx):
    """A person's own preferences. No permission gates this — it is about what
    HE wants to look at, not what he is allowed to do."""
    return {"prefs": _read_prefs(ctx.user["id"])}


@route("PUT", r"/api/me/prefs")
def set_my_prefs(ctx):
    b = ctx.body if isinstance(ctx.body, dict) else {}
    unknown = set(b) - PREF_KEYS
    if unknown:
        raise ApiError(400, "Unknown preference: %s" % ", ".join(sorted(unknown)))
    if "nav_hidden" in b:
        val = b["nav_hidden"]
        if not isinstance(val, list):
            raise ApiError(400, "nav_hidden must be a list of sections")
        if len(val) > 60:
            raise ApiError(400, "Too many sections")
        clean = []
        for x in val:
            if not isinstance(x, str) or x not in NAV_KEYS:
                raise ApiError(400, "Not a section that can be hidden: %s" % str(x)[:40])
            if x not in clean:
                clean.append(x)
        db.execute("INSERT INTO user_prefs(user_id,key,value) VALUES(?,?,?) "
                   "ON CONFLICT(user_id,key) DO UPDATE SET value=excluded.value",
                   (ctx.user["id"], "nav_hidden", json.dumps(clean)))
    return {"prefs": _read_prefs(ctx.user["id"])}


@route("GET", r"/api/fixed-assignments")
def list_fixed_assignments(ctx):
    require_perm(ctx.user, "shifts.view")
    rows = db.query(_POST_SQL + "ORDER BY s.name")
    return {"items": [_post_row(r) for r in rows]}


def _fixed_fields(b, existing=None):
    cur = existing or {}
    try:
        site_id = int(b.get("site_id", cur.get("site_id")))
    except (TypeError, ValueError):
        raise ApiError(400, "Which site is the post at?")
    if not db.query("SELECT 1 FROM sites WHERE id=?", (site_id,), one=True):
        raise ApiError(404, "Site not found")

    def _who(key, required):
        raw = b.get(key, cur.get(key))
        if raw in (None, "", 0, "0"):
            if required:
                raise ApiError(400, "A post needs an engineer")
            return None
        who = db.query("SELECT role FROM users WHERE id=?", (int(raw),), one=True)
        if not who:
            raise ApiError(404, "Engineer not found")
        if who["role"] not in FIELD_ROLES:
            raise ApiError(400, "Only engineers and team leaders can hold a post")
        return int(raw)

    prim = _who("primary_agent_id", True)
    relief = _who("relief_agent_id", False)
    pdays = _post_days(b.get("primary_weekdays", cur.get("primary_weekdays")))
    rdays = _post_days(b.get("relief_weekdays", cur.get("relief_weekdays")))
    if set(pdays) & set(rdays):
        raise ApiError(400, "A day belongs to one of them, not both")
    if rdays and not relief:
        raise ApiError(400, "Name the relief engineer for the days he covers")
    if not pdays and not rdays:
        raise ApiError(400, "A post needs at least one day")
    f = _shift_time(b.get("from_time", cur.get("from_time")), "from_time")
    t = _shift_time(b.get("to_time", cur.get("to_time")), "to_time")
    if not f or not t:
        raise ApiError(400, "A post needs its hours")
    if roster.hhmm_min(t) <= roster.hhmm_min(f):
        raise ApiError(400, "A post must end after it starts")
    sd = b.get("start_date", cur.get("start_date")) or None
    ed = b.get("end_date", cur.get("end_date")) or None
    if sd:
        sd = _shift_date(sd, "start_date")
    if ed:
        ed = _shift_date(ed, "end_date")
    if sd and ed and ed < sd:
        raise ApiError(400, "A post cannot end before it starts")
    active = b.get("active", cur.get("active", 1))
    active = 1 if str(active) not in ("0", "False", "false") else 0
    # TWO LIVE POSTS CANNOT CLAIM THE SAME DOOR ON THE SAME DAY — the site
    # would be manned twice and one of the men would be sold to nobody.
    if active:
        claim = set(pdays) | set(rdays)
        for other in db.query("SELECT * FROM fixed_assignments WHERE site_id=? AND active=1",
                              (site_id,)):
            if existing and other["id"] == existing["id"]:
                continue
            taken = set(_post_days(other["primary_weekdays"])) | set(_post_days(other["relief_weekdays"]))
            if claim & taken:
                raise ApiError(400, "That site already has a post on those days")
    return {"start_date": sd, "end_date": ed,
            "site_id": site_id, "primary_agent_id": prim, "relief_agent_id": relief,
            "primary_weekdays": ",".join(str(x) for x in pdays),
            "relief_weekdays": ",".join(str(x) for x in rdays),
            "from_time": f, "to_time": t, "active": active}


@route("POST", r"/api/fixed-assignments")
def create_fixed_assignment(ctx):
    require_perm(ctx.user, "shifts.edit")
    f = _fixed_fields(ctx.body)
    fid = db.execute(
        "INSERT INTO fixed_assignments(site_id,primary_agent_id,relief_agent_id,"
        "primary_weekdays,relief_weekdays,from_time,to_time,start_date,end_date,active) "
        "VALUES(?,?,?,?,?,?,?,?,?,?)",
        (f["site_id"], f["primary_agent_id"], f["relief_agent_id"],
         f["primary_weekdays"], f["relief_weekdays"], f["from_time"], f["to_time"],
         f["start_date"], f["end_date"], f["active"]))
    audit(ctx, "fixed.create", "site", f["site_id"], "resident post")
    return _post_row(db.query(_POST_SQL + "WHERE f.id=?", (fid,), one=True))


@route("PUT", r"/api/fixed-assignments/(\d+)")
def update_fixed_assignment(ctx):
    require_perm(ctx.user, "shifts.edit")
    fid = int(ctx.params[0])
    cur = db.query("SELECT * FROM fixed_assignments WHERE id=?", (fid,), one=True)
    if not cur:
        raise ApiError(404, "Post not found")
    f = _fixed_fields(ctx.body, dict(cur, id=fid))
    db.execute("UPDATE fixed_assignments SET site_id=?,primary_agent_id=?,relief_agent_id=?,"
               "primary_weekdays=?,relief_weekdays=?,from_time=?,to_time=?,"
               "start_date=?,end_date=?,active=? WHERE id=?",
               (f["site_id"], f["primary_agent_id"], f["relief_agent_id"],
                f["primary_weekdays"], f["relief_weekdays"], f["from_time"], f["to_time"],
                f["start_date"], f["end_date"], f["active"], fid))
    audit(ctx, "fixed.update", "site", f["site_id"], "resident post")
    return _post_row(db.query(_POST_SQL + "WHERE f.id=?", (fid,), one=True))


@route("DELETE", r"/api/fixed-assignments/(\d+)")
def delete_fixed_assignment(ctx):
    require_perm(ctx.user, "shifts.edit")
    fid = int(ctx.params[0])
    cur = db.query("SELECT site_id FROM fixed_assignments WHERE id=?", (fid,), one=True)
    if not cur:
        raise ApiError(404, "Post not found")
    db.execute("DELETE FROM fixed_assignments WHERE id=?", (fid,))
    audit(ctx, "fixed.delete", "site", cur["site_id"], "resident post")
    return {"deleted": True}


@route("GET", r"/api/dispatch/grid")
def dispatch_grid(ctx):
    """THE BOARD FOR A WHOLE MONTH, counted on this side of the wire.

    A month of the office's book is 823 visits and 708 KB — a visit record
    carries its GPS, its accuracy, its notes and its area names in two
    languages, and a grid needs none of that. So the counting happens here and
    what crosses is one small cell per engineer per day: how many calls, and
    the first and last hour of them. Days a man is not out have no cell at all.
    """
    require_perm(ctx.user, "dispatch.view")
    frm = _shift_date(ctx.query.get("from"), "from")
    to = _shift_date(ctx.query.get("to") or ctx.query.get("from"), "to")
    if (_dt_mod.date.fromisoformat(to) - _dt_mod.date.fromisoformat(frm)).days > 62:
        raise ApiError(400, "Ask for at most two months at a time")
    want_agent = ctx.query.get("agent")
    want_area = ctx.query.get("area")
    people = db.query("SELECT id, full_name FROM users WHERE role='agent' AND active=1 "
                      "ORDER BY full_name")
    if want_agent:
        people = [p for p in people if str(p["id"]) == str(want_agent)]
    allowed = {p["id"] for p in people}
    rows = db.query(
        "SELECT v.id, v.agent_id, v.site_id, v.scheduled_start, v.status, s.area_id "
        "FROM visits v LEFT JOIN sites s ON s.id=v.site_id "
        "WHERE v.agent_id IS NOT NULL AND date(v.scheduled_start) BETWEEN ? AND ?",
        (frm, to))
    cells = {}
    for r in rows:
        if r["agent_id"] not in allowed:
            continue
        if want_area and str(r["area_id"] or "") != str(want_area):
            continue
        day = (r["scheduled_start"] or "")[:10]
        hhmm = (r["scheduled_start"] or "")[11:16]
        c = cells.setdefault((r["agent_id"], day),
                             {"agent_id": r["agent_id"], "date": day, "count": 0,
                              "first": hhmm, "last": hhmm})
        c["count"] += 1
        if hhmm and hhmm < c["first"]:
            c["first"] = hhmm
        if hhmm and hhmm > c["last"]:
            c["last"] = hhmm
    days, d0 = [], _dt_mod.date.fromisoformat(frm)
    while d0 <= _dt_mod.date.fromisoformat(to):
        days.append(d0.isoformat())
        d0 += _dt_mod.timedelta(days=1)
    return {"from": frm, "to": to, "days": days,
            "engineers": [{"id": p["id"], "full_name": p["full_name"]} for p in people],
            "cells": sorted(cells.values(), key=lambda c: (c["agent_id"], c["date"]))}


@route("GET", r"/api/dispatch/cell")
def dispatch_cell(ctx):
    """ONE ENGINEER, ONE DAY — the visits themselves, small enough to open on a
    phone. A month cell can only carry a count and two times; this is what it
    opens into, and what the office actually drags: one call at a time."""
    require_perm(ctx.user, "dispatch.view")
    date = _shift_date(ctx.query.get("date"), "date")
    try:
        agent_id = int(ctx.query.get("agent"))
    except (TypeError, ValueError):
        raise ApiError(400, "Which engineer?")
    rows = db.query(
        "SELECT v.id, v.scheduled_start, v.status, s.name AS site_name, s.area_id "
        "FROM visits v LEFT JOIN sites s ON s.id=v.site_id "
        "WHERE v.agent_id=? AND date(v.scheduled_start)=? "
        "ORDER BY v.scheduled_start", (agent_id, date))
    return {"date": date, "agent_id": agent_id,
            "visits": [{"id": r["id"], "time": (r["scheduled_start"] or "")[11:16],
                        "site_name": r["site_name"] or "", "status": r["status"],
                        "area_id": r["area_id"]} for r in rows]}


def _move_refusal(book, branch, person, date, visit_id, keep_min, dur, s):
    """WHY THE PLANNER WOULD NOT DRIVE THIS, in the office's own words.

    Every rule asked here is one the auto-roster already obeys, and it is asked
    THROUGH THE PLANNER'S OWN CODE — `Day._sequence` for the hours, the door's
    window, the length of the visit, the travel between stops and never being
    in two places at once. A board that let the office arrange what the planner
    would refuse would only be inventing work nobody can drive.
    """
    wd = date.weekday()
    if person is None or not person.days:
        return "%s has no working hours on the board." % (
            person.name if person else "That engineer")
    if branch is None:
        return "That visit has no branch to place."
    if branch.area_id not in person.areas:
        return "%s is not permitted in %s's area." % (person.name, branch.name)
    if not person.may_work(branch.area_id, wd):
        return "%s does not work that area on a %s." % (person.name, _WEEKDAYS[wd])
    if person.hours(wd) is None:
        return "%s does not work on a %s." % (person.name, _WEEKDAYS[wd])
    if person.id != branch.owner_id and not person.works_shift(branch.shift):
        return "%s works the %s shift and %s is %s work." % (
            person.name, person.shift, branch.name, branch.shift)
    if not branch.opens_on(wd):
        return "%s is not open on a %s." % (branch.name, _WEEKDAYS[wd])
    # ONE BRANCH, ONE DAY, ONE MAN — across every engineer, not just this one.
    clash = db.query(
        "SELECT v.id FROM visits v WHERE v.site_id=? AND date(v.scheduled_start)=? "
        "AND v.id<>? AND v.status NOT IN ('cancelled')",
        (branch.id, date.isoformat(), visit_id), one=True)
    if clash:
        return "%s already has a visit that day — one branch, one day, one van." % branch.name
    return None


@route("POST", r"/api/dispatch/move")
def dispatch_move(ctx):
    """Move work to another engineer or another day, if it can be driven.

    All or nothing: a move the planner would refuse is refused here too, with
    the reason, and the diary is left exactly as it was."""
    require_perm(ctx.user, "dispatch.view")
    require_perm(ctx.user, "visits.edit")
    b = ctx.body
    ids = b.get("visit_ids") or ([b["visit_id"]] if b.get("visit_id") else [])
    if not isinstance(ids, list) or not ids:
        raise ApiError(400, "Nothing to move")
    if len(ids) > 40:
        raise ApiError(400, "Too many visits in one move")
    try:
        agent_id = int(b.get("agent_id"))
    except (TypeError, ValueError):
        raise ApiError(400, "Which engineer?")
    date = _shift_date(b.get("date"), "date")
    d = _dt_mod.date.fromisoformat(date)
    s = _roster_settings()
    book = roster.load_book(db, date, date)
    roster.assign_owners(book, s, keep=True)
    person = book["people"].get(agent_id)
    visits = [db.query("SELECT * FROM visits WHERE id=?", (i,), one=True) for i in ids]
    if any(v is None for v in visits):
        raise ApiError(404, "Visit not found")
    # ---- every rule, before a single row is written ---------------------
    plan = []
    for v in visits:
        branch = book["branches"].get(v["site_id"])
        start = str(v["scheduled_start"] or "")
        keep = start[11:16] or "09:00"
        dur = 60
        try:
            dur = max(15, int((_dt_mod.datetime.fromisoformat(str(v["scheduled_end"]))
                               - _dt_mod.datetime.fromisoformat(start)).total_seconds() // 60))
        except Exception:
            pass
        why = _move_refusal(book, branch, person, d, v["id"], keep, dur, s)
        if why:
            raise ApiError(400, why)
        plan.append((v, branch, keep, dur))
    # ...and then the day as a whole: his hours, the doors' windows, the drive
    # between them, and never two calls at once. This is the planner's own
    # timing code, so the board and the button cannot disagree.
    day = roster.Day(person, d, person.hours(d.weekday()), s,
                     windows=person.windows(d.weekday()))
    keep_ids = {v["id"] for v, _b, _k, _du in plan}
    others = db.query(
        "SELECT v.id, v.site_id, v.scheduled_start, v.scheduled_end FROM visits v "
        "WHERE v.agent_id=? AND date(v.scheduled_start)=? AND v.status NOT IN ('cancelled')",
        (agent_id, date))
    items = []
    for o in others:
        if o["id"] in keep_ids:
            continue
        ob = book["branches"].get(o["site_id"])
        if ob is None:
            continue
        items.append((ob, 60, ob.window_on(d.weekday())))
    for _v, branch, _keep, dur in plan:
        items.append((branch, dur, branch.window_on(d.weekday())))
    if items and day._sequence(items) is None:
        loose = dict(s, travel_max=0, travel_area=0)
        was, day.s = day.s, loose
        room = day._sequence(items) is not None
        day.s = was
        raise ApiError(400, (
            "That round cannot be driven — the %d-minute travel ceiling is in the way."
            % int(s["travel_max"])) if room else
            "That round cannot be driven: his hours, the doors' opening times and "
            "the visits do not fit together.")
    with db.transaction() as cx:
        for v, _branch, keep, dur in plan:
            st = "%sT%s:00" % (date, keep)
            en = (_dt_mod.datetime.fromisoformat(st)
                  + _dt_mod.timedelta(minutes=dur)).isoformat(sep="T", timespec="seconds")
            cx.execute("UPDATE visits SET agent_id=?, scheduled_start=?, scheduled_end=? "
                       "WHERE id=?", (agent_id, st, en, v["id"]))
    audit(ctx, "dispatch.move", "visit", None,
          "%d visit(s) -> %s on %s" % (len(plan), person.name, date))
    return {"moved": len(plan), "agent_id": agent_id, "date": date}


# --------------------------------------------------------------------------
# VISIT REQUESTS — client self-service ("request a visit")
# --------------------------------------------------------------------------
@route("GET", r"/api/visit-requests")
def list_visit_requests(ctx):
    u = ctx.user
    require_perm(u, "requests.view")
    where, params = [], []
    if u["role"] == "client":
        where.append("vr.client_id=?"); params.append(u["client_id"])
        pin = client_site_scope_id(u)
        if pin:
            where.append("(vr.site_id IS NULL OR vr.site_id=?)"); params.append(pin)
    else:
        if ctx.query.get("status"):
            where.append("vr.status=?"); params.append(ctx.query["status"])
    sql = ("SELECT vr.*, c.name_en client_en, c.name_ar client_ar, s.name site_name, "
           "u.full_name requested_by FROM visit_requests vr "
           "JOIN clients c ON c.id=vr.client_id "
           "LEFT JOIN sites s ON s.id=vr.site_id "
           "LEFT JOIN users u ON u.id=vr.created_by")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY CASE vr.status WHEN 'pending' THEN 0 ELSE 1 END, vr.created_at DESC"
    return db.query(sql, params)


@route("POST", r"/api/visit-requests")
def create_visit_request(ctx):
    u, b = ctx.user, ctx.body
    require_perm(u, "requests.create")
    if u["role"] == "client":
        cid = u["client_id"]
    else:
        cid = b.get("client_id")
    if not cid:
        raise ApiError(400, "Client is required")
    _assert_client_access(u, cid)
    # A location-pinned portal login can only ever request work for its own site.
    site_id = client_site_scope_id(u) or b.get("site_id") or None
    if site_id and not db.query("SELECT 1 FROM sites WHERE id=? AND client_id=?", (site_id, cid), one=True):
        raise ApiError(400, "Invalid branch for this client")
    rid = db.execute(
        "INSERT INTO visit_requests(client_id,site_id,preferred_date,note,created_by) "
        "VALUES(?,?,?,?,?)", (cid, site_id, b.get("preferred_date"), b.get("note"), u["id"]))
    cl = db.query("SELECT name_en FROM clients WHERE id=?", (cid,), one=True)
    _notify_roles(("admin", "manager"), "visit_request", "New visit request",
                  f"{cl['name_en'] if cl else 'A client'} requested a visit"
                  + (f" for {b['preferred_date']}" if b.get("preferred_date") else ""),
                  "requests", rid, f"vreq:{rid}", exclude=u["id"])
    return db.query("SELECT * FROM visit_requests WHERE id=?", (rid,), one=True)


def _get_request_or_404(rid):
    r = db.query("SELECT * FROM visit_requests WHERE id=?", (rid,), one=True)
    if not r:
        raise ApiError(404, "Request not found")
    return r


@route("POST", r"/api/visit-requests/(\d+)/approve")
def approve_visit_request(ctx):
    # Approving books a real visit, so it needs both: the inbox and the diary.
    require_perm(ctx.user, "requests.edit")
    require_perm(ctx.user, "visits.create")
    r = _get_request_or_404(int(ctx.params[0]))
    if r["status"] != "pending":
        raise ApiError(400, "Request already handled")
    b = ctx.body
    day = r["preferred_date"] or db.query("SELECT date('now','localtime') d", one=True)["d"]
    start = b.get("scheduled_start") or (day + " 09:00:00")
    site_id = b.get("site_id", r["site_id"]) or None
    with db.transaction() as cx:
        vid = cx.execute(
            "INSERT INTO visits(client_id,site_id,agent_id,service_type_id,scheduled_start,"
            "status,notes) VALUES(?,?,?,?,?,?,?)",
            (r["client_id"], site_id, b.get("agent_id"), b.get("service_type_id"), start,
             "scheduled", r["note"])).lastrowid
        cx.execute("UPDATE visit_requests SET status='approved', visit_id=?, handled_by=?, "
                   "handled_at=datetime('now','localtime') WHERE id=?", (vid, ctx.user["id"], r["id"]))
    audit(ctx, "visit_request.approve", "visit", vid, f"from request #{r['id']}")
    # tell the requester their request was scheduled
    if r["created_by"]:
        _notify(r["created_by"], "request_approved", "Visit scheduled",
                f"Your visit request was scheduled for {start[:16]}", "visit", vid,
                f"vreqok:{r['id']}")
    return db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)


@route("POST", r"/api/visit-requests/(\d+)/decline")
def decline_visit_request(ctx):
    require_perm(ctx.user, "requests.edit")
    r = _get_request_or_404(int(ctx.params[0]))
    if r["status"] != "pending":
        raise ApiError(400, "Request already handled")
    db.execute("UPDATE visit_requests SET status='declined', handled_by=?, handled_at=datetime('now','localtime') "
               "WHERE id=?", (ctx.user["id"], r["id"]))
    audit(ctx, "visit_request.decline", "visit_request", r["id"])
    if r["created_by"]:
        _notify(r["created_by"], "request_declined", "Visit request declined",
                ctx.body.get("reason") or "Your visit request was declined.", "requests", r["id"],
                f"vreqno:{r['id']}")
    return {"ok": True}


# --------------------------------------------------------------------------
# NOTIFICATIONS / REMINDERS
# --------------------------------------------------------------------------
@route("GET", r"/api/notifications")
def list_notifications(ctx):
    if ctx.user["role"] in ("admin", "manager", "agent") + SUPERVISOR_ROLES:
        _maybe_generate_reminders()  # keep the bell live without a manual trigger
    rows = db.query("SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT 50",
                    (ctx.user["id"],))
    # Notification text is stored in English; show it in the user's language.
    # _translate caches per string, so 60s polls don't keep hitting the network.
    lang = ctx.query.get("lang")
    if lang in ("en", "ar"):
        for r in rows:
            r["title"] = _translate(r.get("title"), lang)
            if r.get("body"):
                r["body"] = _translate(r["body"], lang)
    unread = sum(1 for r in rows if not r["is_read"])
    return {"items": rows, "unread": unread}


@route("POST", r"/api/reminders/run")
def run_reminders(ctx):
    """Run the whole reminder scan now, ignoring the poll throttle.

    Configuring a dunning ladder or an expiry window and then waiting for the
    next background sweep to find out whether it works is a poor way to set
    something up — and the same button is what makes these paths testable."""
    require_perm(ctx.user, "settings.edit")
    global _reminder_last
    created = _generate_reminders()
    with _reminder_lock:
        _reminder_last = time.time()
    audit(ctx, "reminders.run", None, None, f"{created} notification(s)")
    return {"created": created}


@route("POST", r"/api/notifications/read")
def mark_notifications_read(ctx):
    ids = ctx.body.get("ids")
    if ids:
        q = ",".join("?" * len(ids))
        db.execute(f"UPDATE notifications SET is_read=1 WHERE user_id=? AND id IN ({q})",
                   [ctx.user["id"], *ids])
    else:
        db.execute("UPDATE notifications SET is_read=1 WHERE user_id=?", (ctx.user["id"],))
    return {"ok": True}


@route("POST", r"/api/notifications/generate")
def gen_notifications(ctx):
    require_perm(ctx.user, "visits.view")
    return {"created": _generate_reminders()}


# The bell rings for around thirty different things. Nobody can reason about
# thirty switches, and a bell that rings for everything gets ignored — which
# quietly breaks every feature that depends on somebody reading it. So the
# choice is offered by KIND. A type not listed here can never be muted: those
# are the ones about your own work or your own money.
NOTIFY_GROUPS = {
    "schedule": ("roster_ready", "roster_unplaced", "weekly_plan", "visit_due", "visit_reminder",
                 "visit_status", "visit_started", "visit_completed", "visit_request",
                 "request_approved", "request_declined"),
    "money": ("invoice_new", "invoice_overdue", "payment_received", "quote_new",
              "quote_approved", "quote_declined", "vat_due", "cost_due", "over_budget",
              "commission_started", "commission_ended"),
    "stock": ("low_stock", "issue_confirm", "issue_approved", "issue_declined",
              "return_received", "return_approved", "return_declined", "return_disputed"),
    "quality": ("rate_visit", "report_draft", "sla_breach", "devices_stale",
                "visit_rated"),
    "system": ("monitor_http", "monitor_disk", "monitor_db", "monitor_backup",
               "contract_expiring", "contract_new"),
}
_NOTIFY_GROUP_OF = {t: g for g, types in NOTIFY_GROUPS.items() for t in types}


def _notify_allowed(user_id, ntype):
    """Whether this person still wants to hear about this kind of thing."""
    grp = _NOTIFY_GROUP_OF.get(ntype)
    if not grp:
        return True                       # unmutable by design
    row = db.query("SELECT enabled FROM notification_prefs WHERE user_id=? AND grp=?",
                   (user_id, grp), one=True)
    return True if row is None else bool(row["enabled"])


@route("GET", r"/api/notification-prefs")
def get_notification_prefs(ctx):
    """A person's own choices. There is deliberately no way to set somebody
    else's — muting another person's alerts is not an administrative act."""
    have = {r["grp"]: bool(r["enabled"]) for r in db.query(
        "SELECT grp, enabled FROM notification_prefs WHERE user_id=?", (ctx.user["id"],))}
    return {"groups": [{"key": g, "enabled": have.get(g, True)} for g in NOTIFY_GROUPS]}


@route("PUT", r"/api/notification-prefs")
def set_notification_prefs(ctx):
    groups = ctx.body.get("groups") or {}
    if not isinstance(groups, dict):
        raise ApiError(400, "Expected a map of groups")
    unknown = [g for g in groups if g not in NOTIFY_GROUPS]
    if unknown:
        raise ApiError(400, f"Unknown alert kind: {unknown[0]}")
    with db.transaction() as cx:
        for g, on in groups.items():
            cx.execute("INSERT INTO notification_prefs(user_id,grp,enabled) VALUES(?,?,?) "
                       "ON CONFLICT(user_id,grp) DO UPDATE SET enabled=excluded.enabled",
                       (ctx.user["id"], g, 1 if on else 0))
    return get_notification_prefs(ctx)


def _notify(user_id, ntype, title, body, link_view=None, link_id=None, dedup_key=None):
    if not _notify_allowed(user_id, ntype):
        return False
    if dedup_key and db.query("SELECT id FROM notifications WHERE dedup_key=?", (dedup_key,), one=True):
        return False
    db.execute("INSERT INTO notifications(user_id,type,title,body,link_view,link_id,dedup_key) "
               "VALUES(?,?,?,?,?,?,?)", (user_id, ntype, title, body, link_view, link_id, dedup_key))
    _maybe_send_email(user_id, title, body)
    return True


def _notify_roles(roles, ntype, title, body, link_view=None, link_id=None, dedup_key=None, exclude=None):
    """Notify every active user holding one of `roles` (dedup key is made unique
    per recipient). `exclude` skips one user id (e.g. the actor)."""
    ph = ",".join("?" * len(roles))
    n = 0
    for usr in db.query(f"SELECT id FROM users WHERE role IN ({ph}) AND active=1", tuple(roles)):
        if exclude and usr["id"] == exclude:
            continue
        dk = f"{dedup_key}:{usr['id']}" if dedup_key else None
        if _notify(usr["id"], ntype, title, body, link_view, link_id, dk):
            n += 1
    return n


def _area_of(client_id, site_id=None):
    """The area a piece of work sits in: its branch's, falling back to its
    client's — the same rule VISIT_AREA_SQL uses, so the bell and the lists can
    never disagree about whose patch something is in."""
    if site_id:
        row = db.query("SELECT area_id FROM sites WHERE id=?", (site_id,), one=True)
        if row and row["area_id"]:
            return row["area_id"]
    row = db.query("SELECT area_id FROM clients WHERE id=?", (client_id,), one=True)
    return row["area_id"] if row else None


def _notify_supervisors(client_id, site_id, ntype, title, body,
                         link_view=None, link_id=None, dedup_key=None, exclude=None,
                         agent_id=None):
    """Tell whoever answers for this work: the area managers holding the patch
    it falls in, and — when the work has an engineer on it — that engineer's
    team leader.

    The area half is resolved from the area at the moment the event happens,
    never from a stored manager: hand an area to somebody else today and
    tonight's alerts go to them. Work whose branch and client are both untagged
    reaches no area manager, which is deliberate: an area nobody set is not
    silently everybody's business. The dedup key is made unique per recipient,
    so a supervisor's copy never collides with the manager's for the same
    event."""
    targets = []
    area = _area_of(client_id, site_id)
    if area:
        targets += [r["id"] for r in db.query(
            "SELECT u.id FROM users u JOIN area_manager_areas la ON la.manager_id=u.id "
            "WHERE u.role='area_manager' AND u.active=1 AND la.area_id=?", (area,))]
    if agent_id:
        boss = db.query(
            "SELECT tl.id FROM users u JOIN users tl ON tl.id=u.team_leader_id "
            "WHERE u.id=? AND tl.active=1 AND tl.role='team_leader'", (agent_id,), one=True)
        if boss:
            targets.append(boss["id"])
    n = 0
    for uid in dict.fromkeys(targets):
        if exclude and uid == exclude:
            continue
        dk = f"{dedup_key}:{uid}" if dedup_key else None
        if _notify(uid, ntype, title, body, link_view, link_id, dk):
            n += 1
    return n


def _notify_client_users(client_id, ntype, title, body, link_view=None, link_id=None, dedup_key=None):
    """Notify every active portal user of a client company."""
    n = 0
    for cu in db.query("SELECT id FROM users WHERE role='client' AND client_id=? AND active=1",
                       (client_id,)):
        dk = f"{dedup_key}:{cu['id']}" if dedup_key else None
        if _notify(cu["id"], ntype, title, body, link_view, link_id, dk):
            n += 1
    return n


def _maybe_send_email(user_id, subject, body):
    """Send email if SMTP is configured in settings; otherwise no-op (in-app only)."""
    s = get_settings()
    host = s.get("smtp_host")
    if not host:
        return
    try:
        import smtplib
        from email.message import EmailMessage
        user = db.query("SELECT email FROM users WHERE id=?", (user_id,), one=True)
        if not user or not user["email"]:
            return
        msg = EmailMessage()
        msg["From"] = s.get("smtp_from", s.get("email", "noreply@pestcare.com"))
        msg["To"] = user["email"]
        msg["Subject"] = subject
        msg.set_content(body or subject)
        port = int(s.get("smtp_port", 587))
        with smtplib.SMTP(host, port, timeout=10) as srv:
            if s.get("smtp_tls", "1") == "1":
                srv.starttls()
            if s.get("smtp_user"):
                srv.login(s["smtp_user"], s.get("smtp_pass", ""))
            srv.send_message(msg)
    except Exception as e:
        print("email send failed:", e)


# The notification bell is polled by every signed-in staff browser every 60s.
# Running the full reminder scan on each poll means repeated table scans + writes
# (DB contention + latency). Throttle it so the scan runs at most once per window
# no matter how many users are polling; the result is identical (it's idempotent
# and de-duplicated), just not recomputed needlessly.
_reminder_lock = threading.Lock()
_reminder_last = 0.0
REMINDER_MIN_INTERVAL = 120  # seconds (keeps "time to start" reminders timely)


def _maybe_generate_reminders():
    global _reminder_last
    now = time.time()
    with _reminder_lock:
        if now - _reminder_last < REMINDER_MIN_INTERVAL:
            return
        _reminder_last = now
    try:
        _generate_due_invoices()  # recurring billing, alongside reminders (idempotent)
        _generate_due_costs()     # rent, salaries and the rest post themselves
        _generate_vat_returns()   # open a return once a filing period closes
        _generate_reminders()
    except Exception as e:
        print("reminder gen:", e)


def _int_ladder(raw, default):
    """Parse a "3,14,30" setting into a descending list of whole days."""
    out = []
    for part in str(raw or "").split(","):
        part = part.strip()
        if not part:
            continue
        try:
            n = int(float(part))
        except (TypeError, ValueError):
            continue
        if n >= 0:
            out.append(n)
    return sorted(set(out or default), reverse=True)


def _run_dunning():
    """Remind the customer about an invoice that is past due."""
    s = get_settings()
    if str(s.get("dunning_enabled", "1")) in ("0", "false", "False"):
        return 0
    rungs = _int_ladder(s.get("dunning_days"), [3, 14, 30])
    if not rungs:
        return 0
    created = 0
    for inv in db.query(
            "SELECT i.id, i.number, i.total, i.due_date, c.id client_id, c.name_en, "
            "CAST(julianday('now','localtime') - julianday(i.due_date) AS INTEGER) days_over, "
            "COALESCE((SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0) paid "
            "FROM invoices i JOIN clients c ON c.id=i.client_id "
            "WHERE i.doc_type='invoice' AND i.status IN ('sent','overdue') "
            "AND i.due_date IS NOT NULL AND date(i.due_date) < date('now','localtime') "
            "AND COALESCE(c.dunning,1)=1"):
        balance = round((inv["total"] or 0) - (inv["paid"] or 0), 2)
        if balance <= 0.01:
            continue
        reached = next((r for r in rungs if inv["days_over"] >= r), None)
        if reached is None:
            continue
        body = (f"Invoice {inv['number']} was due on {str(inv['due_date'])[:10]} "
                f"and {balance:g} is still outstanding ({inv['days_over']} days).")
        created += _notify_client_users(
            inv["client_id"], "invoice_reminder", "Payment reminder", body,
            "invoice", inv["id"], f"dun:{inv['id']}:{reached}")
    return created


def _flag_expiring_contracts():
    """Tell the office before a contract lapses, not after."""
    rungs = _int_ladder(get_settings().get("contract_expiry_days"), [60, 30])
    if not rungs:
        return 0
    created = 0
    for ct in db.query(
            "SELECT ct.id, ct.end_date, ct.price, ct.frequency, c.name_en, "
            "CAST(julianday(ct.end_date) - julianday('now','localtime') AS INTEGER) days_left "
            "FROM contracts ct JOIN clients c ON c.id=ct.client_id "
            "WHERE ct.status='active' AND ct.end_date IS NOT NULL "
            "AND date(ct.end_date) >= date('now','localtime')"):
        reached = next((r for r in sorted(rungs) if ct["days_left"] <= r), None)
        if reached is None:
            continue
        for u in db.query("SELECT * FROM users WHERE active=1 AND role!='client'"):
            if not has_perm(u, "contracts.view"):
                continue
            if _notify(u["id"], "contract_expiring", "Contract expiring",
                       f"{ct['name_en']} — {ct['frequency']} contract ends "
                       f"{str(ct['end_date'])[:10]} ({ct['days_left']} days)",
                       "contracts", ct["id"], f"ctexp:{ct['id']}:{reached}:{u['id']}"):
                created += 1
    return created


def _generate_reminders():
    """Scan upcoming visits and overdue invoices and create de-duplicated reminders."""
    created = 0
    # upcoming visits in next 2 days -> notify assigned agent
    for v in db.query(
        "SELECT v.id, v.agent_id, v.scheduled_start, c.name_en FROM visits v "
        "JOIN clients c ON c.id=v.client_id WHERE v.status='scheduled' AND v.agent_id IS NOT NULL "
        "AND date(v.scheduled_start) BETWEEN date('now','localtime') AND date('now','localtime','+2 days')"):
        if _notify(v["agent_id"], "visit_reminder", "Upcoming visit",
                   f"{v['name_en']} on {v['scheduled_start'][:16]}", "visit", v["id"],
                   f"visitrem:{v['id']}:{v['scheduled_start'][:10]}"):
            created += 1
    # visits about to start (<=15 min away, still not started) -> remind the agent
    # it's time to start the visit.
    for v in db.query(
        "SELECT v.id, v.agent_id, v.scheduled_start, c.name_en FROM visits v "
        "JOIN clients c ON c.id=v.client_id WHERE v.status='scheduled' AND v.agent_id IS NOT NULL "
        "AND datetime(v.scheduled_start) <= datetime('now','localtime','+15 minutes') "
        "AND datetime(v.scheduled_start) >= datetime('now','localtime','-3 hours')"):
        if _notify(v["agent_id"], "visit_due", "Time to start your visit",
                   f"Your visit at {v['name_en']} starts at {v['scheduled_start'][11:16]}",
                   "visit", v["id"], f"visitstart:{v['id']}"):
            created += 1
    # unfinished (draft) reports left by agents -> remind the agent to complete &
    # save. Only nag once the draft has sat for >10 min (i.e. they likely left the
    # visit / logged out mid-report rather than still actively typing).
    for r in db.query(
        "SELECT r.visit_id, v.agent_id, c.name_en FROM reports r "
        "JOIN visits v ON v.id=r.visit_id JOIN clients c ON c.id=v.client_id "
        "WHERE r.status='draft' AND v.agent_id IS NOT NULL "
        "AND datetime(r.created_at) < datetime('now','localtime','-10 minutes')"):
        if _notify(r["agent_id"], "report_draft", "Unfinished report",
                   f"Complete & save your report for {r['name_en']}", "visit", r["visit_id"],
                   f"draftrep:{r['visit_id']}"):
            created += 1
    # materials released to an engineer that they have not answered for. The
    # approval notice already asked once; this is the follow-up half a day later,
    # so a handover cannot quietly stay one-sided.
    for i in db.query(
        "SELECT id, agent_id FROM engineer_issues WHERE status='approved' "
        "AND receipt_status IS NULL AND agent_id IS NOT NULL "
        "AND datetime(COALESCE(handled_at, created_at)) < datetime('now','localtime','-12 hours')"):
        if _notify(i["agent_id"], "issue_confirm", "Confirm your materials",
                   "Confirm you received the materials issued to you.",
                   "issues", i["id"], f"issuercv:{i['id']}"):
            created += 1
    # overdue invoices -> notify managers/admins
    managers = db.query("SELECT id FROM users WHERE role IN ('admin','manager') AND active=1")
    for inv in db.query(
        "SELECT i.id, i.number, i.total, c.name_en FROM invoices i JOIN clients c ON c.id=i.client_id "
        "WHERE i.doc_type='invoice' AND i.status IN ('sent','overdue') AND i.due_date IS NOT NULL "
        "AND date(i.due_date) < date('now','localtime')"):
        db.execute("UPDATE invoices SET status='overdue' WHERE id=? AND status='sent'", (inv["id"],))
        for m in managers:
            if _notify(m["id"], "invoice_overdue", "Invoice overdue",
                       f"{inv['number']} — {inv['name_en']} ({inv['total']})", "invoice", inv["id"],
                       f"ovd:{inv['id']}:{m['id']}"):
                created += 1
    # Chase the money. The office already hears about an overdue invoice; the
    # customer holding it should hear too, and on a schedule rather than when
    # somebody remembers. Only the highest rung reached fires, so an invoice
    # found at 40 days does not deliver three reminders at once, and a customer
    # marked dunning=0 is never chased automatically.
    created += _run_dunning()
    # A contract quietly running out is the cheapest revenue a company ever
    # loses. Flagged twice — far enough out to renegotiate, then again to act.
    created += _flag_expiring_contracts()
    # SLA breaches: a contract site whose service has slipped past its cadence
    # (period + grace) -> alert managers/admins. Dedup per contract per month so
    # a standing breach re-alerts monthly rather than every scan.
    bucket = db.query("SELECT strftime('%Y-%m','now','localtime') m", one=True)["m"]
    for r in _sla_rows():
        if r["status"] != "overdue":
            continue
        name = r["client_en"] + (f" — {r['site_name']}" if r["site_name"] else "")
        for m in managers:
            if _notify(m["id"], "sla_breach", "SLA breach — service overdue",
                       f"{name}: {r['frequency']} service is {r['days_overdue']} days overdue",
                       "dispatch", r["contract_id"], f"sla:{r['contract_id']}:{bucket}:{m['id']}"):
                created += 1
        # A service that has slipped in an area manager's patch is theirs to get
        # done — they hold the roster and the board that would fix it.
        created += _notify_supervisors(
            r["client_id"], r["site_id"], "sla_breach", "Service overdue in your area",
            f"{name}: {r['frequency']} service is {r['days_overdue']} days overdue",
            "dispatch", r["contract_id"], f"sla:{r['contract_id']}:{bucket}")
    # low-stock items -> alert managers/admins to reorder. Only flag items that
    # have a reorder level set (reorder_level=0 means "not tracked"). Dedup per
    # item per month so a standing shortage re-alerts monthly, not every scan.
    for ch in db.query(
        "SELECT id, name_en, unit, quantity_in_stock, reorder_level FROM chemicals "
        "WHERE reorder_level > 0 AND quantity_in_stock <= reorder_level"):
        for m in managers:
            if _notify(m["id"], "low_stock", "Low stock — reorder",
                       f"{ch['name_en']}: {ch['quantity_in_stock']:g} {ch['unit']} left "
                       f"(reorder at {ch['reorder_level']:g} {ch['unit']})",
                       "chemicals", ch["id"], f"restock:{ch['id']}:{bucket}:{m['id']}"):
                created += 1
    # Standing bills the owner asked to pay by hand (auto_post off) never post
    # themselves, so a due one is a reminder rather than a ledger row. Only
    # people who may see the finance page hear about the rent.
    due_bills = db.query(
        "SELECT id, name, amount, next_due FROM cost_recurring WHERE active=1 AND auto_post=0 "
        "AND next_due IS NOT NULL AND date(next_due) <= date('now','localtime','+3 days')")
    # A category that has already outrun this month's budget. Compared on the
    # month, not the year, so it is news while there is still time to act, and
    # deduped per category per month so it says so once.
    over_budget = []
    for b in db.query("SELECT * FROM cost_budgets WHERE year=strftime('%Y','now','localtime')"):
        allowed = _budget_for_window(b, 1)
        if allowed <= 0:
            continue
        spent = _category_actual_this_month(b["category"])
        if spent > allowed:
            over_budget.append((b["category"], spent, allowed))
    if due_bills or over_budget:
        for u in db.query("SELECT * FROM users WHERE active=1 AND role!='client'"):
            if not has_perm(u, "finance.view"):
                continue
            for r in due_bills:
                if _notify(u["id"], "cost_due", "Cost due",
                           f"{r['name']} — {r['amount']:g} due {str(r['next_due'])[:10]}",
                           "finance", r["id"], f"costdue:{r['id']}:{str(r['next_due'])[:10]}:{u['id']}"):
                    created += 1
            for r in db.query(
                    "SELECT * FROM vat_returns WHERE status='pending' "
                    "AND date(due_date) <= date('now','localtime','+7 days')"):
                net = round((r["output_vat"] or 0) - (r["input_vat"] or 0), 2)
                if net <= 0:
                    continue
                if _notify(u["id"], "vat_due", "VAT return due",
                           f"{r['period']}: {net:g} due {str(r['due_date'])[:10]}",
                           "finance", r["id"], f"vatdue:{r['period']}:{u['id']}"):
                    created += 1
            for cat, spent, allowed in over_budget:
                if _notify(u["id"], "over_budget", "Over budget",
                           f"{cat}: {spent:g} spent this month against a budget of {allowed:g}",
                           "finance", None, f"overbudget:{cat}:{bucket}:{u['id']}"):
                    created += 1
    # Devices overdue for a scan (not inspected in STALE_SCAN_DAYS, or never)
    # -> monthly summary alert to managers/admins so routine service gaps get
    # chased. One notification per month, not per device, to avoid spam.
    stale_n = _stale_count()
    if stale_n:
        for m in managers:
            if _notify(m["id"], "devices_stale", "Devices overdue for service",
                       f"{stale_n} device(s) not scanned in {STALE_SCAN_DAYS}+ days",
                       "devices", None, f"staledev:{bucket}:{m['id']}"):
                created += 1
    return created


# --------------------------------------------------------------------------
# ANALYTICS
# --------------------------------------------------------------------------
@route("GET", r"/api/engineers/scorecard")
def engineer_scorecard(ctx):
    """One row per engineer: the work done, and what it cost to do it.

    Every number here already exists somewhere in the CRM — visits, hours,
    scans, faults, deferrals, pocket money, materials, reports. The point is
    that a manager asking "how is Yousef doing?" should not have to open four
    screens and do arithmetic to find out."""
    require_perm(ctx.user, "analytics.view")
    if ctx.user["role"] in SUPERVISOR_ROLES:
        # analytics.view gets a supervisor their OPERATIONS. This card is built
        # on what each person costs, which is the office's business — the
        # My Team screen is the supervisor's version of the same question.
        raise ApiError(403, "You do not have permission for this action")
    import datetime as _dt
    q = ctx.query
    to = q.get("to") or _dt.date.today().isoformat()
    frm = q.get("from") or (_dt.date.today() - _dt.timedelta(days=90)).isoformat()
    rng = (frm, to)

    def by_agent(sql, params=None):
        return {r["k"]: r["v"] for r in db.query(sql, params if params is not None else rng)
                if r["k"]}

    visits = by_agent(
        "SELECT agent_id k, COUNT(*) v FROM visits WHERE date(scheduled_start) BETWEEN ? AND ? "
        "GROUP BY 1")
    done = by_agent(
        "SELECT agent_id k, COUNT(*) v FROM visits WHERE status='completed' "
        "AND date(scheduled_start) BETWEEN ? AND ? GROUP BY 1")
    hours = {k: v for k, v in _visit_hours_by("v.agent_id", rng).items() if k}
    scans = by_agent(
        "SELECT recorded_by k, COUNT(*) v FROM device_inspections "
        "WHERE date(recorded_at) BETWEEN ? AND ? GROUP BY 1")
    found = by_agent(
        "SELECT recorded_by k, COUNT(*) v FROM device_inspections "
        "WHERE status='activity' AND date(recorded_at) BETWEEN ? AND ? GROUP BY 1")
    # Promises made and promises kept: an engineer who defers everything and one
    # who fixes on the spot look identical on a visit count.
    defer_expr = " + ".join(
        "(CASE WHEN json_extract(details,'$.%s') LIKE 'next_visit%%' THEN 1 ELSE 0 END)" % f
        for f in ("trap_action", "lamp_action", "trans_light_action", "sheet_action",
                  "station_action", "electricity_action", "bait_action", "cleaned_action"))
    fixed_expr = " + ".join(
        "(CASE WHEN json_extract(details,'$.%s') IS NOT NULL "
        "AND json_extract(details,'$.%s') NOT LIKE 'next_visit%%' THEN 1 ELSE 0 END)" % (f, f)
        for f in ("trap_action", "lamp_action", "trans_light_action", "sheet_action",
                  "station_action", "electricity_action", "bait_action", "cleaned_action"))
    deferred = by_agent("SELECT recorded_by k, COALESCE(SUM(%s),0) v FROM device_inspections "
                        "WHERE date(recorded_at) BETWEEN ? AND ? GROUP BY 1" % defer_expr)
    fixed = by_agent("SELECT recorded_by k, COALESCE(SUM(%s),0) v FROM device_inspections "
                     "WHERE date(recorded_at) BETWEEN ? AND ? GROUP BY 1" % fixed_expr)
    materials = by_agent(
        "SELECT v.agent_id k, COALESCE(SUM(cu.quantity * ch.cost_per_unit),0) v "
        "FROM chemical_usage cu JOIN visits v ON v.id=cu.visit_id "
        "JOIN chemicals ch ON ch.id=cu.chemical_id "
        "WHERE date(v.scheduled_start) BETWEEN ? AND ? GROUP BY 1")
    cash = by_agent(
        "SELECT agent_id k, COALESCE(SUM(amount),0) v FROM petty_cash "
        "WHERE kind='expense' AND status='approved' AND date(spent_on) BETWEEN ? AND ? GROUP BY 1")
    drafts = by_agent(
        "SELECT v.agent_id k, COUNT(*) v FROM reports r JOIN visits v ON v.id=r.visit_id "
        "WHERE r.status<>'complete' AND date(v.scheduled_start) BETWEEN ? AND ? GROUP BY 1")
    signed = by_agent(
        "SELECT v.agent_id k, COUNT(*) v FROM reports r JOIN visits v ON v.id=r.visit_id "
        "WHERE r.customer_signature IS NOT NULL AND r.customer_signature<>'' "
        "AND date(v.scheduled_start) BETWEEN ? AND ? GROUP BY 1")
    rated = db.query(
        "SELECT v.agent_id k, AVG(vr.stars) v, COUNT(*) n FROM visit_ratings vr "
        "JOIN visits v ON v.id=vr.visit_id WHERE date(v.scheduled_start) BETWEEN ? AND ? "
        "GROUP BY 1", rng)
    stars = {r["k"]: (round(r["v"], 1), r["n"]) for r in rated if r["k"]}
    returns = by_agent(
        "SELECT mr.agent_id k, COUNT(*) v FROM material_returns mr "
        "WHERE mr.status='approved' AND date(mr.created_at) BETWEEN ? AND ? GROUP BY 1")

    rows = []
    for u in db.query("SELECT id, full_name, role, specialization FROM users "
                      "WHERE role IN ('agent','manager') AND active=1 ORDER BY full_name"):
        aid = u["id"]
        v_total, v_done = visits.get(aid, 0), done.get(aid, 0)
        hrs = round(hours.get(aid, 0), 1)
        actions = fixed.get(aid, 0) + deferred.get(aid, 0)
        if not (v_total or scans.get(aid) or cash.get(aid)):
            continue                       # nobody with nothing to say about them
        rows.append({
            "agent_id": aid, "agent_name": u["full_name"],
            "specialization": u["specialization"], "role": u["role"],
            "visits": v_total, "completed": v_done,
            "completion_rate": round(v_done * 100.0 / v_total) if v_total else 0,
            "hours": hrs,
            "visits_per_day": round(v_done / max(1, len(_months_between(frm, to)) * 22), 2),
            "scans": scans.get(aid, 0), "activity_found": found.get(aid, 0),
            "fixed": fixed.get(aid, 0), "deferred": deferred.get(aid, 0),
            "fixed_rate": round(fixed.get(aid, 0) * 100.0 / actions) if actions else None,
            "materials": round(materials.get(aid, 0), 2),
            "pocket": round(cash.get(aid, 0), 2),
            "returns": returns.get(aid, 0),
            "drafts": drafts.get(aid, 0), "signed": signed.get(aid, 0),
            "stars": stars.get(aid, (None, 0))[0], "ratings": stars.get(aid, (None, 0))[1],
            "cost_per_visit": round((materials.get(aid, 0) + cash.get(aid, 0)) / v_done, 2)
                              if v_done else 0,
        })
    rows.sort(key=lambda r: (-r["completed"], r["agent_name"]))
    return {"from": frm, "to": to, "engineers": rows}


@route("GET", r"/api/analytics")
def analytics(ctx):
    """Company-wide analytics, optionally scoped to one client and/or one of its
    sites, over a [from,to] date range (default: last 12 months). Finance +
    operations + collection KPIs + a fleet/pest rollup from the QR device scans."""
    require_perm(ctx.user, "analytics.view")
    import datetime
    q = ctx.query
    d_to = q.get("to") or datetime.date.today().isoformat()
    d_from = q.get("from") or (datetime.date.today() - datetime.timedelta(days=365)).isoformat()
    dr = (d_from, d_to)
    cid = int(q["client_id"]) if (q.get("client_id") or "").isdigit() else None
    if cid:
        _assert_client_access(ctx.user, cid)
    site_id = q.get("site_id") or None      # numeric id | "none" | None(all)
    labels = _months_between(d_from, d_to)
    r1 = lambda x: round(x, 1) if x is not None else None

    # A supervisor's analytics cover what they answer for and stop there — an
    # area manager's patch, a team leader's team. Applied inside scope(), which
    # every query below already goes through, so a new panel is scoped the day
    # it is written rather than the day someone remembers.
    is_leader = ctx.user["role"] in SUPERVISOR_ROLES
    leader_areas = area_manager_area_ids(ctx.user)
    crew = ([*team_member_ids(ctx.user), ctx.user["id"]]
            if ctx.user["role"] == "team_leader" else [])

    def scope(client_col, site_col):
        """AND-clause + params scoping to the selected client and/or site."""
        cl, pr = "", []
        if cid:
            cl += " AND %s=?" % client_col
            pr.append(cid)
        sf, sp = _site_filter(site_id, site_col)
        cl, pr = cl + sf, pr + list(sp)
        if ctx.user["role"] == "team_leader":
            # The companies this team is actually sent to — the same rule the
            # client list and the search box already apply to them.
            marks = ",".join("?" for _ in crew)
            cl += (f" AND {client_col} IN (SELECT client_id FROM visits "
                   f"WHERE agent_id IN ({marks}))")
            pr = pr + list(crew)
        elif is_leader:
            if not leader_areas:
                return cl + " AND 1=0", pr
            marks = ",".join("?" for _ in leader_areas)
            cl += (f" AND COALESCE((SELECT area_id FROM sites WHERE id={site_col}),"
                   f"(SELECT area_id FROM clients WHERE id={client_col})) IN ({marks})")
            pr = pr + list(leader_areas)
        return cl, pr

    DI_SITE = "(SELECT site_id FROM devices WHERE id=device_inspections.device_id)"

    # --- revenue trend: invoiced vs collected, per month over the range ---
    sc, sp = scope("client_id", "site_id")
    inv_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',issue_date) m, SUM(total) v FROM invoices "
        "WHERE doc_type='invoice' AND date(issue_date) BETWEEN ? AND ?" + sc + " GROUP BY m", (*dr, *sp))}
    sc, sp = scope("i.client_id", "i.site_id")
    paid_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',p.paid_at) m, SUM(p.amount) v FROM payments p "
        "JOIN invoices i ON i.id=p.invoice_id WHERE date(p.paid_at) BETWEEN ? AND ?" + sc + " GROUP BY m", (*dr, *sp))}
    months = [{"m": k, "total": round(inv_by.get(k, 0) or 0, 2),
               "paid": round(paid_by.get(k, 0) or 0, 2)} for k in labels]

    # AR aging: point-in-time snapshot of open invoices (client/site scoped).
    sc, sp = scope("i.client_id", "i.site_id")
    ar_aging = db.query(
        "SELECT CASE WHEN due_date IS NULL OR date(due_date)>=date('now','localtime') THEN 'current' "
        "WHEN date(due_date)>=date('now','localtime','-30 days') THEN '1-30' "
        "WHEN date(due_date)>=date('now','localtime','-60 days') THEN '31-60' ELSE '60+' END bucket, "
        "SUM(total - COALESCE((SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0)) due "
        "FROM invoices i WHERE doc_type='invoice' AND status NOT IN('paid','cancelled')" + sc + " GROUP BY bucket", sp)
    sc, sp = scope("v.client_id", "v.site_id")
    agents = db.query(
        "SELECT u.full_name, COUNT(v.id) total, "
        "SUM(CASE WHEN v.status='completed' THEN 1 ELSE 0 END) completed "
        "FROM users u LEFT JOIN visits v ON v.agent_id=u.id "
        "AND date(v.scheduled_start) BETWEEN ? AND ?" + sc +
        " WHERE u.role IN ('agent','area_manager','team_leader') GROUP BY u.id ORDER BY completed DESC", (*dr, *sp))
    # chemicals: scope via the usage's visit when a client/site is selected.
    sc, sp = scope("v.client_id", "v.site_id")
    cu_extra = (" AND cu.visit_id IN (SELECT v.id FROM visits v WHERE 1=1" + sc + ")") if sc else ""
    chemicals = db.query(
        "SELECT ch.name_en, ch.name_ar, ch.unit, COALESCE(SUM(cu.quantity),0) used "
        "FROM chemicals ch LEFT JOIN chemical_usage cu ON cu.chemical_id=ch.id "
        "AND date(cu.created_at) BETWEEN ? AND ?" + cu_extra +
        " GROUP BY ch.id HAVING used > 0 ORDER BY used DESC LIMIT 10", (*dr, *sp))
    sc, sp = scope("v.client_id", "v.site_id")
    services = db.query(
        "SELECT s.name_en, s.name_ar, COUNT(v.id) cnt FROM service_types s "
        "LEFT JOIN visits v ON v.service_type_id=s.id "
        "AND date(v.scheduled_start) BETWEEN ? AND ?" + sc +
        " GROUP BY s.id HAVING cnt>0 ORDER BY cnt DESC", (*dr, *sp))

    # --- totals + operational / collection KPIs (range + client/site scoped) ---
    sc, sp = scope("v.client_id", "v.site_id")
    vis = db.query(
        "SELECT COUNT(*) total, SUM(status='completed') completed, "
        "SUM(status='cancelled') cancelled FROM visits v "
        "WHERE date(v.scheduled_start) BETWEEN ? AND ?" + sc, (*dr, *sp), one=True)
    sc, sp = scope("client_id", "site_id")
    invoiced = db.query("SELECT COALESCE(SUM(total),0) v FROM invoices "
                        "WHERE doc_type='invoice' AND date(issue_date) BETWEEN ? AND ?" + sc, (*dr, *sp), one=True)["v"]
    sc, sp = scope("i.client_id", "i.site_id")
    revenue = db.query("SELECT COALESCE(SUM(p.amount),0) v FROM payments p "
                       "JOIN invoices i ON i.id=p.invoice_id WHERE date(p.paid_at) BETWEEN ? AND ?" + sc, (*dr, *sp), one=True)["v"]
    sla = {"ok": 0, "due_soon": 0, "overdue": 0}
    site_num = int(site_id) if (site_id or "").isdigit() else None
    for r in _sla_rows():
        if cid and r["client_id"] != cid:
            continue
        if site_num is not None and r["site_id"] != site_num:
            continue
        sla[r["status"]] = sla.get(r["status"], 0) + 1
    vtotal, vcomp = vis["total"] or 0, vis["completed"] or 0
    nc_extra, nc_p = (" AND id=?", [cid]) if cid else ("", [])
    ac_extra, ac_p = (" AND client_id=?", [cid]) if cid else ("", [])
    totals = {
        "revenue": revenue, "invoiced": invoiced,
        "visits_total": vtotal, "visits_completed": vcomp,
        "visits_cancelled": vis["cancelled"] or 0,
        "completion_rate": round(vcomp * 100.0 / vtotal) if vtotal else 0,
        "collection_rate": round(revenue * 100.0 / invoiced) if invoiced else 0,
        "revenue_per_visit": round(revenue / vcomp, 2) if vcomp else 0,
        "new_clients": db.query("SELECT COUNT(*) c FROM clients WHERE date(created_at) BETWEEN ? AND ?" + nc_extra, (*dr, *nc_p), one=True)["c"],
        "active_contracts": db.query("SELECT COUNT(*) c FROM contracts WHERE status='active'" + ac_extra, ac_p, one=True)["c"],
        "sla_overdue": sla["overdue"], "sla_due_soon": sla["due_soon"],
    }

    # --- fleet & pest rollup from the QR device scans (client/site scoped) ---
    dsc, dsp = scope("client_id", "site_id")                 # devices d (bare cols)
    total_dev = db.query("SELECT COUNT(*) c FROM devices WHERE active=1 AND client_id IS NOT NULL" + dsc, dsp, one=True)["c"]
    isc, isp = scope("client_id", DI_SITE)                   # device_inspections (bare)
    di_by = {r["m"]: r for r in db.query(
        "SELECT strftime('%Y-%m',recorded_at) m, COUNT(*) inspections, "
        "COUNT(DISTINCT device_id) scanned, SUM(status='activity') detections, "
        "AVG(CAST(COALESCE(json_extract(details,'$.fly_count'),"
        "json_extract(details,'$.fly_density')) AS REAL)) fly, "
        "AVG(CAST(json_extract(details,'$.consumption_pct') AS REAL)) bait_pct "
        "FROM device_inspections WHERE date(recorded_at) BETWEEN ? AND ?" + isc + " GROUP BY m", (*dr, *isp))}
    fleet_months = [{"m": k,
                     "inspections": (di_by[k]["inspections"] if k in di_by else 0),
                     "detections": (di_by[k]["detections"] if k in di_by else 0),
                     "coverage": (round(100.0 * di_by[k]["scanned"] / total_dev) if (k in di_by and total_dev) else 0),
                     "fly": r1(di_by[k]["fly"]) if k in di_by else None,
                     "bait_pct": r1(di_by[k]["bait_pct"]) if k in di_by else None} for k in labels]
    scanned_month = db.query("SELECT COUNT(DISTINCT device_id) c FROM device_inspections "
                             "WHERE strftime('%Y-%m',recorded_at)=strftime('%Y-%m','now','localtime')" + isc, isp, one=True)["c"]
    tsc, tsp = scope("di.client_id", "(SELECT site_id FROM devices WHERE id=di.device_id)")
    top_clients = db.query(
        "SELECT c.name_en, c.name_ar, COUNT(*) detections FROM device_inspections di "
        "JOIN clients c ON c.id=di.client_id WHERE di.status='activity' "
        "AND date(di.recorded_at) BETWEEN ? AND ?" + tsc + " GROUP BY di.client_id "
        "ORDER BY detections DESC LIMIT 8", (*dr, *tsp))
    # What was actually replaced/changed on the traps. A scan filed before the
    # fault/action split says so on the STATUS ("lamp_status=replaced"); one
    # filed since says so on the ACTION — both are counted, or the history
    # would appear to stop the day the fields changed.
    def _j(field):
        return "json_extract(details,'$.%s')" % field
    rep = db.query(
        "SELECT SUM({ls}='replaced' OR {la}='replaced') lamps, "
        "SUM({ss}='replaced' OR {sa}='changed') sheets, "
        "SUM({gs}='changed' OR {ga}='changed') glue_boards, "
        "SUM({bs}='changed' OR {ba}='changed') baits, "
        "SUM({ta}='replaced') traps, SUM({tla}='replaced') transformers, "
        "SUM({sta}='replaced') stations "
        "FROM device_inspections WHERE date(recorded_at) BETWEEN ? AND ?".format(
            ls=_j("lamp_status"), la=_j("lamp_action"), ss=_j("sheet_status"),
            sa=_j("sheet_action"), gs=_j("glue_status"), ga=_j("glue_action"),
            bs=_j("bait_status"), ba=_j("bait_action"), ta=_j("trap_action"),
            tla=_j("trans_light_action"), sta=_j("station_action")) + isc,
        (*dr, *isp), one=True)

    # --- what the scans FOUND (faults) and what was LEFT for the next visit ---
    # Every fault the four device types can report, counted from the same
    # details blob the engineer filled in on the trap.
    FAULTS = [
        ("trap_damaged", "trap_condition", "damaged"), ("trap_missing", "trap_condition", "missing"),
        ("lamp_damaged", "lamp_status", "damaged"), ("lamp_missing", "lamp_status", "missing"),
        ("trans_damaged", "trans_light_status", "damaged"), ("trans_missing", "trans_light_status", "missing"),
        ("sheet_expired", "sheet_status", "expired"), ("sheet_full", "sheet_status", "full"),
        ("sheet_missing", "sheet_status", "missing"),
        ("station_damaged", "station_condition", "damaged"),
        ("station_missing", "station_condition", "missing"),
        ("power_disconnected", "electricity", "disconnected"),
        ("power_cable_missing", "electricity", "cable_missing"),
        ("glue_caught", "glue_status", "caught"), ("glue_damaged", "glue_status", "damaged"),
        ("bait_activity", "bait_status", "activity_eating"),
        ("bait_damaged", "bait_status", "damaged"), ("bait_missing", "bait_status", "missing"),
        ("not_cleaned", "cleaned", "no"),
    ]
    faults_row = db.query(
        "SELECT " + ", ".join("SUM(%s=?) %s" % (_j(f), k) for k, f, _v in FAULTS) +
        " FROM device_inspections WHERE date(recorded_at) BETWEEN ? AND ?" + isc,
        (*[v for _k, _f, v in FAULTS], *dr, *isp), one=True)
    faults = [{"key": k, "count": faults_row[k] or 0} for k, _f, _v in FAULTS if faults_row[k]]
    faults.sort(key=lambda x: -x["count"])

    # Work an engineer deferred: every action field that says "next visit".
    ACTION_FIELDS = ("trap_action", "lamp_action", "trans_light_action", "sheet_action",
                     "station_action", "electricity_action", "bait_action", "cleaned_action")
    done_expr = " + ".join(
        "(CASE WHEN %s IS NOT NULL AND %s NOT LIKE 'next_visit%%' THEN 1 ELSE 0 END)" % (_j(f), _j(f))
        for f in ACTION_FIELDS)
    defer_expr = " + ".join(
        "(CASE WHEN %s LIKE 'next_visit%%' THEN 1 ELSE 0 END)" % _j(f) for f in ACTION_FIELDS)
    act = db.query("SELECT COALESCE(SUM(%s),0) done, COALESCE(SUM(%s),0) deferred "
                   "FROM device_inspections WHERE date(recorded_at) BETWEEN ? AND ?" % (done_expr, defer_expr)
                   + isc, (*dr, *isp), one=True)
    # The deferred items themselves, newest first — a real to-do list for the
    # next visit rather than a number.
    defer_rows = db.query(
        "SELECT di.recorded_at, di.details, d.code, d.type, c.name_en, c.name_ar "
        "FROM device_inspections di JOIN devices d ON d.id=di.device_id "
        "LEFT JOIN clients c ON c.id=di.client_id "
        "WHERE di.details LIKE '%next_visit%' AND date(di.recorded_at) BETWEEN ? AND ?" +
        isc.replace("client_id", "di.client_id").replace(DI_SITE, "d.site_id") +
        " ORDER BY di.recorded_at DESC LIMIT 25", (*dr, *isp))
    deferred_list = []
    for r in defer_rows:
        det = _json_obj(r["details"])
        for f in ACTION_FIELDS:
            if str(det.get(f, "")).startswith("next_visit"):
                deferred_list.append({"code": r["code"], "type": r["type"],
                                      "name_en": r["name_en"], "name_ar": r["name_ar"],
                                      "field": f, "action": det[f], "at": r["recorded_at"]})

    # --- what the traps CAUGHT: the tick-lists, counted per pest ---------------
    # Stored as a comma-joined list of keys, which SQL cannot split — so the
    # rows come back and Python does the counting.
    pest_rows = db.query(
        "SELECT d.type, json_extract(di.details,'$.pests_found') pests "
        "FROM device_inspections di JOIN devices d ON d.id=di.device_id "
        "WHERE json_extract(di.details,'$.pests_found') IS NOT NULL "
        "AND date(di.recorded_at) BETWEEN ? AND ?" +
        isc.replace("client_id", "di.client_id").replace(DI_SITE, "d.site_id"), (*dr, *isp))
    pest_count = {}
    for r in pest_rows:
        for k in str(r["pests"] or "").split(","):
            k = k.strip()
            if k:
                pest_count[(r["type"], k)] = pest_count.get((r["type"], k), 0) + 1
    pests = sorted(({"type": ty, "key": k, "count": n} for (ty, k), n in pest_count.items()),
                   key=lambda x: -x["count"])

    # Scans per device type: how much of the fleet each type accounts for.
    by_type = db.query(
        "SELECT d.type, COUNT(*) scans, COUNT(DISTINCT di.device_id) devices, "
        "SUM(di.status='activity') detections "
        "FROM device_inspections di JOIN devices d ON d.id=di.device_id "
        "WHERE date(di.recorded_at) BETWEEN ? AND ?" +
        isc.replace("client_id", "di.client_id").replace(DI_SITE, "d.site_id") +
        " GROUP BY d.type ORDER BY scans DESC", (*dr, *isp))
    # --- how the chemicals were applied, and with what -----------------------
    sc, sp = scope("v.client_id", "v.site_id")
    cu_join = (" AND cu.visit_id IN (SELECT v.id FROM visits v WHERE 1=1" + sc + ")") if sc else ""
    def _cu_group(col):
        return db.query(
            "SELECT cu.%s k, COUNT(*) cnt, COALESCE(SUM(cu.quantity),0) qty FROM chemical_usage cu "
            "WHERE cu.%s IS NOT NULL AND cu.%s<>'' AND date(cu.created_at) BETWEEN ? AND ?" % (col, col, col)
            + cu_join + " GROUP BY cu.%s ORDER BY cnt DESC" % col, (*dr, *sp))
    application = {"methods": _cu_group("method"), "equipment": _cu_group("equipment")}

    # --- the reports themselves ----------------------------------------------
    sc, sp = scope("v.client_id", "v.site_id")
    rep_sev = db.query(
        "SELECT r.severity k, COUNT(*) cnt FROM reports r JOIN visits v ON v.id=r.visit_id "
        "WHERE r.severity IS NOT NULL AND date(v.scheduled_start) BETWEEN ? AND ?" + sc +
        " GROUP BY r.severity ORDER BY cnt DESC", (*dr, *sp))
    rep_status = db.query(
        "SELECT r.status k, COUNT(*) cnt FROM reports r JOIN visits v ON v.id=r.visit_id "
        "WHERE date(v.scheduled_start) BETWEEN ? AND ?" + sc + " GROUP BY r.status", (*dr, *sp))
    # Conditions and recommendations are the office's own wording, one per line
    # (see the report option pickers) — so they are split and tallied verbatim.
    def _wording(col):
        tally = {}
        for r in db.query(
                "SELECT r.%s v FROM reports r JOIN visits v ON v.id=r.visit_id "
                "WHERE r.%s IS NOT NULL AND r.%s<>'' AND date(v.scheduled_start) BETWEEN ? AND ?" % (col, col, col)
                + sc, (*dr, *sp)):
            for line in str(r["v"] or "").split("\n"):
                line = line.strip()
                if line:
                    tally[line] = tally.get(line, 0) + 1
        return sorted(({"text": k, "count": n} for k, n in tally.items()),
                      key=lambda x: -x["count"])[:10]
    reports = {"severity": rep_sev, "status": rep_status,
               "conditions": _wording("condition"),
               "recommendations": _wording("recommendations"),
               "signed": db.query(
                   "SELECT COUNT(*) c FROM reports r JOIN visits v ON v.id=r.visit_id "
                   "WHERE r.customer_signature IS NOT NULL AND r.customer_signature<>'' "
                   "AND date(v.scheduled_start) BETWEEN ? AND ?" + sc, (*dr, *sp), one=True)["c"]}

    # --- what serving the work COSTS in the field ---------------------------
    # Three things leave the company on a visit: product off the shelf, the
    # travel to get there, and cash out of an engineer's pocket. They are shown
    # together because that is the number a branch manager is asked about.
    CHEM_COST = ("(SELECT COALESCE(SUM(cu.quantity * ch.cost_per_unit),0) "
                 "FROM chemical_usage cu JOIN chemicals ch ON ch.id=cu.chemical_id "
                 "WHERE cu.visit_id=v.id)")
    TRIP_COST = ("(SELECT COALESCE(SUM(te.cost),0) FROM transport_entries te "
                 "WHERE te.visit_id=v.id)")
    CASH_COST = ("(SELECT COALESCE(SUM(pc.amount),0) FROM petty_cash pc "
                 "WHERE pc.visit_id=v.id AND pc.kind='expense' AND pc.status='approved')")
    sc, sp = scope("v.client_id", "v.site_id")
    vis_rng = " WHERE date(v.scheduled_start) BETWEEN ? AND ?" + sc
    # Per client: what the range cost, and what an average visit there costs.
    spend_clients = db.query(
        "SELECT v.client_id, c.name_en, c.name_ar, COUNT(*) visits, "
        "COALESCE(SUM(" + CHEM_COST + "),0) chemicals, "
        "COALESCE(SUM(" + TRIP_COST + "),0) transport, "
        "COALESCE(SUM(" + CASH_COST + "),0) cash "
        "FROM visits v JOIN clients c ON c.id=v.client_id" + vis_rng +
        " GROUP BY v.client_id ORDER BY (chemicals + transport + cash) DESC LIMIT 25",
        (*dr, *sp))
    for r in spend_clients:
        r["total"] = round((r["chemicals"] or 0) + (r["transport"] or 0) + (r["cash"] or 0), 2)
        r["per_visit"] = round(r["total"] / r["visits"], 2) if r["visits"] else 0
        for k in ("chemicals", "transport", "cash"):
            r[k] = round(r[k] or 0, 2)
    # Visit by visit, newest first — the detail behind those totals.
    spend_visits = db.query(
        "SELECT v.id, v.scheduled_start, v.client_id, c.name_en, c.name_ar, "
        "s.name site_name, u.full_name agent_name, " +
        CHEM_COST + " chemicals, " + TRIP_COST + " transport, " + CASH_COST + " cash "
        "FROM visits v JOIN clients c ON c.id=v.client_id "
        "LEFT JOIN sites s ON s.id=v.site_id LEFT JOIN users u ON u.id=v.agent_id" + vis_rng +
        " ORDER BY v.scheduled_start DESC LIMIT 30", (*dr, *sp))
    for r in spend_visits:
        r["total"] = round((r["chemicals"] or 0) + (r["transport"] or 0) + (r["cash"] or 0), 2)
        for k in ("chemicals", "transport", "cash"):
            r[k] = round(r[k] or 0, 2)
    # The same three, month by month.
    spend_by_month = {r["m"]: r for r in db.query(
        "SELECT strftime('%Y-%m',v.scheduled_start) m, "
        "COALESCE(SUM(" + CHEM_COST + "),0) chemicals, "
        "COALESCE(SUM(" + TRIP_COST + "),0) transport, "
        "COALESCE(SUM(" + CASH_COST + "),0) cash "
        "FROM visits v" + vis_rng + " GROUP BY m", (*dr, *sp))}
    spend_months = [{"m": k,
                     "chemicals": round((spend_by_month[k]["chemicals"] if k in spend_by_month else 0) or 0, 2),
                     "transport": round((spend_by_month[k]["transport"] if k in spend_by_month else 0) or 0, 2),
                     "cash": round((spend_by_month[k]["cash"] if k in spend_by_month else 0) or 0, 2)}
                    for k in labels]

    # --- pocket money, per engineer -----------------------------------------
    # Dated by spent_on: the day the money left the engineer's pocket, not the
    # day the office got round to settling it. Scoped by client/site through the
    # visit a claim names, since that is the only tie a claim has to a client.
    sc, sp = scope("v.client_id", "v.site_id")
    cash_join = (" AND pc.visit_id IN (SELECT v.id FROM visits v WHERE 1=1" + sc + ")") if sc else ""
    cash_eng = db.query(
        "SELECT pc.agent_id, u.full_name agent_name, "
        "COALESCE(SUM(CASE WHEN pc.kind='expense' THEN pc.amount END),0) spent, "
        "COALESCE(SUM(CASE WHEN pc.kind='advance' THEN pc.amount END),0) advanced, "
        "COALESCE(SUM(CASE WHEN pc.kind='return' THEN pc.amount END),0) returned, "
        "COUNT(CASE WHEN pc.kind='expense' THEN 1 END) claims "
        "FROM petty_cash pc JOIN users u ON u.id=pc.agent_id "
        "WHERE pc.status='approved' AND date(pc.spent_on) BETWEEN ? AND ?" + cash_join +
        " GROUP BY pc.agent_id HAVING spent>0 OR advanced>0 ORDER BY spent DESC", (*dr, *sp))
    cash_cats = db.query(
        "SELECT COALESCE(pc.category,'other') k, COALESCE(SUM(pc.amount),0) amount, COUNT(*) cnt "
        "FROM petty_cash pc WHERE pc.status='approved' AND pc.kind='expense' "
        "AND date(pc.spent_on) BETWEEN ? AND ?" + cash_join + " GROUP BY 1 ORDER BY amount DESC",
        (*dr, *sp))
    pocket = {"engineers": cash_eng, "categories": cash_cats,
              "spent": round(sum(r["spent"] or 0 for r in cash_eng), 2),
              "unlinked": db.query(
                  "SELECT COALESCE(SUM(amount),0) v FROM petty_cash WHERE status='approved' "
                  "AND kind='expense' AND visit_id IS NULL AND date(spent_on) BETWEEN ? AND ?",
                  dr, one=True)["v"] if not cash_join else None}

    st_sc, st_sp = scope("d.client_id", "d.site_id")
    fleet = {
        "kpi": {
            "devices": total_dev,
            "needs_service": db.query("SELECT COUNT(*) c FROM devices WHERE active=1 AND status='needs_service'" + dsc, dsp, one=True)["c"],
            "activity": db.query("SELECT COUNT(*) c FROM device_inspections WHERE status='activity' AND date(recorded_at) BETWEEN ? AND ?" + isc, (*dr, *isp), one=True)["c"],
            "coverage": round(100.0 * scanned_month / total_dev) if total_dev else None,
        },
        "months": fleet_months, "top_clients": top_clients,
        "replaced": {"lamps": rep["lamps"] or 0, "sheets": rep["sheets"] or 0,
                     "glue_boards": rep["glue_boards"] or 0, "baits": rep["baits"] or 0,
                     "traps": rep["traps"] or 0, "transformers": rep["transformers"] or 0,
                     "stations": rep["stations"] or 0},
        "faults": faults, "pests": pests, "by_type": by_type,
        "actions": {"done": act["done"] or 0, "deferred": act["deferred"] or 0},
        "deferred_list": deferred_list[:25],
        "stale": _stale_devices(20, st_sc, st_sp), "stale_count": _stale_count(st_sc, st_sp),
        "stale_days": STALE_SCAN_DAYS,
    }
    out = {"range": {"from": d_from, "to": d_to},
           "client_id": cid, "site_id": site_id, "months": months,
           "ar_aging": ar_aging, "agents": agents, "chemicals": chemicals,
           "services": services, "totals": totals, "fleet": fleet,
           "application": application, "reports": reports,
           "spend": {"clients": spend_clients, "visits": spend_visits,
                     "months": spend_months, "pocket": pocket}}
    if is_leader:
        # analytics.view lets a supervisor read their OPERATIONS. The money
        # is not theirs to see — revenue, debtors and what the work costs stay
        # with the office, the same boundary their sidebar draws.
        # EMPTIED, not deleted. Every consumer of this payload maps over these
        # keys; removing them would crash the page instead of hiding the money.
        out["months"] = []
        out["ar_aging"] = []
        out["spend"] = {"clients": [], "visits": [], "months": [],
                        "pocket": {"engineers": [], "categories": [], "spent": 0, "unlinked": 0}}
        # A whitelist, not a blocklist: a KPI added later is withheld until
        # someone decides it is operational, rather than leaking because nobody
        # remembered to exclude it.
        keep = ("visits_total", "visits_completed", "visits_cancelled",
                "completion_rate", "new_clients", "active_contracts",
                "sla_overdue", "sla_due_soon")
        out["totals"] = {k: v for k, v in (out["totals"] or {}).items() if k in keep}
    return out


def _json_obj(raw):
    """A stored details blob as a dict — never raises on a bad or empty value."""
    try:
        v = json.loads(raw) if raw else {}
        return v if isinstance(v, dict) else {}
    except (ValueError, TypeError):
        return {}


def _month_labels(n=12):
    import datetime
    today = datetime.date.today().replace(day=1)
    out, y, m = [], today.year, today.month
    for i in range(n - 1, -1, -1):
        mm, yy = m - i, y
        while mm <= 0:
            mm += 12; yy -= 1
        out.append(f"{yy:04d}-{mm:02d}")
    return out


@route("GET", r"/api/clients/(\d+)/analytics")
def client_analytics(ctx):
    """Everything we know about one client, shaped for curve + 3D charts."""
    cid = int(ctx.params[0])
    _assert_client_access(ctx.user, cid)
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "analytics.view")
    site_id = _requested_site_id(ctx)
    vf, vp = _site_filter(site_id, "v.site_id")     # visit-derived queries
    inf, inp = _site_filter(site_id, "site_id")     # bare invoices table
    iif, iip = _site_filter(site_id, "i.site_id")   # invoices via alias i
    labels = _month_labels(12)
    # build continuous 12-month series (fill gaps with zero) for smooth curves
    inv_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',issue_date) m, SUM(total) v FROM invoices "
        "WHERE client_id=? AND doc_type='invoice'" + inf + " GROUP BY m", (cid, *inp))}
    paid_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',p.paid_at) m, SUM(p.amount) v FROM payments p "
        "JOIN invoices i ON i.id=p.invoice_id WHERE i.client_id=?" + iif + " GROUP BY m", (cid, *iip))}
    vis_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',scheduled_start) m, COUNT(*) v FROM visits v "
        "WHERE client_id=?" + vf + " GROUP BY m", (cid, *vp))}
    months = [{"m": k, "invoiced": round(inv_by.get(k, 0) or 0, 2),
               "paid": round(paid_by.get(k, 0) or 0, 2), "visits": vis_by.get(k, 0) or 0}
              for k in labels]
    status = db.query("SELECT status, COUNT(*) cnt FROM visits v WHERE client_id=?" + vf + " GROUP BY status", (cid, *vp))
    services = db.query(
        "SELECT s.name_en, s.name_ar, COUNT(v.id) cnt FROM service_types s "
        "JOIN visits v ON v.service_type_id=s.id WHERE v.client_id=?" + vf + " GROUP BY s.id "
        "HAVING cnt>0 ORDER BY cnt DESC", (cid, *vp))
    severity = db.query(
        "SELECT r.severity, COUNT(*) cnt FROM reports r JOIN visits v ON v.id=r.visit_id "
        "WHERE v.client_id=?" + vf + " AND r.severity IS NOT NULL GROUP BY r.severity", (cid, *vp))
    chemicals = db.query(
        "SELECT ch.name_en, ch.name_ar, ch.unit, SUM(cu.quantity) used FROM chemical_usage cu "
        "JOIN chemicals ch ON ch.id=cu.chemical_id JOIN visits v ON v.id=cu.visit_id "
        "WHERE v.client_id=?" + vf + " GROUP BY ch.id ORDER BY used DESC LIMIT 8", (cid, *vp))
    # Engineer service-log materials consumed across the selected location's visits.
    mat_cols = ("lamps_used", "cables_used", "transformers_used", "light_sheets_used",
                "fipronil_ml", "imidacloprid_gm", "baits_count", "glo_pieces", "flybase_bags")
    mat_sum = db.query(
        "SELECT " + ",".join(f"COALESCE(SUM(r.{c}),0) {c}" for c in mat_cols) +
        " FROM reports r JOIN visits v ON v.id=r.visit_id WHERE v.client_id=?" + vf, (cid, *vp), one=True)
    materials = [{"key": c, "total": round(mat_sum[c] or 0, 2)} for c in mat_cols if (mat_sum[c] or 0) > 0]
    fin = _finance_summary(cid, site_id)
    totals = {
        "visits": db.query("SELECT COUNT(*) c FROM visits v WHERE client_id=?" + vf, (cid, *vp), one=True)["c"],
        "completed": db.query("SELECT COUNT(*) c FROM visits v WHERE client_id=?" + vf + " AND status='completed'", (cid, *vp), one=True)["c"],
        "invoiced": fin["total_invoiced"], "paid": fin["total_paid"], "outstanding": fin["outstanding"],
        "contracts": _active_contracts_for_site(cid, site_id),
    }
    sites = db.query("SELECT id, name FROM sites WHERE client_id=? ORDER BY name", (cid,))
    out = {"months": months, "status": status, "services": services,
           "severity": severity, "chemicals": chemicals, "materials": materials,
           "totals": totals, "sites": sites, "site_id": site_id or ""}
    if ctx.user["role"] in SUPERVISOR_ROLES:
        # Same boundary as /api/analytics: a supervisor reads the WORK at a
        # client they cover, never what it was billed at or what is still owed.
        out["months"] = [{"m": m["m"], "visits": m.get("visits", 0)} for m in months]
        out["totals"] = {k: v for k, v in totals.items() if k in ("visits", "completed", "contracts")}
    return out


@route("GET", r"/api/clients/(\d+)/pest-trends")
def client_pest_trends(ctx):
    """Device-monitoring trends for one client, built from the QR device scans
    (device_inspections + devices). Monthly pest-activity + pest-pressure
    (fly counts, bait consumption), device-type breakdown, hotspots, and
    follow-up KPIs (catch rate, consumables replaced). For audit/HACCP."""
    cid = int(ctx.params[0])
    _assert_client_access(ctx.user, cid)
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "analytics.view")
    site_id = _requested_site_id(ctx)
    # Inspections carry no site_id; scope through the device's location.
    df, dp = _site_filter(site_id, "d.site_id")
    r1 = lambda x: round(x, 1) if x is not None else None
    labels = _month_labels(12)
    DI = "device_inspections di JOIN devices d ON d.id=di.device_id"

    mrows = db.query(
        "SELECT strftime('%Y-%m',di.recorded_at) m, COUNT(*) inspections, "
        "SUM(CASE WHEN di.status='activity' THEN 1 ELSE 0 END) detections, "
        "AVG(CAST(COALESCE(json_extract(di.details,'$.fly_count'),"
        "json_extract(di.details,'$.fly_density')) AS REAL)) fly, "
        "AVG(CAST(json_extract(di.details,'$.consumption_pct') AS REAL)) bait_pct "
        "FROM " + DI + " WHERE di.client_id=?" + df + " GROUP BY m", (cid, *dp))
    by_m = {r["m"]: r for r in mrows}
    months = [{"m": k,
               "inspections": (by_m[k]["inspections"] if k in by_m else 0),
               "detections": (by_m[k]["detections"] if k in by_m else 0),
               "fly": r1(by_m[k]["fly"]) if k in by_m else None,
               "bait_pct": r1(by_m[k]["bait_pct"]) if k in by_m else None}
              for k in labels]
    by_type = db.query(
        "SELECT d.type, COUNT(*) detections FROM " + DI +
        " WHERE di.client_id=? AND di.status='activity'" + df +
        " GROUP BY d.type ORDER BY detections DESC", (cid, *dp))
    # Hotspots keyed by device (code + friendly location) rather than map marker.
    hotspots = db.query(
        "SELECT d.id, d.code label, d.label loc, d.type, d.status, "
        "COUNT(di.id) detections, MAX(di.recorded_at) last_seen "
        "FROM " + DI + " WHERE di.client_id=? AND di.status='activity'" + df +
        " GROUP BY di.device_id ORDER BY detections DESC, last_seen DESC LIMIT 8", (cid, *dp))

    # Follow-up KPIs from the scan details JSON (over the scoped inspections).
    k = db.query(
        "SELECT AVG(CAST(COALESCE(json_extract(di.details,'$.fly_count'),"
        "json_extract(di.details,'$.fly_density')) AS REAL)) fly_avg, "
        "AVG(CAST(json_extract(di.details,'$.consumption_pct') AS REAL)) bait_pct_avg, "
        "SUM(json_extract(di.details,'$.caught')='yes') caught, "
        "SUM(json_extract(di.details,'$.caught') IS NOT NULL) glue_checks, "
        "SUM(json_extract(di.details,'$.lamp_status')='replaced') lamps, "
        "SUM(json_extract(di.details,'$.sheet_status')='replaced') sheets, "
        "SUM(json_extract(di.details,'$.glue_status')='changed') glue_boards, "
        "SUM(json_extract(di.details,'$.bait_status')='changed') baits "
        "FROM " + DI + " WHERE di.client_id=?" + df, (cid, *dp), one=True)
    glue_checks = k["glue_checks"] or 0
    kpis = {
        "fly_avg": r1(k["fly_avg"]),
        "bait_pct_avg": r1(k["bait_pct_avg"]),
        "catch_rate": round(100.0 * (k["caught"] or 0) / glue_checks) if glue_checks else None,
        "replaced": {"lamps": k["lamps"] or 0, "sheets": k["sheets"] or 0,
                     "glue_boards": k["glue_boards"] or 0, "baits": k["baits"] or 0},
    }

    def dev_count(extra=""):
        return db.query("SELECT COUNT(*) c FROM devices d WHERE d.client_id=? AND d.active=1"
                        + df + extra, (cid, *dp), one=True)["c"]
    totals = {
        "inspections": db.query("SELECT COUNT(*) c FROM " + DI + " WHERE di.client_id=?" + df, (cid, *dp), one=True)["c"],
        "detections": db.query("SELECT COUNT(*) c FROM " + DI + " WHERE di.client_id=? AND di.status='activity'" + df, (cid, *dp), one=True)["c"],
        "devices": dev_count(),
        "active_now": dev_count(" AND d.status='activity'"),
        "needs_service": dev_count(" AND d.status='needs_service'"),
        "missing": dev_count(" AND d.status='missing'"),
    }
    last = db.query("SELECT MAX(di.recorded_at) v FROM " + DI + " WHERE di.client_id=?" + df, (cid, *dp), one=True)
    return {"months": months, "by_type": by_type, "hotspots": hotspots,
            "totals": totals, "kpis": kpis, "last_inspection": last["v"] if last else None}


def _months_between(d_from, d_to, cap=24):
    """Continuous 'YYYY-MM' buckets spanning [d_from, d_to], capped to the most
    recent `cap` months so an open-ended range can't produce a huge series."""
    import datetime
    a = datetime.date.fromisoformat(d_from).replace(day=1)
    b = datetime.date.fromisoformat(d_to).replace(day=1)
    out, y, m = [], a.year, a.month
    while (y, m) <= (b.year, b.month):
        out.append(f"{y:04d}-{m:02d}")
        m += 1
        if m > 12:
            m = 1; y += 1
    return out[-cap:]


@route("GET", r"/api/clients/(\d+)/audit-pack")
def client_audit_pack(ctx):
    """One aggregated payload for the auditor "Audit Pack" binder: per-site
    service history, device/pest-activity trends, the chemical usage log (with
    application rates + SDS/label attachments), technician licence/cert numbers,
    and corrective actions derived from report findings + flagged devices. The
    frontend renders this into a single branded printable PDF."""
    cid = int(ctx.params[0])
    _assert_client_access(ctx.user, cid)
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "analytics.view")
    site_id = _requested_site_id(ctx)
    import datetime
    today = datetime.date.today()

    def _d(s, default):
        try:
            return datetime.date.fromisoformat((s or "")[:10]).isoformat()
        except (ValueError, TypeError):
            return default
    try:
        year_ago = today.replace(year=today.year - 1).isoformat()
    except ValueError:           # Feb 29 guard
        year_ago = today.replace(month=today.month, day=28, year=today.year - 1).isoformat()
    d_from = _d(ctx.query.get("from"), year_ago)
    d_to = _d(ctx.query.get("to"), today.isoformat())
    vf, vp = _site_filter(site_id, "v.site_id")
    dr = " AND date(v.scheduled_start) BETWEEN ? AND ?"
    drp = (d_from, d_to)

    client = db.query(
        "SELECT id,name_en,name_ar,contact_person,phone,email,address_en,address_ar,city "
        "FROM clients WHERE id=?", (cid,), one=True)
    if not client:
        raise ApiError(404, "Client not found")
    site = None
    if site_id and site_id not in ("none", "0", ""):
        site = db.query("SELECT id,name,address,area FROM sites WHERE id=? AND client_id=?",
                        (site_id, cid), one=True)

    # --- service history (per site): each visit + its report summary -----------
    history = db.query(
        "SELECT v.id, v.scheduled_start, v.status, " + VISIT_NO_SQL + ", "
        "s.name site_name, st.name_en svc_en, st.name_ar svc_ar, u.full_name agent, "
        "r.severity, r.summary, r.findings, r.recommendations, r.pests_found, "
        "r.branch_issue, r.status report_status, "
        "r.customer_signature, r.technician_signature "
        "FROM visits v LEFT JOIN sites s ON s.id=v.site_id "
        "LEFT JOIN service_types st ON st.id=v.service_type_id "
        "LEFT JOIN users u ON u.id=v.agent_id "
        "LEFT JOIN reports r ON r.visit_id=v.id "
        "WHERE v.client_id=?" + vf + dr + " ORDER BY v.scheduled_start DESC",
        (cid, *vp, *drp))
    _apply_visit_no(history)

    # --- chemical usage log (application rate = quantity / area_treated) -------
    chem_log = db.query(
        "SELECT v.scheduled_start, s.name site_name, u.full_name agent, "
        "ch.name_en, ch.name_ar, ch.active_ingredient, ch.reg_no, ch.hazard_class, "
        "cu.quantity, ch.unit, cu.area_treated, cu.method, cu.equipment "
        "FROM chemical_usage cu JOIN visits v ON v.id=cu.visit_id "
        "JOIN chemicals ch ON ch.id=cu.chemical_id "
        "LEFT JOIN sites s ON s.id=v.site_id LEFT JOIN users u ON u.id=v.agent_id "
        "WHERE v.client_id=?" + vf + dr + " ORDER BY v.scheduled_start DESC",
        (cid, *vp, *drp))

    # distinct products used + their SDS / label attachments (chemical photos)
    products = db.query(
        "SELECT DISTINCT ch.id, ch.name_en, ch.name_ar, ch.active_ingredient, "
        "ch.reg_no, ch.hazard_class, ch.unit "
        "FROM chemical_usage cu JOIN chemicals ch ON ch.id=cu.chemical_id "
        "JOIN visits v ON v.id=cu.visit_id "
        "WHERE v.client_id=?" + vf + dr + " ORDER BY ch.name_en", (cid, *vp, *drp))
    for p in products:
        p["attachments"] = db.query(
            "SELECT filename, original_name, caption FROM photos "
            "WHERE entity_type='chemical' AND entity_id=? ORDER BY uploaded_at", (p["id"],))

    # --- technicians who serviced + their licence / certification -------------
    technicians = db.query(
        "SELECT u.id, u.full_name, u.specialization, u.license_no, u.license_expiry, "
        "COUNT(v.id) visits, MAX(v.scheduled_start) last_visit "
        "FROM visits v JOIN users u ON u.id=v.agent_id "
        "WHERE v.client_id=?" + vf + dr + " GROUP BY u.id ORDER BY u.full_name",
        (cid, *vp, *drp))

    # --- corrective actions, derived from report findings ---------------------
    corrective = db.query(
        "SELECT v.scheduled_start, s.name site_name, u.full_name agent, "
        "r.severity, r.findings, r.pests_found, r.recommendations, r.branch_issue, "
        "v.status visit_status "
        "FROM reports r JOIN visits v ON v.id=r.visit_id "
        "LEFT JOIN sites s ON s.id=v.site_id LEFT JOIN users u ON u.id=v.agent_id "
        "WHERE v.client_id=?" + vf + dr +
        " AND (COALESCE(r.recommendations,'')<>'' OR COALESCE(r.branch_issue,'')<>'' "
        "      OR r.severity IN ('high','critical')) "
        "ORDER BY v.scheduled_start DESC", (cid, *vp, *drp))

    # QR devices currently flagged (needs service / live activity) — open actions
    daf, dap = _site_filter(site_id, "d.site_id")
    device_alerts = db.query(
        "SELECT d.code label, d.label loc, d.type, d.status, "
        "(SELECT MAX(recorded_at) FROM device_inspections di WHERE di.device_id=d.id) last_seen "
        "FROM devices d WHERE d.client_id=? AND d.active=1" + daf +
        " AND d.status IN ('needs_service','activity') ORDER BY d.status DESC", (cid, *dap))

    # --- pest-activity trend over the range (from QR device scans) ------------
    months = _months_between(d_from, d_to)
    ef, ep = _site_filter(site_id, "d.site_id")
    DIA = "device_inspections di JOIN devices d ON d.id=di.device_id"
    md = " AND date(di.recorded_at) BETWEEN ? AND ?"
    insp_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',di.recorded_at) m, COUNT(*) v FROM " + DIA +
        " WHERE di.client_id=?" + ef + md + " GROUP BY m", (cid, *ep, d_from, d_to))}
    act_by = {r["m"]: r["v"] for r in db.query(
        "SELECT strftime('%Y-%m',di.recorded_at) m, COUNT(*) v FROM " + DIA +
        " WHERE di.client_id=? AND di.status='activity'" + ef + md + " GROUP BY m",
        (cid, *ep, d_from, d_to))}
    trend_months = [{"m": k, "inspections": insp_by.get(k, 0) or 0,
                     "detections": act_by.get(k, 0) or 0} for k in months]
    by_type = db.query(
        "SELECT d.type, COUNT(*) detections FROM " + DIA +
        " WHERE di.client_id=? AND di.status='activity'" + ef + md +
        " GROUP BY d.type ORDER BY detections DESC", (cid, *ep, d_from, d_to))

    completed = sum(1 for h in history if h["status"] == "completed")
    signed = sum(1 for h in history if h["customer_signature"] and h["technician_signature"])
    summary = {
        "visits": len(history), "completed": completed, "signed": signed,
        "products": len(products), "chem_records": len(chem_log),
        "technicians": len(technicians), "corrective": len(corrective),
        "detections": sum(m["detections"] for m in trend_months),
        "open_devices": len(device_alerts),
    }
    return {
        "client": client, "site": site,
        "range": {"from": d_from, "to": d_to},
        "summary": summary,
        "history": history, "chem_log": chem_log, "products": products,
        "technicians": technicians, "corrective": corrective,
        "device_alerts": device_alerts,
        "trend": {"months": trend_months, "by_type": by_type},
    }


# --------------------------------------------------------------------------
# E-SIGNATURE (capture on report)
# --------------------------------------------------------------------------
@route("POST", r"/api/visits/(\d+)/signature")
def save_signature(ctx):
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    u = ctx.user
    require_perm(u, "visits.edit")
    if u["role"] == "agent" and v["agent_id"] != u["id"]:
        raise ApiError(403, "Not your visit")
    _assert_sup_visit(u, v)
    b = ctx.body
    which = b.get("which")  # 'customer' | 'technician'
    data_url = b.get("data", "")
    if which not in ("customer", "technician") or "," not in data_url:
        raise ApiError(400, "which and data (data URL) required")
    import base64
    try:
        raw = base64.b64decode(data_url.split(",", 1)[1])
    except Exception:
        raise ApiError(400, "Signature image could not be read")
    # The signature is a photograph of the signed page now, so it arrives as a
    # JPEG rather than the old canvas PNG. Trust the bytes, not the header: the
    # extension follows what the file actually is.
    if len(raw) > MAX_UPLOAD_BYTES:
        raise ApiError(413, f"File too large (max {MAX_UPLOAD_BYTES // (1024 * 1024)} MB)")
    if not _sniff_image(raw):
        raise ApiError(400, "Signature must be an image")
    ext = ".png" if raw[:8] == b"\x89PNG\r\n\x1a\n" else (
        ".webp" if raw[:4] == b"RIFF" else (".gif" if raw[:3] == b"GIF" else ".jpg"))
    fname = f"sig_{which}_{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(raw)
    # ensure a report row exists
    rep = db.query("SELECT * FROM reports WHERE visit_id=?", (vid,), one=True)
    if not rep:
        db.execute("INSERT INTO reports(visit_id) VALUES(?)", (vid,))
    col = "customer_signature" if which == "customer" else "technician_signature"
    db.execute(f"UPDATE reports SET {col}=? WHERE visit_id=?", (fname, vid))
    if which == "customer" and b.get("customer_name"):
        db.execute("UPDATE reports SET customer_name=? WHERE visit_id=?", (b["customer_name"], vid))
    return db.query("SELECT * FROM reports WHERE visit_id=?", (vid,), one=True)


# --------------------------------------------------------------------------
# CSV EXPORT
# --------------------------------------------------------------------------
def _xlsx_col(i):
    """0 -> A, 25 -> Z, 26 -> AA (spreadsheet column letters)."""
    name = ""
    i += 1
    while i:
        i, rem = divmod(i - 1, 26)
        name = chr(65 + rem) + name
    return name


def build_xlsx(rows, sheet_name="Export"):
    """A minimal .xlsx workbook from a list of dict-like rows, stdlib only.

    Real spreadsheet cells (numbers stay numbers), not a CSV wearing an Excel
    extension — Excel opens a renamed CSV with a warning and mangles Arabic.
    Text goes in as inline strings so there is no shared-string table to keep
    in sync."""
    import zipfile, io
    from xml.sax.saxutils import escape

    def cell(ref, val):
        if isinstance(val, bool) or val is None:
            val = "" if val is None else ("TRUE" if val else "FALSE")
        if isinstance(val, (int, float)):
            return f'<c r="{ref}"><v>{val}</v></c>'
        text = escape(str(val))
        return f'<c r="{ref}" t="inlineStr"><is><t xml:space="preserve">{text}</t></is></c>'

    headers = list(rows[0].keys()) if rows else []
    xml_rows = []
    if headers:
        xml_rows.append("<row r=\"1\">" + "".join(
            cell(f"{_xlsx_col(i)}1", h) for i, h in enumerate(headers)) + "</row>")
    for n, r in enumerate(rows, start=2):
        xml_rows.append(f'<row r="{n}">' + "".join(
            cell(f"{_xlsx_col(i)}{n}", r[h]) for i, h in enumerate(headers)) + "</row>")
    sheet = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
             '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
             "<sheetData>" + "".join(xml_rows) + "</sheetData></worksheet>")
    content_types = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                     '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
                     '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
                     '<Default Extension="xml" ContentType="application/xml"/>'
                     '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
                     '<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>'
                     "</Types>")
    root_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                 '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
                 '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>'
                 "</Relationships>")
    workbook = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
                '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" '
                'xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
                f'<sheets><sheet name="{escape(sheet_name)[:31]}" sheetId="1" r:id="rId1"/></sheets></workbook>')
    wb_rels = ('<?xml version="1.0" encoding="UTF-8" standalone="yes"?>'
               '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
               '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>'
               "</Relationships>")
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("[Content_Types].xml", content_types)
        z.writestr("_rels/.rels", root_rels)
        z.writestr("xl/workbook.xml", workbook)
        z.writestr("xl/_rels/workbook.xml.rels", wb_rels)
        z.writestr("xl/worksheets/sheet1.xml", sheet)
    return buf.getvalue()


@route("GET", r"/api/export/(clients|visits|invoices|chemicals|payments|expenses|reports)\.(csv|xlsx)")
def export_csv(ctx):
    entity = ctx.params[0]
    u = ctx.user
    # Clients may only export their own visits & invoices; staff need the perm.
    # Reports are staff-only, matching the sidebar page they come from.
    if u["role"] == "client":
        if entity not in ("visits", "invoices"):
            raise ApiError(403, "You do not have permission for this action")
    else:
        require_perm(u, {"expenses": "finance.view",
                         "reports": "visits.view"}.get(entity, entity + ".view"))
    queries = {
        "clients": "SELECT id,name_en,name_ar,contact_person,phone,email,city,status,created_at FROM clients",
        "visits": "SELECT v.id,c.name_en client,v.scheduled_start,v.status,u.full_name engineer "
                  "FROM visits v JOIN clients c ON c.id=v.client_id LEFT JOIN users u ON u.id=v.agent_id",
        "invoices": "SELECT i.number,c.name_en client,i.doc_type,i.issue_date,i.due_date,i.total,i.status "
                    "FROM invoices i JOIN clients c ON c.id=i.client_id",
        "chemicals": "SELECT name_en,name_ar,active_ingredient,unit,quantity_in_stock,reorder_level,reg_no FROM chemicals",
        "payments": "SELECT p.id,i.number invoice,p.amount,p.method,p.paid_at FROM payments p "
                    "JOIN invoices i ON i.id=p.invoice_id",
        "expenses": "SELECT e.spent_on,e.category,e.description,e.amount,e.vendor,e.method,"
                    "e.reference,u.full_name person,e.source FROM expenses e "
                    "LEFT JOIN users u ON u.id=e.user_id",
        # One row per report, with the written-up text in columns — a
        # spreadsheet of what was found, not the report documents themselves
        # (those come out of the Reports page as PDF).
        "reports": "SELECT v.scheduled_start date,c.name_en client,st.name branch,"
                   'u.full_name engineer,r.severity,r.status,r.summary,r."condition",'
                   "r.recommendations,r.pests_found,r.findings,r.completed_at "
                   "FROM reports r JOIN visits v ON v.id=r.visit_id "
                   "JOIN clients c ON c.id=v.client_id "
                   "LEFT JOIN sites st ON st.id=v.site_id "
                   "LEFT JOIN users u ON u.id=v.agent_id",
    }
    # Row-scope the export to match what each role may see in the app:
    # clients -> only their own company; agents -> only their own visits.
    where, params = [], []
    pin = client_site_scope_id(u)       # portal login limited to one location
    if entity == "visits":
        if u["role"] == "client":
            where.append("v.client_id=?"); params.append(u["client_id"])
            if pin:
                where.append("(v.site_id IS NULL OR v.site_id=?)"); params.append(pin)
        elif u["role"] == "agent":
            where.append("v.agent_id=?"); params.append(u["id"])
        elif u["role"] in SUPERVISOR_ROLES:
            lc, lp = _sup_visit_clause(u)
            where.append(lc); params += lp
    elif entity in ("invoices", "payments") and u["role"] == "client":
        where.append("i.client_id=?"); params.append(u["client_id"])
        if pin:
            where.append("(i.site_id IS NULL OR i.site_id=?)"); params.append(pin)
    elif entity == "clients" and u["role"] == "client":
        where.append("id=?"); params.append(u["client_id"])
    elif entity == "expenses":
        # The ledger exports the period the finance page is showing.
        if ctx.query.get("from"):
            where.append("date(e.spent_on) >= date(?)"); params.append(ctx.query["from"][:10])
        if ctx.query.get("to"):
            where.append("date(e.spent_on) <= date(?)"); params.append(ctx.query["to"][:10])
    elif entity == "reports":
        # Exactly what the Reports page is showing: same scoping, same filters.
        where, params = _report_scope(ctx)
    sql = queries[entity]
    if where:
        sql += " WHERE " + " AND ".join(where)
    if entity == "reports":
        _sd = _sort_dir(ctx)
        sql += f" ORDER BY v.scheduled_start {_sd}"
    rows = db.query(sql, params)
    if ctx.params[1] == "xlsx":
        return {"_xlsx": rows, "_filename": entity + ".xlsx", "_sheet": entity}
    return {"_csv": rows, "_filename": entity + ".csv"}


# --------------------------------------------------------------------------
# PER-REPORT BUNDLE — a zip holding one file per report, rather than one file
# holding every report. The printable-page bundle is assembled in the browser
# instead (app.js), where the report layout already lives; only the data
# formats are built here, where build_xlsx already lives.
# --------------------------------------------------------------------------
REPORT_BUNDLE_MAX = 200


def _safe_filename(text, fallback="report"):
    """A filename that survives Windows, macOS and a zip listing. Keeps Arabic
    (the zip carries UTF-8 names) and drops only what a filesystem chokes on."""
    text = re.sub(r'[\\/:*?"<>|\x00-\x1f]', " ", str(text or "")).strip()
    text = re.sub(r"\s+", " ", text).replace(" ", "-")
    return text[:80] or fallback


def _report_bundle_rows(ctx):
    """The reports the caller may bundle: the page's scoping and filters, then
    an optional ?ids= narrowing to the ticked ones. The ids INTERSECT the scope
    — they never widen it, so asking for another agent's visit ids returns
    nothing rather than their reports."""
    where, params = _report_scope(ctx)
    ids = [i for i in re.split(r"[^0-9]+", ctx.query.get("ids", "")) if i]
    if ids:
        ids = ids[:REPORT_BUNDLE_MAX]
        where.append("v.id IN (%s)" % ",".join("?" * len(ids)))
        params.extend(int(i) for i in ids)
    sql = ("SELECT r.*, v.id visit_id, v.scheduled_start, v.location, v.completed_at visit_completed, "
           "c.name_en client_en, c.name_ar client_ar, st.name site_name, u.full_name agent_name, "
           "s.name_en service_en "
           "FROM reports r JOIN visits v ON v.id=r.visit_id "
           "JOIN clients c ON c.id=v.client_id "
           "LEFT JOIN sites st ON st.id=v.site_id "
           "LEFT JOIN users u ON u.id=v.agent_id "
           "LEFT JOIN service_types s ON s.id=v.service_type_id")
    if where:
        sql += " WHERE " + " AND ".join(where)
    sql += " ORDER BY v.scheduled_start DESC LIMIT %d" % REPORT_BUNDLE_MAX
    return db.query(sql, params)


def _report_sheet_rows(rep, usage):
    """One report as field/value lines — what a single-report spreadsheet is,
    as opposed to a row in a list of many."""
    def val(k):
        v = rep.get(k)
        return "" if v is None else v
    rows = [
        ("Date", val("scheduled_start")), ("Visit", val("visit_id")),
        ("Client", val("client_en")), ("Branch", val("site_name") or val("location")),
        ("Engineer", val("agent_name")), ("Service", val("service_en")),
        ("Severity", val("severity")), ("Status", val("status")),
        ("Completed at", val("completed_at") or val("visit_completed")),
        ("Summary", val("summary")), ("Condition", val("condition")),
        ("Recommendations", val("recommendations")),
        ("Pests found", val("pests_found")), ("Findings", val("findings")),
        ("Spare parts changed", val("spare_parts_changed")),
        ("Branch issue", val("branch_issue")),
    ]
    for cu in usage:
        detail = "%s %s" % (cu.get("quantity"), cu.get("unit") or "")
        if cu.get("area_treated"):
            detail += " — %s" % cu["area_treated"]
        # method/equipment are stored as keys; this sheet is English-only, so
        # the key reads as its own label once the underscores come out.
        how = " / ".join(x.replace("_", " ") for x in (cu.get("method"), cu.get("equipment")) if x)
        if how:
            detail += " (%s)" % how
        rows.append(("Chemical: " + (cu.get("name_en") or ""), detail.strip()))
    return [{"field": f, "value": v} for f, v in rows]


@route("GET", r"/api/export/reports-bundle\.(csv|xlsx)\.zip")
def export_reports_bundle(ctx):
    """A zip with one spreadsheet (or csv) per report."""
    if ctx.user["role"] == "client":
        raise ApiError(403, "You do not have permission for this action")
    require_perm(ctx.user, "visits.view")
    fmt = ctx.params[0]
    reports = _report_bundle_rows(ctx)
    if not reports:
        raise ApiError(404, "No reports match those filters")
    usage_by_visit = {}
    vids = [r["visit_id"] for r in reports]
    for cu in db.query(
            "SELECT cu.visit_id, cu.quantity, cu.area_treated, cu.method, cu.equipment, ch.name_en, ch.unit "
            "FROM chemical_usage cu JOIN chemicals ch ON ch.id=cu.chemical_id "
            "WHERE cu.visit_id IN (%s)" % ",".join("?" * len(vids)), vids):
        usage_by_visit.setdefault(cu["visit_id"], []).append(cu)

    import zipfile, io, csv as _csv
    buf = io.BytesIO()
    used = set()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for rep in reports:
            rows = _report_sheet_rows(rep, usage_by_visit.get(rep["visit_id"], []))
            base = "%s_%s_%05d" % (str(rep.get("scheduled_start") or "")[:10],
                                   _safe_filename(rep.get("client_en"), "client"),
                                   rep["visit_id"])
            name = "%s.%s" % (_safe_filename(base), fmt)
            while name in used:            # same client, same day, same visit id cannot repeat
                name = name[:-len(fmt) - 1] + "-1." + fmt
            used.add(name)
            if fmt == "xlsx":
                z.writestr(name, build_xlsx(rows, "report"))
            else:
                out = io.StringIO()
                w = _csv.DictWriter(out, fieldnames=["field", "value"])
                w.writeheader(); w.writerows(rows)
                # BOM per file: each one is opened by Excel on its own.
                z.writestr(name, ("﻿" + out.getvalue()).encode("utf-8"))
    return {"_bytes": buf.getvalue(), "_filename": "reports-%s.zip" % fmt,
            "_mime": "application/zip"}


# --------------------------------------------------------------------------
# PHOTOS / UPLOADS
# --------------------------------------------------------------------------
@route("GET", r"/api/photos")
def list_photos(ctx):
    et = ctx.query.get("entity_type")
    eid = ctx.query.get("entity_id")
    if not et or not eid:
        raise ApiError(400, "entity_type and entity_id required")
    try:
        eid = int(eid)
    except (TypeError, ValueError):
        raise ApiError(400, "entity_id must be numeric")
    # Enforce the same per-company / per-agent isolation as the parent record,
    # so users can't enumerate other tenants' photos by id.
    _assert_photo_access(ctx.user, et, eid)
    return db.query("SELECT * FROM photos WHERE entity_type=? AND entity_id=? ORDER BY uploaded_at DESC",
                    (et, eid))


@route("POST", r"/api/photos")
def upload_photo(ctx):
    fields, files = parse_multipart(ctx.raw_body, ctx.content_type)
    if not files:
        raise ApiError(400, "No file uploaded")
    et = fields.get("entity_type")
    eid = fields.get("entity_id")
    if et not in ("client", "report", "visit", "chemical", "expense", "cash") or not eid:
        raise ApiError(400, "Valid entity_type and entity_id required")
    require_perm(ctx.user, _PHOTO_ENTITY_PERM[et])
    _assert_entity_write_access(ctx.user, et, int(eid))
    f = files[0]
    ext = _validate_upload(f)
    fname = f"{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(f["data"])
    bp = 1 if str(fields.get("business_plan", "")).lower() in ("1", "true", "on", "yes") else 0
    pid = db.execute(
        "INSERT INTO photos(entity_type,entity_id,filename,original_name,caption,is_business_plan,uploaded_by) "
        "VALUES(?,?,?,?,?,?,?)",
        (et, int(eid), fname, f["filename"], fields.get("caption"), bp, ctx.user["id"]))
    return db.query("SELECT * FROM photos WHERE id=?", (pid,), one=True)


@route("PUT", r"/api/photos/(\d+)")
def update_photo(ctx):
    """RENAME ONE ATTACHMENT — the comment that prints under it on the report.

    Attachments used to carry whatever the phone or the laptop called the file
    ("IMG_20260906_113255.jpg"), and a batch uploaded together all took the one
    comment typed for the batch. Each picture now gets its own words, and they
    can be changed afterwards without deleting and uploading the photo again.

    Same permission and same scoping as uploading or deleting the attachment:
    whoever may put a picture on this record may say what it shows."""
    pid = int(ctx.params[0])
    row = db.query("SELECT * FROM photos WHERE id=?", (pid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    require_perm(ctx.user, _PHOTO_ENTITY_PERM.get(row["entity_type"], "clients.edit"))
    _assert_entity_write_access(ctx.user, row["entity_type"], row["entity_id"])
    cap = str(ctx.body.get("caption") or "").strip()
    db.execute("UPDATE photos SET caption=? WHERE id=?", (cap or None, pid))
    return db.query("SELECT * FROM photos WHERE id=?", (pid,), one=True)


@route("DELETE", r"/api/photos/(\d+)")
def delete_photo(ctx):
    pid = int(ctx.params[0])
    row = db.query("SELECT * FROM photos WHERE id=?", (pid,), one=True)
    if row:
        require_perm(ctx.user, _PHOTO_ENTITY_PERM.get(row["entity_type"], "clients.edit"))
        _assert_entity_write_access(ctx.user, row["entity_type"], row["entity_id"])
        try:
            os.remove(os.path.join(UPLOAD_DIR, row["filename"]))
        except OSError:
            pass
        db.execute("DELETE FROM photos WHERE id=?", (pid,))
    return {"ok": True}


# --------------------------------------------------------------------------
# IPM FILE LIBRARY — company-wide PDF documents
# --------------------------------------------------------------------------
# One shelf for the whole company (IPM manual, policies, licences). The office
# publishes; every client portal login reads the same list. A document can be
# marked internal (visible_to_clients=0) — then only ipm.edit holders see it,
# both in the list and when fetching the file itself.
def _ipm_row(fid):
    return db.query(
        "SELECT f.*, u.full_name uploaded_by_name FROM company_files f "
        "LEFT JOIN users u ON u.id=f.uploaded_by WHERE f.id=?", (fid,), one=True)


def _ipm_fields(fields, existing=None):
    """Shared parse of the title/description/visibility form fields."""
    title = (fields.get("title") or "").strip()
    if not title and existing:
        title = existing["title"]
    if not title:
        raise ApiError(400, "Title is required")
    desc = fields.get("description")
    vis = fields.get("visible_to_clients")
    if vis is None:
        visible = 1 if existing is None else existing["visible_to_clients"]
    else:
        visible = 1 if str(vis).lower() in ("1", "true", "on", "yes") else 0
    return title, desc, visible


@route("GET", r"/api/ipm-files")
def list_ipm_files(ctx):
    require_perm(ctx.user, "ipm.view")
    where = "" if has_perm(ctx.user, "ipm.edit") else " WHERE f.visible_to_clients=1"
    return db.query(
        "SELECT f.*, u.full_name uploaded_by_name FROM company_files f "
        "LEFT JOIN users u ON u.id=f.uploaded_by" + where +
        " ORDER BY f.title COLLATE NOCASE", ())


@route("POST", r"/api/ipm-files")
def create_ipm_file(ctx):
    require_perm(ctx.user, "ipm.create")
    fields, files = parse_multipart(ctx.raw_body, ctx.content_type)
    if not files:
        raise ApiError(400, "No file uploaded")
    f = files[0]
    ext = _validate_library_upload(f)
    title, desc, visible = _ipm_fields(
        fields, {"title": os.path.splitext(f["filename"])[0], "visible_to_clients": 1})
    fname = f"{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(f["data"])
    fid = db.execute(
        "INSERT INTO company_files(title,description,filename,original_name,size_bytes,"
        "visible_to_clients,uploaded_by) VALUES(?,?,?,?,?,?,?)",
        (title, desc, fname, f["filename"], len(f["data"]), visible, ctx.user["id"]))
    audit(ctx, "ipmfile.create", "company_file", fid, title)
    return _ipm_row(fid)


@route("PUT", r"/api/ipm-files/(\d+)")
def update_ipm_file(ctx):
    """Rename / re-describe / hide a document. Replacing the PDF itself goes
    through POST /api/ipm-files/<id>/file (a multipart body)."""
    require_perm(ctx.user, "ipm.edit")
    fid = int(ctx.params[0])
    row = db.query("SELECT * FROM company_files WHERE id=?", (fid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    b = ctx.body
    title, desc, visible = _ipm_fields(b, row)
    db.execute("UPDATE company_files SET title=?, description=?, visible_to_clients=?, "
               "updated_at=datetime('now','localtime') WHERE id=?",
               (title, row["description"] if "description" not in b else desc, visible, fid))
    audit(ctx, "ipmfile.update", "company_file", fid, title)
    return _ipm_row(fid)


@route("POST", r"/api/ipm-files/(\d+)/file")
def replace_ipm_file(ctx):
    """Swap in a new PDF for an existing entry (metadata fields optional), so a
    revised manual keeps its place in the list instead of appearing twice."""
    require_perm(ctx.user, "ipm.edit")
    fid = int(ctx.params[0])
    row = db.query("SELECT * FROM company_files WHERE id=?", (fid,), one=True)
    if not row:
        raise ApiError(404, "Not found")
    fields, files = parse_multipart(ctx.raw_body, ctx.content_type)
    if not files:
        raise ApiError(400, "No file uploaded")
    f = files[0]
    ext = _validate_library_upload(f)
    title, desc, visible = _ipm_fields(fields, row)
    fname = f"{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(f["data"])
    db.execute("UPDATE company_files SET title=?, description=?, filename=?, original_name=?, "
               "size_bytes=?, visible_to_clients=?, updated_at=datetime('now','localtime') WHERE id=?",
               (title, row["description"] if "description" not in fields else desc,
                fname, f["filename"], len(f["data"]), visible, fid))
    try:                                     # drop the superseded copy from disk
        os.remove(os.path.join(UPLOAD_DIR, row["filename"]))
    except OSError:
        pass
    audit(ctx, "ipmfile.replace", "company_file", fid, title)
    return _ipm_row(fid)


@route("DELETE", r"/api/ipm-files/(\d+)")
def delete_ipm_file(ctx):
    require_perm(ctx.user, "ipm.delete")
    fid = int(ctx.params[0])
    row = db.query("SELECT * FROM company_files WHERE id=?", (fid,), one=True)
    if row:
        try:
            os.remove(os.path.join(UPLOAD_DIR, row["filename"]))
        except OSError:
            pass
        db.execute("DELETE FROM company_files WHERE id=?", (fid,))
        audit(ctx, "ipmfile.delete", "company_file", fid, row["title"])
    return {"ok": True}


# --------------------------------------------------------------------------
# SITE MAPS + DEVICE MARKERS (traps, bait stations, monitors …)
# --------------------------------------------------------------------------
@route("GET", r"/api/maps")
def list_all_maps(ctx):
    """Every map the user may see (staff: all; client: own), with client/site
    names and device counts. Powers the central Devices / QR-labels page."""
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "maps.view")
    where, params = "", []
    cid = client_scope_id(ctx.user)
    if cid is not None:
        sc, sp = _client_site_clause(ctx.user, "m.site_id")
        where, params = " WHERE m.client_id=?" + sc, [cid, *sp]
    return db.query(
        "SELECT m.*, c.name_en client_en, c.name_ar client_ar, s.name site_name, "
        "(SELECT COUNT(*) FROM map_markers k WHERE k.map_id=m.id) marker_count "
        "FROM maps m JOIN clients c ON c.id=m.client_id "
        "LEFT JOIN sites s ON s.id=m.site_id" + where +
        " ORDER BY c.name_en, m.created_at DESC", params)


@route("GET", r"/api/clients/(\d+)/maps")
def list_maps(ctx):
    cid = int(ctx.params[0])
    _assert_client_access(ctx.user, cid)
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "maps.view")
    msc, msp = _client_site_clause(ctx.user, "m.site_id")
    return db.query(
        "SELECT m.*, s.name site_name, "
        "(SELECT COUNT(*) FROM map_markers k WHERE k.map_id=m.id) marker_count "
        "FROM maps m LEFT JOIN sites s ON s.id=m.site_id WHERE m.client_id=?" + msc +
        " ORDER BY m.created_at DESC", (cid, *msp))


@route("GET", r"/api/maps/(\d+)")
def get_map(ctx):
    mid = int(ctx.params[0])
    m = db.query("SELECT m.*, c.name_en client_en, c.name_ar client_ar, s.name site_name "
                 "FROM maps m JOIN clients c ON c.id=m.client_id "
                 "LEFT JOIN sites s ON s.id=m.site_id WHERE m.id=?", (mid,), one=True)
    if not m:
        raise ApiError(404, "Map not found")
    _assert_client_access(ctx.user, m["client_id"])
    pin = client_site_scope_id(ctx.user)
    if pin and m["site_id"] and m["site_id"] != pin:
        raise ApiError(403, "No permission")
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "maps.view")
    m["markers"] = db.query("SELECT * FROM map_markers WHERE map_id=? ORDER BY id", (mid,))
    return m


@route("POST", r"/api/maps")
def upload_map(ctx):
    require_perm(ctx.user, "maps.create")
    fields, files = parse_multipart(ctx.raw_body, ctx.content_type)
    if not files:
        raise ApiError(400, "No map image uploaded")
    cid = fields.get("client_id")
    if not cid:
        raise ApiError(400, "client_id required")
    f = files[0]
    ext = _validate_image_upload(f)
    fname = f"map_{uuid.uuid4().hex}{ext}"
    with open(os.path.join(UPLOAD_DIR, fname), "wb") as out:
        out.write(f["data"])
    mid = db.execute(
        "INSERT INTO maps(client_id,site_id,name,filename,uploaded_by) VALUES(?,?,?,?,?)",
        (int(cid), fields.get("site_id") or None, fields.get("name") or "Site map",
         fname, ctx.user["id"]))
    return db.query("SELECT * FROM maps WHERE id=?", (mid,), one=True)


@route("DELETE", r"/api/maps/(\d+)")
def delete_map(ctx):
    require_perm(ctx.user, "maps.delete")
    mid = int(ctx.params[0])
    row = db.query("SELECT * FROM maps WHERE id=?", (mid,), one=True)
    if row:
        try:
            os.remove(os.path.join(UPLOAD_DIR, row["filename"]))
        except OSError:
            pass
        db.execute("DELETE FROM maps WHERE id=?", (mid,))
    return {"ok": True}


def _log_marker_event(marker_id, map_id, status, note, user_id,
                      source="manual", lat=None, lng=None):
    """Append a monitoring record for a device (feeds pest-trend analytics).
    source='scan' marks a record made via the QR tap-to-inspect flow; lat/lng
    geo-stamp where the technician was standing when they scanned."""
    client_id = db.query("SELECT client_id FROM maps WHERE id=?", (map_id,), one=True)
    mk = db.query("SELECT type FROM map_markers WHERE id=?", (marker_id,), one=True)
    db.execute(
        "INSERT INTO marker_events(marker_id,map_id,client_id,type,status,note,"
        "source,lat,lng,recorded_by) VALUES(?,?,?,?,?,?,?,?,?,?)",
        (marker_id, map_id, client_id["client_id"] if client_id else None,
         mk["type"] if mk else None, status, note, source, lat, lng, user_id))


@route("POST", r"/api/maps/(\d+)/markers")
def add_marker(ctx):
    require_perm(ctx.user, "maps.create")
    mid = int(ctx.params[0])
    if not db.query("SELECT id FROM maps WHERE id=?", (mid,), one=True):
        raise ApiError(404, "Map not found")
    b = ctx.body
    status = b.get("status", "ok")
    nid = db.execute(
        "INSERT INTO map_markers(map_id,type,label,x,y,status,notes,qr_token) "
        "VALUES(?,?,?,?,?,?,?,?)",
        (mid, b.get("type", "other"), b.get("label"), float(b.get("x", 0)),
         float(b.get("y", 0)), status, b.get("notes"), uuid.uuid4().hex))
    _log_marker_event(nid, mid, status, b.get("notes") or "Device installed", ctx.user["id"])
    return db.query("SELECT * FROM map_markers WHERE id=?", (nid,), one=True)


@route("PUT", r"/api/markers/(\d+)")
def update_marker(ctx):
    require_perm(ctx.user, "maps.edit")
    nid = int(ctx.params[0])
    b = ctx.body
    existing = db.query("SELECT * FROM map_markers WHERE id=?", (nid,), one=True)
    if not existing:
        raise ApiError(404, "Marker not found")
    cols = ("type", "label", "x", "y", "status", "notes")
    fields = [f"{c}=?" for c in cols if c in b]
    vals = [b[c] for c in cols if c in b]
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(nid)
    db.execute(f"UPDATE map_markers SET {','.join(fields)} WHERE id=?", vals)
    # Record an inspection event when status is (re)set — even if unchanged,
    # an agent re-confirming a device is a valid monitoring record.
    if "status" in b:
        _log_marker_event(nid, existing["map_id"], b["status"],
                          b.get("notes", existing.get("notes")), ctx.user["id"])
    return db.query("SELECT * FROM map_markers WHERE id=?", (nid,), one=True)


@route("DELETE", r"/api/markers/(\d+)")
def delete_marker(ctx):
    require_perm(ctx.user, "maps.delete")
    db.execute("DELETE FROM map_markers WHERE id=?", (int(ctx.params[0]),))
    return {"ok": True}


# --------------------------------------------------------------------------
# QR-CODED DEVICES — scan a station's label to inspect it in two seconds.
# A marker's qr_token is printed as a QR that deep-links to /scan/<token>.
# --------------------------------------------------------------------------
_SCAN_STATUSES = ("ok", "needs_service", "activity", "missing")


def _marker_by_token(token):
    """Resolve a QR token to its device + map/client/site context (or None)."""
    return db.query(
        "SELECT k.*, m.client_id, m.site_id, m.name map_name, m.filename map_filename, "
        "c.name_en client_en, c.name_ar client_ar, s.name site_name "
        "FROM map_markers k JOIN maps m ON m.id=k.map_id "
        "JOIN clients c ON c.id=m.client_id LEFT JOIN sites s ON s.id=m.site_id "
        "WHERE k.qr_token=?", (token,), one=True)


@route("GET", r"/api/scan/([0-9a-fA-F]{32})")
def scan_device(ctx):
    """Landing data for a scanned device: identity + recent inspection trail."""
    mk = _marker_by_token(ctx.params[0])
    if not mk:
        raise ApiError(404, "Unknown device code")
    _assert_client_access(ctx.user, mk["client_id"])
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "maps.view")
    mk["history"] = db.query(
        "SELECT e.status, e.note, e.source, e.lat, e.lng, e.recorded_at, u.full_name recorded_by_name "
        "FROM marker_events e LEFT JOIN users u ON u.id=e.recorded_by "
        "WHERE e.marker_id=? ORDER BY e.recorded_at DESC, e.id DESC LIMIT 20", (mk["id"],))
    return mk


@route("POST", r"/api/scan/([0-9a-fA-F]{32})")
def scan_inspect(ctx):
    """Tap-to-inspect: record one auto time- & geo-stamped inspection event and
    set the device's current status. The fast path a technician uses on site."""
    mk = _marker_by_token(ctx.params[0])
    if not mk:
        raise ApiError(404, "Unknown device code")
    _assert_client_access(ctx.user, mk["client_id"])
    require_perm(ctx.user, "maps.edit")
    b = ctx.body
    status = b.get("status", "ok")
    if status not in _SCAN_STATUSES:
        raise ApiError(400, "Invalid status")

    def _coord(v):
        try:
            f = float(v)
            return f if math.isfinite(f) else None
        except (TypeError, ValueError):
            return None
    lat, lng = _coord(b.get("lat")), _coord(b.get("lng"))
    with db.transaction() as cx:
        cx.execute("UPDATE map_markers SET status=? WHERE id=?", (status, mk["id"]))
        cx.execute(
            "INSERT INTO marker_events(marker_id,map_id,client_id,type,status,note,"
            "source,lat,lng,recorded_by) VALUES(?,?,?,?,?,?,'scan',?,?,?)",
            (mk["id"], mk["map_id"], mk["client_id"], mk["type"], status,
             (b.get("note") or "").strip() or None, lat, lng, ctx.user["id"]))
    audit(ctx, "device.inspect", "marker", mk["id"], f"{mk.get('label') or mk['type']} -> {status}")
    return {"ok": True, "status": status, "marker_id": mk["id"]}


# --------------------------------------------------------------------------
# QR-CODED DEVICES — standalone codes (LIT0001…) printed onto traps. Admin
# generates a batch per type + assigns to a client; agents scan on a visit to
# file each device's report (proof-of-presence). Independent of site maps.
# --------------------------------------------------------------------------
DEVICE_TYPES = {                       # device type -> printed code prefix
    "light_trap":   "LIT",
    "glue_station": "GLU",
    "bait_station": "BAI",
    "fly_trap":     "FLY",
}
_DEV_STATUSES = ("ok", "activity", "needs_service", "missing")

# The per-type follow-up fields captured on a scan (mirrors the printed follow-up
# form). Values are validated only for shape here — the client renders the inputs
# from an equivalent DEVICE_FIELDS map. Keys not listed for a type are dropped.
# Numeric fields are coerced with _finite; everything else is stored as a string.
DEVICE_FIELD_KEYS = {
    "bait_station": {"bait_status", "bait_action", "consumption_pct", "station_condition",
                     "station_action", "cleaned", "cleaned_action"},
    "fly_trap":     {"washed", "water_refilled", "trap_condition", "trap_action", "fly_density"},
    "glue_station": {"glue_status", "glue_action", "insect_count", "pests_found",
                     "station_condition", "station_action", "cleaned"},
    # trap_action / electricity_action are the follow-up the engineer took when
    # the trap came back damaged/missing or the power was off — the client only
    # sends them alongside the fault they answer.
    "light_trap":   {"trap_condition", "trap_action", "electricity", "electricity_action",
                     "lamp_status", "lamp_action", "trans_light_status", "trans_light_action",
                     "sheet_status", "sheet_action", "fly_count", "pests_found"},
}
_DEVICE_NUM_FIELDS = {"consumption_pct", "fly_density", "fly_count", "insect_count"}
# Tick-list answers: a comma-joined list of option keys, so they need more room
# than a single choice (all twelve light-trap pests run past 80 characters).
_DEVICE_MULTI_FIELDS = {"pests_found"}


def _clean_device_details(dtype, raw):
    """Keep only the whitelisted follow-up fields for this device type, coercing
    numeric fields. Returns a JSON string, or None when nothing usable is given."""
    if not isinstance(raw, dict):
        return None
    allowed = DEVICE_FIELD_KEYS.get(dtype, set())
    out = {}
    for k in allowed:
        if k not in raw:
            continue
        v = raw[k]
        if v is None or v == "":
            continue
        if k in _DEVICE_NUM_FIELDS:
            n = _finite(v)
            if n is not None:
                out[k] = n
        elif k in _DEVICE_MULTI_FIELDS:
            picks = v if isinstance(v, list) else str(v).split(",")
            picks = [str(p).strip()[:40] for p in picks if str(p).strip()]
            if picks:
                out[k] = ",".join(picks[:40])
        else:
            out[k] = str(v)[:80]
    return json.dumps(out) if out else None


def _finite(v):
    try:
        f = float(v)
        return f if math.isfinite(f) else None
    except (TypeError, ValueError):
        return None


def _device_by_code(code):
    return db.query(
        "SELECT d.*, c.name_en client_en, c.name_ar client_ar, s.name site_name "
        "FROM devices d LEFT JOIN clients c ON c.id=d.client_id "
        "LEFT JOIN sites s ON s.id=d.site_id WHERE d.code=?", (code.upper(),), one=True)


def _agent_active_visit(user, client_id):
    """The visit a scan attaches to: an in-progress visit at this client,
    preferring one owned by the scanning agent. None if there isn't one."""
    if not client_id:
        return None
    rows = db.query("SELECT id, agent_id FROM visits WHERE client_id=? AND "
                    "status='in_progress' ORDER BY scheduled_start DESC", (client_id,))
    if not rows:
        return None
    own = next((r for r in rows if r["agent_id"] == user["id"]), None)
    return (own or rows[0])["id"]


@route("GET", r"/api/devices")
def list_devices(ctx):
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "devices.view")
    where, params = [], []
    cid = client_scope_id(ctx.user)
    if cid is not None:
        where.append("d.client_id=?"); params.append(cid)
        pin = client_site_scope_id(ctx.user)
        if pin:
            where.append("(d.site_id IS NULL OR d.site_id=?)"); params.append(pin)
    # An area manager sees the traps standing in their patch — the device's
    # branch area, falling back to its client's, exactly as a visit's area is
    # derived. Unassigned stock belongs to the office, not to a patch. (A team
    # leader holds no devices.view at all: the registry follows the places.)
    if ctx.user["role"] == "area_manager":
        areas = area_manager_area_ids(ctx.user)
        if areas:
            marks = ",".join("?" for _ in areas)
            where.append("COALESCE((SELECT area_id FROM sites WHERE id=d.site_id),"
                         f"(SELECT area_id FROM clients WHERE id=d.client_id)) IN ({marks})")
            params += areas
        else:
            where.append("1=0")
    q = ctx.query
    if q.get("client_id"):
        where.append("d.client_id=?"); params.append(int(q["client_id"]))
    if q.get("type") in DEVICE_TYPES:
        where.append("d.type=?"); params.append(q["type"])
    # Narrow to one branch. "none" is the stock that belongs to a client but is
    # not standing at any of their branches yet.
    if q.get("site_id") == "none":
        where.append("d.site_id IS NULL")
    elif q.get("site_id"):
        where.append("d.site_id=?"); params.append(int(q["site_id"]))
    if q.get("unassigned") == "1":
        where.append("d.client_id IS NULL")
    clause = (" WHERE " + " AND ".join(where)) if where else ""
    return db.query(
        "SELECT d.*, c.name_en client_en, c.name_ar client_ar, s.name site_name, "
        "(SELECT MAX(recorded_at) FROM device_inspections di WHERE di.device_id=d.id) last_seen "
        "FROM devices d LEFT JOIN clients c ON c.id=d.client_id "
        "LEFT JOIN sites s ON s.id=d.site_id" + clause + " ORDER BY d.type, d.code", params)


@route("POST", r"/api/devices/generate")
def generate_devices(ctx):
    """Mint the next N sequential codes for a device type (LIT0001, LIT0002…).
    Numbers continue from the highest existing code and are never reused."""
    require_perm(ctx.user, "devices.create")
    b = ctx.body
    dtype = b.get("type")
    if dtype not in DEVICE_TYPES:
        raise ApiError(400, "Invalid device type")
    try:
        count = int(b.get("count", 0))
    except (TypeError, ValueError):
        count = 0
    if count < 1 or count > 500:
        raise ApiError(400, "Count must be between 1 and 500")
    prefix = DEVICE_TYPES[dtype]
    cid = b.get("client_id") or None
    sid = b.get("site_id") or None
    placement = (b.get("placement") or "").strip() or None
    if cid is not None:
        cid = int(cid); _assert_client_access(ctx.user, cid)
    created = []
    with db.transaction() as cx:
        row = cx.execute(
            "SELECT MAX(CAST(substr(code,?) AS INTEGER)) m FROM devices WHERE type=?",
            (len(prefix) + 1, dtype)).fetchone()
        start = (row["m"] or 0) + 1
        for i in range(start, start + count):
            code = f"{prefix}{i:04d}"
            cx.execute("INSERT INTO devices(code,type,client_id,site_id,placement) "
                       "VALUES(?,?,?,?,?)", (code, dtype, cid, sid, placement))
            created.append(code)
    audit(ctx, "device.generate", "device", None,
          f"{count}x {dtype} ({created[0]}..{created[-1]})")
    return {"ok": True, "type": dtype, "codes": created}


@route("POST", r"/api/devices/assign")
def assign_devices(ctx):
    require_perm(ctx.user, "devices.edit")
    b = ctx.body
    ids = b.get("ids") or []
    if not isinstance(ids, list) or not ids:
        raise ApiError(400, "No devices selected")
    if not b.get("client_id"):
        raise ApiError(400, "client_id required")
    cid = int(b["client_id"]); _assert_client_access(ctx.user, cid)
    sid = b.get("site_id") or None
    with db.transaction() as cx:
        for did in ids:
            cx.execute("UPDATE devices SET client_id=?, site_id=? WHERE id=?",
                       (cid, sid, int(did)))
    audit(ctx, "device.assign", "device", None, f"{len(ids)} -> client {cid}")
    return {"ok": True, "count": len(ids)}


@route("PUT", r"/api/devices/(\d+)")
def update_device(ctx):
    require_perm(ctx.user, "devices.edit")
    did = int(ctx.params[0])
    if not db.query("SELECT id FROM devices WHERE id=?", (did,), one=True):
        raise ApiError(404, "Device not found")
    b = ctx.body
    nullable = ("label", "placement", "client_id", "site_id")
    fields, vals = [], []
    for c in ("label", "placement", "status", "client_id", "site_id", "active"):
        if c in b:
            fields.append(f"{c}=?")
            vals.append((b[c] or None) if c in nullable else b[c])
    if not fields:
        raise ApiError(400, "Nothing to update")
    vals.append(did)
    db.execute(f"UPDATE devices SET {','.join(fields)} WHERE id=?", vals)
    return db.query("SELECT * FROM devices WHERE id=?", (did,), one=True)


@route("DELETE", r"/api/devices/(\d+)")
def delete_device(ctx):
    """A trap that has ever been scanned is never deleted.

    Its inspections cascade with it, and that history is the evidence the whole
    QR system exists to produce — what was found at that spot, month after
    month, and what was done about it. A trap that leaves the wall is RETIRED
    (active=0): it stops appearing in coverage and on the board, and every scan
    it ever carried stays exactly as it was filed."""
    require_perm(ctx.user, "devices.delete")
    did = int(ctx.params[0])
    dev = db.query("SELECT id, code, active FROM devices WHERE id=?", (did,), one=True)
    if not dev:
        raise ApiError(404, "Device not found")
    scans = db.query("SELECT COUNT(*) c FROM device_inspections WHERE device_id=?",
                     (did,), one=True)["c"]
    if scans:
        raise ApiError(409, f"{dev['code']} has {scans} scan(s) on record — retire it "
                             f"instead, so its history is kept")
    db.execute("DELETE FROM devices WHERE id=?", (did,))
    audit(ctx, "device.delete", "device", did, dev["code"])
    return {"ok": True}


@route("GET", r"/api/devices/(\d+)/history")
def device_history(ctx):
    """Everything ever recorded at one trap, oldest last. The scan screen shows
    the recent few; this is the whole file, for the visit that needs to know
    what happened here last spring."""
    did = int(ctx.params[0])
    d = db.query(
        "SELECT d.*, c.name_en client_en, c.name_ar client_ar, s.name site_name "
        "FROM devices d LEFT JOIN clients c ON c.id=d.client_id "
        "LEFT JOIN sites s ON s.id=d.site_id WHERE d.id=?", (did,), one=True)
    if not d:
        raise ApiError(404, "Device not found")
    if d["client_id"]:
        _assert_client_access(ctx.user, d["client_id"])
    pin = client_site_scope_id(ctx.user)
    if pin and d["site_id"] and d["site_id"] != pin:
        raise ApiError(403, "No permission")
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "maps.view")
    d["history"] = db.query(
        "SELECT di.id, di.status, di.findings, di.note, di.source, di.lat, di.lng, "
        "di.recorded_at, di.visit_id, di.details, u.full_name recorded_by_name "
        "FROM device_inspections di LEFT JOIN users u ON u.id=di.recorded_by "
        "WHERE di.device_id=? ORDER BY di.recorded_at DESC, di.id DESC", (did,))
    d["scans"] = len(d["history"])
    return d


@route("GET", r"/api/scan/([A-Za-z]{3}\d{4,})")
def scan_device_code(ctx):
    """Landing data when a printed device code is scanned: identity + recent
    inspections + which in-progress visit this scan would file against."""
    d = _device_by_code(ctx.params[0])
    if not d:
        raise ApiError(404, "Unknown device code")
    if d["client_id"]:
        _assert_client_access(ctx.user, d["client_id"])
    pin = client_site_scope_id(ctx.user)
    if pin and d["site_id"] and d["site_id"] != pin:
        raise ApiError(403, "No permission")
    if ctx.user["role"] != "client":
        require_perm(ctx.user, "maps.view")
    d["history"] = db.query(
        "SELECT di.status, di.findings, di.note, di.source, di.lat, di.lng, di.recorded_at, "
        "di.visit_id, di.details, u.full_name recorded_by_name FROM device_inspections di "
        "LEFT JOIN users u ON u.id=di.recorded_by WHERE di.device_id=? "
        "ORDER BY di.recorded_at DESC, di.id DESC LIMIT 20", (d["id"],))
    d["active_visit_id"] = (_agent_active_visit(ctx.user, d["client_id"])
                            if ctx.user["role"] != "client" else None)
    # What the last visit promised to do on this one. Only the newest scan is
    # consulted: a later scan either did the work or promised it again, so it
    # is always the current word on the device.
    d["promised"] = _promised_actions(d["history"][0] if d["history"] else None)
    return d


# The action fields an engineer can defer, and the field each one answers.
_DEFERRABLE = {
    "trap_action": "trap_condition", "lamp_action": "lamp_status",
    "trans_light_action": "trans_light_status", "sheet_action": "sheet_status",
    "station_action": "station_condition", "electricity_action": "electricity",
    "bait_action": "bait_status", "glue_action": "glue_status",
    "cleaned_action": "cleaned",
}


def _promised_actions(inspection):
    """Work the previous scan left for "next visit", as {field, action, fault}
    so the engineer standing at the device is told what was promised for it."""
    if not inspection:
        return []
    det = _json_obj(inspection.get("details"))
    out = []
    for field, parent in _DEFERRABLE.items():
        val = str(det.get(field) or "")
        if val.startswith("next_visit"):
            out.append({"field": field, "action": val, "fault": det.get(parent),
                        "at": inspection.get("recorded_at")})
    return out


@route("POST", r"/api/scan/([A-Za-z]{3}\d{4,})")
def inspect_device_code(ctx):
    """File one device's inspection for a visit (the scan-to-report action)."""
    d = _device_by_code(ctx.params[0])
    if not d:
        raise ApiError(404, "Unknown device code")
    if not d["client_id"]:
        raise ApiError(409, "Device not assigned to a client yet")
    _assert_client_access(ctx.user, d["client_id"])
    require_perm(ctx.user, "maps.edit")
    b = ctx.body
    status = b.get("status", "ok")
    if status not in _DEV_STATUSES:
        raise ApiError(400, "Invalid status")
    vid = b.get("visit_id") or _agent_active_visit(ctx.user, d["client_id"])
    if vid:
        v = db.query("SELECT client_id FROM visits WHERE id=?", (int(vid),), one=True)
        if not v or v["client_id"] != d["client_id"]:
            vid = None                      # ignore a visit that isn't this client's
    lat, lng = _finite(b.get("lat")), _finite(b.get("lng"))
    details = _clean_device_details(d["type"], b.get("details"))
    with db.transaction() as cx:
        cx.execute("UPDATE devices SET status=? WHERE id=?", (status, d["id"]))
        cx.execute(
            "INSERT INTO device_inspections(device_id,visit_id,client_id,status,findings,"
            "note,source,lat,lng,recorded_by,details) VALUES(?,?,?,?,?,?,'scan',?,?,?,?)",
            (d["id"], int(vid) if vid else None, d["client_id"], status,
             (b.get("findings") or "").strip() or None,
             (b.get("note") or "").strip() or None, lat, lng, ctx.user["id"], details))
    audit(ctx, "device.inspect", "device", d["id"], f"{d['code']} -> {status}")
    return {"ok": True, "status": status, "code": d["code"],
            "visit_id": int(vid) if vid else None}


@route("GET", r"/api/visits/(\d+)/devices")
def visit_device_coverage(ctx):
    """Per-visit device coverage: how many of the client's devices were scanned
    on this visit, and which are still pending."""
    vid = int(ctx.params[0])
    v = db.query("SELECT * FROM visits WHERE id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    _assert_visit_access(ctx.user, v)
    conds, cparams = ["d.client_id=?", "d.active=1"], [v["client_id"]]
    if v["site_id"]:
        conds.append("(d.site_id=? OR d.site_id IS NULL)"); cparams.append(v["site_id"])
    devs = db.query(
        "SELECT d.id, d.code, d.type, d.label, d.placement, d.status, "
        "(SELECT MAX(recorded_at) FROM device_inspections di "
        " WHERE di.device_id=d.id AND di.visit_id=?) scanned_at "
        "FROM devices d WHERE " + " AND ".join(conds) + " ORDER BY d.type, d.code",
        [vid] + cparams)
    scanned = sum(1 for d in devs if d["scanned_at"])
    return {"total": len(devs), "scanned": scanned, "devices": devs}


@route("GET", r"/api/visits/(\d+)/followup")
def visit_followup(ctx):
    """Data for the printable follow-up report: visit/client header + each device
    scanned on this visit, grouped by type, with its latest inspection's fields."""
    vid = int(ctx.params[0])
    v = db.query(
        "SELECT v.id, v.scheduled_start, " + VISIT_NO_SQL + ", v.client_id, v.site_id, "
        "c.name_en client_en, c.name_ar client_ar, u.full_name agent_name, "
        "st.name site_name FROM visits v JOIN clients c ON c.id=v.client_id "
        "LEFT JOIN users u ON u.id=v.agent_id "
        "LEFT JOIN sites st ON st.id=v.site_id WHERE v.id=?", (vid,), one=True)
    if not v:
        raise ApiError(404, "Visit not found")
    require_perm(ctx.user, "visits.view")
    _assert_visit_access(ctx.user, v)
    _apply_visit_no(v)
    # Latest inspection per device recorded on THIS visit (proof-of-visit).
    rows = db.query(
        "SELECT d.code, d.type, d.label, di.status, di.findings, di.details, di.recorded_at "
        "FROM device_inspections di JOIN devices d ON d.id=di.device_id "
        "WHERE di.visit_id=? AND di.id=("
        "  SELECT MAX(di2.id) FROM device_inspections di2 "
        "  WHERE di2.device_id=di.device_id AND di2.visit_id=di.visit_id) "
        "ORDER BY d.type, d.code", (vid,))
    groups = {}
    for r in rows:
        try:
            r["details"] = json.loads(r["details"]) if r.get("details") else {}
        except (ValueError, TypeError):
            r["details"] = {}
        groups.setdefault(r["type"], []).append(r)
    return {"visit": v, "groups": groups}


# --------------------------------------------------------------------------
# GLOBAL SEARCH
# --------------------------------------------------------------------------
@route("GET", r"/api/search")
def search(ctx):
    q = ctx.query.get("q", "").strip()
    if not q:
        return {"clients": [], "visits": [], "chemicals": [], "invoices": []}
    like = f"%{q}%"
    u = ctx.user
    res = {"clients": [], "visits": [], "chemicals": [], "invoices": []}
    if u["role"] == "client":
        cid = u["client_id"]
        res["clients"] = db.query(
            "SELECT id,name_en,name_ar,city FROM clients WHERE id=? AND (name_en LIKE ? OR name_ar LIKE ?)",
            (cid, like, like))
        vsc, vsp = _client_site_clause(u, "v.site_id")
        isc, isp = _client_site_clause(u, "site_id")
        res["visits"] = db.query(
            "SELECT v.id,v.scheduled_start,v.status,c.name_en client_en FROM visits v "
            "JOIN clients c ON c.id=v.client_id WHERE v.client_id=?" + vsc + " AND "
            "(v.location LIKE ? OR v.notes LIKE ?)", (cid, *vsp, like, like))
        res["invoices"] = db.query(
            "SELECT id,number,total,status FROM invoices WHERE client_id=? AND number LIKE ?" + isc,
            (cid, like, *isp))
        return res
    # Search must not be the back door around a role's scoping: a team leader
    # finds their patch here and nothing else, exactly as their lists show.
    csql = ("SELECT id,name_en,name_ar,city FROM clients WHERE (name_en LIKE ? OR name_ar LIKE ? "
            "OR city LIKE ? OR contact_person LIKE ?)")
    cparams = [like, like, like, like]
    lcc, lcp = _sup_client_clause(u)
    if lcc:
        csql += f" AND {lcc}"
        cparams += lcp
    res["clients"] = db.query(csql + " LIMIT 20", cparams)
    vsql = ("SELECT v.id,v.scheduled_start,v.status,c.name_en client_en FROM visits v "
            "JOIN clients c ON c.id=v.client_id WHERE (v.location LIKE ? OR v.notes LIKE ? "
            "OR c.name_en LIKE ?)")
    vparams = [like, like, like]
    if u["role"] == "agent":
        vsql += " AND v.agent_id=?"
        vparams.append(u["id"])
    lvc, lvp = _sup_visit_clause(u)
    if lvc:
        vsql += f" AND {lvc}"
        vparams += lvp
    res["visits"] = db.query(vsql + " LIMIT 20", vparams)
    if has_perm(u, "chemicals.view"):
        res["chemicals"] = db.query(
            "SELECT id,name_en,name_ar,quantity_in_stock,unit FROM chemicals "
            "WHERE name_en LIKE ? OR name_ar LIKE ? OR active_ingredient LIKE ? LIMIT 20",
            (like, like, like))
    if has_perm(u, "invoices.view"):
        res["invoices"] = db.query(
            "SELECT i.id,i.number,i.total,i.status,c.name_en client_en FROM invoices i "
            "JOIN clients c ON c.id=i.client_id WHERE i.number LIKE ? OR c.name_en LIKE ? LIMIT 20",
            (like, like))
    return res


# --------------------------------------------------------------------------
# internal helpers
# --------------------------------------------------------------------------
def _assert_client_access(user, client_id):
    if user["role"] == "client" and user["client_id"] != client_id:
        raise ApiError(403, "No permission")
    if user["role"] in SUPERVISOR_ROLES and not _sup_covers_client(user, client_id):
        raise ApiError(403, "No permission")


def _assert_invoice_access(user, inv):
    """Client-side guard for one invoice/quote: own company, own location."""
    _assert_client_access(user, inv["client_id"])
    sid = client_site_scope_id(user)
    if sid and inv.get("site_id") and inv["site_id"] != sid:
        raise ApiError(403, "No permission")


def _assert_visit_access(user, visit):
    if user["role"] == "client" and visit["client_id"] != user["client_id"]:
        raise ApiError(403, "No permission")
    sid = client_site_scope_id(user)
    if sid and visit.get("site_id") and visit["site_id"] != sid:
        raise ApiError(403, "No permission")
    if user["role"] == "agent" and visit["agent_id"] != user["id"]:
        raise ApiError(403, "No permission")
    if user["role"] in SUPERVISOR_ROLES and not _sup_covers_visit(user, visit):
        raise ApiError(403, "No permission")


def _assert_sup_visit(user, visit):
    """Area guard for the visit endpoints that check the agent INLINE.

    Those guards read `role == "agent" and visit.agent_id != me`. A supervisor is
    not an agent, so they sail straight through — which without this would mean
    a supervisor could write a report, log a chemical or sign off a job in a patch
    that is not theirs. Additive on purpose: no other role's behaviour moves."""
    if user["role"] in SUPERVISOR_ROLES and not _sup_covers_visit(user, visit):
        raise ApiError(403, "No permission")


def _assert_entity_write_access(user, entity_type, entity_id):
    """Per-tenant write guard for photo upload/delete: an agent may only touch
    their own visits' (and reports') attachments; clients only their own."""
    if entity_type in ("visit", "report"):
        vid = entity_id
        if entity_type == "report":
            rep = db.query("SELECT visit_id FROM reports WHERE id=?", (entity_id,), one=True)
            if not rep:
                raise ApiError(404, "Not found")
            vid = rep["visit_id"]
        v = db.query("SELECT client_id, agent_id, site_id FROM visits WHERE id=?", (vid,), one=True)
        if not v:
            raise ApiError(404, "Not found")
        _assert_visit_access(user, v)
    elif entity_type == "client":
        _assert_client_access(user, entity_id)
    elif entity_type == "expense":
        # No tenant dimension — a company cost belongs to the company — but the
        # row has to exist, or a receipt could be filed against nothing.
        if not db.query("SELECT 1 FROM expenses WHERE id=?", (entity_id,), one=True):
            raise ApiError(404, "Not found")
    elif entity_type == "cash":
        row = db.query("SELECT agent_id FROM petty_cash WHERE id=?", (entity_id,), one=True)
        if not row:
            raise ApiError(404, "Not found")
        # An engineer photographs their own receipts and nobody else's.
        if not has_perm(user, "cash.approve") and row["agent_id"] != user["id"]:
            raise ApiError(403, "Not your claim")


def _assert_photo_access(user, entity_type, entity_id):
    """Authorize reading photos/attachments for an entity, enforcing per-company
    (client) and per-agent isolation the same way the parent records do."""
    if entity_type == "client":
        if user["role"] != "client":
            require_perm(user, "clients.view")
        _assert_client_access(user, entity_id)
    elif entity_type in ("visit", "report"):
        if entity_type == "report":
            rep = db.query("SELECT visit_id FROM reports WHERE id=?", (entity_id,), one=True)
            if not rep:
                raise ApiError(404, "Not found")
            entity_id = rep["visit_id"]
        v = db.query("SELECT client_id, agent_id, site_id FROM visits WHERE id=?", (entity_id,), one=True)
        if not v:
            raise ApiError(404, "Not found")
        if user["role"] != "client":
            require_perm(user, "visits.view")
        _assert_visit_access(user, v)
    elif entity_type == "chemical":
        # SDS / label sheets — product safety, not company data. Engineers hold
        # issues.view rather than chemicals.view and still need them; clients
        # have neither, so this 403s for them.
        if not has_perm(user, "chemicals.view"):
            require_perm(user, "issues.view")
    elif entity_type == "expense":
        # Receipts are as private as the ledger they belong to. Never a client's
        # business, and never an engineer's.
        require_perm(user, "finance.view")
        if not db.query("SELECT 1 FROM expenses WHERE id=?", (entity_id,), one=True):
            raise ApiError(404, "Not found")
    elif entity_type == "cash":
        require_perm(user, "cash.view")
        row = db.query("SELECT agent_id FROM petty_cash WHERE id=?", (entity_id,), one=True)
        if not row:
            raise ApiError(404, "Not found")
        if not has_perm(user, "cash.approve") and row["agent_id"] != user["id"]:
            raise ApiError(403, "Not your claim")
    else:
        raise ApiError(400, "Invalid entity_type")


def authorize_upload_file(user, filename):
    """Per-file read authorization for /uploads/<filename>. Closes the last
    cross-tenant leak: a logged-in user guessing another tenant's file UUID.
    Returns True if `user` may read this specific file.

    Shared, non-tenant assets (the company logo + chemical SDS/label docs) are
    readable by any authenticated user; everything else is scoped to the owning
    client/visit the same way the API enforces it. Admins/managers see all."""
    if user["role"] in ("admin", "manager"):
        return True
    if filename and filename == get_settings().get("logo"):
        return True  # branding, shown on client-facing certificates/docs
    # IPM library: company-wide documents, deliberately readable across tenants.
    # Published ones need ipm.view; internal ones stay with the office.
    doc = db.query("SELECT visible_to_clients FROM company_files WHERE filename=?",
                   (filename,), one=True)
    if doc:
        if not has_perm(user, "ipm.view"):
            return False
        return bool(doc["visible_to_clients"]) or has_perm(user, "ipm.edit")
    # attachments tracked in the photos table
    ph = db.query("SELECT entity_type, entity_id FROM photos WHERE filename=?", (filename,), one=True)
    if ph:
        if ph["entity_type"] == "chemical":
            return True  # product safety docs (SDS/labels) — shared catalog
        try:
            _assert_photo_access(user, ph["entity_type"], ph["entity_id"])
            return True
        except ApiError:
            return False
    # uploaded site-map picture -> scope to the owning client
    site = db.query("SELECT client_id FROM sites WHERE map_image=?", (filename,), one=True)
    if site:
        try:
            _assert_client_access(user, site["client_id"]); return True
        except ApiError:
            return False
    # captured e-signatures live on the report -> scope to the visit
    rep = db.query("SELECT visit_id FROM reports WHERE customer_signature=? OR "
                   "technician_signature=?", (filename, filename), one=True)
    if rep:
        v = db.query("SELECT client_id, agent_id, site_id FROM visits WHERE id=?", (rep["visit_id"],), one=True)
        if v:
            try:
                _assert_visit_access(user, v); return True
            except ApiError:
                return False
    # Unknown / orphaned file: deny for restricted roles (fail closed).
    return False


def _client_outstanding(cid, site_id=None):
    """What the client still owes; optionally for one location only."""
    ic, ip = ("", []) if not site_id else (" AND (site_id IS NULL OR site_id=?)", [site_id])
    pc, pp = ("", []) if not site_id else (" AND (i.site_id IS NULL OR i.site_id=?)", [site_id])
    total = db.query("SELECT COALESCE(SUM(total),0) v FROM invoices WHERE client_id=? "
                     "AND status IN('sent','overdue','paid')" + ic, (cid, *ip), one=True)["v"]
    paid = db.query("SELECT COALESCE(SUM(p.amount),0) v FROM payments p "
                    "JOIN invoices i ON i.id=p.invoice_id WHERE i.client_id=?" + pc,
                    (cid, *pp), one=True)["v"]
    return round(total - paid, 2)


def _requested_site_id(ctx, key="site_id"):
    """The location filter for a per-client report.

    A portal login pinned to one location can't widen it back out — its own
    site always wins over whatever ?site_id the caller asked for."""
    sid = client_site_scope_id(ctx.user)
    return str(sid) if sid else ctx.query.get(key)


def _site_filter(site_id, col):
    """Build an AND-clause + params for an optional location filter.

    site_id: None/"" -> all locations (no filter); "none"/"0" -> unassigned
    (col IS NULL); a numeric id -> that single location."""
    if site_id in (None, "", "all"):
        return "", []
    if str(site_id) in ("none", "0"):
        return f" AND {col} IS NULL", []
    try:
        return f" AND {col}=?", [int(site_id)]
    except (TypeError, ValueError):
        return "", []


def _active_contracts_for_site(cid, site_id):
    """Count a client's active contracts, scoped to the selected location.

    Contracts link to a location via contracts.site_id and/or per-site rows in
    contract_sites, so a contract counts for a location if either matches.
    'none'/'0' = contracts with no location at all; None/all = client total."""
    base = ("SELECT COUNT(DISTINCT ct.id) c FROM contracts ct "
            "WHERE ct.client_id=? AND ct.status='active'")
    if site_id in (None, "", "all"):
        return db.query(base, (cid,), one=True)["c"]
    if str(site_id) in ("none", "0"):
        return db.query(base + " AND ct.site_id IS NULL AND NOT EXISTS "
                        "(SELECT 1 FROM contract_sites cs WHERE cs.contract_id=ct.id)",
                        (cid,), one=True)["c"]
    try:
        sid = int(site_id)
    except (TypeError, ValueError):
        return db.query(base, (cid,), one=True)["c"]
    return db.query(base + " AND (ct.site_id=? OR EXISTS "
                    "(SELECT 1 FROM contract_sites cs WHERE cs.contract_id=ct.id AND cs.site_id=?))",
                    (cid, sid, sid), one=True)["c"]


def _finance_summary(cid, site_id=None):
    clause, params = _site_filter(site_id, "i.site_id")
    invoices = db.query(
        "SELECT i.*, COALESCE((SELECT SUM(amount) FROM payments p WHERE p.invoice_id=i.id),0) paid "
        "FROM invoices i WHERE i.client_id=?" + clause + " ORDER BY i.issue_date DESC",
        (cid, *params))
    total = sum(i["total"] for i in invoices)
    paid = sum(i["paid"] for i in invoices)
    return {
        "invoices": invoices,
        "total_invoiced": round(total, 2),
        "total_paid": round(paid, 2),
        "outstanding": round(total - paid, 2),
    }


def _next_invoice_number(doc_type="invoice"):
    # Monotonic counter persisted in settings so a number is NEVER reused — not
    # after deletions (COUNT/MAX both reuse the tail) nor concurrently (the +1
    # UPDATE is atomic under the write lock). Numbers look like INV-00042.
    prefix = "QUO" if doc_type == "quote" else "INV"
    key = f"seq_{doc_type}"
    with db.transaction() as cx:
        row = cx.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()
        if row is None:
            # Seed once from any existing numbers so we don't restart at 1.
            cur = 0
            for r in cx.execute("SELECT number FROM invoices WHERE doc_type=? AND number LIKE ?",
                                (doc_type, prefix + "-%")).fetchall():
                try:
                    cur = max(cur, int(str(r["number"]).rsplit("-", 1)[1]))
                except (ValueError, IndexError):
                    pass
            cx.execute("INSERT INTO settings(key,value) VALUES(?,?)", (key, str(cur)))
        cx.execute("UPDATE settings SET value = CAST(value AS INTEGER) + 1 WHERE key=?", (key,))
        nxt = int(cx.execute("SELECT value FROM settings WHERE key=?", (key,)).fetchone()["value"])
    return f"{prefix}-{nxt:05d}"


# --------------------------------------------------------------------------
# HTTP plumbing
# --------------------------------------------------------------------------
class Handler(BaseHTTPRequestHandler):
    server_version = "PestCRM/1.0"

    def log_message(self, fmt, *args):
        pass  # quiet

    # dispatch -------------------------------------------------------------
    def _handle(self, method):
        # Reset per-request state (handler instances are reused on keep-alive).
        self._auth_cookie_token = None
        parsed = urlparse(self.path)
        path = parsed.path
        # /api/public/* is called cross-origin by the marketing website.
        self._cors = path.startswith("/api/public/")
        if self._redirect_to_public(method, path, parsed.query):
            return
        # static + uploads
        if method == "GET" and not path.startswith("/api/"):
            return self._serve_static(path)

        length = int(self.headers.get("Content-Length", 0) or 0)
        # A restored backup can be hundreds of megabytes. It is the one body
        # that never goes through memory: straight to a scratch file, checked
        # there, and only then allowed anywhere near the live data.
        if method == "POST" and path == "/api/backup/restore":
            return self._restore_upload(length)
        # Reject oversized bodies before reading them into memory (multipart
        # overhead allowed on top of the per-file image cap).
        if length > MAX_UPLOAD_BYTES + 1024 * 1024:
            return self._json(413, {"error": "Request body too large"})
        raw_body = self.rfile.read(length) if length else b""
        content_type = self.headers.get("Content-Type", "")
        body = {}
        if raw_body and content_type.startswith("application/json"):
            try:
                body = json.loads(raw_body.decode())
            except Exception:
                return self._json(400, {"error": "Invalid JSON body"})

        query = {k: v[0] for k, v in parse_qs(parsed.query).items()}

        for m, regex, fn, auth_req in ROUTES:
            if m != method:
                continue
            match = regex.match(path)
            if not match:
                continue
            user = None
            if auth_req:
                user = self._current_user()
                if not user:
                    return self._json(401, {"error": "Authentication required"})
            client_ip = self.client_address[0] if self.client_address else None
            ctx = Ctx(user, list(match.groups()), query, body, raw_body, content_type, ip=client_ip)
            try:
                result = fn(ctx)
                # Fresh login issues a token -> seed the /uploads access cookie.
                if isinstance(result, dict) and result.get("token"):
                    self._auth_cookie_token = result["token"]
                if isinstance(result, dict) and "_file" in result:
                    return self._file(result["_file"], result.get("_filename", "download"),
                                      result.get("_mime", "application/octet-stream"),
                                      cleanup=result.get("_cleanup"))
                if isinstance(result, dict) and "_csv" in result:
                    return self._csv(result["_csv"], result.get("_filename", "export.csv"))
                if isinstance(result, dict) and "_xlsx" in result:
                    return self._xlsx(result["_xlsx"], result.get("_filename", "export.xlsx"),
                                      result.get("_sheet", "Export"))
                if isinstance(result, dict) and "_bytes" in result:
                    return self._binary(result["_bytes"], result.get("_filename", "download"),
                                        result.get("_mime", "application/octet-stream"))
                return self._json(200, result)
            except ApiError as e:
                return self._json(e.status, {"error": e.message})
            except Exception:
                # Log the full traceback server-side; return only a reference id
                # to the client so internals (SQL, paths) are never exposed.
                err_id = uuid.uuid4().hex[:8]
                print(f"[error {err_id}] {method} {path}", file=sys.stderr)
                traceback.print_exc()
                return self._json(500, {"error": "Internal server error", "error_id": err_id})
        return self._json(404, {"error": "Not found"})

    def do_GET(self):
        self._handle("GET")

    def do_POST(self):
        self._handle("POST")

    def do_PUT(self):
        self._handle("PUT")

    def do_DELETE(self):
        self._handle("DELETE")

    def do_OPTIONS(self):
        # CORS preflight — only the public endpoints are callable cross-origin.
        if self.path.split("?")[0].startswith("/api/public/"):
            self.send_response(204)
            self.send_header("Access-Control-Allow-Origin", "*")
            self.send_header("Access-Control-Allow-Methods", "POST, OPTIONS")
            self.send_header("Access-Control-Allow-Headers", "Content-Type")
            self.send_header("Access-Control-Max-Age", "86400")
            self.end_headers()
        else:
            self.send_response(404)
            self.end_headers()

    # helpers --------------------------------------------------------------
    def _user_from_token(self, token):
        """Validate a session token string -> active user row (or None)."""
        payload = auth.verify_token(token or "")
        if not payload:
            return None
        user = db.query("SELECT * FROM users WHERE id=? AND active=1", (payload["uid"],), one=True)
        if not user:
            return None
        # Reject tokens issued before the user's token_version was bumped.
        if (user["token_version"] or 0) != payload.get("tv", 0):
            return None
        return user

    def _current_user(self):
        hdr = self.headers.get("Authorization", "")
        if not hdr.startswith("Bearer "):
            return None
        user = self._user_from_token(hdr[7:])
        if user:
            # Refresh the /uploads access cookie so <img> tags (which can't send
            # the Bearer header) stay authorised for the life of the session.
            self._auth_cookie_token = hdr[7:]
        return user

    def _upload_user(self):
        """Resolve the session behind an /uploads request -> user row or None.
        Accepts a Bearer header (direct fetch) or the scoped pc_upl cookie that
        <img>/<a> tags send automatically."""
        hdr = self.headers.get("Authorization", "")
        if hdr.startswith("Bearer "):
            u = self._user_from_token(hdr[7:])
            if u:
                return u
        raw = self.headers.get("Cookie", "")
        if raw:
            try:
                jar = SimpleCookie()
                jar.load(raw)
                if "pc_upl" in jar:
                    return self._user_from_token(jar["pc_upl"].value)
            except Exception:
                pass
        return None

    def _json(self, status, payload):
        data = json.dumps(payload, default=str).encode()
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(data)))
        if getattr(self, "_cors", False):
            self.send_header("Access-Control-Allow-Origin", "*")
        self._send_upload_cookie()
        self.end_headers()
        self.wfile.write(data)

    def end_headers(self):
        # One hook for every response (JSON, CSV, static, redirects, errors):
        # tell the browser to stick to https once it has arrived over https.
        try:
            if _forwarded_https(self.headers):
                self.send_header("Strict-Transport-Security", "max-age=31536000")
        except Exception:
            pass   # a malformed request must still get its response
        BaseHTTPRequestHandler.end_headers(self)

    def _redirect_to_public(self, method, path, query):
        """Bounce plain-HTTP visitors on the bare IP to the canonical https host.

        The QR labels already printed and stuck on traps encode the old
        http://<ip>:8000/scan/<code> address, and older app installs and
        bookmarks point there too. Sending them on to the https host is what
        makes the camera, geolocation and the service worker available to them,
        without reprinting a single label.

        Loop-proof by construction: a request that arrives through the proxy
        carries the canonical Host, which is exactly the case we skip.
        """
        if not _public_url or method != "GET" or path.startswith("/api/"):
            return False
        host = (self.headers.get("Host") or "").strip().lower()
        if not host or host == _public_host:
            return False
        if host.rsplit(":", 1)[0].strip("[]") in _LOCAL_HOSTS:
            return False        # local dev, the test suite and monitor.py
        if _forwarded_https(self.headers):
            return False        # already secure behind some other proxy
        target = _public_url + path + (("?" + query) if query else "")
        self.send_response(301)
        self.send_header("Location", target)
        self.send_header("Content-Length", "0")
        self.end_headers()
        return True

    def _send_upload_cookie(self):
        # Scoped, HttpOnly, expiring access cookie for /uploads/. Sent on login
        # and refreshed on every authenticated API call.
        tok = getattr(self, "_auth_cookie_token", None)
        if tok:
            # Mark Secure when the visitor reached the TLS-terminating proxy
            # over https, so the cookie is never sent in the clear.
            secure = "; Secure" if _forwarded_https(self.headers) else ""
            self.send_header(
                "Set-Cookie",
                "pc_upl=%s; HttpOnly; SameSite=Lax; Path=/uploads; Max-Age=%d%s"
                % (tok, auth.TOKEN_TTL, secure),
            )

    def _restore_upload(self, length):
        """Take the uploaded archive to disk and hand it to the restore.

        Refuses early on the two things that would hurt: an archive bigger than
        MAX_RESTORE_BYTES, and one bigger than the free space it needs to
        unpack into — running the disk to zero WHILE replacing the database is
        the one failure with no way back."""
        user = self._current_user()
        if not user:
            return self._json(401, {"error": "Authentication required"})
        if length <= 0:
            return self._json(400, {"error": "No file was uploaded"})
        if length > MAX_RESTORE_BYTES:
            return self._json(413, {"error": "That backup is larger than this server accepts"})
        try:
            free = shutil.disk_usage(DATA_DIR).free
        except OSError:
            free = None
        if free is not None and free < length * 3:
            return self._json(507, {"error": "Not enough free space on the server to restore that"})
        tmpdir = tempfile.mkdtemp(prefix="pestcrm-upload-")
        target = os.path.join(tmpdir, "incoming.tar.gz")
        left = length
        try:
            with open(target, "wb") as f:
                while left > 0:
                    chunk = self.rfile.read(min(left, 1024 * 256))
                    if not chunk:
                        break
                    f.write(chunk)
                    left -= len(chunk)
            if left > 0:
                return self._json(400, {"error": "The upload did not finish"})
            result = do_backup_restore(user, target, self.headers.get("X-Confirm", ""))
            return self._json(200, result)
        except ApiError as e:
            return self._json(e.status, {"error": e.message})
        except Exception:
            traceback.print_exc()
            return self._json(500, {"error": "The restore failed — nothing was changed"})
        finally:
            shutil.rmtree(tmpdir, ignore_errors=True)

    def _file(self, path, filename, mime="application/octet-stream", cleanup=None):
        """Send a file from disk in chunks. A full backup is ~95 MB; reading
        that into memory to hand it over would put the whole archive in RAM on
        a box with 3.8 GB, once per office member who presses the button."""
        try:
            size = os.path.getsize(path)
        except OSError:
            return self._json(404, {"error": "Not found"})
        try:
            self.send_response(200)
            self.send_header("Content-Type", mime)
            self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
            self.send_header("Content-Length", str(size))
            self.send_header("Cache-Control", "no-store")
            self.end_headers()
            with open(path, "rb") as f:
                while True:
                    chunk = f.read(1024 * 256)
                    if not chunk:
                        break
                    self.wfile.write(chunk)
        finally:
            if cleanup:
                shutil.rmtree(cleanup, ignore_errors=True)

    def _csv(self, rows, filename):
        import csv, io
        buf = io.StringIO()
        if rows:
            w = csv.DictWriter(buf, fieldnames=list(rows[0].keys()))
            w.writeheader()
            w.writerows(rows)
        data = ("﻿" + buf.getvalue()).encode("utf-8")  # BOM for Excel/Arabic
        self.send_response(200)
        self.send_header("Content-Type", "text/csv; charset=utf-8")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _xlsx(self, rows, filename, sheet_name="Export"):
        data = build_xlsx(rows, sheet_name)
        self.send_response(200)
        self.send_header("Content-Type",
                         "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _binary(self, data, filename, mime="application/octet-stream"):
        """Any ready-made file (a zip of per-report exports, today) sent as a
        download rather than JSON."""
        self.send_response(200)
        self.send_header("Content-Type", mime)
        self.send_header("Content-Disposition", f'attachment; filename="{filename}"')
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def _serve_static(self, path):
        if path == "/" or path == "":
            path = "/index.html"
        if path.startswith("/uploads/"):
            # Uploaded files (photos, signatures, maps, logos, attachments) are
            # private and per-file authorized: a logged-in session AND permission
            # to read that specific file (random UUID filenames are not authz).
            user = self._upload_user()
            if not user:
                return self._json(403, {"error": "Forbidden"})
            rel = path[len("/uploads/"):]
            if not authorize_upload_file(user, os.path.basename(rel)):
                return self._json(403, {"error": "Forbidden"})
            base = UPLOAD_DIR
        else:
            base, rel = STATIC_DIR, path.lstrip("/")
        full = os.path.normpath(os.path.join(base, rel))
        if not full.startswith(base) or not os.path.isfile(full):
            # SPA fallback
            full = os.path.join(STATIC_DIR, "index.html")
        try:
            stat = os.stat(full)
        except OSError:
            return self._json(404, {"error": "Not found"})
        is_upload = path.startswith("/uploads/")
        # "private" on uploads is the load-bearing word: these files are
        # authorized per user and per file, and the CDN in front of us caches
        # by extension (.pdf/.png are on its static list). "public" invited it
        # to keep one customer's document at the edge and serve it to the next
        # request for that URL — including one with no session at all.
        # THE APP'S OWN CODE IS NEVER STORED BY THE PHONE (2026-09-06). This
        # used to say "no-cache", which is a promise to revalidate — but the CDN
        # in front of us rewrites Cache-Control on everything it caches, and it
        # was handing the app `max-age=14400`. The WebView then answered its own
        # "network first" request out of a FOUR-HOUR-OLD local cache without
        # asking anybody, so a fix could be live on the server and invisible in
        # the installed app for the rest of the day — which is exactly what he
        # reported. "no-store" is the one header the CDN does not overwrite,
        # because it refuses to cache the response at all. It costs one real
        # fetch of the code per app open, which the service worker's
        # network-first rule was already making anyway.
        code_ext = full.endswith((".html", ".css", ".webmanifest"))
        if not code_ext and full.endswith(".js"):
            # ...but not the two big libraries that never change: pdf.js is
            # megabytes, and re-downloading it on every open is a real cost to
            # someone on mobile data.
            code_ext = "/js/pdfjs/" not in path and path != "/js/jsqr.js"
        cache = ("private, max-age=86400" if is_upload
                 else "no-store" if code_ext else "no-cache")
        # Validator from file mtime+size: lets the browser revalidate and get a
        # tiny 304 instead of re-downloading unchanged assets. App code carries
        # one too — a CDN that revalidates still gets a cheap 304 — but nothing
        # is allowed to serve it from a store without asking.
        etag = 'W/"%x-%x"' % (int(stat.st_mtime), stat.st_size)
        if self.headers.get("If-None-Match") == etag:
            self.send_response(304)
            self.send_header("ETag", etag)
            self.send_header("Cache-Control", cache)
            self.end_headers()
            return
        try:
            with open(full, "rb") as f:
                data = f.read()
        except OSError:
            return self._json(404, {"error": "Not found"})
        ctype = mimetypes.guess_type(full)[0] or "application/octet-stream"
        # Compress text assets (JS/CSS/HTML/JSON/SVG) when the client accepts it.
        encoding = None
        if ("gzip" in self.headers.get("Accept-Encoding", "") and len(data) > 512
                and ctype.split(";")[0] in _COMPRESSIBLE):
            data = gzip.compress(data, 6)
            encoding = "gzip"
        self.send_response(200)
        self.send_header("Content-Type", ctype)
        if encoding:
            self.send_header("Content-Encoding", encoding)
            self.send_header("Vary", "Accept-Encoding")
        self.send_header("Content-Length", str(len(data)))
        self.send_header("ETag", etag)
        self.send_header("Cache-Control", cache)
        self.end_headers()
        self.wfile.write(data)


def main():
    db.init_db()
    # The uploads folder may be somewhere else entirely (PESTCRM_UPLOAD_DIR) and
    # may not exist yet — a fresh install, or a throwaway instance keeping its
    # photos to itself. Nothing that saves a photo should have to create it.
    os.makedirs(UPLOAD_DIR, exist_ok=True)
    # auto-seed on first run
    if db.query("SELECT COUNT(*) c FROM users", one=True)["c"] == 0:
        import seed
        seed.run()
    refresh_public_url()   # canonical https host, cached off the hot path
    # generate any due recurring visits + invoices + reminders at startup
    try:
        _generate_due_visits()
        _generate_due_invoices()
        _generate_due_costs()
        _generate_vat_returns()
        _generate_reminders()
    except Exception as e:
        print("startup generation:", e)
    port = int(sys.argv[1]) if len(sys.argv) > 1 else 8000
    srv = ThreadingHTTPServer(("0.0.0.0", port), Handler)
    print(f"Pest Control CRM running on http://localhost:{port}")
    print("Default login: admin@pestcrm.com / admin123")
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")


if __name__ == "__main__":
    main()
